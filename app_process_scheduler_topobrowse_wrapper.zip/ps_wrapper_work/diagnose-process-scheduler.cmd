@echo off
setlocal
cd /d "%~dp0"
python -m scripts.diagnose_process_scheduler %*
exit /b %errorlevel%
