@echo off
setlocal
cd /d "%~dp0"
python -m scripts.diagnose_autosys %*
exit /b %errorlevel%
