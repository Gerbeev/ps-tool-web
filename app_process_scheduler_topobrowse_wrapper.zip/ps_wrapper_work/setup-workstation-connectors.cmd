@echo off
setlocal
cd /d "%~dp0"

set "TARGET_DIR=%~1"
if not defined TARGET_DIR set "TARGET_DIR=workstation_connectors"

if not exist "%TARGET_DIR%" mkdir "%TARGET_DIR%"

call :copy_ready "workstation_connectors\bridge_v1_runtime.py" "bridge_v1_runtime.py"
call :copy_ready "workstation_connectors\autosys_connector.py" "autosys_connector.py"
call :copy_ready "workstation_connectors\autosys_connector.json" "autosys_connector.json"
call :copy_ready "workstation_connectors\process_scheduler_connector.py" "process_scheduler_connector.py"
call :copy_ready "workstation_connectors\process_scheduler_connector.json" "process_scheduler_connector.json"

if errorlevel 1 exit /b 1

echo.
echo Workstation connector files are ready under:
echo   %TARGET_DIR%
echo.
echo Both Python connectors are shipped components and should not be edited on the workstation.
echo Keep bridge_v1_runtime.py unchanged.
echo Copy the existing TopoBrowse.Bridge directory under:
echo   %TARGET_DIR%\TopoBrowse.Bridge
echo or configure PROCESS_SCHEDULER_BRIDGE_DIR.
echo.
echo If this directory is outside the project, set in .env:
echo   PS_TOOL_CONNECTOR_DIR=%TARGET_DIR%
echo.
echo Validate with:
echo   diagnose-autosys.cmd --environment autosys-u1
echo   diagnose-process-scheduler.cmd --environment ps-u5
echo.
exit /b 0

:copy_ready
if /I "%TARGET_DIR%"=="workstation_connectors" (
  echo KEEP  %TARGET_DIR%\%~2
  exit /b 0
)
copy /Y "%~1" "%TARGET_DIR%\%~2" >nul
if errorlevel 1 exit /b 1
echo COPY  %TARGET_DIR%\%~2
exit /b 0
