from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

import workstation_connectors.process_scheduler_connector as connector


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.delenv("PROCESS_SCHEDULER_CONNECTOR_CONFIG", raising=False)
    monkeypatch.delenv("PROCESS_SCHEDULER_BRIDGE_DIR", raising=False)


def _write_fake_bridge(path: Path, *, partial: bool = False, details: bool = True) -> None:
    payload = f'''from __future__ import annotations
import json, sys
cmd = sys.argv[1] if len(sys.argv) > 1 else ""
if cmd == "list-topologies":
    print(json.dumps({{"topologies": ["Topology_A", "Topology_B"]}}))
elif cmd == "fetch-topology":
    jobs = [
      {{"Name":"ROOT_BOX","Kind":"BOX","Status":"Running","LastStartTime":"2026-10-02T11:32:37+02:00","LastFinishTime":None,"Machine":None{',"JobType":"Box","Schedule":"Tuesday,Wednesday","StartAtTime":"00:01","Context":"Topology_A","Box":"Topology_A"' if details else ''}}},
      {{"Name":"JOB_A","Kind":"JOB","Status":"Success","LastStartTime":"2026-10-02T11:33:00+02:00","LastFinishTime":"2026-10-02T11:34:00+02:00","Machine":"host-a"{',"JobType":"Command","Schedule":"Tuesday,Wednesday","StartAtTime":"00:02","Owner":"owner-a","ParentName":"ROOT_BOX","ConditionExpression":"success(ROOT_BOX)"' if details else ''}}}
    ]
    out = {{"name":"Topology_A","snapshot_time":"2026-10-04T13:44:14+00:00","job_count":{3 if partial else 2},"jobs":jobs,"dependencies":[{{"from":"ROOT_BOX","to":"JOB_A","kind":"finish_to_start","condition":"success(ROOT_BOX)"}}]}}
    print(json.dumps(out))
elif cmd == "job-detail":
    print(json.dumps({{"job": {{"Name":"JOB_A","Status":"Success","JobType":"Command"}}}}))
else:
    print(json.dumps({{"ok": True}}))
'''
    path.write_text(payload, encoding="utf-8")


def _write_config(path: Path, bridge: Path) -> None:
    path.write_text(
        json.dumps(
            {
                "launcher": [sys.executable, str(bridge)],
                "protocol_mode": "args",
                "allow_text_output": True,
                "timeout_sec": 10,
                "max_response_mb": 4,
                "commands": {
                    "list_roots": ["list-topologies", "--environment", "{environment}", "--host", "{host}", "--json"],
                    "fetch_topology": ["fetch-topology", "--environment", "{environment}", "--host", "{host}", "--topology", "{topology}", "--json"],
                    "fetch_job_detail": ["job-detail", "--environment", "{environment}", "--host", "{host}", "--topology", "{topology}", "--job", "{job}", "--json"],
                },
            }
        ),
        encoding="utf-8",
    )


def _context() -> dict[str, object]:
    return {
        "environment_id": "ps-u5",
        "environment": "U5",
        "scheduler": "process_scheduler",
        "host": "ps.internal:9001",
        "as_of_kind": "latest",
        "as_of_value": "",
        "root_box": "Topology_A",
        "topology_id": "Topology_A",
    }


def test_wrapper_lists_topologies_and_normalizes_topology(monkeypatch: pytest.MonkeyPatch, tmp_path: Path):
    fake = tmp_path / "fake_bridge.py"
    config = tmp_path / "connector.json"
    _write_fake_bridge(fake)
    _write_config(config, fake)
    monkeypatch.setenv("PROCESS_SCHEDULER_CONNECTOR_CONFIG", str(config))

    provider = connector.ProcessSchedulerProvider()
    assert provider.list_roots(_context()) == {"roots": ["Topology_A", "Topology_B"]}

    result = provider.fetch_topology(_context())
    assert len(result["jobs"]) == 2
    root, child = result["jobs"]
    assert root["scheduler_job_name"] == "ROOT_BOX"
    assert root["status"] == "running"
    assert child["status"] == "success"
    assert child["autosys_jil"]["machine"] == "host-a"
    assert child["autosys_jil"]["job_type"] == "CMD"
    assert child["autosys_jil"]["days_of_week"] == "Tuesday,Wednesday"
    assert child["parent_uid"] == root["job_uid"]
    assert child["process_scheduler"]["ConditionExpression"] == "success(ROOT_BOX)"
    assert result["dependencies"][0]["from_uid"] == root["job_uid"]
    assert result["dependencies"][0]["to_uid"] == child["job_uid"]
    assert result["metadata"]["source"] == "TopoBrowse.Bridge"
    assert result["metadata"]["explicit_dependency_count"] == 1

    caps = provider.capabilities()
    assert caps["strict_parameter_support"] is True
    assert caps["dependencies"] is True
    assert caps["parameter_support"]["dependencies"] == "supported"
    assert caps["parameter_support"]["command"] == "unknown"


def test_wrapper_rejects_partial_topology(monkeypatch: pytest.MonkeyPatch, tmp_path: Path):
    fake = tmp_path / "fake_bridge.py"
    config = tmp_path / "connector.json"
    _write_fake_bridge(fake, partial=True)
    _write_config(config, fake)
    monkeypatch.setenv("PROCESS_SCHEDULER_CONNECTOR_CONFIG", str(config))

    provider = connector.ProcessSchedulerProvider()
    with pytest.raises(connector.ConnectorError) as exc:
        provider.fetch_topology(_context())
    assert exc.value.code == "partial_topology"


def test_wrapper_does_not_infer_dependency_from_condition_expression(monkeypatch: pytest.MonkeyPatch, tmp_path: Path):
    fake = tmp_path / "fake_bridge.py"
    fake.write_text(
        '''import json, sys\ncmd=sys.argv[1]\nif cmd=="list-topologies": print(json.dumps({"topologies":["Topology_A"]}))\nelif cmd=="fetch-topology": print(json.dumps({"jobs":[{"Name":"A","Status":"Success","JobType":"Command"},{"Name":"B","Status":"Success","JobType":"Command","ConditionExpression":"success(A)"}]}))\n''',
        encoding="utf-8",
    )
    config = tmp_path / "connector.json"
    _write_config(config, fake)
    monkeypatch.setenv("PROCESS_SCHEDULER_CONNECTOR_CONFIG", str(config))

    provider = connector.ProcessSchedulerProvider()
    result = provider.fetch_topology(_context())
    assert result["dependencies"] == []
    assert provider.capabilities()["dependencies"] is False
    assert provider.capabilities()["parameter_support"]["dependencies"] == "unsupported"


def test_bridge_v1_process_scheduler_end_to_end(monkeypatch: pytest.MonkeyPatch, tmp_path: Path):
    fake = tmp_path / "fake_bridge.py"
    config = tmp_path / "connector.json"
    _write_fake_bridge(fake)
    _write_config(config, fake)

    request = {
        "protocol": "scheduler-bridge",
        "version": 1,
        "request_id": "req-1",
        "operation": "fetch_topology",
        "context": _context(),
    }
    env = os.environ.copy()
    env["PROCESS_SCHEDULER_CONNECTOR_CONFIG"] = str(config)
    completed = subprocess.run(
        [sys.executable, "workstation_connectors/process_scheduler_connector.py"],
        cwd=Path(__file__).resolve().parent.parent,
        input=json.dumps(request),
        text=True,
        encoding="utf-8",
        capture_output=True,
        env=env,
        timeout=20,
        check=False,
    )
    assert completed.returncode == 0
    response = json.loads(completed.stdout)
    assert response["ok"] is True
    assert response["request_id"] == "req-1"
    assert len(response["data"]["jobs"]) == 2
    assert response["capabilities"]["strict_parameter_support"] is True
    assert response["capabilities"]["dependencies"] is True


def test_observed_read_only_cli_verbs_are_prioritized(monkeypatch: pytest.MonkeyPatch, tmp_path: Path):
    bridge_dir = tmp_path / "TopoBrowse.Bridge"
    bridge_dir.mkdir()
    (bridge_dir / "Program.cs").write_text('''
class Program {
    static void Main(string[] args) {
        switch(args[0]) {
            case "list-contexts": break;
            case "get-contexts": break;
            case "describe-job": break;
        }
    }
}
''', encoding="utf-8")
    fake = bridge_dir / "native_bridge.py"
    fake.write_text('''import json, sys
cmd = sys.argv[1]
if cmd == "list-contexts":
    print(json.dumps({"contexts": ["Topology_A", "Topology_B"]}))
elif cmd == "get-contexts":
    print(json.dumps({"jobs": [{"Name": "BOX_A", "Status": "Running", "JobType": "Box"}, {"Name": "JOB_A", "Status": "Success", "JobType": "Command"}]}))
else:
    sys.exit(2)
''', encoding="utf-8")
    config_path = tmp_path / "connector.json"
    config_path.write_text(json.dumps({
        "bridge_dir": str(bridge_dir),
        "launcher": [sys.executable, str(fake)],
        "protocol_mode": "args", "max_response_mb": 4,
        "allow_text_output": True, "commands": {},
    }), encoding="utf-8")
    monkeypatch.setenv("PROCESS_SCHEDULER_CONNECTOR_CONFIG", str(config_path))
    provider = connector.ProcessSchedulerProvider()
    assert provider.list_roots(_context()) == {"roots": ["Topology_A", "Topology_B"]}
    snapshot = provider.fetch_topology(_context())
    assert len(snapshot["jobs"]) == 2
    assert snapshot["metadata"]["topobrowse_command"] == "get-contexts"


def test_contract_mismatch_reports_safe_attempt_labels(monkeypatch: pytest.MonkeyPatch, tmp_path: Path):
    bridge_dir = tmp_path / "TopoBrowse.Bridge"
    bridge_dir.mkdir()
    (bridge_dir / "Program.cs").write_text('''switch(args[0]) { case "list-contexts": break; case "get-contexts": break; }''', encoding="utf-8")
    fake = bridge_dir / "invalid_bridge.py"
    fake.write_text("import sys; print('secret-job-command-UNSAFE'); sys.exit(2)", encoding="utf-8")
    cfg = {"bridge_dir": str(bridge_dir), "launcher": [sys.executable, str(fake)], "protocol_mode": "args"}
    with pytest.raises(connector.ConnectorError) as caught:
        connector._invoke_bridge(cfg, "list_roots", {"environment": "U5", "host": "secret-host", "topology": "", "job": ""})
    error = caught.value
    assert error.code == "topobrowse_contract_mismatch"
    assert "list-contexts" in error.details["attempt_trace"]
    assert "list-topologies" not in error.details["attempt_trace"]
    assert "secret-host" not in str(error.details)
    assert "secret-job-command-UNSAFE" not in str(error.details)


def test_context_name_list_cannot_masquerade_as_topology_jobs():
    assert not connector._payload_matches_operation("fetch_topology", {"contexts": ["Topology_A"]})
    assert not connector._payload_matches_operation("fetch_topology", ["Topology_A", "Topology_B"])
    assert not connector._payload_matches_operation("fetch_topology", {"items": [{"Name": "Topology_A"}]})
    assert connector._payload_matches_operation("fetch_topology", {"jobs": [{"Name": "JOB_A", "Status": "Running"}]})
