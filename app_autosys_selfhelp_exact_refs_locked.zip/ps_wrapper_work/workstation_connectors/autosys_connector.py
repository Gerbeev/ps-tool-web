"""Portable AutoSys web connector for scheduler-bridge/v1.

This module is shipped with the application. It talks directly to the configured
AutoSys web/self-help endpoint, parses the runtime report and static JIL pages,
and returns the frozen scheduler-bridge/v1 DTO. No workstation-side code edits are
required.

The endpoint-specific request shape lives in ``autosys_connector.json`` next to
this file (or ``AUTOSYS_CONNECTOR_CONFIG``). The default mode can discover a
simple HTML form and the observed AutoSys runtime table automatically.
"""

from __future__ import annotations

import argparse
import base64
import fnmatch
import json
import os
import re
import subprocess
import sys
import tempfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import date, datetime
from html import unescape
from html.parser import HTMLParser
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import parse_qsl, quote, urlencode, urljoin, urlsplit, urlunsplit
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

try:  # Script execution from connector directory.
    from bridge_v1_runtime import ConnectorError, run
except ImportError:  # Package import from tests.
    from .bridge_v1_runtime import ConnectorError, run


JIL_PARAMETERS = (
    "job_type", "machine", "box_name", "command", "watch_file", "condition",
    "profile", "envvars", "exit_code_policy", "date_conditions", "start_times",
    "start_mins", "days_of_week", "run_calendar", "exclude_calendar", "run_window",
    "must_start_times", "must_complete_times", "timezone", "watch_interval",
    "watch_file_min_size", "box_success", "box_failure", "box_terminator",
    "job_terminator", "std_out_file", "std_err_file", "owner", "permission",
    "group", "application", "priority", "resources", "alarm_if_fail",
    "alarm_if_terminated", "min_run_alarm", "max_run_alarm", "term_run_time",
    "n_retrys", "send_notification", "notification_id", "notification_msg",
    "notification_template", "notification_alarm_types", "auto_hold", "auto_delete",
)
RUN_PARAMETERS = ("resolved_command", "exit_code", "actual_start", "actual_end")
SUPPORT_PARAMETERS = (*JIL_PARAMETERS, *RUN_PARAMETERS, "status", "dependencies", "topology_parent")

_STATUS_MAP = {
    "SU": "success", "SUCCESS": "success", "4": "success",
    "FA": "failure", "FAILURE": "failure", "5": "failure",
    "TE": "killed", "TERMINATED": "killed", "6": "killed",
    "RU": "running", "RUNNING": "running", "1": "running",
    "ST": "running", "STARTING": "running", "3": "running",
    "AC": "pending", "ACTIVATED": "pending", "9": "pending",
    "RE": "pending", "RESTART": "pending", "10": "pending",
    "OH": "pending", "ON_HOLD": "pending", "11": "pending",
    "QU": "pending", "QUE_WAIT": "pending", "12": "pending",
    "WR": "pending", "WAIT_REPLY": "pending", "13": "pending",
    "PE": "pending", "PEND_MACH": "pending", "14": "pending",
    "RW": "pending", "RESWAIT": "pending", "15": "pending",
    "IN": "not_run", "INACTIVE": "not_run", "8": "not_run",
    "OI": "disabled", "ON_ICE": "disabled", "7": "disabled",
    "NO": "disabled", "ON_NOEXEC": "disabled", "16": "disabled",
    "SUSPENDED": "pending", "17": "pending",
}

_TIMEZONE_ALIASES = {
    "London": "Europe/London",
    "UK": "Europe/London",
    "Zurich": "Europe/Zurich",
    "CET": "Europe/Zurich",
    "UTC": "UTC",
    "GMT": "Etc/GMT",
}

_HEADER_ALIASES = {
    "job_name": {"job", "jobname", "name", "job_name"},
    "last_start": {"laststart", "laststarttime", "start", "last_start"},
    "last_end": {"lastend", "lastendtime", "lastfinish", "lastfinishtime", "last_end"},
    "st_ex": {"stex", "status", "state", "st_ex"},
    "run_ntry": {"runntry", "runtry", "runntry", "run_ntry"},
    "pri_xit": {"prixit", "priorityexit", "exit", "exitcode", "pri_xit"},
    "timezone": {"timezone", "tz", "time_zone"},
}

_ATTR_KEYS = {
    "insert_job", "job_type", "box_name", "command", "machine", "owner", "permission",
    "date_conditions", "condition", "description", "std_out_file", "std_err_file",
    "max_run_alarm", "min_run_alarm", "alarm_if_fail", "alarm_if_terminated", "profile",
    "timezone", "group", "application", "start_times", "start_mins", "days_of_week",
    "run_calendar", "exclude_calendar", "run_window", "must_start_times",
    "must_complete_times", "watch_file", "watch_interval", "watch_file_min_size",
    "success_codes", "fail_codes", "n_retrys", "box_success", "box_failure",
    "box_terminator", "job_terminator", "term_run_time", "send_notification",
    "notification_id", "notification_msg", "notification_template",
    "notification_alarm_types", "auto_hold", "auto_delete", "priority", "resources",
    "envvars",
}

_DEFAULT_CONFIG: dict[str, Any] = {
    "transport": {
        "engine": "auto",
        "auth_mode": "windows_sso",
        "timeout_sec": 60,
        "verify_tls": True,
        "follow_redirects": True,
        "max_response_mb": 64,
        "username_env": "AUTOSYS_HTTP_USERNAME",
        "password_env": "AUTOSYS_HTTP_PASSWORD",
        "token_env": "AUTOSYS_HTTP_TOKEN",
        "user_agent": "ps-tool-web-autosys-connector/1",
    },
    "runtime": {
        "url_template": "{host}",
        "method": "AUTO",
        "query": {},
        "form": {
            "enabled": True,
            "job_field": "",
            "cob_field": "",
            "environment_field": "",
            "job_value": "{job_pattern}",
            "cob_value": "AUTO",
            "environment_value": "{environment}",
            "extra_fields": {},
        },
        "job_pattern": "IB_CT_CVA_*_{environment}_*",
        "require_job_binding": True,
        "require_cob_binding": True,
        "allow_empty": False,
        "max_pages": 25,
    },
    "definitions": {
        "mode": "auto",
        "url_template": "",
        "method": "GET",
        "query": {},
        "parallelism": 8,
        "required": True,
    },
    "diagnostics": {
        "definition_sample": 8,
    },
}


@dataclass(frozen=True)
class HttpResult:
    url: str
    status_code: int
    content_type: str
    text: str


@dataclass
class HtmlCell:
    text: str = ""
    links: list[str] = field(default_factory=list)


@dataclass
class HtmlTable:
    rows: list[list[HtmlCell]] = field(default_factory=list)


@dataclass
class HtmlLink:
    url: str
    text: str = ""


@dataclass
class HtmlForm:
    action: str = ""
    method: str = "GET"
    fields: dict[str, str] = field(default_factory=dict)
    field_types: dict[str, str] = field(default_factory=dict)


@dataclass
class RuntimeRow:
    job_name: str
    last_start_raw: str = ""
    last_end_raw: str = ""
    st_ex_raw: str = ""
    run_ntry_raw: str = ""
    pri_xit_raw: str = ""
    timezone_raw: str = ""
    detail_url: str = ""


@dataclass
class ParsedPage:
    tables: list[HtmlTable]
    forms: list[HtmlForm]
    pre_blocks: list[str]
    links: list[HtmlLink]
    next_url: str = ""
    visible_text: str = ""


class _PageParser(HTMLParser):
    def __init__(self, base_url: str) -> None:
        super().__init__(convert_charrefs=True)
        self.base_url = base_url
        self.tables: list[HtmlTable] = []
        self.forms: list[HtmlForm] = []
        self.pre_blocks: list[str] = []
        self.links: list[HtmlLink] = []
        self._table: HtmlTable | None = None
        self._row: list[HtmlCell] | None = None
        self._cell: HtmlCell | None = None
        self._cell_text: list[str] = []
        self._form: HtmlForm | None = None
        self._select_name = ""
        self._select_selected = False
        self._pre_depth = 0
        self._pre_text: list[str] = []
        self._all_text: list[str] = []
        self._anchor_url = ""
        self._anchor_text: list[str] = []
        self.next_url = ""

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        props = {k.lower(): (v or "") for k, v in attrs}
        tag = tag.lower()
        if tag == "table":
            self._table = HtmlTable()
        elif tag == "tr" and self._table is not None:
            self._row = []
        elif tag in {"th", "td"} and self._row is not None:
            self._cell = HtmlCell()
            self._cell_text = []
        elif tag == "a":
            href = props.get("href", "").strip()
            absolute = urljoin(self.base_url, href) if href else ""
            self._anchor_url = absolute
            self._anchor_text = []
            if absolute and self._cell is not None:
                self._cell.links.append(absolute)
            rel = props.get("rel", "").lower().split()
            if href and "next" in rel and not self.next_url:
                self.next_url = urljoin(self.base_url, href)
        elif tag == "form":
            self._form = HtmlForm(
                action=urljoin(self.base_url, props.get("action", "") or self.base_url),
                method=(props.get("method", "GET") or "GET").upper(),
            )
        elif tag == "input" and self._form is not None:
            name = props.get("name", "").strip()
            if name:
                typ = props.get("type", "text").lower()
                self._form.field_types[name] = typ
                if typ not in {"submit", "button", "image", "file"}:
                    self._form.fields[name] = props.get("value", "")
        elif tag == "select" and self._form is not None:
            self._select_name = props.get("name", "").strip()
            if self._select_name:
                self._form.field_types[self._select_name] = "select"
                self._form.fields.setdefault(self._select_name, "")
        elif tag == "option" and self._form is not None and self._select_name:
            selected = "selected" in props
            value = props.get("value", "")
            if selected or not self._form.fields.get(self._select_name):
                self._form.fields[self._select_name] = value
                self._select_selected = selected
        elif tag == "pre":
            self._pre_depth += 1
            if self._pre_depth == 1:
                self._pre_text = []

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag == "a":
            if self._anchor_url:
                self.links.append(HtmlLink(self._anchor_url, _collapse_ws("".join(self._anchor_text))))
            self._anchor_url = ""
            self._anchor_text = []
        elif tag in {"th", "td"} and self._cell is not None and self._row is not None:
            self._cell.text = _collapse_ws("".join(self._cell_text))
            self._row.append(self._cell)
            self._cell = None
            self._cell_text = []
        elif tag == "tr" and self._row is not None and self._table is not None:
            if any(cell.text or cell.links for cell in self._row):
                self._table.rows.append(self._row)
            self._row = None
        elif tag == "table" and self._table is not None:
            if self._table.rows:
                self.tables.append(self._table)
            self._table = None
        elif tag == "form" and self._form is not None:
            self.forms.append(self._form)
            self._form = None
            self._select_name = ""
        elif tag == "select":
            self._select_name = ""
        elif tag == "pre" and self._pre_depth:
            self._pre_depth -= 1
            if self._pre_depth == 0:
                text = "".join(self._pre_text).strip()
                if text:
                    self.pre_blocks.append(text)
                self._pre_text = []

    def handle_data(self, data: str) -> None:
        if self._cell is not None:
            self._cell_text.append(data)
        if self._anchor_url:
            self._anchor_text.append(data)
        if self._pre_depth:
            self._pre_text.append(data)
        if data.strip():
            self._all_text.append(data)

    def result(self) -> ParsedPage:
        return ParsedPage(
            tables=self.tables,
            forms=self.forms,
            pre_blocks=self.pre_blocks,
            links=self.links,
            next_url=self.next_url,
            visible_text="\n".join(_collapse_ws(item) for item in self._all_text if item.strip()),
        )


def _collapse_ws(value: str) -> str:
    return re.sub(r"\s+", " ", unescape(value or "")).strip()


def _norm_key(value: str) -> str:
    return re.sub(r"[^a-z0-9_]", "", value.lower().replace(" ", "_").replace("/", ""))


def _canonical_header(value: str) -> str | None:
    normalized = _norm_key(value)
    compact = normalized.replace("_", "")
    for canonical, aliases in _HEADER_ALIASES.items():
        for alias in aliases:
            a = _norm_key(alias)
            if normalized == a or compact == a.replace("_", ""):
                return canonical
    return None


def _parse_page(html: str, base_url: str) -> ParsedPage:
    parser = _PageParser(base_url)
    parser.feed(html)
    parser.close()
    return parser.result()


def _table_runtime_rows(table: HtmlTable) -> tuple[list[RuntimeRow], list[str]]:
    if not table.rows:
        return [], []
    header_index = -1
    mapping: dict[int, str] = {}
    headers: list[str] = []
    for idx, row in enumerate(table.rows[:5]):
        candidate: dict[int, str] = {}
        candidate_headers = [cell.text for cell in row]
        for col, cell in enumerate(row):
            canonical = _canonical_header(cell.text)
            if canonical:
                candidate[col] = canonical
        names = set(candidate.values())
        if "job_name" in names and "st_ex" in names and (
            "last_start" in names or "last_end" in names or "run_ntry" in names
        ):
            header_index = idx
            mapping = candidate
            headers = candidate_headers
            break
    if header_index < 0:
        return [], []

    rows: list[RuntimeRow] = []
    for row in table.rows[header_index + 1 :]:
        values: dict[str, str] = {}
        detail_url = ""
        for col, canonical in mapping.items():
            if col >= len(row):
                continue
            cell = row[col]
            values[canonical] = _clean_missing(cell.text)
            if canonical == "job_name" and cell.links:
                detail_url = cell.links[0]
        job_name = values.get("job_name", "").strip()
        if not job_name or _canonical_header(job_name):
            continue
        rows.append(
            RuntimeRow(
                job_name=job_name,
                last_start_raw=values.get("last_start", ""),
                last_end_raw=values.get("last_end", ""),
                st_ex_raw=values.get("st_ex", ""),
                run_ntry_raw=values.get("run_ntry", ""),
                pri_xit_raw=values.get("pri_xit", ""),
                timezone_raw=values.get("timezone", ""),
                detail_url=detail_url,
            )
        )
    return rows, headers


def _fixed_width_runtime_rows(text: str) -> tuple[list[RuntimeRow], list[str]]:
    lines = [line.rstrip("\r") for line in text.splitlines()]
    for i, line in enumerate(lines):
        if not ("Last Start" in line and "Last End" in line and "ST/Ex" in line and "Run/Ntry" in line):
            continue
        labels = ["Job Name", "Last Start", "Last End", "ST/Ex", "Run/Ntry", "Pri/Xit", "TimeZone"]
        positions: list[tuple[str, int]] = []
        for label in labels:
            pos = line.find(label)
            if pos >= 0:
                positions.append((label, pos))
        positions.sort(key=lambda item: item[1])
        if len(positions) < 6:
            continue
        rows: list[RuntimeRow] = []
        timestamp_re = re.compile(r"\b\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}:\d{2}\b")
        for raw in lines[i + 1 :]:
            # The selfhelp plain-text table is *not* truly column-position-stable.
            # Some nested jobs are indented and values can shift by multiple characters.
            # Parse two full timestamps first; header offsets are fallback for null fields.
            tokens = raw.strip().split()
            if not tokens or not re.fullmatch(r"[A-Za-z0-9_.\-]{3,}", tokens[0]):
                continue
            if tokens[0].lower() in {"job", "job_name", "jobname", "box", "status"}:
                continue
            timestamps = list(timestamp_re.finditer(raw))
            if len(timestamps) >= 2:
                suffix = raw[timestamps[1].end():].strip().split()
                tz_match = re.search(r"\(([^()]*)\)\s*$", raw)
                rows.append(RuntimeRow(
                    job_name=tokens[0],
                    last_start_raw=timestamps[0].group(),
                    last_end_raw=timestamps[1].group(),
                    st_ex_raw=suffix[0] if len(suffix) > 0 else "",
                    run_ntry_raw=suffix[1] if len(suffix) > 1 else "",
                    pri_xit_raw=suffix[2] if len(suffix) > 2 else "",
                    timezone_raw=tz_match.group(1) if tz_match else "",
                ))
                continue
            if not raw.strip() or set(raw.strip()) <= {"_", "-", " "}:
                continue
            fields: dict[str, str] = {}
            for pidx, (label, start) in enumerate(positions):
                end = positions[pidx + 1][1] if pidx + 1 < len(positions) else None
                fields[label] = _clean_missing(raw[start:end].strip())
            name = fields.get("Job Name", "")
            if not name:
                continue
            rows.append(
                RuntimeRow(
                    job_name=name,
                    last_start_raw=fields.get("Last Start", ""),
                    last_end_raw=fields.get("Last End", ""),
                    st_ex_raw=fields.get("ST/Ex", ""),
                    run_ntry_raw=fields.get("Run/Ntry", ""),
                    pri_xit_raw=fields.get("Pri/Xit", ""),
                    timezone_raw=fields.get("TimeZone", ""),
                )
            )
        if rows:
            return rows, [item[0] for item in positions]
    return [], []


def parse_runtime_report(html: str, base_url: str) -> tuple[list[RuntimeRow], list[str], ParsedPage]:
    # Some AutoSys report endpoints return fixed-width text directly rather than HTML.
    looks_like_html = bool(re.search(r"<(?:html|body|table|tr|td|th|form)\b", html, flags=re.I))
    direct_rows: list[RuntimeRow] = []
    direct_headers: list[str] = []
    if not looks_like_html:
        direct_rows, direct_headers = _fixed_width_runtime_rows(html)
    page = _parse_page(html, base_url)
    if direct_rows:
        return direct_rows, direct_headers, page
    for table in page.tables:
        rows, headers = _table_runtime_rows(table)
        if rows:
            return rows, headers, page
    for block in page.pre_blocks:
        rows, headers = _fixed_width_runtime_rows(block)
        if rows:
            return rows, headers, page
    rows, headers = _fixed_width_runtime_rows(page.visible_text)
    return rows, headers, page


def _clean_missing(value: str) -> str:
    text = _collapse_ws(value)
    return "" if text in {"-----", "---", "-", "N/A", "n/a", "null", "None"} else text


def _strip_quotes(value: str) -> str:
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
        return value[1:-1]
    return value


def parse_jil(text: str) -> dict[str, Any]:
    """Parse one AutoSys JIL definition without evaluating its contents."""
    cleaned = re.sub(r"/\*.*?\*/", "", unescape(text), flags=re.S)
    lines = cleaned.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    attrs: dict[str, str] = {}
    current_key = ""

    for original in lines:
        line = original.strip()
        if not line:
            continue
        if line.startswith("insert_job:"):
            match = re.match(r"insert_job:\s*(\S+)(?:\s+job_type:\s*(\S+))?", line, flags=re.I)
            if match:
                attrs["job_name"] = match.group(1)
                if match.group(2):
                    attrs["job_type"] = match.group(2)
                current_key = ""
                continue
        match = re.match(r"([A-Za-z][A-Za-z0-9_]*):\s*(.*)$", line)
        if match and match.group(1).lower() in _ATTR_KEYS:
            key = match.group(1).lower()
            if key == "insert_job":
                key = "job_name"
            attrs[key] = _strip_quotes(match.group(2).strip())
            current_key = key
        elif current_key:
            attrs[current_key] = f"{attrs[current_key]} {line}".strip()

    return attrs


def parse_jil_page(html: str, base_url: str) -> dict[str, Any]:
    # Raw JIL may be returned as text/plain; parse it before HTML extraction.
    direct = parse_jil(html)
    if direct.get("job_name"):
        return direct
    page = _parse_page(html, base_url)
    candidates = list(page.pre_blocks)
    candidates.append(page.visible_text)
    for candidate in candidates:
        if "insert_job:" in candidate.lower():
            parsed = parse_jil(candidate)
            if parsed.get("job_name"):
                return parsed

    # Some internal pages render JIL as a two-column property table.
    for table in page.tables:
        attrs: dict[str, Any] = {}
        for row in table.rows:
            if len(row) < 2:
                continue
            key = _norm_key(row[0].text)
            if key in _ATTR_KEYS:
                attrs["job_name" if key == "insert_job" else key] = _strip_quotes(row[1].text)
        if attrs.get("job_name") or attrs.get("job_type"):
            return attrs
    return {}


def _status(raw: str) -> str:
    key = raw.strip().upper().replace(" ", "_")
    return _STATUS_MAP.get(key, "unknown")


def _timezone(name: str) -> ZoneInfo | None:
    raw = name.strip()
    if not raw:
        return None
    zone = _TIMEZONE_ALIASES.get(raw, raw)
    try:
        return ZoneInfo(zone)
    except ZoneInfoNotFoundError:
        return None


def _parse_time(raw: str, timezone_name: str) -> datetime | None:
    value = _clean_missing(raw)
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        parsed = None
    if parsed is None:
        for fmt in (
            "%m/%d/%Y %H:%M:%S",
            "%m/%d/%Y %H:%M:%S,%f",
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%d %H:%M:%S,%f",
            "%Y/%m/%d %H:%M:%S",
            "%Y/%m/%d %H:%M:%S,%f",
        ):
            try:
                parsed = datetime.strptime(value, fmt)
                break
            except ValueError:
                continue
    if parsed is None:
        return None
    if parsed.tzinfo is None:
        zone = _timezone(timezone_name)
        if zone is not None:
            parsed = parsed.replace(tzinfo=zone)
    return parsed


def _uid(environment_id: str, job_name: str) -> str:
    encoded = base64.urlsafe_b64encode(job_name.encode("utf-8")).decode("ascii").rstrip("=")
    return f"autosys:{environment_id}:{encoded}"


def _dependency_refs(condition: str) -> list[tuple[str, str]]:
    if not condition:
        return []
    refs: list[tuple[str, str]] = []
    pattern = re.compile(
        r"(?i)\b(success|s|failure|f|done|d|terminated|t|notrunning|n|exitcode|e)\s*\(\s*([^,()\s]+)"
    )
    for match in pattern.finditer(condition):
        fn = match.group(1).lower()
        job_name = match.group(2).strip("'\"")
        if job_name:
            refs.append((fn, job_name))
    return list(dict.fromkeys(refs))


def _instance_for_environment(environment: str) -> str:
    """AutoSys selfhelp instance codes, per docs/reference specification."""
    value = environment.strip().upper()
    if re.fullmatch(r"U[0-9]+", value):
        return "IUT"
    if re.fullmatch(r"P[0-9]+", value) or value == "PROD":
        return "IL2"
    raise ConnectorError("source_configuration_error", "Unsupported AutoSys environment tier; expected U<n> or P<n>/PROD")


def _render(template: str, context: dict[str, Any], *, job_name: str = "", job_pattern: str = "") -> str:
    cob = context.get("as_of_value", "")
    try:
        d = date.fromisoformat(cob)
    except ValueError:
        d = None
    host = str(context.get("host") or "").strip()
    environment = str(context.get("environment") or "").strip()
    values = {
        "host": _normalize_host(host),
        "environment": environment,
        "environment_id": str(context.get("environment_id") or ""),
        "instance": _instance_for_environment(environment),
        "cob_date": cob,
        "cob_yyyymmdd": d.strftime("%Y%m%d") if d else cob,
        "cob_mmddyyyy": d.strftime("%m/%d/%Y") if d else cob,
        "cob_ddmmyyyy": d.strftime("%d/%m/%Y") if d else cob,
        "job_name": job_name,
        "job_name_url": quote(job_name, safe=""),
        "job_pattern": job_pattern,
        "job_pattern_url": quote(job_pattern, safe=""),
    }
    try:
        return template.format(**values)
    except KeyError as exc:
        raise ConnectorError("source_configuration_error", f"Unknown endpoint template key: {exc.args[0]}") from exc


def _normalize_host(host: str) -> str:
    if not host:
        return ""
    if "://" not in host:
        return f"https://{host}"
    return host


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    result = dict(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def load_connector_config() -> dict[str, Any]:
    raw_path = os.getenv("AUTOSYS_CONNECTOR_CONFIG", "").strip()
    path = Path(raw_path) if raw_path else Path(__file__).with_name("autosys_connector.json")
    if not path.is_file():
        return _DEFAULT_CONFIG
    try:
        override = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ConnectorError("source_configuration_error", "AutoSys connector config is invalid JSON") from exc
    if not isinstance(override, dict):
        raise ConnectorError("source_configuration_error", "AutoSys connector config root must be an object")
    if int(override.get("schema_version", 1)) != 1:
        raise ConnectorError("source_configuration_error", "Unsupported AutoSys connector config schema_version")
    return _deep_merge(_DEFAULT_CONFIG, override)


class AutoSysHttpClient:
    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        self.transport = config["transport"]
        engine = str(self.transport.get("engine", "auto")).lower()
        auth = str(self.transport.get("auth_mode", "none")).lower()
        if engine == "auto":
            engine = "curl" if os.name == "nt" or auth in {"windows_sso", "negotiate", "ntlm"} else "httpx"
        self.engine = engine
        self._tmp = tempfile.TemporaryDirectory(prefix="ps-tool-autosys-")
        self.cookie_jar = str(Path(self._tmp.name) / "cookies.txt")
        self._httpx_client = None

    def close(self) -> None:
        client = self._httpx_client
        if client is not None:
            client.close()
        self._tmp.cleanup()

    def __enter__(self) -> "AutoSysHttpClient":
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()

    def request(self, method: str, url: str, params: dict[str, str] | None = None) -> HttpResult:
        method = method.upper()
        if self.engine == "curl":
            try:
                return self._curl(method, url, params or {})
            except ConnectorError as exc:
                # The selfhelp spec explicitly allows anonymous/IP-allowlisted fallback.
                # Do not reuse credentials across redirects (disabled in CGI config).
                if (exc.code != "source_auth_error"
                        or str(self.transport.get("auth_mode", "")).lower() not in {"windows_sso", "negotiate"}
                        or not self.transport.get("allow_anonymous_fallback", False)):
                    raise
                fallback_config = _deep_merge(self.config, {"transport": {"auth_mode": "none"}})
                with AutoSysHttpClient(fallback_config) as fallback:
                    return fallback._curl(method, url, params or {})
        if self.engine == "httpx":
            return self._httpx(method, url, params or {})
        raise ConnectorError("source_configuration_error", f"Unsupported HTTP transport engine: {self.engine}")

    def _curl(self, method: str, url: str, params: dict[str, str]) -> HttpResult:
        executable = "curl.exe" if os.name == "nt" else "curl"
        timeout = max(1, int(self.transport.get("timeout_sec", 60)))
        args = [
            executable, "--silent", "--show-error", "--max-time", str(timeout),
            "--connect-timeout", str(min(timeout, 20)), "--cookie", self.cookie_jar,
            "--cookie-jar", self.cookie_jar, "--user-agent", str(self.transport.get("user_agent") or "ps-tool-web"),
        ]
        if bool(self.transport.get("follow_redirects", True)):
            args.append("--location")
        if not bool(self.transport.get("verify_tls", True)):
            args.append("--insecure")
        auth = str(self.transport.get("auth_mode", "none")).lower()
        if auth in {"windows_sso", "negotiate"}:
            args.extend(["--negotiate", "--user", ":"])
        elif auth == "ntlm":
            args.extend(["--ntlm", "--user", ":"])
        elif auth == "basic":
            user = os.getenv(str(self.transport.get("username_env") or "AUTOSYS_HTTP_USERNAME"), "")
            password = os.getenv(str(self.transport.get("password_env") or "AUTOSYS_HTTP_PASSWORD"), "")
            if not user:
                raise ConnectorError("source_auth_error", "Basic-auth username environment variable is empty")
            args.extend(["--user", f"{user}:{password}"])
        elif auth == "bearer":
            token = os.getenv(str(self.transport.get("token_env") or "AUTOSYS_HTTP_TOKEN"), "")
            if not token:
                raise ConnectorError("source_auth_error", "Bearer-token environment variable is empty")
            args.extend(["--header", f"Authorization: Bearer {token}"])
        elif auth != "none":
            raise ConnectorError("source_configuration_error", f"Unsupported auth_mode: {auth}")

        if method == "GET" and params:
            query = urlencode(params, doseq=False)
            separator = "&" if "?" in url else "?"
            url = f"{url}{separator}{query}"
        elif method == "POST":
            args.extend(["--request", "POST"])
            for key, value in params.items():
                args.extend(["--data-urlencode", f"{key}={value}"])
        elif method not in {"GET", "HEAD"}:
            args.extend(["--request", method])

        marker = "__PS_TOOL_HTTP_META__"
        args.extend(["--write-out", f"\\n{marker}%{{http_code}}|%{{content_type}}|%{{url_effective}}", url])
        try:
            completed = subprocess.run(
                args,
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=timeout + 5,
                check=False,
            )
        except FileNotFoundError as exc:
            raise ConnectorError("source_transport_error", "curl executable was not found") from exc
        except subprocess.TimeoutExpired as exc:
            raise ConnectorError("source_timeout", "AutoSys HTTP request timed out", retryable=True) from exc

        if completed.returncode != 0:
            raise ConnectorError(
                "source_transport_error",
                f"AutoSys HTTP transport failed (curl exit {completed.returncode})",
                retryable=completed.returncode in {5, 6, 7, 28, 52, 56},
            )
        body, sep, meta = completed.stdout.rpartition(f"\n{marker}")
        if not sep:
            raise ConnectorError("source_transport_error", "AutoSys HTTP transport returned no response metadata")
        try:
            status_raw, content_type, effective_url = meta.split("|", 2)
            status = int(status_raw)
        except (ValueError, TypeError) as exc:
            raise ConnectorError("source_transport_error", "AutoSys HTTP response metadata is invalid") from exc
        self._validate_status(status)
        self._validate_size(body)
        return HttpResult(effective_url or url, status, content_type, body)

    def _httpx(self, method: str, url: str, params: dict[str, str]) -> HttpResult:
        try:
            import httpx
        except ImportError as exc:
            raise ConnectorError("source_transport_error", "httpx is not installed") from exc
        if self._httpx_client is None:
            auth_mode = str(self.transport.get("auth_mode", "none")).lower()
            auth: Any = None
            headers = {"User-Agent": str(self.transport.get("user_agent") or "ps-tool-web")}
            if auth_mode == "basic":
                user = os.getenv(str(self.transport.get("username_env") or "AUTOSYS_HTTP_USERNAME"), "")
                password = os.getenv(str(self.transport.get("password_env") or "AUTOSYS_HTTP_PASSWORD"), "")
                auth = (user, password)
            elif auth_mode == "bearer":
                token = os.getenv(str(self.transport.get("token_env") or "AUTOSYS_HTTP_TOKEN"), "")
                headers["Authorization"] = f"Bearer {token}"
            elif auth_mode != "none":
                raise ConnectorError(
                    "source_configuration_error",
                    "httpx transport supports auth_mode none/basic/bearer; use curl for Windows SSO",
                )
            self._httpx_client = httpx.Client(
                timeout=max(1, int(self.transport.get("timeout_sec", 60))),
                verify=bool(self.transport.get("verify_tls", True)),
                follow_redirects=bool(self.transport.get("follow_redirects", True)),
                auth=auth,
                headers=headers,
            )
        try:
            if method == "POST":
                response = self._httpx_client.request(method, url, data=params)
            else:
                response = self._httpx_client.request(method, url, params=params)
        except Exception as exc:
            raise ConnectorError("source_transport_error", "AutoSys HTTP request failed", retryable=True) from exc
        self._validate_status(response.status_code)
        self._validate_size(response.text)
        return HttpResult(str(response.url), response.status_code, response.headers.get("content-type", ""), response.text)

    def _validate_size(self, text: str) -> None:
        limit_mb = max(1, int(self.transport.get("max_response_mb", 64)))
        if len(text.encode("utf-8")) > limit_mb * 1024 * 1024:
            raise ConnectorError(
                "source_response_too_large",
                f"AutoSys HTTP response exceeded {limit_mb} MB limit",
            )

    @staticmethod
    def _validate_status(status: int) -> None:
        if status in {401, 403}:
            raise ConnectorError("source_auth_error", f"AutoSys endpoint returned HTTP {status}")
        if status == 404:
            raise ConnectorError("source_not_found", "AutoSys endpoint returned HTTP 404")
        if status == 429:
            raise ConnectorError("source_rate_limited", "AutoSys endpoint returned HTTP 429", retryable=True)
        if status >= 500:
            raise ConnectorError("source_unavailable", f"AutoSys endpoint returned HTTP {status}", retryable=True)
        if status < 200 or status >= 400:
            raise ConnectorError("source_http_error", f"AutoSys endpoint returned HTTP {status}")


def _pick_field(form: HtmlForm, explicit: str, tokens: Iterable[str]) -> str:
    if explicit and explicit in form.fields:
        return explicit
    scored: list[tuple[int, str]] = []
    for name in form.fields:
        normalized = _norm_key(name)
        score = sum(2 if normalized == token else 1 for token in tokens if token in normalized)
        if score:
            scored.append((score, name))
    scored.sort(key=lambda item: (-item[0], item[1]))
    return scored[0][1] if scored else ""


def _form_cob_value(form: HtmlForm, field_name: str, configured: str, context: dict[str, Any], pattern: str) -> str:
    if configured and configured.upper() != "AUTO":
        return _render(configured, context, job_pattern=pattern)
    existing = str(form.fields.get(field_name) or "").strip()
    field_type = str(form.field_types.get(field_name) or "").lower()
    if field_type == "date" or re.fullmatch(r"\d{4}-\d{2}-\d{2}", existing):
        return _render("{cob_date}", context, job_pattern=pattern)
    if re.fullmatch(r"\d{8}", existing):
        return _render("{cob_yyyymmdd}", context, job_pattern=pattern)
    # The observed AutoSys report renders dates as MM/DD/YYYY; use the same convention
    # for ordinary text inputs unless the form itself indicates another format.
    return _render("{cob_mmddyyyy}", context, job_pattern=pattern)


def _page_diagnostic_details(page: ParsedPage, headers: list[str]) -> dict[str, Any]:
    return {
        "form_count": len(page.forms),
        "form_fields": sorted({name for form in page.forms for name in form.fields})[:40],
        "table_count": len(page.tables),
        "pre_count": len(page.pre_blocks),
        "headers": headers[:20],
    }




def _safe_endpoint_discovery(client: AutoSysHttpClient, config: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
    """Return structure-only endpoint hints without exposing business payload values."""
    runtime = config.get("runtime") or {}
    pattern = _render(str(runtime.get("job_pattern") or "*"), context)
    url = _render(str(runtime.get("url_template") or "{host}"), context, job_pattern=pattern)
    query_cfg = runtime.get("query") or {}
    params = {str(k): _render(str(v), context, job_pattern=pattern) for k, v in query_cfg.items()}
    result = client.request("GET", url, params)
    details: dict[str, Any] = {
        "probe_http": result.status_code,
        "probe_content_type": result.content_type or "unknown",
        "probe_body_bytes": len(result.text.encode("utf-8", errors="replace")),
    }
    split = urlsplit(result.url)
    details["probe_final_host"] = split.netloc or "unknown"
    details["probe_final_path"] = split.path or "/"
    details["probe_final_query_keys"] = ",".join(sorted({key for key, _ in parse_qsl(split.query, keep_blank_values=True)})) or "none"

    content_type = (result.content_type or "").lower()
    text = result.text
    if "json" in content_type or text.lstrip().startswith(("{", "[")):
        try:
            payload = json.loads(text)
        except json.JSONDecodeError:
            payload = None
        if isinstance(payload, dict):
            details["probe_json_keys"] = ",".join(sorted(str(k) for k in payload.keys())[:60]) or "none"
        elif isinstance(payload, list):
            details["probe_json_shape"] = "array"
            if payload and isinstance(payload[0], dict):
                details["probe_json_item_keys"] = ",".join(sorted(str(k) for k in payload[0].keys())[:60]) or "none"
        return details

    rows, headers, page = parse_runtime_report(text, result.url)
    details.update({
        "probe_forms": len(page.forms),
        "probe_form_fields": ",".join(sorted({name for form in page.forms for name in form.fields})[:60]) or "none",
        "probe_tables": len(page.tables),
        "probe_pre_blocks": len(page.pre_blocks),
        "probe_parsed_rows": len(rows),
        "probe_headers": "|".join(headers[:30]) or "none",
        "probe_links": len(page.links),
    })

    title_match = re.search(r"(?is)<title[^>]*>(.*?)</title>", text)
    if title_match:
        title = re.sub(r"\s+", " ", unescape(title_match.group(1))).strip()
        title = re.sub(r"[^A-Za-z0-9 _.:/()\-]+", "?", title)[:100]
        details["probe_title"] = title or "present"

    script_paths: list[str] = []
    for match in re.finditer(r"(?is)<script[^>]+src=[\"']([^\"']+)[\"']", text):
        candidate = urlsplit(urljoin(result.url, unescape(match.group(1)))).path
        if candidate and candidate not in script_paths:
            script_paths.append(candidate)
    details["probe_script_paths"] = ",".join(script_paths[:20]) or "none"

    route_hints: list[str] = []
    for match in re.finditer(r"[\"'](/[^\"'\s]{2,160})[\"']", text):
        candidate = unescape(match.group(1)).split("?", 1)[0]
        low = candidate.lower()
        if not any(token in low for token in ("autosys", "job", "report", "api", "query", "search", "monitor", "jil")):
            continue
        if re.fullmatch(r"/[A-Za-z0-9_./{}:%+\-]+", candidate) and candidate not in route_hints:
            route_hints.append(candidate)
    details["probe_route_hints"] = ",".join(route_hints[:30]) or "none"

    visible = page.visible_text.lower()
    auth_terms = [term for term in ("login", "sign in", "authentication", "access denied", "unauthorized") if term in visible]
    details["probe_auth_page_hint"] = "yes" if auth_terms else "no"
    return details


def _runtime_request(
    client: AutoSysHttpClient,
    config: dict[str, Any],
    context: dict[str, Any],
) -> tuple[list[RuntimeRow], list[str], dict[str, Any]]:
    runtime = config["runtime"]
    pattern = _render(str(runtime.get("job_pattern") or "*"), context)
    url = _render(str(runtime.get("url_template") or "{host}"), context, job_pattern=pattern)
    if not url:
        raise ConnectorError("source_configuration_error", "AutoSys host/endpoint is empty")

    method = str(runtime.get("method", "AUTO")).upper()
    query_cfg = runtime.get("query") or {}
    params = {str(k): _render(str(v), context, job_pattern=pattern) for k, v in query_cfg.items()}
    bound_job = any("{job_pattern" in str(v) for v in query_cfg.values()) or "{job_pattern" in str(runtime.get("url_template", ""))
    bound_cob = any("{cob_" in str(v) or "{cob_date" in str(v) for v in query_cfg.values()) or "{cob_" in str(runtime.get("url_template", "")) or "{cob_date" in str(runtime.get("url_template", ""))

    first_method = "GET" if method == "AUTO" else method
    response = client.request(first_method, url, params)
    rows, headers, page = parse_runtime_report(response.text, response.url)

    if method == "AUTO" and not rows and bool((runtime.get("form") or {}).get("enabled", True)):
        form_cfg = runtime.get("form") or {}
        selected: tuple[HtmlForm, str, str, str] | None = None
        for form in page.forms:
            job_field = _pick_field(form, str(form_cfg.get("job_field") or ""), ("job", "name", "mask", "pattern", "filter"))
            cob_field = _pick_field(form, str(form_cfg.get("cob_field") or ""), ("cob", "businessdate", "business_date", "date"))
            env_field = _pick_field(form, str(form_cfg.get("environment_field") or ""), ("environment", "env", "instance"))
            score = int(bool(job_field)) + int(bool(cob_field))
            if score:
                selected = (form, job_field, cob_field, env_field)
                if score == 2:
                    break
        if selected is not None:
            form, job_field, cob_field, env_field = selected
            submitted = dict(form.fields)
            if job_field:
                submitted[job_field] = _render(
                    str(form_cfg.get("job_value") or "{job_pattern}"),
                    context,
                    job_pattern=pattern,
                )
                bound_job = True
            if cob_field:
                submitted[cob_field] = _form_cob_value(
                    form,
                    cob_field,
                    str(form_cfg.get("cob_value") or "AUTO"),
                    context,
                    pattern,
                )
                bound_cob = True
            if env_field:
                submitted[env_field] = _render(
                    str(form_cfg.get("environment_value") or "{environment}"),
                    context,
                    job_pattern=pattern,
                )
            for key, value in (form_cfg.get("extra_fields") or {}).items():
                submitted[str(key)] = _render(str(value), context, job_pattern=pattern)
            response = client.request(form.method or "GET", form.action or url, submitted)
            rows, headers, page = parse_runtime_report(response.text, response.url)

    if bool(runtime.get("require_job_binding", True)) and not bound_job:
        raise ConnectorError(
            "source_configuration_error",
            "AutoSys runtime endpoint did not expose/bind a job-pattern parameter; configure runtime.query/form",
            details=_page_diagnostic_details(page, headers),
        )
    if bool(runtime.get("require_cob_binding", True)) and not bound_cob:
        raise ConnectorError(
            "source_configuration_error",
            "AutoSys runtime endpoint did not expose/bind a COB/date parameter; configure runtime.query/form",
            details=_page_diagnostic_details(page, headers),
        )
    if not rows:
        if bool(runtime.get("allow_empty", False)):
            return [], headers, {
                "http_status": response.status_code,
                "content_type": response.content_type,
                "pages": 1,
                "job_pattern": pattern,
                "rows_before_filter": 0,
                "rows_after_filter": 0,
                "endpoint_host": urlsplit(response.url).netloc,
            }
        raise ConnectorError(
            "source_schema_error",
            "AutoSys response contained no recognizable runtime rows",
            details=_page_diagnostic_details(page, headers),
        )

    # Read all bounded pages before applying the defensive local scope filter. The endpoint remains
    # responsible for using the COB parameter; COB is not reinterpreted here as an as-of filter over
    # Last Start/Last End. Filtering after pagination avoids a false no-match when a matching row is
    # present only on a later page.
    all_rows = list(rows)
    pages = 1
    next_url = page.next_url
    max_pages = max(1, int(runtime.get("max_pages", 25)))
    while next_url:
        if pages >= max_pages:
            raise ConnectorError("source_incomplete", f"AutoSys pagination exceeded max_pages={max_pages}")
        next_response = client.request("GET", next_url, {})
        next_rows, _next_headers, next_page = parse_runtime_report(next_response.text, next_response.url)
        all_rows.extend(next_rows)
        pages += 1
        next_url = next_page.next_url

    rows_before_filter = len(all_rows)
    # The selfhelp CGI uses SQL-like '%' wildcards, not shell '*' wildcards.
    local_glob = pattern.replace("%", "*")
    filtered_rows = [row for row in all_rows if fnmatch.fnmatchcase(row.job_name, local_glob)]
    rows_after_filter = len(filtered_rows)
    if not filtered_rows and not bool(runtime.get("allow_empty", False)):
        raise ConnectorError(
            "source_schema_error",
            "AutoSys runtime rows did not match the configured job pattern",
            details={
                "job_pattern": pattern,
                "rows_before_filter": rows_before_filter,
                "rows_after_filter": rows_after_filter,
                "pages": pages,
            },
        )

    # De-duplicate page overlap by job name while preserving first occurrence.
    unique: dict[str, RuntimeRow] = {}
    for row in filtered_rows:
        unique.setdefault(row.job_name, row)
    result_rows = list(unique.values())
    return result_rows, headers, {
        "http_status": response.status_code,
        "content_type": response.content_type,
        "pages": pages,
        "job_pattern": pattern,
        "rows_before_filter": rows_before_filter,
        "rows_after_filter": rows_after_filter,
        "rows_after_dedup": len(result_rows),
        "endpoint_host": urlsplit(response.url).netloc,
    }


def _definition_url(config: dict[str, Any], context: dict[str, Any], row: RuntimeRow, pattern: str) -> str:
    definitions = config["definitions"]
    template = str(definitions.get("url_template") or "").strip()
    if template:
        return _render(template, context, job_name=row.job_name, job_pattern=pattern)
    mode = str(definitions.get("mode", "auto")).lower()
    if mode in {"auto", "links"}:
        return row.detail_url
    return ""


def _fetch_one_definition(
    config: dict[str, Any],
    context: dict[str, Any],
    row: RuntimeRow,
    pattern: str,
) -> tuple[str, dict[str, Any], str]:
    url = _definition_url(config, context, row, pattern)
    if not url:
        return row.job_name, {}, "no_detail_url"
    definitions = config["definitions"]
    query_cfg = definitions.get("query") or {}
    params = {
        str(k): _render(str(v), context, job_name=row.job_name, job_pattern=pattern)
        for k, v in query_cfg.items()
    }
    try:
        with AutoSysHttpClient(config) as client:
            response = client.request(str(definitions.get("method", "GET")).upper(), url, params)
            parsed = parse_jil_page(response.text, response.url)
            if not parsed and str(definitions.get("mode", "auto")).lower() == "auto":
                page = _parse_page(response.text, response.url)
                candidates = []
                for link in page.links:
                    marker = f"{link.text} {link.url}".lower()
                    if any(token in marker for token in ("jil", "definition", "autorep")):
                        candidates.append(link.url)
                for nested_url in list(dict.fromkeys(candidates))[:3]:
                    nested = client.request("GET", nested_url, {})
                    parsed = parse_jil_page(nested.text, nested.url)
                    if parsed:
                        break
        if not parsed:
            return row.job_name, {}, "jil_not_found"
        if str(parsed.get("job_name", "")) != row.job_name:
            return row.job_name, {}, "jil_name_mismatch"
        return row.job_name, parsed, "ok"
    except ConnectorError as exc:
        return row.job_name, {}, exc.code


def _fetch_definitions(
    config: dict[str, Any], context: dict[str, Any], rows: list[RuntimeRow], pattern: str
) -> tuple[dict[str, dict[str, Any]], dict[str, str]]:
    mode = str(config["definitions"].get("mode", "auto")).lower()
    if mode == "none":
        return {}, {row.job_name: "disabled" for row in rows}
    candidates = [row for row in rows if _definition_url(config, context, row, pattern)]
    if not candidates:
        return {}, {row.job_name: "no_detail_url" for row in rows}

    parallelism = max(1, min(32, int(config["definitions"].get("parallelism", 8))))
    definitions: dict[str, dict[str, Any]] = {}
    errors: dict[str, str] = {row.job_name: "no_detail_url" for row in rows if row not in candidates}
    with ThreadPoolExecutor(max_workers=parallelism, thread_name_prefix="autosys-jil") as pool:
        futures = [pool.submit(_fetch_one_definition, config, context, row, pattern) for row in candidates]
        for future in as_completed(futures):
            name, parsed, outcome = future.result()
            if parsed:
                definitions[name] = parsed
            else:
                errors[name] = outcome
    return definitions, errors


def _path_for(job_name: str, definitions: dict[str, dict[str, Any]]) -> list[str]:
    path: list[str] = []
    seen: set[str] = set()
    current = job_name
    while current and current not in seen:
        seen.add(current)
        path.append(current)
        parent = str((definitions.get(current) or {}).get("box_name") or "").strip()
        if not parent or parent == current:
            break
        current = parent
    path.reverse()
    return path


def _job_payload(
    context: dict[str, Any],
    row: RuntimeRow,
    definition: dict[str, Any] | None,
    definitions: dict[str, dict[str, Any]],
    source_names: set[str],
) -> dict[str, Any]:
    definition = dict(definition or {})
    name = row.job_name
    actual_start = _parse_time(row.last_start_raw, row.timezone_raw)
    actual_end = _parse_time(row.last_end_raw, row.timezone_raw)
    duration = (actual_end - actual_start).total_seconds() if actual_start and actual_end else None
    run_no = ""
    attempt = ""
    if "/" in row.run_ntry_raw:
        run_no, attempt = (part.strip() for part in row.run_ntry_raw.split("/", 1))

    parent_name = str(definition.get("box_name") or "").strip()
    parent_uid = _uid(str(context.get("environment_id")), parent_name) if parent_name and parent_name in source_names else None
    has_definition = bool(definition)
    comparison_support = {param: ("supported" if has_definition else "unknown") for param in JIL_PARAMETERS}
    comparison_support.update({
        "actual_start": "supported",
        "actual_end": "supported",
        "resolved_command": "unsupported",
        "exit_code": "unknown",
        "dependencies": "supported" if has_definition else "unknown",
        "topology_parent": "supported" if has_definition else "unknown",
        "status": "supported",
    })

    evidence: dict[str, dict[str, str]] = {
        "actual_start": {"source": "autosys_user_report", "locator": "Last Start", "note": ""},
        "actual_end": {"source": "autosys_user_report", "locator": "Last End", "note": ""},
    }
    if has_definition:
        for param in JIL_PARAMETERS:
            if param == "exit_code_policy":
                evidence[param] = {"source": "autosys_jil", "locator": "success_codes/fail_codes", "note": ""}
            else:
                evidence[param] = {"source": "autosys_jil", "locator": param, "note": ""}

    autosys_run: dict[str, Any] = {
        "status": row.st_ex_raw or None,
        "actual_start": actual_start.isoformat() if actual_start else None,
        "actual_end": actual_end.isoformat() if actual_end else None,
        "run_ntry_raw": row.run_ntry_raw or None,
        "pri_xit_raw": row.pri_xit_raw or None,
        "run_number": run_no or None,
        "try_number": attempt or None,
        "timezone_raw": row.timezone_raw or None,
    }
    autosys_jil = definition
    autosys_jil.setdefault("job_name", name)
    if row.timezone_raw and not autosys_jil.get("timezone"):
        autosys_jil["timezone"] = row.timezone_raw

    return {
        "job_uid": _uid(str(context.get("environment_id")), name),
        "scheduler_job_name": name,
        "scheduler_native_id": name,
        "parent_uid": parent_uid,
        "path_labels": _path_for(name, definitions),
        "status": _status(row.st_ex_raw),
        "status_raw": row.st_ex_raw,
        "actual_start": actual_start.isoformat() if actual_start else None,
        "actual_end": actual_end.isoformat() if actual_end else None,
        "duration_sec": duration,
        "exit_code": None,
        "autosys_jil": autosys_jil,
        "autosys_run": autosys_run,
        "process_scheduler": None,
        "attributes": {
            "run_ntry_raw": row.run_ntry_raw or None,
            "pri_xit_raw": row.pri_xit_raw or None,
            "timezone_raw": row.timezone_raw or None,
            "definition_available": has_definition,
        },
        "comparison_support": comparison_support,
        "comparison_evidence": evidence,
    }


def _dependencies(
    context: dict[str, Any], definitions: dict[str, dict[str, Any]], names: set[str]
) -> list[dict[str, Any]]:
    edges: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str]] = set()
    environment_id = str(context.get("environment_id"))
    for target_name, definition in definitions.items():
        condition = str(definition.get("condition") or "")
        for fn, source_name in _dependency_refs(condition):
            if source_name not in names or source_name == target_name:
                continue
            kind = "finish_to_start" if fn in {"s", "success"} else "custom"
            key = (source_name, target_name, kind)
            if key in seen:
                continue
            seen.add(key)
            edges.append({
                "from_uid": _uid(environment_id, source_name),
                "to_uid": _uid(environment_id, target_name),
                "kind": kind,
                "condition": condition or None,
            })
    return edges


class AutoSysProvider:
    scheduler = "autosys"

    def __init__(self) -> None:
        self.config = load_connector_config()
        self._support = {key: "unknown" for key in SUPPORT_PARAMETERS}
        self._support.update({"actual_start": "supported", "actual_end": "supported", "status": "supported", "resolved_command": "unsupported"})

    def capabilities(self) -> dict[str, Any]:
        return {
            "topology": True,
            "dependencies": True,
            "runtime": True,
            "job_detail": False,
            "root_listing": False,
            "autosys_projection": True,
            "strict_parameter_support": True,
            "parameter_support": dict(self._support),
        }

    def health(self, context: dict[str, Any]) -> dict[str, Any]:
        host = _normalize_host(str(context.get("host") or ""))
        if not host:
            return {"healthy": False, "message": "AutoSys endpoint host is not configured"}
        try:
            with AutoSysHttpClient(self.config) as client:
                rows, _headers, meta = _runtime_request(client, self.config, context)
            return {"healthy": True, "message": f"HTTP {meta['http_status']}; matched {len(rows)} jobs"}
        except ConnectorError as exc:
            return {"healthy": False, "message": f"{exc.code}: {exc.message}"}

    def list_roots(self, context: dict[str, Any]) -> dict[str, Any]:
        return {"roots": []}

    def fetch_topology(self, context: dict[str, Any]) -> dict[str, Any]:
        if context.get("as_of_kind") != "business_date" or not context.get("as_of_value"):
            raise ConnectorError("invalid_request", "AutoSys connector requires a business_date COB")

        with AutoSysHttpClient(self.config) as client:
            rows, headers, runtime_meta = _runtime_request(client, self.config, context)
        pattern = str(runtime_meta.get("job_pattern") or "")
        definitions, definition_errors = _fetch_definitions(self.config, context, rows, pattern)

        if bool(self.config["definitions"].get("required", False)) and len(definitions) != len(rows):
            raise ConnectorError(
                "source_incomplete",
                f"AutoSys JIL retrieval incomplete ({len(definitions)}/{len(rows)})",
                details={"definition_error_counts": _count_values(definition_errors)},
            )

        names = {row.job_name for row in rows}
        jobs = [
            _job_payload(context, row, definitions.get(row.job_name), definitions, names)
            for row in rows
        ]
        edges = _dependencies(context, definitions, names)

        definition_complete = bool(rows) and len(definitions) == len(rows)
        if definition_complete:
            for key in JIL_PARAMETERS:
                self._support[key] = "supported"
            self._support["dependencies"] = "supported"
            self._support["topology_parent"] = "supported"
        else:
            for key in JIL_PARAMETERS:
                self._support[key] = "unknown"
            self._support["dependencies"] = "unknown"
            self._support["topology_parent"] = "unknown"

        return {
            "fetched_at": datetime.now().astimezone().isoformat(),
            "jobs": jobs,
            "dependencies": edges,
            "metadata": {
                "source": "autosys_web_endpoint",
                "cob_date": str(context.get("as_of_value")),
                "cob_semantics": "snapshot_label_only_not_source_request",
                "cob_used_in_http_request": False,
                "runtime_headers": headers,
                "runtime_rows": len(rows),
                "runtime_pages": runtime_meta.get("pages", 1),
                "runtime_http_status": runtime_meta.get("http_status"),
                "runtime_content_type": runtime_meta.get("content_type", ""),
                "source_host": runtime_meta.get("endpoint_host", ""),
                "job_pattern": pattern,
                "definitions_succeeded": len(definitions),
                "definitions_failed": len(definition_errors),
                "definition_error_counts": _count_values(definition_errors),
                "definition_complete": definition_complete,
            },
        }

    def fetch_job_detail(self, context: dict[str, Any], job_uid: str) -> dict[str, Any]:
        # Browse/Compare are snapshot-only; source job-detail reads are intentionally disabled.
        return {"job": None}


def _count_values(values: dict[str, str]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for value in values.values():
        counts[value] = counts.get(value, 0) + 1
    return counts


def _diagnostic_context(args: argparse.Namespace) -> dict[str, Any]:
    return {
        "environment_id": args.environment_id or f"autosys-{args.environment.lower()}",
        "environment": args.environment,
        "scheduler": "autosys",
        "host": args.host,
        "as_of_kind": "business_date",
        "as_of_value": args.cob,
        "root_box": None,
        "topology_id": None,
    }


def diagnose(context: dict[str, Any]) -> int:
    """Print compact, value-safe value-safe diagnostics for workstation validation."""
    provider = AutoSysProvider()
    cfg = provider.config
    print("AUTOSYS CONNECTOR DIAGNOSTICS v1")
    print(f"Environment : {context.get('environment') or context.get('environment_id')}")
    print(f"COB         : {context.get('as_of_value')}")
    host = _normalize_host(str(context.get("host") or ""))
    print(f"Host        : {urlsplit(host).netloc or '(missing)'}")
    print(f"Transport   : {cfg['transport'].get('engine')} / {cfg['transport'].get('auth_mode')}")
    try:
        with AutoSysHttpClient(cfg) as client:
            rows, headers, meta = _runtime_request(client, cfg, context)
        print(f"HTTP        : {meta.get('http_status')}")
        print(f"Content-Type: {meta.get('content_type') or '(unknown)'}")
        print(f"Pages       : {meta.get('pages', 1)}")
        print(f"Rows parsed : {meta.get('rows_before_filter', len(rows))}")
        print(f"Rows matched: {meta.get('rows_after_filter', len(rows))}")
        if meta.get("rows_after_dedup", len(rows)) != meta.get("rows_after_filter", len(rows)):
            print(f"Rows unique : {meta.get('rows_after_dedup', len(rows))}")
        print("Headers     : " + (" | ".join(headers) if headers else "(not detected)"))
        print(f"Detail links: {sum(1 for row in rows if row.detail_url)}/{len(rows)}")
        print("Status codes: " + (", ".join(sorted({row.st_ex_raw for row in rows if row.st_ex_raw})) or "(none)"))
        print("Timezone(s) : " + (", ".join(sorted({row.timezone_raw for row in rows if row.timezone_raw})) or "(none)"))

        sample_n = max(0, min(len(rows), int(cfg.get("diagnostics", {}).get("definition_sample", 8))))
        definitions, errors = _fetch_definitions(cfg, context, rows[:sample_n], str(meta.get("job_pattern") or "")) if sample_n else ({}, {})
        keys = sorted({key for value in definitions.values() for key in value})
        print(f"JIL sample  : {len(definitions)}/{sample_n}")
        print("JIL keys    : " + (", ".join(keys) if keys else "(none detected)"))
        if errors:
            print("JIL errors  : " + ", ".join(f"{k}={v}" for k, v in sorted(_count_values(errors).items())))

        definitions_required = bool(cfg.get("definitions", {}).get("required", False))
        jil_complete = sample_n > 0 and len(definitions) == sample_n
        if not rows:
            print("Result      : EMPTY (no jobs matched pattern)")
            return 0
        if definitions_required and not jil_complete:
            print("Result      : INCOMPLETE")
            print("Reason      : required JIL/definition sample is incomplete")
            return 3
        print("Result      : READY")
        return 0
    except ConnectorError as exc:
        print(f"Result      : FAILED {exc.code}")
        print(f"Reason      : {exc.message}")
        if exc.details:
            safe = exc.details
            if "form_count" in safe:
                print(f"Forms       : {safe.get('form_count')}")
            if "form_fields" in safe:
                fields = safe.get("form_fields") or []
                print("Form fields : " + (", ".join(str(v) for v in fields) if fields else "(none)"))
            if "table_count" in safe:
                print(f"Tables      : {safe.get('table_count')}")
            if "pre_count" in safe:
                print(f"PRE blocks  : {safe.get('pre_count')}")
            if "headers" in safe:
                headers = safe.get("headers") or []
                print("Headers     : " + (" | ".join(str(v) for v in headers) if headers else "(none)"))
            if "rows_before_filter" in safe:
                print(f"Rows parsed : {safe.get('rows_before_filter')}")
            if "rows_after_filter" in safe:
                print(f"Rows matched: {safe.get('rows_after_filter')}")
            if "pages" in safe:
                print(f"Pages       : {safe.get('pages')}")

        if exc.code in {"source_configuration_error", "source_schema_error"} and cfg.get("runtime", {}).get("method") == "AUTO":
            try:
                print("Discovery   : STRUCTURE PROBE")
                with AutoSysHttpClient(cfg) as discovery_client:
                    discovery = _safe_endpoint_discovery(discovery_client, cfg, context)
                labels = {
                    "probe_http": "Probe HTTP",
                    "probe_content_type": "Probe type",
                    "probe_final_host": "Final host",
                    "probe_final_path": "Final path",
                    "probe_final_query_keys": "Query keys",
                    "probe_body_bytes": "Body bytes",
                    "probe_title": "Page title",
                    "probe_forms": "Probe forms",
                    "probe_form_fields": "Probe fields",
                    "probe_tables": "Probe tables",
                    "probe_pre_blocks": "Probe PRE",
                    "probe_parsed_rows": "Probe rows",
                    "probe_headers": "Probe headers",
                    "probe_links": "Probe links",
                    "probe_script_paths": "Script paths",
                    "probe_route_hints": "Route hints",
                    "probe_auth_page_hint": "Auth page",
                    "probe_json_keys": "JSON keys",
                    "probe_json_shape": "JSON shape",
                    "probe_json_item_keys": "JSON item keys",
                }
                for key, label in labels.items():
                    if key in discovery:
                        print(f"{label:<12}: {discovery[key]}")
            except ConnectorError as probe_exc:
                print(f"Discovery   : FAILED {probe_exc.code}")
            hidden = sorted(set(safe) - {
                "form_count", "form_fields", "table_count", "pre_count", "headers",
                "rows_before_filter", "rows_after_filter", "pages", "job_pattern"
            })
            if hidden:
                print("Detail keys : " + ", ".join(hidden))
        return 2


def _main() -> int:
    if "--diagnose" not in sys.argv:
        return run(AutoSysProvider())
    parser = argparse.ArgumentParser(description="Run value-safe AutoSys endpoint diagnostics")
    parser.add_argument("--diagnose", action="store_true")
    parser.add_argument("--environment", required=True)
    parser.add_argument("--environment-id", default="")
    parser.add_argument("--host", required=True)
    parser.add_argument("--cob", required=True)
    args = parser.parse_args()
    return diagnose(_diagnostic_context(args))


if __name__ == "__main__":
    raise SystemExit(_main())
