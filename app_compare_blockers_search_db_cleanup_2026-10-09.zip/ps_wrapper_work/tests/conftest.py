import os
import tempfile
from pathlib import Path

import pytest

# Existing unit tests exercise the compact fixture unless a test explicitly opts into
# the canonical 2500-job dataset. Runtime default remains reference_2500.
os.environ.setdefault("MOCK_DATASET", "legacy_small")

# Global search_index is constructed when app.search.sqlite_fts is imported,
# often during test collection. Isolate it before any app imports can occur.
# Never let pytest write synthetic snapshot indices to data/search.db.
_TEST_SEARCH_DB_DIR = tempfile.TemporaryDirectory(prefix="ps-tool-pytest-fts-")
os.environ["SEARCH_DB_PATH"] = str(Path(_TEST_SEARCH_DB_DIR.name) / "search.db")


@pytest.fixture(autouse=True)
def _reset_cached_settings(monkeypatch, tmp_path):
    from app.config import get_settings

    monkeypatch.setenv("SNAPSHOT_DIR", str(tmp_path / "snapshots"))
    get_settings.cache_clear()
    yield
    get_settings.cache_clear()
