"""Indexes for O(1) tree child lookup on large snapshots."""

from __future__ import annotations

from app.models import JobNode, SnapshotJob, TopologySnapshot


def build_children_index(roots: list[JobNode]) -> dict[str, list[str]]:
    """Map parent job_uid -> ordered child job_uids."""
    index: dict[str, list[str]] = {}

    def walk(node: JobNode) -> None:
        if node.children:
            index[node.job.job_uid] = [c.job.job_uid for c in node.children]
            for child in node.children:
                walk(child)

    for root in roots:
        walk(root)
    return index


def _indexes_match_snapshot(snapshot: TopologySnapshot) -> bool:
    by_uid = snapshot.metadata.get("jobs_by_uid")
    if not isinstance(by_uid, dict):
        return False
    expected = {j.job_uid for j in snapshot.flat_jobs}
    return set(by_uid) == expected and snapshot.metadata.get("children_index") is not None


def ensure_topology_indexes(snapshot: TopologySnapshot) -> None:
    """Populate metadata indexes used by lazy tree and exports."""
    if _indexes_match_snapshot(snapshot):
        return
    snapshot.metadata.pop("children_index", None)
    snapshot.metadata.pop("jobs_by_uid", None)
    snapshot.metadata["children_index"] = build_children_index(snapshot.roots)
    snapshot.metadata["jobs_by_uid"] = {j.job_uid: j for j in snapshot.flat_jobs}


def child_count(snapshot: TopologySnapshot, job_uid: str) -> int:
    ensure_topology_indexes(snapshot)
    index = snapshot.metadata.get("children_index") or {}
    return len(index.get(job_uid, []))


def get_child_nodes(snapshot: TopologySnapshot, parent_uid: str) -> list[JobNode]:
    """Return shallow JobNode list (no nested children) for lazy tree expansion."""
    ensure_topology_indexes(snapshot)
    index = snapshot.metadata.get("children_index") or {}
    by_uid: dict[str, SnapshotJob] = snapshot.metadata.get("jobs_by_uid") or {}
    child_uids = index.get(parent_uid, [])
    return [
        JobNode(job=by_uid[uid], children=[])
        for uid in child_uids
        if uid in by_uid
    ]


def get_job(snapshot: TopologySnapshot, job_uid: str) -> SnapshotJob | None:
    """Return a job by UID using the snapshot index."""
    ensure_topology_indexes(snapshot)
    by_uid: dict[str, SnapshotJob] = snapshot.metadata.get("jobs_by_uid") or {}
    return by_uid.get(job_uid)


def lazy_roots(snapshot: TopologySnapshot) -> list[JobNode]:
    """Root nodes without embedded descendants (for lazy SSR)."""
    return [JobNode(job=r.job, children=[]) for r in snapshot.roots]
