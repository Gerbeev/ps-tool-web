"""One-click diagnostics for the complete workstation connector stack.

This module is intentionally operator-oriented: it prints compact diagnostics,
continues after individual failures, and writes the same output to a timestamped
log under data/runtime/diagnostics.
"""

from __future__ import annotations

import argparse
import os
import platform
import sys
from contextlib import redirect_stderr, redirect_stdout
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path
from typing import Callable, TextIO

from app.config import (
    endpoint_for_environment,
    get_settings,
    load_all_environments,
    resolve_scheduler,
)
from app.models import SchedulerType
from app.services.snapshot_generation import autosys_business_date
from workstation_connectors.autosys_connector import diagnose as diagnose_autosys
from workstation_connectors.process_scheduler_connector import (
    ConnectorError as PsConnectorError,
    ProcessSchedulerProvider,
    diagnose as diagnose_process_scheduler,
)

ROOT = Path(__file__).resolve().parent.parent


class Tee(TextIO):
    def __init__(self, *streams: TextIO) -> None:
        self.streams = streams

    def write(self, text: str) -> int:
        for stream in self.streams:
            stream.write(text)
            stream.flush()
        return len(text)

    def flush(self) -> None:
        for stream in self.streams:
            stream.flush()


@dataclass
class CheckResult:
    name: str
    status: str
    detail: str = ""


def _section(title: str) -> None:
    print()
    print("=" * 78)
    print(title)
    print("=" * 78)


def _context(entry, *, topology: str | None = None) -> dict[str, object]:
    scheduler = resolve_scheduler(entry)
    if scheduler == SchedulerType.AUTOSYS:
        return {
            "environment_id": entry.id,
            "environment": entry.environment,
            "scheduler": scheduler.value,
            "host": endpoint_for_environment(entry.id),
            "as_of_kind": "business_date",
            "as_of_value": autosys_business_date(date.today()),
            "root_box": None,
            "topology_id": None,
        }
    return {
        "environment_id": entry.id,
        "environment": entry.environment,
        "scheduler": scheduler.value,
        "host": endpoint_for_environment(entry.id),
        "as_of_kind": "latest",
        "as_of_value": "",
        "root_box": topology,
        "topology_id": topology,
    }


def _run_autosys(entry) -> CheckResult:
    _section(f"AUTOSYS / {entry.environment} / {entry.id}")
    host = endpoint_for_environment(entry.id)
    if not host:
        print("Result      : FAILED")
        print("Reason      : configured AutoSys host is empty")
        return CheckResult(entry.id, "FAIL", "empty host")
    code = diagnose_autosys(_context(entry))
    return CheckResult(entry.id, "PASS" if code == 0 else "FAIL", f"diagnostic exit={code}")


def _run_ps(entry) -> CheckResult:
    _section(f"PROCESS SCHEDULER / {entry.environment} / {entry.id}")
    host = endpoint_for_environment(entry.id)
    if not host:
        print("Result            : FAILED")
        print("Failure           : configured Process Scheduler host is empty")
        return CheckResult(entry.id, "FAIL", "empty host")

    context = _context(entry)
    try:
        provider = ProcessSchedulerProvider()
        roots = provider.list_roots(context)["roots"]
    except PsConnectorError as exc:
        print("Stage             : list_roots")
        print(f"Failure code      : {exc.code}")
        print(f"Failure           : {exc.message}")
        if exc.details:
            for key in sorted(exc.details):
                value = exc.details[key]
                if isinstance(value, (str, int, float, bool)):
                    print(f"{key:<18}: {value}")
        print("Result            : FAILED")
        return CheckResult(entry.id, "FAIL", f"list_roots: {exc.code}")

    print(f"Topology listing  : OK ({len(roots)} topologies)")
    if not roots:
        print("Result            : FAILED")
        print("Failure           : no topology names returned")
        return CheckResult(entry.id, "FAIL", "no topologies")

    # Full read probe of one returned topology. The topology name itself is not
    # printed so the log remains compact and data-minimal.
    selected = roots[0]
    code = diagnose_process_scheduler(_context(entry, topology=selected), topology=selected)
    return CheckResult(entry.id, "PASS" if code == 0 else "FAIL", f"full topology probe exit={code}")


def _run(scope: str) -> int:
    settings = get_settings()
    all_entries = load_all_environments()
    enabled = [entry for entry in all_entries if entry.enabled]

    _section("PS TOOL - FULL WORKSTATION DIAGNOSTICS")
    print(f"Timestamp          : {datetime.now().astimezone().isoformat(timespec='seconds')}")
    print(f"Python             : {sys.version.split()[0]} ({sys.executable})")
    print(f"Platform           : {platform.platform()}")
    print(f"Project root       : {ROOT}")
    print(f"Adapter mode       : {'MOCK' if settings.use_mock_adapters else 'REAL'}")
    print(f"Connector dir      : {settings.connector_dir}")
    print(f"Environment config : {len(all_entries)} total / {len(enabled)} enabled")
    print(f"Scope              : {scope}")

    results: list[CheckResult] = []
    if settings.use_mock_adapters:
        print()
        print("CONFIGURATION ERROR: USE_MOCK_ADAPTERS=true")
        print("Real connector diagnostics will still run, but the web application is currently in MOCK mode.")
        results.append(CheckResult("web-runtime-mode", "FAIL", "USE_MOCK_ADAPTERS=true"))
    else:
        results.append(CheckResult("web-runtime-mode", "PASS", "REAL"))

    selected_entries = []
    for entry in enabled:
        scheduler = resolve_scheduler(entry)
        if scope == "autosys" and scheduler != SchedulerType.AUTOSYS:
            continue
        if scope == "process_scheduler" and scheduler != SchedulerType.PROCESS_SCHEDULER:
            continue
        selected_entries.append(entry)

    if not selected_entries:
        results.append(CheckResult("enabled-environments", "FAIL", f"no enabled environments for {scope}"))
    else:
        results.append(CheckResult("enabled-environments", "PASS", str(len(selected_entries))))

    for entry in selected_entries:
        scheduler = resolve_scheduler(entry)
        try:
            if scheduler == SchedulerType.AUTOSYS:
                results.append(_run_autosys(entry))
            elif scheduler == SchedulerType.PROCESS_SCHEDULER:
                results.append(_run_ps(entry))
        except Exception as exc:  # keep the complete diagnostic run alive
            print(f"UNEXPECTED ERROR: {type(exc).__name__}: {exc}")
            results.append(CheckResult(entry.id, "FAIL", type(exc).__name__))

    _section("DIAGNOSTIC SUMMARY")
    for result in results:
        suffix = f" - {result.detail}" if result.detail else ""
        print(f"{result.status:<5} {result.name}{suffix}")

    failures = [item for item in results if item.status == "FAIL"]
    print()
    print(f"Overall            : {'FAILED' if failures else 'READY'}")
    print(f"Failures           : {len(failures)}")
    return 1 if failures else 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--scope",
        choices=("all", "autosys", "process_scheduler"),
        default="all",
        help="Diagnostic scope; launchers set this automatically.",
    )
    args = parser.parse_args()

    log_dir = ROOT / "data" / "runtime" / "diagnostics"
    log_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = log_dir / f"{args.scope}_diagnostics_{stamp}.log"

    original_stdout = sys.stdout
    original_stderr = sys.stderr
    with log_path.open("w", encoding="utf-8", newline="\n") as log:
        tee_out = Tee(original_stdout, log)
        tee_err = Tee(original_stderr, log)
        with redirect_stdout(tee_out), redirect_stderr(tee_err):
            print(f"Diagnostic log     : {log_path}")
            code = _run(args.scope)
            print(f"Diagnostic log     : {log_path}")
            return code


if __name__ == "__main__":
    raise SystemExit(main())
