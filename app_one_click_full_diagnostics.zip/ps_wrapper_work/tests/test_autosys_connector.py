from __future__ import annotations

from copy import deepcopy
from pathlib import Path

import workstation_connectors.autosys_connector as connector


RUNTIME_HTML = """
<html><body>
<form action="/report" method="get">
  <input name="jobMask" value="">
  <input name="cobDate" value="">
  <select name="environment"><option value="U1" selected>U1</option></select>
</form>
<table>
<tr><th>Job Name</th><th>Last Start</th><th>Last End</th><th>ST/Ex</th><th>Run/Ntry</th><th>Pri/Xit</th><th>TimeZone</th></tr>
<tr><td><a href="/jil?job=A">IB_CT_CVA_1109_U1_A</a></td><td>10/07/2026 01:02:03</td><td>10/07/2026 01:03:04</td><td>SU</td><td>123/1</td><td>0</td><td>London</td></tr>
<tr><td><a href="/jil?job=B">IB_CT_CVA_1109_U1_B</a></td><td>-----</td><td>-----</td><td>OI</td><td>0/0</td><td>-----</td><td>London</td></tr>
</table>
</body></html>
"""


class FakeHttpClient:
    submitted: list[tuple[str, str, dict[str, str]]] = []

    def __init__(self, _config):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return None

    def request(self, method: str, url: str, params: dict[str, str] | None = None):
        params = dict(params or {})
        self.submitted.append((method, url, params))
        if "/jil" in url:
            job = "IB_CT_CVA_1109_U1_A" if "A" in url else "IB_CT_CVA_1109_U1_B"
            parent = "IB_CT_CVA_1109_U1_B" if job.endswith("_A") else ""
            condition = "s(IB_CT_CVA_1109_U1_B)" if job.endswith("_A") else ""
            body = f"""<pre>insert_job: {job} job_type: CMD\nbox_name: {parent}\ncondition: {condition}\ncommand: echo ok\ntimezone: London</pre>"""
            return connector.HttpResult(url, 200, "text/html", body)
        if url.endswith("/report"):
            return connector.HttpResult(url, 200, "text/html", RUNTIME_HTML)
        landing = """<html><body><form action="/report" method="get"><input name="jobMask"><input name="cobDate"><select name="environment"><option value="U1" selected>U1</option></select></form></body></html>"""
        return connector.HttpResult(url, 200, "text/html", landing)


def _context() -> dict[str, str | None]:
    return {
        "environment_id": "autosys-u1",
        "environment": "U1",
        "scheduler": "autosys",
        "host": "https://autosys.example",
        "as_of_kind": "business_date",
        "as_of_value": "2026-10-07",
        "root_box": None,
        "topology_id": None,
    }


def test_parse_runtime_report_observed_columns():
    rows, headers, _page = connector.parse_runtime_report(RUNTIME_HTML, "https://autosys.example/report")
    assert headers == ["Job Name", "Last Start", "Last End", "ST/Ex", "Run/Ntry", "Pri/Xit", "TimeZone"]
    assert [row.job_name for row in rows] == ["IB_CT_CVA_1109_U1_A", "IB_CT_CVA_1109_U1_B"]
    assert rows[0].st_ex_raw == "SU"
    assert rows[0].detail_url == "https://autosys.example/jil?job=A"
    assert rows[1].last_start_raw == ""


def test_parse_current_jil_fixture():
    raw = Path("examples/autosys_endpoint/job_definition.sample.jil").read_text(encoding="utf-8")
    parsed = connector.parse_jil(raw)
    assert parsed["job_name"] == "IB_CT_CVA_1109_U1_DP_ADP_Accounts_Load"
    assert parsed["job_type"] == "CMD"
    assert parsed["box_name"] == "IB_CT_CVA_1109_U1_DP_ADP_Box"
    assert parsed["timezone"] == "London"
    assert parsed["condition"].startswith("s(IB_CT_CVA_1109_U1_DP_ADP_ClearedPositions_Load)")
    assert "$$(1109_GV_U1_CVA_Date)" in parsed["command"]


def test_status_mapping_for_observed_and_documented_codes():
    assert connector._status("SU") == "success"
    assert connector._status("RU") == "running"
    assert connector._status("IN") == "not_run"
    assert connector._status("OI") == "disabled"
    assert connector._status("AC") == "pending"
    assert connector._status("TE") == "killed"
    assert connector._status("FA") == "failure"


def test_dependency_parser_keeps_semantics_separate_from_box_parent():
    refs = connector._dependency_refs("s(A) & failure(B) | e(C, 1)")
    assert refs == [("s", "A"), ("failure", "B"), ("e", "C")]


def test_full_provider_uses_form_binding_and_returns_bridge_snapshot(monkeypatch):
    FakeHttpClient.submitted = []
    monkeypatch.setattr(connector, "AutoSysHttpClient", FakeHttpClient)
    provider = connector.AutoSysProvider()
    provider.config = deepcopy(connector._DEFAULT_CONFIG)
    provider.config["runtime"]["job_pattern"] = "IB_CT_CVA_1109_{environment}_*"
    provider.config["runtime"]["form"]["cob_value"] = "{cob_mmddyyyy}"
    provider.config["definitions"]["parallelism"] = 1

    result = provider.fetch_topology(_context())

    assert len(result["jobs"]) == 2
    assert result["jobs"][0]["status"] == "success"
    assert result["jobs"][0]["actual_start"].startswith("2026-10-07T01:02:03")
    assert result["jobs"][0]["autosys_jil"]["command"] == "echo ok"
    assert len(result["dependencies"]) == 1
    assert result["dependencies"][0]["kind"] == "finish_to_start"
    assert result["metadata"]["definition_complete"] is True

    report_calls = [call for call in FakeHttpClient.submitted if call[1].endswith("/report")]
    assert report_calls
    submitted = report_calls[0][2]
    assert submitted["jobMask"] == "IB_CT_CVA_1109_U1_*"
    assert submitted["cobDate"] == "10/07/2026"
    assert submitted["environment"] == "U1"


def test_connector_process_end_to_end_over_http(tmp_path):
    import json
    import os
    import subprocess
    import sys
    import threading
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    from urllib.parse import parse_qs, urlsplit

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_args):
            return

        def do_GET(self):
            parsed = urlsplit(self.path)
            if parsed.path == "/":
                body = '<form action="/report" method="get"><input name="jobMask"><input name="cobDate"><select name="environment"><option value="U1">U1</option></select></form>'
            elif parsed.path == "/report":
                query = parse_qs(parsed.query)
                assert query["jobMask"] == ["IB_CT_CVA_1109_U1_*"]
                assert query["cobDate"] == ["10/07/2026"]
                body = RUNTIME_HTML
            elif parsed.path == "/jil":
                query = parse_qs(parsed.query)
                suffix = query.get("job", ["A"])[0]
                job = f"IB_CT_CVA_1109_U1_{suffix}"
                condition = "s(IB_CT_CVA_1109_U1_B)" if suffix == "A" else ""
                body = f"<pre>insert_job: {job} job_type: CMD\ncondition: {condition}\ncommand: echo ok\ntimezone: London</pre>"
            else:
                self.send_response(404)
                self.end_headers()
                return
            payload = body.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        cfg = deepcopy(connector._DEFAULT_CONFIG)
        cfg["transport"].update({"engine": "httpx", "auth_mode": "none"})
        cfg["runtime"]["job_pattern"] = "IB_CT_CVA_1109_{environment}_*"
        cfg["definitions"]["parallelism"] = 1
        cfg_path = tmp_path / "autosys.json"
        cfg_path.write_text(json.dumps(cfg), encoding="utf-8")

        request = {
            "protocol": "scheduler-bridge",
            "version": 1,
            "request_id": "e2e-test",
            "operation": "fetch_topology",
            "context": {
                "environment_id": "autosys-u1",
                "environment": "U1",
                "scheduler": "autosys",
                "host": f"http://127.0.0.1:{server.server_port}",
                "as_of_kind": "business_date",
                "as_of_value": "2026-10-07",
                "root_box": None,
                "topology_id": None,
            },
        }
        env = dict(os.environ)
        env["AUTOSYS_CONNECTOR_CONFIG"] = str(cfg_path)
        completed = subprocess.run(
            [sys.executable, "workstation_connectors/autosys_connector.py"],
            input=json.dumps(request),
            text=True,
            capture_output=True,
            env=env,
            timeout=10,
            check=False,
        )
        assert completed.returncode == 0, completed.stderr
        response = json.loads(completed.stdout)
        assert response["ok"] is True, response
        assert response["request_id"] == "e2e-test"
        assert len(response["data"]["jobs"]) == 2
        assert response["data"]["metadata"]["definition_complete"] is True
        assert response["capabilities"]["strict_parameter_support"] is True
    finally:
        server.shutdown()
        thread.join(timeout=2)
        server.server_close()


def test_plain_text_jil_is_parsed():
    raw = "insert_job: JOB_A job_type: CMD\ncommand: echo hello\ntimezone: London\n"
    parsed = connector.parse_jil_page(raw, "https://autosys.example/jil")
    assert parsed["job_name"] == "JOB_A"
    assert parsed["command"] == "echo hello"


def test_plain_text_fixed_width_runtime_is_parsed():
    raw = (
        "Job Name                      Last Start          Last End            ST/Ex Run/Ntry       Pri/Xit TimeZone\n"
        "IB_CT_CVA_1109_U1_JOB_A       10/07/2026 01:02:03 10/07/2026 01:03:04 SU    123/1          0       London\n"
    )
    rows, _headers, _page = connector.parse_runtime_report(raw, "https://autosys.example/report")
    assert len(rows) == 1
    assert rows[0].job_name == "IB_CT_CVA_1109_U1_JOB_A"
    assert rows[0].st_ex_raw == "SU"


def test_definition_fetch_follows_nested_jil_link(monkeypatch):
    class NestedClient:
        def __init__(self, _config):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *_args):
            return None

        def request(self, _method, url, _params=None):
            if url.endswith('/detail'):
                return connector.HttpResult(url, 200, 'text/html', '<html><a href="/raw-jil">JIL Definition</a></html>')
            return connector.HttpResult(url, 200, 'text/plain', 'insert_job: JOB_A job_type: CMD\ncommand: echo ok\n')

    monkeypatch.setattr(connector, 'AutoSysHttpClient', NestedClient)
    cfg = deepcopy(connector._DEFAULT_CONFIG)
    row = connector.RuntimeRow(job_name='JOB_A', detail_url='https://autosys.example/detail')
    name, parsed, outcome = connector._fetch_one_definition(cfg, _context(), row, '*')
    assert name == 'JOB_A'
    assert outcome == 'ok'
    assert parsed['command'] == 'echo ok'


def test_runtime_filter_runs_after_pagination_and_reports_counts():
    page1 = """
    <html><body>
    <table>
    <tr><th>Job Name</th><th>Last Start</th><th>Last End</th><th>ST/Ex</th><th>Run/Ntry</th><th>Pri/Xit</th><th>TimeZone</th></tr>
    <tr><td>OTHER_JOB</td><td>10/07/2026 01:00:00</td><td>10/07/2026 01:01:00</td><td>SU</td><td>1/1</td><td>0</td><td>London</td></tr>
    </table>
    <a rel="next" href="/report?page=2">Next</a>
    </body></html>
    """
    page2 = """
    <html><body>
    <table>
    <tr><th>Job Name</th><th>Last Start</th><th>Last End</th><th>ST/Ex</th><th>Run/Ntry</th><th>Pri/Xit</th><th>TimeZone</th></tr>
    <tr><td>IB_CT_CVA_1109_U1_MATCH</td><td>10/07/2026 02:00:00</td><td>10/07/2026 02:01:00</td><td>SU</td><td>2/1</td><td>0</td><td>London</td></tr>
    </table>
    </body></html>
    """

    class PagedClient:
        def request(self, _method, url, _params=None):
            body = page2 if "page=2" in url else page1
            return connector.HttpResult(url, 200, "text/html", body)

    cfg = deepcopy(connector._DEFAULT_CONFIG)
    cfg["runtime"].update({
        "method": "GET",
        "url_template": "{host}/report",
        "query": {"job": "{job_pattern}", "cob": "{cob_date}"},
        "job_pattern": "IB_CT_CVA_1109_{environment}_*",
    })

    rows, _headers, meta = connector._runtime_request(PagedClient(), cfg, _context())

    assert [row.job_name for row in rows] == ["IB_CT_CVA_1109_U1_MATCH"]
    assert meta["pages"] == 2
    assert meta["rows_before_filter"] == 2
    assert meta["rows_after_filter"] == 1
    assert meta["rows_after_dedup"] == 1


def test_runtime_filter_error_reports_true_pre_filter_count():
    class SinglePageClient:
        def request(self, _method, url, _params=None):
            body = """
            <table>
            <tr><th>Job Name</th><th>Last Start</th><th>Last End</th><th>ST/Ex</th><th>Run/Ntry</th><th>Pri/Xit</th><th>TimeZone</th></tr>
            <tr><td>OTHER_JOB</td><td>10/07/2026 01:00:00</td><td>10/07/2026 01:01:00</td><td>SU</td><td>1/1</td><td>0</td><td>London</td></tr>
            </table>
            """
            return connector.HttpResult(url, 200, "text/html", body)

    cfg = deepcopy(connector._DEFAULT_CONFIG)
    cfg["runtime"].update({
        "method": "GET",
        "url_template": "{host}/report",
        "query": {"job": "{job_pattern}", "cob": "{cob_date}"},
        "job_pattern": "IB_CT_CVA_1109_{environment}_*",
    })

    try:
        connector._runtime_request(SinglePageClient(), cfg, _context())
    except connector.ConnectorError as exc:
        assert exc.code == "source_schema_error"
        assert exc.details["rows_before_filter"] == 1
        assert exc.details["rows_after_filter"] == 0
        assert exc.details["pages"] == 1
    else:
        raise AssertionError("Expected source_schema_error")


def test_diagnostics_marks_required_jil_failure_incomplete(monkeypatch, capsys):
    class DiagnosticClient:
        def __init__(self, _config):
            pass

        def __enter__(self):
            return self

        def __exit__(self, *_args):
            return None

    rows = [connector.RuntimeRow(job_name="JOB_A", detail_url="https://autosys.example/jil/A")]

    monkeypatch.setattr(connector, "AutoSysHttpClient", DiagnosticClient)
    monkeypatch.setattr(
        connector,
        "_runtime_request",
        lambda _client, _cfg, _context: (
            rows,
            ["Job Name", "ST/Ex"],
            {
                "http_status": 200,
                "content_type": "text/html",
                "pages": 1,
                "job_pattern": "JOB_*",
                "rows_before_filter": 1,
                "rows_after_filter": 1,
                "rows_after_dedup": 1,
            },
        ),
    )
    monkeypatch.setattr(connector, "_fetch_definitions", lambda *_args, **_kwargs: ({}, {"JOB_A": "jil_not_found"}))

    result = connector.diagnose(_context())
    output = capsys.readouterr().out

    assert result == 3
    assert "JIL sample  : 0/1" in output
    assert "Result      : INCOMPLETE" in output
    assert "required JIL/definition sample is incomplete" in output
    assert "Result      : READY" not in output
