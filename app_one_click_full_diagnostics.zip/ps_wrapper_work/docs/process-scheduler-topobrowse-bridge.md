# Process Scheduler through TopoBrowse.Bridge

Process Scheduler connectivity is provided by the existing C# `TopoBrowse.Bridge` component. The Python project does not implement WCF.

```text
Snapshots
  -> ExternalBridgeAdapter
  -> scheduler-bridge/v1
  -> process_scheduler_connector.py
  -> TopoBrowse.Bridge
  -> WCF / Process Scheduler
```

The shipped Python wrapper discovers the C# bridge, invokes only read operations, parses native results and normalizes them into `scheduler-bridge/v1`. Copy the complete C# bridge directory to `workstation_connectors/TopoBrowse.Bridge/` or configure another path with `PROCESS_SCHEDULER_BRIDGE_DIR`.

The wrapper supports an auto-detected CLI/JSON contract because the web engine must remain independent from the exact C# entry-point syntax. Once the real bridge invocation has been validated, the command templates may be pinned declaratively in `workstation_connectors/process_scheduler_connector.json`.

Use:

```cmd
diagnose-process-scheduler.cmd --environment ps-u5
```

and optionally:

```cmd
diagnose-process-scheduler.cmd --environment ps-u5 --topology <exact-topology-name>
```

See `ai-agent/process-scheduler-topobrowse-bridge.md` for the full implementation contract and normalization rules.
