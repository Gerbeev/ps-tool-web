# Workstation Connectors

This directory is the isolated source-system boundary used when `USE_MOCK_ADAPTERS=false`.

## AutoSys

`autosys_connector.py` is a **shipped application component**, not a workstation TODO. It calls the configured AutoSys web/self-help endpoint directly, authenticates using the configured local mechanism, parses the runtime report and JIL/detail pages, and returns `scheduler-bridge/v1`.

Endpoint request shape is declarative in `autosys_connector.json`. Do not edit Python on the workstation. If the internal page uses non-standard field names or a fixed route, adjust only this JSON configuration (or point `AUTOSYS_CONNECTOR_CONFIG` at an approved local JSON file).

Run compact value-safe diagnostics with:

```cmd
diagnose-autosys.cmd --environment autosys-u1
```

The command derives the endpoint from `config/autosys_environments.yaml` and the AutoSys COB as local `today - 1 day`.

Diagnostic result semantics are strict: `READY` means runtime rows were read and the required JIL sample was complete; `INCOMPLETE` means runtime access worked but required JIL/definition retrieval did not. Do not generate a real snapshot after `INCOMPLETE`.

## Process Scheduler

`process_scheduler_connector.py` and `process_scheduler_connector.json` are **shipped application components**. They do not implement WCF. The wrapper invokes the existing C# `TopoBrowse.Bridge`, which owns WCF transport and Process Scheduler service contracts.

Deploy the complete C# directory at the default location:

```text
workstation_connectors/TopoBrowse.Bridge/
```

or set `PROCESS_SCHEDULER_BRIDGE_DIR` to another directory. The wrapper auto-discovers `TopoBrowse.Bridge.exe`, then `.dll`, then the `.csproj` fallback through `dotnet run`. The exact command shape can be pinned in `process_scheduler_connector.json` after validation; no Python edit is required.

Run compact diagnostics with:

```cmd
diagnose-process-scheduler.cmd --environment ps-u5
```

To validate one topology end-to-end:

```cmd
diagnose-process-scheduler.cmd --environment ps-u5 --topology <exact-topology-name>
```

The wrapper preserves native Process Scheduler DTO fields and projects only semantics that are verified. `Box` and `Context` do not imply parent/dependency links. Explicit parents and topology edges are accepted. Verified `ConditionExpression` predicates (`ConditionDto.ConditionType` + `DependsOnJobName`) now provide dependency edges, but multiple predicates **without an explicit logical operator** remain unverified.

Connector scripts must not import `app` modules. The frozen `bridge_v1_runtime.py` owns stdin/stdout protocol handling. Source data, credentials, tokens and commands must never be printed to bridge stdout.


### Windows diagnostics runtime

Diagnostics always use the project `.venv\Scripts\python.exe`. Run `setup-env.cmd` once after unpacking a fresh archive; this installs `requirements.txt` including PyYAML. The launchers stop with a readable error and `pause` if the virtual environment or dependencies are missing. The application itself loads `.env` before resolving `USE_MOCK_ADAPTERS` and connector settings.

### Workstation diagnostics revision (2026-10-08)

For the `jil_name_mismatch` and `topobrowse_contract_mismatch` diagnostics, see
`docs/diagnostics-fixes-2026-10-08.md`. The wrapper reads known read-only commands
from the locally copied `Program.cs` and prints sanitized argument-attempt categories.
An exact C# CLI signature remains source-specific and can be pinned through the JSON
`commands` mapping; do not publish a topology from context-only output.

### Exact C# CLI contract (Program.cs reference)

For the supplied `TopoBrowse.Bridge`, the default connector configuration pins the native
`list-contexts --address`, `get-contexts --address --names`, and
`describe-job --address --context --job` commands. The bridge returns a `contexts`
array containing separate `boxes` and `commands` arrays (not an application `jobs`
array). The Python adapter combines those arrays only after selecting the exact
requested topology. Avoid legacy `--environment`, `--host`, `--json` flags.

The C# CLI and DTO reference is in
`docs/reference/TOPOBROWSE_PROGRAM_CS_REFERENCE.md`;
implementation details and deployment checks are in
`docs/process-scheduler-program-cs-contract-fix-2026-10-08.md`.

### Per-job Process Scheduler snapshot details

The shipped `process_scheduler_connector.json` enables read-only `describe-job`
for every job while generating a topology snapshot (`enable_job_detail: true`,
`job_detail_workers: 6`). Each result is stored on the job's native
`process_scheduler` object; common fields such as command, host and stdout/stderr
log files also populate the existing Browse fields. Failed individual requests
are counted and marked per job, without dropping the job itself. Runtime values
remain those from the original topology listing. See `docs/snapshots.md`.

### Process Scheduler native conditions and Blockers

The connector reads `ConditionExpression → Conditions → ConditionDto` from both
structured JSON and the indentation-based `describe-job` text output. Native
`ConditionType: Success` and `DependsOnJobName: JOB_A` become
`success(JOB_A)` and an explicit `JOB_A → target` edge in **new** snapshots.
`Failure` and `Done` predicates are supported as well. Multiple predicates
with an explicit `AND`/`OR` retain their boolean expression across every edge.
If a native list lacks an operator, its individual referenced job names are
recorded but the edges are **unverified**, not silently combined with AND.
Missing predecessor names and conflicts with topology-provided edges are also
unverified. The saved `process_scheduler.NativeConditionExpression` retains the
complete original condition tree for review; `metadata.native_conditions`
contains compact counters. Browse displays the predecessors and evidence
status. Blockers consumes only verified execution expressions to prove impact.
