# Immutable Snapshot Workflow

## Contract

`Snapshots` is the only web workflow allowed to read AutoSys or Process Scheduler.

The runtime dependency direction is fixed:

```text
Snapshots route
  -> snapshot_generation
      -> SchedulerAdapter / scheduler-bridge/v1
      -> validation
      -> SnapshotCatalogStore

Browse route  -> SnapshotCatalogStore
Compare route -> SnapshotCatalogStore
Export route  -> comparison session or SnapshotCatalogStore
Search route  -> loaded Browse/Compare session
```

Browse and Compare must not import `get_adapter`, `fetch_snapshot`, `ExternalBridgeAdapter`, or any connector implementation.

## AutoSys generation

AutoSys generation accepts only an environment. The application creates a `ComparisonContext` using the previous local calendar day as COB (`today - 1 day`) and asks the configured adapter for a topology snapshot. There is no business-date selector in Browse or Compare; the captured date is part of the immutable snapshot metadata.

## Process Scheduler generation

Process Scheduler generation has two source operations, both exposed only from the Snapshots view:

1. `list_roots` retrieves available topology names for the selected environment.
2. `fetch_topology` retrieves the selected topology and normalizes it into the engine model.

The chosen topology is stored in the snapshot context and catalog record. Browse and Compare only select a saved snapshot ID.

## Persistence

`SnapshotCatalogStore` writes runtime state under `SNAPSHOT_DIR`, defaulting to:

```text
data/runtime/snapshots/
  index.json
  <snapshot-id>.snapshot.json.gz
  <snapshot-id>.snapshot.json.gz
  ...
```

Each catalog record contains:

- `snapshot_id`
- capture/fetch timestamps
- scheduler and environment
- frozen `ComparisonContext`
- business date or topology scope
- job/dependency counts
- payload filename and SHA-256 checksum

Snapshot payloads are immutable. A new capture always produces a new ID and file. The index is published atomically after the snapshot payload is complete.

### Catalog index recovery

If `index.json` is unreadable, invalid, or missing while snapshot payloads exist,
the application **does not replace it with an empty index**. Instead:

1. **Snapshots** displays the recoverable entries from validated payload files in
   read-only mode, plus a warning and validation counts. Browse and Compare can
   still use these entries. The payload SHA-256 values are recalculated.
2. Creating and deleting snapshots is blocked until the catalog is repaired; no
   additional payload file is created when a save is rejected.
3. **Restore catalog** explicitly rebuilds `index.json` from the validated files.
   When the original index exists, it is preserved as
   `index.corrupt.<unique-id>.json`, never discarded. Payload files are unchanged.
4. If any payload is invalid (or no usable payload exists), automatic restoration
   is blocked. The warning remains visible and `logs/application.log` records
   the error category and counts without storing source data.

Recovered capture time uses the payload file's modification timestamp because
the exact original catalog creation time is not available in the payload itself.
Original user-defined catalog display names, if any, cannot be reconstructed
from payloads alone; source context and fetch timestamp are preserved.

## Failure behavior

Source fetch and validation happen before catalog publication. If adapter/bridge access fails or snapshot validation reports errors, no catalog record is added and all existing snapshots remain unchanged.

A snapshot whose payload is missing or fails its checksum is rejected when Browse/Compare attempt to load it.

## Source isolation

This boundary is deliberate for the bank-workstation deployment model. The web project can evolve independently while the workstation connector scripts remain fixed behind `scheduler-bridge/v1`. Process Scheduler source access continues one layer further through the existing C# `TopoBrowse.Bridge`; Browse/Compare never call it directly.

The test suite contains an explicit regression test that generates snapshots, replaces the adapter factory with a function that raises immediately, and then verifies that Browse and Compare still work. This guards against accidental live-source access being reintroduced later.


## Snapshot naming and deletion

- AutoSys display name: `<ENV>-AutoSys_<YYYY-MM-DD>_<HH-MM-SS>` using local capture time.
- Process Scheduler display name: `<ENV>-ProcessScheduler_<YYYY-MM-DD>_<TOPOLOGY>` using local capture date.
- AutoSys source `business_date` is always the previous local calendar day (`today - 1 day`).
- Snapshots can be deleted only from the Snapshots tab; deletion removes both the catalog entry and payload file.

## Live ingestion and local diagnostics

- Snapshots → **Generate snapshot** immediately starts one controlled background worker;
  `/api/snapshots/progress/<run_id>` reports current stage, count and timestamp.
  The UI polls every 1.5 seconds and refreshes the immutable catalog on completion.
  A reload of the browser page reattaches to the current run via `/api/snapshots/current`.
- Both `POST /api/snapshots/start` and the deprecated
  `POST /api/snapshots/generate` enqueue through that **same** worker. Both return
  JSON `{"run_id": "..."}` with HTTP 202; while a run is active both return HTTP 409
  with the active `run_id`. Neither request waits for ingestion to finish or returns
  the old generated-catalog HTML response. Poll the run status; on success read its
  `snapshot_id` and refresh `/api/snapshots/catalog`.
- AutoSys runtime parsing is followed by **all** JIL definitions (the standalone
  `RUN-AUTOSYS-DIAGNOSTICS.cmd` samples only 8), then model construction,
  validation, and atomic catalog persistence. The JIL connector reports a
  numeric checkpoint every 25 definitions, including failed count. No job names
  or definition contents are sent through progress events.
- The previous global **120-second** process timeout is inadequate for thousands
  of JIL requests. The AutoSys snapshot timeout has a separate minimum of
  **1800 seconds** (`PS_TOOL_AUTOSYS_SNAPSHOT_TIMEOUT_SEC`), even on workstations
  whose existing `.env` still specifies `PS_TOOL_CONNECTOR_TIMEOUT_SEC=120`.
  Process Scheduler now also has a dedicated 1800-second floor for full
  `fetch_topology` enrichment; lightweight operations keep the global timeout.
  The limit is a safety ceiling, **not** a performance guarantee. Individual
  AutoSys HTTP requests still obey the connector's own 60-second limit.
- **Settings → Advanced → Runtime diagnostics** allows toggling detailed logs.
  Default is **ON**, backed by `PS_TOOL_DEBUG=true` and persisted locally in
  `config/runtime_settings.json`. Logs are in `logs/application.log` (5 MB,
  5 rotated backups). Critical errors and final outcome are logged even when
  debug is off. `PS_TOOL_LOG_DIR` may override the folder.
- Logs include run ID, UTC timestamp, stage, processed/total counters, request ID,
  elapsed seconds, error type/code and numeric JIL error summaries. For caught
  application failures the fields `module`, `function` and `line` identify the
  application call site; wrapped failures retain the underlying error type.
  They deliberately exclude credentials, URLs, raw response bodies, source DTOs,
  job names, JIL, exception messages, traceback values and full command lines.
- Failed snapshot runs emit exactly one `snapshot_failed` event with the same
  `run_id` as the on-screen progress panel. The progress API returns a short
  message referring to the run ID, rather than the raw failure text. Unexpected
  application request errors return HTTP 500 and a short `request_id`, which is
  logged with the event `application_request_failed`. HTMX requests receive an
  HTML fragment; JSON API requests receive a JSON error body. Expected input
  validation failures keep their normal HTTP status codes.
- Only one snapshot generation is active at once; duplicate submissions return
  HTTP 409 with the active run ID. The subprocess and progress state live in the
  app process; **restarting the server terminates in-memory progress** and may
  interrupt the source operation. Avoid restarting during ingestion.
- If work stalls, check **Last update** and `logs/application.log` for the same
  `run_id`. During long JIL fetches the displayed percentage refers to the **current
  step**, not an invented estimate for the entire pipeline.

## Process Scheduler per-job detail capture

- Process Scheduler snapshot generation first captures a single `get-contexts` listing,
  then retrieves details for **each listed job** with the existing read-only
  `TopoBrowse.Bridge describe-job --context ... --job ...` command. No new endpoint,
  authentication mode, or schema migration is required.
- In `workstation_connectors/process_scheduler_connector.json`,
  `enable_job_detail: true` enables per-job enrichment and `job_detail_workers: 6`
  bounds parallel commands (valid range: 1–16). The default shipped config enables
  enrichment; set `enable_job_detail: false` to revert to listing-only snapshots.
- Native fields such as `Command`, `Machine`, `ResourceName`, `StdOutputFile`,
  `StdErrorFile`, `Schedule`, and `ConditionExpression` are preserved on each
  `job.process_scheduler` object. Recognized command, host and log-path fields
  also populate existing JIL-equivalent fields, so Browse displays them directly.
  Unrecognized native fields are retained instead of silently discarded.
- The status and runtime timestamps from the original topology listing remain
  authoritative even if `describe-job` returns a newer runtime state. A mismatched
  job name/context is rejected; failed detail calls never silently remove jobs.
- `snapshot.metadata.job_details` reports `requested`, `enriched`, `failed`, and
  numeric `errors` by sanitized failure category. Progress reports only counters,
  not job names, commands, or native response contents. Large topologies require
  more time: the `fetch_topology` operation uses a default **1800-second floor**
  (`PS_TOOL_PROCESS_SCHEDULER_SNAPSHOT_TIMEOUT_SEC`) even on older installations
  with a shorter general connector timeout. When falling back to `dotnet run`
  from C# source, enrichment is deliberately serial to avoid concurrent builds.
- Each job also records `attributes.job_detail_capture` (`complete` or
  `unavailable`) and a sanitized `job_detail_error` category when unsuccessful.
- Snapshots are durable local artifacts. Credentials in arbitrary environment
  variables are not persisted (`[REDACTED]`); recognized secret-bearing command
  switches/fields are also redacted. Review other custom command syntaxes before
  exporting a snapshot outside the approved environment.
- Existing snapshots stay immutable: regeneration of the same topology is required
  to populate fields that were not captured in old snapshots.

### Native Process Scheduler condition graph

- New snapshots also extract `ConditionExpression → Conditions → ConditionDto`
  from JSON and indentation-based `describe-job` output. Each recognized leaf
  (`ConditionType: Success`, `Failure`, `Done` with `DependsOnJobName`) records
  its predecessor. A lone leaf yields a verified dependency expression.
- Multiple leaves are interpreted only when the native structure provides an
  explicit `AND` or `OR`. A bare list has unknown aggregation semantics:
  references are preserved, but its dependency edges carry an unverified
  condition. Missing/ambiguous predecessors and disagreements with separately
  supplied topology edges are also unverified and do **not** create confirmed
  Blockers root causes.
- Raw structured trees remain on `job.process_scheduler.NativeConditionExpression`;
  the human-readable expression is in `ConditionExpression`, and
  `job.attributes.ps_condition_*` records evidence, referenced job names, and
  limitations. `snapshot.metadata.native_conditions` reports verified/unverified
  counts, missing references, resolved links and source conflicts.
- No schema migration is needed. Existing snapshots cannot gain missing
  conditions retroactively; create a fresh snapshot with detail enrichment on.

## Debug sample job limit

When Settings → Advanced → Debug is on, the Snapshots form accepts `job_limit` (default 50 in the UI, valid 1–10000; `0` or `full` selects the full capture). The API rejects positive job limits if debug is off. A full capture is the default for older API clients.

The limit is passed as `ComparisonContext.filters.debug_job_limit` through the typed v1 bridge request context. The isolated AutoSys connector slices parsed runtime rows **before** JIL retrieval; the Process Scheduler connector slices its selected topology's source rows **before** calling `describe-job`. Initial runtime/topology listing still reads from the source. The native bridge/Program.cs is unchanged.

The result is saved under its own UUID with a `_DEBUG_N` catalog name, job count and `debug_sample` metadata containing the original source count. Internal explicit edges are retained; links to omitted jobs are not considered evidence. These snapshots are for isolated testing, not complete downstream/blocker or migration analysis. Set `job_limit=0` for a full snapshot.
