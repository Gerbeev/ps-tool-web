"""Shipped Process Scheduler connector backed by the local TopoBrowse.Bridge component.

This module is intentionally independent from the web application's ``app`` package.
It translates scheduler-bridge/v1 operations into read-only TopoBrowse.Bridge calls,
normalizes returned Process Scheduler data, and never implements WCF itself.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

try:
    from bridge_v1_runtime import ConnectorError, run
except ImportError:
    from .bridge_v1_runtime import ConnectorError, run

_CONNECTOR_DIR = Path(__file__).resolve().parent
_DEFAULT_CONFIG = _CONNECTOR_DIR / "process_scheduler_connector.json"
_WEEKDAYS = {
    "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"
}


def _detail_progress(done: int, total: int, failed: int) -> None:
    """Send only counters across the connector stderr progress boundary."""
    if os.environ.get("PS_TOOL_PROGRESS_ENABLED") == "1":
        sys.stderr.write("PS_TOOL_PROGRESS " + json.dumps({
            "stage": "details", "done": done, "total": total, "failed": failed,
        }, separators=(",", ":")) + "\n")
        sys.stderr.flush()


_SENSITIVE_KEYS = re.compile(r"(?:password|passwd|secret|token|api[_-]?key|credential|private[_-]?key)", re.I)
_SENSITIVE_ARG = re.compile(
    r"(?i)((?<!\w)(?:--?|/)(?:password|passwd|secret|token|api[_-]?key|credential)\s*(?:=|:|\s)\s*)(?:\"[^\"]*\"|'[^']*'|\S+)"
)


def _safe_detail_value(key: str, value: Any) -> Any:
    """Do not persist secrets from endpoint free-form fields into durable snapshots."""
    if value is None:
        return None
    if _SENSITIVE_KEYS.search(key) or key.lower().replace("_", "") in {
        "environmentvariables", "envvars", "globalvariables"
    }:
        return "[REDACTED]"
    if isinstance(value, str):
        return _SENSITIVE_ARG.sub(r"\1[REDACTED]", value) if key.lower() in {
            "command", "resolvedcommand", "arguments", "commandline"
        } else value
    if isinstance(value, dict):
        return {str(k): _safe_detail_value(str(k), v) for k, v in value.items()}
    if isinstance(value, list):
        return [_safe_detail_value(key, item) for item in value]
    return value
_COMPARE_PARAMETERS = {
    "job_type", "machine", "box_name", "command", "watch_file", "condition", "profile",
    "envvars", "exit_code_policy", "date_conditions", "start_times", "start_mins",
    "days_of_week", "run_calendar", "exclude_calendar", "run_window", "must_start_times",
    "must_complete_times", "timezone", "watch_interval", "watch_file_min_size",
    "box_success", "box_failure", "box_terminator", "job_terminator", "std_out_file",
    "std_err_file", "owner", "permission", "group", "application", "priority",
    "resources", "alarm_if_fail", "alarm_if_terminated", "min_run_alarm",
    "max_run_alarm", "term_run_time", "n_retrys", "send_notification", "notification_id",
    "notification_msg", "notification_template", "notification_alarm_types", "auto_hold",
    "auto_delete", "resolved_command", "exit_code", "actual_start", "actual_end",
    "status", "dependencies", "topology_parent",
}


@dataclass(frozen=True)
class LaunchSpec:
    argv: list[str]
    kind: str
    target: Path


@dataclass
class BridgeResult:
    payload: Any
    mode: str
    command_label: str
    stdout_bytes: int


def _load_config() -> dict[str, Any]:
    path = Path(os.environ.get("PROCESS_SCHEDULER_CONNECTOR_CONFIG", "") or _DEFAULT_CONFIG)
    if not path.is_absolute():
        path = (_CONNECTOR_DIR / path).resolve()
    if not path.is_file():
        raise ConnectorError("connector_config_missing", f"Process Scheduler connector config not found: {path}")
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ConnectorError("connector_config_invalid", f"Invalid Process Scheduler connector config: {type(exc).__name__}") from exc
    if not isinstance(raw, dict):
        raise ConnectorError("connector_config_invalid", "Process Scheduler connector config must be a JSON object")
    return raw


def _positive_int(value: Any, default: int, *, minimum: int = 1, maximum: int = 4096) -> int:
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return default
    return max(minimum, min(maximum, parsed))


def _bridge_dir(config: dict[str, Any]) -> Path:
    raw = os.environ.get("PROCESS_SCHEDULER_BRIDGE_DIR") or str(config.get("bridge_dir") or "TopoBrowse.Bridge")
    path = Path(raw)
    if not path.is_absolute():
        path = (_CONNECTOR_DIR / path).resolve()
    return path


def _resolve_launcher(config: dict[str, Any]) -> LaunchSpec:
    explicit = config.get("launcher")
    bridge_dir = _bridge_dir(config)
    if isinstance(explicit, list) and explicit and all(isinstance(item, str) and item for item in explicit):
        rendered = [item.replace("{bridge_dir}", str(bridge_dir)) for item in explicit]
        return LaunchSpec(rendered, "configured", Path(rendered[-1]))
    if isinstance(explicit, str) and explicit.strip():
        rendered = explicit.strip().replace("{bridge_dir}", str(bridge_dir))
        return LaunchSpec([rendered], "configured", Path(rendered))

    if not bridge_dir.exists():
        raise ConnectorError(
            "topobrowse_bridge_missing",
            f"TopoBrowse.Bridge directory not found: {bridge_dir}",
            details={"expected_directory": str(bridge_dir)},
        )

    exe_candidates = sorted(
        bridge_dir.glob("bin/**/TopoBrowse.Bridge.exe"),
        key=lambda p: ("release" not in str(p).lower(), -len(p.parts), str(p).lower()),
    )
    if exe_candidates:
        target = exe_candidates[0].resolve()
        return LaunchSpec([str(target)], "exe", target)

    dll_candidates = sorted(
        bridge_dir.glob("bin/**/TopoBrowse.Bridge.dll"),
        key=lambda p: ("release" not in str(p).lower(), -len(p.parts), str(p).lower()),
    )
    if dll_candidates:
        dotnet = shutil.which("dotnet")
        if not dotnet:
            raise ConnectorError("dotnet_missing", "TopoBrowse.Bridge DLL found but dotnet is not available on PATH")
        target = dll_candidates[0].resolve()
        return LaunchSpec([dotnet, str(target)], "dll", target)

    csproj = bridge_dir / "TopoBrowse.Bridge.csproj"
    if csproj.is_file() and bool(config.get("allow_dotnet_run", True)):
        dotnet = shutil.which("dotnet")
        if not dotnet:
            raise ConnectorError("dotnet_missing", "TopoBrowse.Bridge source found but dotnet is not available on PATH")
        return LaunchSpec([dotnet, "run", "--project", str(csproj.resolve()), "--no-launch-profile", "--"], "source", csproj.resolve())

    raise ConnectorError(
        "topobrowse_launcher_missing",
        "TopoBrowse.Bridge was found but no executable/DLL launcher could be resolved",
        details={"bridge_dir": str(bridge_dir)},
    )


def _render_tokens(tokens: Iterable[str], values: dict[str, str]) -> list[str]:
    rendered: list[str] = []
    for token in tokens:
        value = str(token)
        for key, replacement in values.items():
            value = value.replace("{" + key + "}", replacement)
        if value:
            rendered.append(value)
    return rendered


def _observed_bridge_commands(config: dict[str, Any]) -> set[str]:
    """Identify read-only verbs present in the local C# dispatch source.

    Only known operations are eligible for automatic invocations.  Never
    execute an arbitrary command extracted from untrusted source content.
    """
    path = _bridge_dir(config) / "Program.cs"
    try:
        source = path.read_text(encoding="utf-8", errors="ignore")[:250_000]
    except OSError:
        return set()
    allowed = {"list-contexts", "get-contexts", "describe-job"}
    return {name for name in allowed if re.search(r'"' + re.escape(name) + r'"', source, re.I)}


def _candidate_commands(config: dict[str, Any], operation: str, values: dict[str, str]) -> list[list[str]]:
    configured = (config.get("commands") or {}).get(operation)
    if configured:
        if isinstance(configured, list) and configured and all(isinstance(item, str) for item in configured):
            return [_render_tokens(configured, values)]
        if isinstance(configured, list) and all(isinstance(item, list) for item in configured):
            return [_render_tokens(item, values) for item in configured]
        raise ConnectorError("connector_config_invalid", f"commands.{operation} must be a token list or list of token lists")

    # Matches the TopoBrowse.Bridge Program.cs CLI contract:
    # Main(args) requires --address for all verbs; get-contexts requires --names;
    # describe-job requires --context and --job. No environment/host/json flags.
    # Keep the older protocol only for explicitly pinned connector configurations.
    native: dict[str, list[str]] = {
        "list_roots": ["list-contexts", "--address", "{host}"],
        "fetch_topology": ["get-contexts", "--address", "{host}", "--names", "{topology}"],
        "fetch_job_detail": ["describe-job", "--address", "{host}", "--context", "{topology}", "--job", "{job}"],
    }
    if operation == "health":
        # Health is served via provider.list_roots; never invoke a nonexistent C# verb.
        raise ConnectorError("unsupported_operation", "Native TopoBrowse.Bridge does not implement a health CLI command")
    return [_render_tokens(native[operation], values)]


def _stdin_request(operation: str, values: dict[str, str]) -> dict[str, Any]:
    mapped = {
        "health": "health",
        "list_roots": "list_topologies",
        "fetch_topology": "fetch_topology",
        "fetch_job_detail": "fetch_job_detail",
    }[operation]
    return {
        "operation": mapped,
        "environment": values.get("environment", ""),
        "host": values.get("host", ""),
        "topology": values.get("topology") or None,
        "job": values.get("job") or None,
        "include_details": operation == "fetch_topology",
    }


def _run_process(
    launcher: LaunchSpec,
    args: list[str],
    *,
    stdin_text: str | None,
    timeout_sec: int,
    max_response_bytes: int,
) -> tuple[int, str, str]:
    argv = [*launcher.argv, *args]
    try:
        completed = subprocess.run(
            argv,
            input=stdin_text,
            text=True,
            encoding="utf-8",
            errors="replace",
            capture_output=True,
            timeout=timeout_sec,
            check=False,
            cwd=str(launcher.target.parent if launcher.target.parent.exists() else _CONNECTOR_DIR),
        )
    except subprocess.TimeoutExpired as exc:
        raise ConnectorError("topobrowse_timeout", f"TopoBrowse.Bridge timed out after {timeout_sec}s", retryable=True) from exc
    except OSError as exc:
        raise ConnectorError("topobrowse_start_failed", f"Could not start TopoBrowse.Bridge: {type(exc).__name__}") from exc

    stdout = completed.stdout or ""
    stderr = completed.stderr or ""
    if len(stdout.encode("utf-8", errors="replace")) > max_response_bytes:
        raise ConnectorError("topobrowse_response_too_large", "TopoBrowse.Bridge response exceeded configured size limit")
    return completed.returncode, stdout, stderr


def _json_from_text(text: str) -> Any:
    stripped = text.strip().lstrip("\ufeff")
    if not stripped:
        raise ValueError("empty output")
    try:
        return json.loads(stripped)
    except json.JSONDecodeError:
        pass
    starts = [pos for pos in (stripped.find("{"), stripped.find("[")) if pos >= 0]
    if not starts:
        raise ValueError("no JSON payload")
    start = min(starts)
    for end in range(len(stripped), start, -1):
        candidate = stripped[start:end].strip()
        if not candidate or candidate[-1] not in "}]":
            continue
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            continue
    raise ValueError("no complete JSON payload")


def _safe_exit_hint(stdout: str, stderr: str) -> str:
    """Classify native failure output without logging or returning its contents.

    Neither stderr nor stdout is considered safe to print: they may include
    credentials, job definitions, hostnames, file paths, or stack traces.
    """
    content = (stderr[:8192] + "\n" + stdout[:8192]).lower()
    rules = (
        ("unknown_command", r"(?:unknown|unrecognized|invalid|unsupported)\s+(?:command|verb|operation)|command\s+not\s+(?:found|recognized)"),
        ("unknown_option", r"(?:unknown|unrecognized|invalid|unsupported)\s+(?:option|flag|switch)"),
        ("missing_argument", r"(?:missing|required|insufficient|too\s+few)\s+(?:arguments?|parameters?|options?|values?)|missing\s+required\s+--[a-z-]+|indexoutofrangeexception"),
        ("usage", r"\busage\s*:|\bsyntax\s*:|show\s+help|\bhelp\s*:"),
        ("authentication", r"unauthori[sz]ed|access\s+denied|authentication\s+fail|securityexception"),
        ("transport", r"endpointnotfoundexception|endpoint\s+not\s+reachable|timeoutexception|timed\s+out|communicationexception|wcf\s+communication\s+error|socketexception|connection\s+refused|tls\s+handshake"),
        ("runtime_exception", r"unhandled\s+exception|exception\s*:|\bsystem\.[a-z0-9_.]+exception\b"),
        ("configuration", r"configurationerrorsexception|configuration\s+(?:is\s+)?(?:missing|invalid)|missing\s+setting"),
    )
    for name, pattern in rules:
        if re.search(pattern, content, re.I):
            return name
    return "unclassified" if content.strip() else "no_output"


def _safe_stream_presence(stdout: str, stderr: str) -> str:
    return f"out={'yes' if stdout.strip() else 'no'},err={'yes' if stderr.strip() else 'no'}"


def _source_cli_shape(program_text: str) -> dict[str, str]:
    """Expose a strictly bounded, value-free fingerprint of Program.cs CLI grammar.

    Reads source on the same workstation. Reports only numeric argument access,
    control-flow shape and booleans; never code, literals or exception messages.
    """
    result: dict[str, str] = {}
    # Exclude comments: a documented example is not a CLI contract.
    code = re.sub(r"/\*.*?\*/|//[^\r\n]*", " ", program_text, flags=re.S)
    accesses = sorted({int(n) for n in re.findall(r"\bargs\s*\[\s*(\d{1,2})\s*\]", code) if int(n) < 32})
    if accesses:
        result["source_arg_indexes"] = ",".join(map(str, accesses))
    # switch(args[0]), switch (args[1]?.ToLowerInvariant()) etc.
    slots = set()
    for m in re.finditer(r"\bswitch\s*\(\s*args\s*\[\s*(\d{1,2})\s*\]", code, flags=re.I):
        slots.add(int(m.group(1)))
    for m in re.finditer(r"\bargs\s*\[\s*(\d{1,2})\s*\]\s*\.\s*(?:ToLower|ToLowerInvariant)\s*\(\s*\)", code, flags=re.I):
        # Only a hint unless the surrounding code is a switch expression.
        if re.search(r"\bswitch\s*\{", code[m.end():m.end()+40]):
            slots.add(int(m.group(1)))
    if len(slots) == 1:
        result["source_dispatch_arg"] = str(next(iter(slots)))
    elif len(slots) > 1:
        result["source_dispatch_arg"] = "ambiguous"

    checks = []
    for m in re.finditer(r"\bargs\s*\.\s*Length\s*(<=|>=|==|!=|<|>)\s*(\d{1,2})", code, re.I):
        value = f"{m.group(1)}{m.group(2)}"
        if value not in checks:
            checks.append(value)
    if checks:
        result["source_arg_count_tests"] = ",".join(checks[:10])
    exit_sites = list(re.finditer(r"\breturn\s+2\s*;|\bEnvironment\s*\.\s*Exit\s*\(\s*2\s*\)", code, re.I))
    if exit_sites:
        reasons = set()
        for m in exit_sites[:20]:
            # Classify syntax only, not C# source or its string literals.
            neighborhood = code[max(0, m.start()-400):m.end()+80].lower()
            if re.search(r"args\s*\.\s*length|args\s*\[", neighborhood):
                reasons.add("argument_guard")
            if re.search(r"usage|syntax|help", neighborhood):
                reasons.add("usage_path")
            if re.search(r"default\s*:|unknown\s+command|invalid\s+command", neighborhood):
                reasons.add("dispatch_fallback")
            if re.search(r"catch\s*\(", neighborhood):
                reasons.add("exception_handler")
        result["source_exit2_paths"] = ",".join(sorted(reasons)) if reasons else "unclassified"
    else:
        result["source_exit2_paths"] = "none_found"
    return result


def _source_hints(config: dict[str, Any]) -> dict[str, bool]:
    program = _bridge_dir(config) / "Program.cs"
    if not program.is_file():
        return {"program_cs": False, "stdin_json": False, "args": False}
    try:
        text = program.read_text(encoding="utf-8", errors="ignore")[:250_000]
    except OSError:
        return {"program_cs": True, "stdin_json": False, "args": False}
    lowered = text.lower()
    return {
        "program_cs": True,
        "stdin_json": ("console.in" in lowered or "readtoend" in lowered) and ("json" in lowered or "deserialize" in lowered),
        "args": "string[] args" in lowered or "args[" in lowered or "args.length" in lowered,
    }


def _payload_matches_operation(operation: str, payload: Any) -> bool:
    source = _unwrap(payload)
    if operation == "health":
        return True
    if operation == "list_roots":
        if isinstance(source, list):
            return True
        if isinstance(source, dict):
            return any(_ci_get(source, key) is not None for key in ("roots", "topologies", "items", "names", "contexts"))
        if isinstance(source, str):
            return bool(re.search(r"(?mi)^\s*#?\s*NAME\s*$|^\s*\d+\s+\S+", source))
        return False
    if operation == "fetch_topology":
        def is_job_row(item: Any) -> bool:
            return isinstance(item, dict) and bool(_ci_get(item, "name", "job_name", "jobName")) and (
                _ci_get(item, "status", "Status", "jobType", "kind") is not None
            )
        if isinstance(source, list):
            return any(is_job_row(item) for item in source)
        if isinstance(source, dict):
            native_contexts = _ci_get(source, "contexts")
            if isinstance(native_contexts, list):
                return bool(native_contexts) and all(
                    isinstance(item, dict)
                    and isinstance(_ci_get(item, "boxes"), list)
                    and isinstance(_ci_get(item, "commands"), list)
                    for item in native_contexts
                )
            candidate = _ci_get(source, "jobs", "nodes", "items")
            if candidate is None and isinstance(_ci_get(source, "topology"), dict):
                candidate = _ci_get(_ci_get(source, "topology"), "jobs", "nodes", "items")
            return isinstance(candidate, list) and any(is_job_row(item) for item in candidate)
        if isinstance(source, str):
            upper = source.upper()
            return "STATUS" in upper and ("KIND" in upper or "SNAPSHOT TIME" in upper)
        return False
    if operation == "fetch_job_detail":
        if isinstance(source, dict):
            return True
        if isinstance(source, str):
            return "RAW WIRE FIELDS" in source.upper() or "JOB:" in source.upper()
        return source is None
    return False


def _invoke_bridge(config: dict[str, Any], operation: str, values: dict[str, str]) -> BridgeResult:
    if not values.get("host", "").strip():
        raise ConnectorError("invalid_request", "Process Scheduler endpoint address (host:port) is required")
    launcher = _resolve_launcher(config)
    timeout_sec = _positive_int(config.get("timeout_sec"), 180, maximum=3600)
    max_response_bytes = _positive_int(config.get("max_response_mb"), 128, maximum=1024) * 1024 * 1024
    mode = str(config.get("protocol_mode") or "auto").lower()
    hints = _source_hints(config)

    attempts: list[tuple[str, list[str], str | None]] = []
    args_candidates = _candidate_commands(config, operation, values)
    stdin_payload = json.dumps(_stdin_request(operation, values), separators=(",", ":"))

    if mode == "stdin_json":
        attempts.append(("stdin_json", [], stdin_payload))
    elif mode == "args":
        attempts.extend(("args", args, None) for args in args_candidates)
    elif mode == "auto":
        if hints["stdin_json"] and not hints["args"]:
            attempts.append(("stdin_json", [], stdin_payload))
            attempts.extend(("args", args, None) for args in args_candidates)
        else:
            attempts.extend(("args", args, None) for args in args_candidates)
            attempts.append(("stdin_json", [], stdin_payload))
    else:
        raise ConnectorError("connector_config_invalid", f"Unsupported protocol_mode: {mode}")

    failures: list[str] = []
    attempt_traces: list[str] = []
    for attempt_mode, args, stdin_text in attempts:
        verb = args[0] if args else "stdin-json"
        flags = "+".join(a for a in args if a.startswith("--"))
        label = f"{verb}({flags})" if flags else verb
        try:
            code, stdout, stderr = _run_process(
                launcher,
                args,
                stdin_text=stdin_text,
                timeout_sec=timeout_sec,
                max_response_bytes=max_response_bytes,
            )
        except ConnectorError as exc:
            failures.append(exc.code)
            attempt_traces.append(f"{label}:{exc.code}")
            if exc.code == "topobrowse_timeout":
                continue
            raise
        if code != 0:
            failures.append(f"exit_{code}")
            hint = _safe_exit_hint(stdout, stderr)
            presence = _safe_stream_presence(stdout, stderr)
            attempt_traces.append(f"{label}:exit_{code}[{hint};{presence}]")
            continue
        if not stdout.strip():
            failures.append("empty_stdout")
            attempt_traces.append(f"{label}:empty_stdout")
            continue
        try:
            payload = _json_from_text(stdout)
            if _payload_matches_operation(operation, payload):
                return BridgeResult(payload=payload, mode=attempt_mode, command_label=args[0] if args else "stdin-json", stdout_bytes=len(stdout.encode("utf-8", errors="replace")))
            failures.append("unexpected_output")
            kind = "json_list" if isinstance(payload, list) else "json_object" if isinstance(payload, dict) else "json_scalar"
            attempt_traces.append(f"{label}:unexpected_{kind}")
            continue
        except ValueError:
            if bool(config.get("allow_text_output", True)) and _payload_matches_operation(operation, stdout):
                return BridgeResult(payload=stdout, mode=attempt_mode + ":text", command_label=args[0] if args else "stdin-json", stdout_bytes=len(stdout.encode("utf-8", errors="replace")))
            failures.append("invalid_or_unexpected_output")
            attempt_traces.append(f"{label}:unexpected_text")

    details: dict[str, Any] = {
        "attempts": len(attempts),
        "failure_kinds": ",".join(sorted(set(failures))),
        "attempt_trace": "; ".join(attempt_traces[:12]),
    }
    details.update(_safe_contract_probe(config))
    raise ConnectorError(
        "topobrowse_contract_mismatch",
        "TopoBrowse.Bridge was started but its actual read-only contract does not match the configured wrapper contract",
        details=details,
    )




def _safe_contract_probe(config: dict[str, Any]) -> dict[str, str]:
    """Extract value-safe CLI/source contract hints from the copied C# bridge.

    Only source identifiers, public signatures and command-like literals are
    returned. Runtime payload values, hosts and business data are never emitted.
    """
    bridge_dir = _bridge_dir(config)
    result: dict[str, str] = {}

    csproj = bridge_dir / "TopoBrowse.Bridge.csproj"
    if csproj.is_file():
        try:
            text = csproj.read_text(encoding="utf-8", errors="ignore")[:200_000]
        except OSError:
            text = ""
        framework = re.search(r"<TargetFramework(?:Version)?>([^<]+)</TargetFramework(?:Version)?>", text, re.I)
        output_type = re.search(r"<OutputType>([^<]+)</OutputType>", text, re.I)
        result["target_framework"] = framework.group(1).strip() if framework else "unknown"
        result["output_type"] = output_type.group(1).strip() if output_type else "unknown"

    program = bridge_dir / "Program.cs"
    program_text = ""
    if program.is_file():
        try:
            program_text = program.read_text(encoding="utf-8", errors="ignore")[:500_000]
        except OSError:
            pass
    lowered = program_text.lower()
    modes: list[str] = []
    if "string[] args" in lowered or "args[" in lowered or "args.length" in lowered:
        modes.append("args")
    if "console.in" in lowered or "readtoend" in lowered:
        modes.append("stdin")
    if "console.readline" in lowered:
        modes.append("interactive")
    if "json" in lowered or "deserialize" in lowered:
        modes.append("json")
    result["program_input_hints"] = ",".join(dict.fromkeys(modes)) or "unknown"
    result["observed_read_verbs"] = ",".join(sorted(_observed_bridge_commands(config))) or "none"
    result.update(_source_cli_shape(program_text))
    # Flags are structural identifiers, not request or payload values.
    flags = set(re.findall(r'"(--[a-zA-Z][a-zA-Z-]{1,50})"', program_text))
    result["program_flags"] = ",".join(sorted(flags)[:24]) or "none"

    # Extract only identifier-like literals from CLI-dispatch-looking lines.
    command_literals: list[str] = []
    for line in program_text.splitlines():
        low = line.lower()
        if not any(token in low for token in ("args", "case ", "switch", "command", "console.readline")):
            continue
        for match in re.finditer(r'"([^"\\]{1,80})"', line):
            literal = match.group(1).strip()
            if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_.:-]{1,60}", literal):
                continue
            ll = literal.lower()
            if any(token in ll for token in ("topolog", "job", "list", "get", "browse", "health", "env", "host", "detail", "dump", "export")):
                command_literals.append(literal)
    if command_literals:
        result["command_literals"] = ",".join(list(dict.fromkeys(command_literals))[:30])
    else:
        result["command_literals"] = "none-detected"

    client = bridge_dir / "DbAccessBridgeClient.cs"
    method_signatures: list[str] = []
    if client.is_file():
        try:
            client_text = client.read_text(encoding="utf-8", errors="ignore")[:800_000]
        except OSError:
            client_text = ""
        method_rx = re.compile(
            r"public\s+(?:async\s+)?(?:static\s+)?[A-Za-z0-9_<>,.?\[\]]+\s+(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s*\((?P<params>[^)]*)\)",
            re.M,
        )
        for match in method_rx.finditer(client_text):
            params: list[str] = []
            raw_params = match.group("params").strip()
            if raw_params:
                for part in raw_params.split(","):
                    tokens = [t for t in re.split(r"\s+", part.strip()) if t and t not in {"ref", "out", "in", "params"}]
                    if tokens:
                        params.append(tokens[0])
            method_signatures.append(f"{match.group('name')}({','.join(params)})")
    result["client_public_methods"] = ";".join(list(dict.fromkeys(method_signatures))[:40]) or "none-detected"

    type_names: list[str] = []
    property_names: list[str] = []
    contracts = bridge_dir / "Contracts"
    if contracts.is_dir():
        for path in sorted(contracts.rglob("*.cs"))[:100]:
            try:
                text = path.read_text(encoding="utf-8", errors="ignore")[:300_000]
            except OSError:
                continue
            for m in re.finditer(r"public\s+(?:sealed\s+|abstract\s+|partial\s+)*(?:class|record|struct|interface|enum)\s+([A-Za-z_][A-Za-z0-9_]*)", text):
                type_names.append(m.group(1))
            for m in re.finditer(r"public\s+[A-Za-z0-9_<>,.?\[\]]+\s+([A-Za-z_][A-Za-z0-9_]*)\s*\{\s*get", text):
                property_names.append(m.group(1))
    result["contract_types"] = ",".join(list(dict.fromkeys(type_names))[:40]) or "none-detected"
    result["contract_properties"] = ",".join(list(dict.fromkeys(property_names))[:60]) or "none-detected"
    return result


def _ci_get(mapping: dict[str, Any], *names: str) -> Any:
    lookup = {str(key).lower().replace("_", "").replace(" ", ""): value for key, value in mapping.items()}
    for name in names:
        key = name.lower().replace("_", "").replace(" ", "")
        if key in lookup:
            return lookup[key]
    return None


def _unwrap(payload: Any) -> Any:
    current = payload
    for _ in range(4):
        if not isinstance(current, dict):
            break
        for key in ("data", "result", "payload", "value"):
            value = _ci_get(current, key)
            if value is not None and value is not current:
                current = value
                break
        else:
            break
    return current


def _parse_roots(payload: Any) -> list[str]:
    source = _unwrap(payload)
    if isinstance(source, str):
        roots: list[str] = []
        for line in source.splitlines():
            match = re.match(r"^\s*\d+\s+([^\s].*?)\s*$", line)
            if match:
                value = match.group(1).strip()
                if value and not value.upper().startswith("NAME"):
                    roots.append(value)
        return list(dict.fromkeys(roots))
    if isinstance(source, list):
        roots = []
        for item in source:
            if isinstance(item, str) and item.strip():
                roots.append(item.strip())
            elif isinstance(item, dict):
                name = _ci_get(item, "name", "topology", "topology_name")
                if name:
                    roots.append(str(name).strip())
        return list(dict.fromkeys(item for item in roots if item))
    if isinstance(source, dict):
        for key in ("roots", "topologies", "items", "names", "contexts"):
            value = _ci_get(source, key)
            if value is not None:
                return _parse_roots(value)
    raise ConnectorError("topobrowse_parse_error", "Could not parse topology list returned by TopoBrowse.Bridge")


def _parse_dt(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    if not text or text in {"-", "None", "null"}:
        return None
    normalized = text.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(normalized).isoformat()
    except ValueError:
        return text


def _duration_seconds(start: str | None, end: str | None) -> float | None:
    if not start or not end:
        return None
    try:
        left = datetime.fromisoformat(start.replace("Z", "+00:00"))
        right = datetime.fromisoformat(end.replace("Z", "+00:00"))
        return max(0.0, (right - left).total_seconds())
    except ValueError:
        return None


def _normalize_status(value: Any) -> tuple[str, str]:
    raw = "" if value is None else str(value).strip()
    key = re.sub(r"[^a-z0-9]", "", raw.lower())
    mapping = {
        "success": "success", "succeeded": "success", "completed": "success",
        "failed": "failure", "failure": "failure", "error": "failure",
        "running": "running", "starting": "running",
        "activated": "pending", "waiting": "pending", "onhold": "pending", "pending": "pending",
        "onice": "disabled", "disabled": "disabled",
        "cancelled": "killed", "canceled": "killed", "terminated": "killed", "killed": "killed",
        "inactive": "not_run", "notrun": "not_run",
    }
    return mapping.get(key, "unknown"), raw


def _stable_uid(environment: str, topology: str, name: str, native_id: str | None) -> str:
    basis = native_id or name
    digest = hashlib.sha256(f"process_scheduler\0{environment}\0{topology}\0{basis}".encode("utf-8")).hexdigest()[:24]
    return f"ps-{digest}"


def _wire_detail(row: dict[str, Any]) -> dict[str, Any]:
    for key in ("process_scheduler", "raw_wire_fields", "rawWireFields", "detail", "details", "job_detail", "jobDetail"):
        value = row.get(key)
        if isinstance(value, dict):
            # Keep native raw extension fields nested: they may contain keys
            # colliding with the verified summary and must not replace it.
            if key in {"raw_wire_fields", "rawWireFields"}:
                return dict(row)
            merged = dict(row)
            merged.update(value)
            return merged
    return dict(row)


def _schedule_projection(detail: dict[str, Any]) -> dict[str, Any]:
    jil: dict[str, Any] = {}
    job_type = _ci_get(detail, "JobType", "kind", "type")
    if job_type:
        value = str(job_type).strip()
        aliases = {"box": "BOX", "command": "CMD", "cmd": "CMD", "filewatcher": "FW", "file watcher": "FW"}
        jil["job_type"] = aliases.get(value.lower(), value)
    machine = _ci_get(detail, "Machine", "machine", "target_machine")
    if machine not in (None, "", "-"):
        jil["machine"] = str(machine)
    for target, source_names in {
        "command": ("Command", "CommandLine", "ExecutableCommand"),
        "std_out_file": ("StdOutputFile", "StdOutFile", "StandardOutputFile"),
        "std_err_file": ("StdErrorFile", "StdErrFile", "StandardErrorFile"),
        "condition": ("ConditionExpression",),
    }.items():
        value = _ci_get(detail, *source_names)
        if value not in (None, "", "-", "None"):
            jil[target] = str(value)
    schedule = _ci_get(detail, "Schedule")
    if schedule:
        tokens = [item.strip() for item in str(schedule).split(",") if item.strip()]
        if tokens and all(item.lower() in _WEEKDAYS for item in tokens):
            jil["days_of_week"] = ",".join(tokens)
    start_at = _ci_get(detail, "StartAtTime", "start_at")
    if start_at and re.fullmatch(r"\d{1,2}:\d{2}(?::\d{2})?", str(start_at).strip()):
        jil["start_times"] = str(start_at).strip()
        jil["date_conditions"] = 1
    owner = _ci_get(detail, "Owner")
    if owner not in (None, "", "None"):
        jil["owner"] = str(owner)
    description = _ci_get(detail, "Description")
    if description not in (None, "", "None"):
        jil["description"] = str(description)
    return jil


def _support_map(*, explicit_dependencies: bool, details_present: bool) -> dict[str, str]:
    support = {name: "unknown" for name in _COMPARE_PARAMETERS}
    support.update({
        "status": "supported",
        "actual_start": "supported",
        "actual_end": "supported",
        "machine": "supported",
        "job_type": "supported",
        "dependencies": "supported" if explicit_dependencies else "unsupported",
        "topology_parent": "unknown",
    })
    if details_present:
        support.update({
            "days_of_week": "supported",
            "start_times": "supported",
            "owner": "supported",
        })
    return support


def _text_topology(text: str, topology: str) -> dict[str, Any]:
    jobs: list[dict[str, Any]] = []
    snapshot_time: str | None = None
    total_jobs: int | None = None
    for line in text.splitlines():
        if line.lower().startswith("snapshot time:"):
            snapshot_time = line.split(":", 1)[1].strip()
        footer = re.match(r"^\s*(\d+)\s*/\s*(\d+)\s+lines\s*$", line, re.I)
        if footer:
            total_jobs = max(0, int(footer.group(2)) - 1)
            continue
        match = re.match(
            r"^\s*(BOX|JOB|CMD|COMMAND|FW|FILEWATCHER)\s{2,}(.+?)\s{2,}(Inactive|Activated|Starting|Running|Success|Terminated|Failed|Waiting|Cancelled|OnIce|OnHold)\s{2,}(.+?)\s{2,}(.+?)\s{2,}(.+?)\s*$",
            line,
            re.I,
        )
        if match:
            kind, name, status, start, finish, machine = match.groups()
            jobs.append({
                "Kind": kind,
                "Name": name.strip(),
                "Status": status,
                "LastStartTime": None if start.strip() == "-" else start.strip(),
                "LastFinishTime": None if finish.strip() == "-" else finish.strip(),
                "Machine": None if machine.strip() == "-" else machine.strip(),
            })
    if not jobs:
        raise ConnectorError("topobrowse_parse_error", "Could not parse topology rows returned by TopoBrowse.Bridge")
    if total_jobs is not None and len(jobs) < total_jobs:
        raise ConnectorError(
            "partial_topology",
            f"TopoBrowse.Bridge returned only {len(jobs)} of {total_jobs} topology rows",
            details={"visible_jobs": len(jobs), "expected_jobs": total_jobs},
        )
    return {"name": topology, "snapshot_time": snapshot_time, "jobs": jobs}


def _topology_source(payload: Any, topology: str) -> dict[str, Any]:
    source = _unwrap(payload)
    if isinstance(source, str):
        return _text_topology(source, topology)
    if isinstance(source, list):
        return {"name": topology, "jobs": source}
    if not isinstance(source, dict):
        raise ConnectorError("topobrowse_parse_error", "Topology response must be an object, list, or supported text table")

    native_contexts = _ci_get(source, "contexts")
    if isinstance(native_contexts, list):
        # Native get-contexts returns {ok,address,contexts:[{name,revisionNumber,
        # saveSnapshotTime,boxes:[...],commands:[...]}]}; never mistake a context
        # name listing for a full snapshot, and never select a different topology.
        matched = [entry for entry in native_contexts if isinstance(entry, dict)
                   and str(_ci_get(entry, "name") or "").casefold() == topology.casefold()]
        if len(matched) != 1:
            raise ConnectorError("topology_not_found", "Named topology was not uniquely returned by TopoBrowse.Bridge",
                                 details={"contexts_received": len(native_contexts), "matches": len(matched)})
        selected = matched[0]
        boxes = _ci_get(selected, "boxes")
        commands = _ci_get(selected, "commands")
        if not isinstance(boxes, list) or not isinstance(commands, list):
            raise ConnectorError("topobrowse_parse_error", "Native context is missing boxes or commands arrays")
        if any(not isinstance(item, dict) for item in boxes + commands):
            raise ConnectorError("topobrowse_parse_error", "Native context contains invalid job entries")
        jobs = [{**item, "Kind": "BOX"} for item in boxes]
        jobs.extend({**item, "Kind": "COMMAND"} for item in commands)
        return {
            "name": _ci_get(selected, "name"),
            "snapshot_time": _ci_get(selected, "saveSnapshotTime"),
            "revision": _ci_get(selected, "revisionNumber"),
            "job_count": len(jobs),
            "jobs": jobs,
        }

    if isinstance(_ci_get(source, "topology"), dict):
        topo_meta = dict(_ci_get(source, "topology"))
        jobs = _ci_get(source, "jobs", "nodes", "items")
        if jobs is None:
            jobs = _ci_get(topo_meta, "jobs", "nodes", "items")
        merged = dict(source)
        merged.update(topo_meta)
        if jobs is not None:
            merged["jobs"] = jobs
        return merged
    return source


def _explicit_dependencies(source: dict[str, Any]) -> list[dict[str, Any]]:
    value = _ci_get(source, "dependencies", "edges", "dependency_edges")
    if not isinstance(value, list):
        return []
    return [item for item in value if isinstance(item, dict)]


_PS_PREDICATES = {"success": "success", "failed": "failure", "failure": "failure", "done": "done"}
_PS_NAME = re.compile(r"[A-Za-z0-9_.:/\-$]+\Z")
_PS_LEAF = re.compile(r"(?i)\b(success|failure|done|s|f|d)\(([A-Za-z0-9_.:/\-$]+)\)")
_PS_EXPRESSION_TOKEN = re.compile(
    r"\s*(success\([A-Za-z0-9_.:/\-$]+\)|failure\([A-Za-z0-9_.:/\-$]+\)|"
    r"done\([A-Za-z0-9_.:/\-$]+\)|[sfd]\([A-Za-z0-9_.:/\-$]+\)|AND\b|OR\b|[()])",
    re.I,
)


@dataclass(frozen=True)
class NativeCondition:
    expression: str | None = None
    references: tuple[str, ...] = ()
    reason: str = ""

    @property
    def verified_syntax(self) -> bool:
        return bool(self.expression and self.references and not self.reason)


def _unique_names(names: Iterable[str]) -> tuple[str, ...]:
    return tuple(dict.fromkeys(name for name in names if name))


def _valid_ps_expression(text: str) -> bool:
    """Validate a small supported boolean grammar without importing app code."""
    if len(text) > 16_384:
        return False
    position = depth = count = 0
    operand_expected = True
    while position < len(text):
        if text[position:].isspace():
            break
        match = _PS_EXPRESSION_TOKEN.match(text, position)
        if not match or count >= 256:
            return False
        token = match.group(1).upper()
        count += 1
        position = match.end()
        if token == "(":
            if not operand_expected:
                return False
            depth += 1
        elif token == ")":
            if operand_expected or depth == 0:
                return False
            depth -= 1
        elif token in {"AND", "OR"}:
            if operand_expected:
                return False
            operand_expected = True
        else:
            if not operand_expected:
                return False
            operand_expected = False
    return count > 0 and depth == 0 and not operand_expected


def _native_predecessor_names(value: Any) -> tuple[str, ...]:
    """Collect names for graph navigation even in unfamiliar condition DTOs."""
    pending: list[tuple[Any, int]] = [(value, 0)]
    names: list[str] = []
    while pending and len(names) < 256:
        node, depth = pending.pop()
        if depth > 24:
            continue
        if isinstance(node, dict):
            for key, child in node.items():
                if str(key).lower().replace("_", "") == "dependsonjobname" and isinstance(child, str):
                    names.append(child.strip())
                else:
                    pending.append((child, depth + 1))
        elif isinstance(node, list):
            pending.extend((child, depth + 1) for child in node)
    return _unique_names(names)


def _native_condition(value: Any, *, depth: int = 0) -> NativeCondition:
    """Read native DTO condition trees without guessing the implicit list operator.

    Each leaf declares a typed dependency. More than one child needs an
    explicit AND/OR on the parent; source DTOs observed so far do not prove
    how a bare `Conditions` collection is combined.
    """
    if depth > 24:
        return NativeCondition(reason="condition_nesting_limit")
    if value is None or value == "":
        return NativeCondition()
    if isinstance(value, str):
        text = value.strip()
        if text.lower() in {"none", "null", "-"}:
            return NativeCondition()
        if text.startswith("{") or text.startswith("["):
            try:
                return _native_condition(json.loads(text), depth=depth + 1)
            except (ValueError, TypeError):
                pass
        leaves = list(_PS_LEAF.finditer(text))
        names = _unique_names(match.group(2) for match in leaves)
        # Only accept expressions made of supported functions, parentheses,
        # AND/OR. The Blockers parser is the final verifier of this grammar.
        if leaves and _valid_ps_expression(text):
            return NativeCondition(expression=text, references=names)
        return NativeCondition(references=names, reason="unsupported_native_expression")
    if isinstance(value, list):
        parts = [_native_condition(item, depth=depth + 1) for item in value]
        refs = _unique_names(name for part in parts for name in part.references)
        if len(parts) == 1:
            return parts[0]
        return NativeCondition(references=refs, reason="multiple_conditions_without_operator")
    if not isinstance(value, dict):
        return NativeCondition(reason="unsupported_native_condition_type")

    job_name = _ci_get(value, "DependsOnJobName", "DependencyJobName")
    if job_name is not None:
        name = str(job_name).strip()
        kind = str(_ci_get(value, "ConditionType") or "").strip().lower()
        predicate = _PS_PREDICATES.get(kind)
        if predicate and _PS_NAME.fullmatch(name):
            return NativeCondition(expression=f"{predicate}({name})", references=(name,))
        return NativeCondition(references=(name,) if name else (), reason="unsupported_condition_type_or_job_name")

    nested = _ci_get(value, "Conditions", "ConditionDto", "Condition", "ConditionExpression")
    if nested is None:
        # Retain references even for unfamiliar DTO containers, but never
        # infer the condition's boolean semantics.
        refs = _native_predecessor_names(value)
        return NativeCondition(references=refs, reason="unknown_condition_container")
    op = _ci_get(value, "LogicalOperator", "Operator", "BooleanOperator", "CombinationOperator", "JoinOperator")
    if op is not None and isinstance(nested, dict):
        # C# text output can wrap the list as Conditions: {ConditionDto: [...]}.
        # The explicit operator on its parent still governs those siblings.
        children = _ci_get(nested, "ConditionDto", "Condition")
        if len(nested) == 1 and isinstance(children, list):
            nested = children
    if isinstance(nested, list):
        parts = [_native_condition(item, depth=depth + 1) for item in nested]
    else:
        parts = [_native_condition(nested, depth=depth + 1)]
    refs = _unique_names(name for part in parts for name in part.references)
    if len(parts) == 1:
        return parts[0]
    operator = str(op or "").strip().upper()
    if operator not in {"AND", "OR"}:
        return NativeCondition(references=refs, reason="multiple_conditions_without_operator")
    if any(not part.verified_syntax for part in parts):
        return NativeCondition(references=refs, reason="unsupported_nested_condition")
    expression = f" {operator} ".join(f"({part.expression})" for part in parts)
    return NativeCondition(expression=expression, references=refs)


def _add_text_field(parent: dict[str, Any], key: str, value: Any) -> dict[str, Any]:
    """Represent repeated ConditionDto keys as an array, without losing siblings."""
    if key not in parent:
        parent[key] = value
    elif isinstance(parent[key], list):
        parent[key].append(value)
    else:
        parent[key] = [parent[key], value]
    return value if isinstance(value, dict) else {}


def _normalize_topology(payload: Any, context: dict[str, Any], topology: str) -> dict[str, Any]:
    source = _topology_source(payload, topology)
    rows = _ci_get(source, "jobs", "nodes", "items")
    if not isinstance(rows, list):
        raise ConnectorError("topobrowse_parse_error", "Topology response does not contain a jobs/nodes/items list")

    expected = _ci_get(source, "total_job_rows", "totalJobs", "job_count", "jobCount")
    if expected is not None:
        try:
            expected_count = int(expected)
        except (TypeError, ValueError):
            expected_count = None
        if expected_count is not None and len(rows) < expected_count:
            raise ConnectorError(
                "partial_topology",
                f"TopoBrowse.Bridge returned only {len(rows)} of {expected_count} topology rows",
                details={"visible_jobs": len(rows), "expected_jobs": expected_count},
            )

    environment = str(context.get("environment") or context.get("environment_id") or "")
    normalized: list[dict[str, Any]] = []
    normalized_pairs: list[tuple[dict[str, Any], dict[str, Any]]] = []
    uid_by_name: dict[str, str] = {}
    details_present = False
    captures: dict[str, NativeCondition] = {}

    for raw in rows:
        if not isinstance(raw, dict):
            continue
        detail = {str(key): _safe_detail_value(str(key), value)
                  for key, value in _wire_detail(raw).items()}
        name = _ci_get(detail, "Name", "name", "job_name", "jobName")
        if not name:
            continue
        name = str(name).strip()
        native_id_value = _ci_get(detail, "Id", "ID", "Uid", "UID", "JobId", "NodeId", "native_id")
        native_id = str(native_id_value).strip() if native_id_value not in (None, "") else None
        uid = _stable_uid(environment, topology, name, native_id)
        uid_by_name[name] = uid
        original_condition = _ci_get(detail, "ConditionExpression")
        if original_condition is None:
            raw_fields = _ci_get(detail, "raw_wire_fields", "rawWireFields")
            if isinstance(raw_fields, dict):
                original_condition = _ci_get(raw_fields, "ConditionExpression")
        if isinstance(original_condition, str) and original_condition.strip().lower() in {
            "", "none", "null", "-"
        }:
            original_condition = None
        condition = _native_condition(original_condition)
        if original_condition is not None:
            captures[uid] = condition
            if isinstance(original_condition, (dict, list)):
                detail["NativeConditionExpression"] = original_condition
            # Preserve a typed string field for the existing native reference
            # model; keep the full native tree in the open source fields.
            detail["ConditionExpression"] = (
                condition.expression if condition.verified_syntax
                else f"[unverified native condition: {condition.reason or 'empty'}]"
            )
        if any(_ci_get(detail, field) is not None for field in ("JobType", "Schedule", "StartAtTime", "ConditionExpression", "Box", "Context")):
            details_present = True

        status, status_raw = _normalize_status(_ci_get(detail, "Status", "status"))
        actual_start = _parse_dt(_ci_get(detail, "LastStartTime", "last_start", "lastStart"))
        actual_end = _parse_dt(_ci_get(detail, "LastFinishTime", "last_finish", "lastFinish", "LastEndTime"))
        exit_code_value = _ci_get(detail, "ExitCode", "exit_code")
        try:
            exit_code = int(exit_code_value) if exit_code_value not in (None, "", "-") else None
        except (TypeError, ValueError):
            exit_code = None

        process_scheduler = dict(detail)
        for key, value in list(process_scheduler.items()):
            if isinstance(value, datetime):
                process_scheduler[key] = value.isoformat()

        job = {
            "job_uid": uid,
            "scheduler_job_name": name,
            "scheduler_native_id": native_id,
            "parent_uid": None,
            "path_labels": [topology],
            "status": status,
            "status_raw": status_raw,
            "scheduled_start": None,
            "actual_start": actual_start,
            "actual_end": actual_end,
            "duration_sec": _duration_seconds(actual_start, actual_end),
            "exit_code": exit_code,
            "autosys_jil": {
                **{key: value for key, value in _schedule_projection(detail).items() if key != "condition"},
                **({"condition": condition.expression} if condition.verified_syntax else {}),
            },
            "autosys_run": {
                key: value for key, value in {
                    "actual_start": actual_start,
                    "actual_end": actual_end,
                    "exit_code": exit_code,
                }.items() if value is not None
            },
            "process_scheduler": process_scheduler,
            "attributes": {
                "topology": topology,
                "native_kind": str(_ci_get(detail, "Kind", "kind", "JobType") or ""),
                **({"ps_condition_status": "verified_syntax" if condition.verified_syntax else "unverified",
                    "ps_condition_predecessors": list(condition.references),
                    "ps_condition_reason": condition.reason}
                   if original_condition is not None else {}),
                **({"job_detail_capture": raw["_ps_detail_capture"]}
                   if "_ps_detail_capture" in raw else {}),
                **({"job_detail_error": raw["_ps_detail_error"]}
                   if "_ps_detail_error" in raw else {}),
            },
            "comparison_support": {},
            "comparison_evidence": {},
        }
        normalized.append(job)
        normalized_pairs.append((raw, job))

    if not normalized:
        raise ConnectorError("empty_topology", "TopoBrowse.Bridge returned no usable topology jobs")

    # Parent links are accepted only from explicitly named parent fields. Box/Context are
    # preserved natively but intentionally not treated as hierarchy until verified.
    for raw, job in normalized_pairs:
        detail = _wire_detail(raw)
        parent_name = _ci_get(detail, "ParentName", "Parent", "ParentJob", "ParentNode")
        parent_id = _ci_get(detail, "ParentId", "ParentUid", "ParentUID")
        if parent_name and str(parent_name).strip() in uid_by_name:
            job["parent_uid"] = uid_by_name[str(parent_name).strip()]
            job["path_labels"] = [topology, str(parent_name).strip()]
        elif parent_id:
            parent_id_text = str(parent_id).strip()
            for candidate in normalized:
                if candidate.get("scheduler_native_id") == parent_id_text:
                    job["parent_uid"] = candidate["job_uid"]
                    job["path_labels"] = [topology, candidate["scheduler_job_name"]]
                    break

    deps_source = _explicit_dependencies(source)
    deps: list[dict[str, Any]] = []
    job_uids = {job["job_uid"] for job in normalized}
    for item in deps_source:
        from_name = _ci_get(item, "from", "from_name", "predecessor", "source", "parent")
        to_name = _ci_get(item, "to", "to_name", "successor", "target", "child")
        from_uid = _ci_get(item, "from_uid", "fromId", "source_id")
        to_uid = _ci_get(item, "to_uid", "toId", "target_id")
        if from_uid not in job_uids and from_name:
            from_uid = uid_by_name.get(str(from_name).strip())
        if to_uid not in job_uids and to_name:
            to_uid = uid_by_name.get(str(to_name).strip())
        if not from_uid or not to_uid:
            continue
        kind = str(_ci_get(item, "kind", "type") or "finish_to_start").lower()
        if kind not in {"finish_to_start", "start_to_start", "file_trigger", "custom"}:
            kind = "custom"
        deps.append({
            "from_uid": str(from_uid),
            "to_uid": str(to_uid),
            "kind": kind,
            "condition": _ci_get(item, "condition", "expression"),
        })

    # Native per-job conditions are the execution-graph source whenever this
    # target has no explicit topology edges. Never invent an AND for bare
    # Conditions lists or silently accept partially resolved references.
    original_explicit_count = len(deps)
    explicit_targets = {dep["to_uid"] for dep in deps}
    native_stats = {"jobs_with_conditions": len(captures), "verified_syntax": 0,
                    "unverified": 0, "resolved_edges": 0, "missing_references": 0,
                    "explicit_targets_preserved": 0, "source_conflicts": 0}
    name_counts = Counter(job["scheduler_job_name"] for job in normalized)
    for job in normalized:
        uid = job["job_uid"]
        capture = captures.get(uid)
        if not capture:
            continue
        missing = [name for name in capture.references if name_counts[name] != 1]
        job["attributes"]["ps_condition_missing_predecessors"] = missing
        native_stats["missing_references"] += len(missing)
        verified = capture.verified_syntax and not missing
        native_stats["verified_syntax" if verified else "unverified"] += 1
        job["attributes"]["ps_condition_status"] = "verified" if verified else "unverified"
        if missing and not capture.reason:
            job["attributes"]["ps_condition_reason"] = "missing_or_ambiguous_predecessor"
        if uid in explicit_targets:
            native_stats["explicit_targets_preserved"] += 1
            existing = [edge for edge in deps if edge["to_uid"] == uid]
            same_predecessors = verified and {
                edge["from_uid"] for edge in existing
            } == {uid_by_name[name] for name in capture.references}
            same_condition = all(
                (edge["condition"] or "").strip() == (capture.expression or "").strip()
                for edge in existing
            )
            if same_predecessors and all(not edge["condition"] for edge in existing):
                # A verified source expression may complete otherwise bare
                # edges, provided the predecessor sets match exactly.
                for edge in existing:
                    edge["condition"] = capture.expression
            elif not (same_predecessors and same_condition):
                for edge in existing:
                    edge["condition"] = "PS_UNVERIFIED_NATIVE_CONFLICT"
                job["attributes"]["ps_condition_status"] = "unverified"
                job["attributes"]["ps_condition_reason"] = "native_explicit_conflict"
                native_stats["source_conflicts"] += 1
                if verified:
                    native_stats["verified_syntax"] -= 1
                    native_stats["unverified"] += 1
            continue
        if not capture.references:
            continue
        condition_text = capture.expression if verified else "PS_UNVERIFIED_NATIVE_CONDITION"
        for predecessor in capture.references:
            if name_counts[predecessor] != 1:
                continue
            predecessor_uid = uid_by_name[predecessor]
            # Self-reference cannot be published as a verified dependency.
            if predecessor_uid == uid:
                native_stats["unverified"] += bool(verified)
                native_stats["verified_syntax"] -= bool(verified)
                job["attributes"]["ps_condition_status"] = "unverified"
                job["attributes"]["ps_condition_reason"] = "self_reference"
                continue
            deps.append({"from_uid": predecessor_uid, "to_uid": uid,
                         "kind": "finish_to_start", "condition": condition_text})
            native_stats["resolved_edges"] += 1

    fetched = _parse_dt(_ci_get(source, "snapshot_time", "snapshotTime", "fetched_at", "fetchedAt"))
    metadata = {
        "source": "TopoBrowse.Bridge",
        "topology": topology,
        "revision": _ci_get(source, "revision", "rev"),
        "native_job_count": len(normalized),
        "native_detail_fields_observed": details_present,
        "explicit_dependency_count": original_explicit_count,
        "native_dependency_count": len(deps) - original_explicit_count,
        "native_conditions": native_stats,
    }
    return {
        "fetched_at": fetched or datetime.now(timezone.utc).isoformat(),
        "jobs": normalized,
        "dependencies": deps,
        "metadata": metadata,
        "_details_present": details_present,
        "_explicit_dependencies": bool(deps),
    }


def _detail_source(payload: Any) -> dict[str, Any] | None:
    source = _unwrap(payload)
    if source is None:
        return None
    if isinstance(source, dict):
        summary = _ci_get(source, "summary")
        if isinstance(summary, dict):
            raw = _ci_get(source, "raw")
            # Native raw fields are source properties, not inferred graph edges.
            # Summary values take precedence when both representations exist.
            combined = {**(raw if isinstance(raw, dict) else {}), **summary}
            if isinstance(raw, dict):
                combined["raw_wire_fields"] = raw
            combined["Kind"] = _ci_get(source, "kind") or _ci_get(summary, "jobType")
            return combined
        for key in ("job", "detail", "job_detail"):
            value = _ci_get(source, key)
            if isinstance(value, dict):
                return _wire_detail(value)
        return source
    if isinstance(source, str):
        fields: dict[str, Any] = {}
        raw_section = False
        stack: list[tuple[int, dict[str, Any]]] = [(-1, fields)]
        for line in source.splitlines():
            if "raw wire fields" in line.lower():
                raw_section = True
                continue
            if raw_section and ":" in line:
                indent = len(line) - len(line.lstrip())
                key, value = line.lstrip().split(":", 1)
                key = re.sub(r"^-\s+", "", key).strip()
                if not key:
                    continue
                text = value.strip()
                if not text:
                    parsed = {}
                elif text in {"None", "null", "-"}:
                    parsed: Any = None
                elif text.lower() in {"true", "false"}:
                    parsed = text.lower() == "true"
                else:
                    parsed = text
                while len(stack) > 1 and stack[-1][0] >= indent:
                    stack.pop()
                child = _add_text_field(stack[-1][1], key, parsed)
                if isinstance(parsed, dict):
                    stack.append((indent, child))
        return fields or None
    return None


def _enrich_topology_details(
    config: dict[str, Any], context: dict[str, Any], topology: str,
    source: dict[str, Any],
) -> dict[str, int | dict[str, int]]:
    """Fetch one read-only describe-job per row, with bounded parallelism.

    Runtime status/timestamps come from the topology listing, which is a single
    snapshot of the source. Later detail responses are definitions, not a new
    replacement runtime snapshot. A failed detail fetch never drops a job.
    """
    rows = _ci_get(source, "jobs", "nodes", "items")
    if not isinstance(rows, list):
        return {"requested": 0, "enriched": 0, "failed": 0, "errors": {}}

    targets = [(index, str(_ci_get(row, "Name", "job_name", "jobName") or "").strip())
               for index, row in enumerate(rows) if isinstance(row, dict)
               and _ci_get(row, "Name", "job_name", "jobName")]
    total = len(targets)
    failed = 0
    enriched = 0
    errors: Counter[str] = Counter()
    values = {
        "environment": str(context.get("environment") or context.get("environment_id") or ""),
        "host": str(context.get("host") or ""),
        "topology": topology,
    }

    def fetch(name: str) -> dict[str, Any]:
        result = _invoke_bridge(config, "fetch_job_detail", {**values, "job": name})
        detail = _detail_source(result.payload)
        if not isinstance(detail, dict) or not detail:
            raise ConnectorError("empty_job_detail", "Job detail payload contained no fields")
        returned_name = _ci_get(detail, "Name", "job_name", "jobName")
        if not returned_name or str(returned_name).strip() != name:
            raise ConnectorError("job_detail_identity_mismatch", "Job detail name does not match requested job")
        returned_topology = _ci_get(detail, "Context", "Topology", "TopologyName")
        if returned_topology not in (None, "", topology):
            raise ConnectorError("job_detail_context_mismatch", "Job detail belongs to another topology")
        return {str(key): _safe_detail_value(str(key), value) for key, value in detail.items()}

    _detail_progress(0, total, 0)
    workers = _positive_int(config.get("job_detail_workers"), 6, maximum=16)
    # Multiple concurrent `dotnet run` invocations of the same source project
    # can race its build output. Compiled .exe/.dll launchers remain parallel.
    if _resolve_launcher(config).kind == "source":
        workers = 1
    with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="ps-detail") as pool:
        futures = {pool.submit(fetch, name): (index, name) for index, name in targets}
        for future in as_completed(futures):
            index, _ = futures[future]
            try:
                detail = future.result()
            except ConnectorError as exc:
                failed += 1
                errors[exc.code] += 1
                rows[index]["_ps_detail_capture"] = "unavailable"
                rows[index]["_ps_detail_error"] = exc.code
            except Exception:
                # Source-specific serialization failures should be visible as
                # missing details, never erase a successfully listed job.
                failed += 1
                errors["invalid_job_detail"] += 1
                rows[index]["_ps_detail_capture"] = "unavailable"
                rows[index]["_ps_detail_error"] = "invalid_job_detail"
            else:
                listing = rows[index]
                # The listing owns runtime state; detail owns other source fields.
                # Never let a later response replace the name or graph identity.
                protected = {"name", "status", "laststarttime", "lastfinishtime", "id", "uid", "jobid", "nodeid"}
                merged = dict(listing)
                for key, value in detail.items():
                    if re.sub(r"[^a-z0-9]", "", key.lower()) in protected and _ci_get(listing, key) not in (None, "", "-"):
                        continue
                    merged[key] = value
                rows[index] = merged
                rows[index]["_ps_detail_capture"] = "complete"
                enriched += 1
            done = enriched + failed
            if done % 10 == 0 or done == total:
                _detail_progress(done, total, failed)
    return {"requested": total, "enriched": enriched, "failed": failed,
            "errors": dict(sorted(errors.items()))}


class ProcessSchedulerProvider:
    scheduler = "process_scheduler"

    def __init__(self) -> None:
        self.config = _load_config()
        self._details_present = False
        self._explicit_dependencies = False

    def capabilities(self) -> dict[str, Any]:
        return {
            "topology": True,
            "dependencies": self._explicit_dependencies,
            "runtime": True,
            "job_detail": bool(self.config.get("enable_job_detail", False)),
            "root_listing": True,
            "autosys_projection": True,
            "strict_parameter_support": True,
            "parameter_support": _support_map(
                explicit_dependencies=self._explicit_dependencies,
                details_present=self._details_present,
            ),
        }

    def _values(self, context: dict[str, Any], *, job: str = "") -> dict[str, str]:
        return {
            "environment": str(context.get("environment") or context.get("environment_id") or ""),
            "host": str(context.get("host") or ""),
            "topology": str(context.get("topology_id") or context.get("root_box") or ""),
            "job": job,
        }

    def health(self, context: dict[str, Any]) -> dict[str, Any]:
        try:
            launcher = _resolve_launcher(self.config)
            roots = self.list_roots(context)["roots"]
            return {
                "healthy": True,
                "message": f"TopoBrowse.Bridge {launcher.kind} ready; {len(roots)} topologies visible",
            }
        except ConnectorError as exc:
            return {"healthy": False, "message": f"{exc.code}: {exc.message}"}

    def list_roots(self, context: dict[str, Any]) -> dict[str, Any]:
        values = self._values(context)
        result = _invoke_bridge(self.config, "list_roots", values)
        roots = _parse_roots(result.payload)
        if not roots:
            raise ConnectorError("no_topologies", "TopoBrowse.Bridge returned no topology names")
        return {"roots": roots}

    def fetch_topology(self, context: dict[str, Any]) -> dict[str, Any]:
        values = self._values(context)
        topology = values["topology"].strip()
        if not topology:
            raise ConnectorError("invalid_request", "Process Scheduler topology_id is required")
        result = _invoke_bridge(self.config, "fetch_topology", values)
        source = _topology_source(result.payload, topology)
        detail_counts: dict[str, Any] = {"requested": 0, "enriched": 0, "failed": 0, "errors": {}}
        if bool(self.config.get("enable_job_detail", False)):
            detail_counts = _enrich_topology_details(self.config, context, topology, source)
        normalized = _normalize_topology(source, context, topology)
        self._details_present = bool(normalized.pop("_details_present", False))
        self._explicit_dependencies = bool(normalized.pop("_explicit_dependencies", False))
        normalized["metadata"].update({
            "topobrowse_protocol_mode": result.mode,
            "topobrowse_command": result.command_label,
            "job_details": detail_counts,
        })
        return normalized

    def fetch_job_detail(self, context: dict[str, Any], job_uid: str) -> dict[str, Any]:
        if not bool(self.config.get("enable_job_detail", False)):
            return {"job": None}
        # scheduler-bridge/v1 passes a generated job_uid, but C# requires the
        # *native job name* in --job. Re-read the selected topology: connector
        # processes are short-lived, so an in-memory UID cache is not reliable.
        values = self._values(context)
        topology = values["topology"].strip()
        if not topology:
            raise ConnectorError("invalid_request", "Process Scheduler topology_id is required")
        listing = _invoke_bridge(self.config, "fetch_topology", values)
        normalized_listing = _normalize_topology(listing.payload, context, topology)
        matches = [item for item in normalized_listing["jobs"] if item["job_uid"] == job_uid]
        if len(matches) != 1:
            raise ConnectorError("job_not_found", "Job UID not found uniquely in selected Process Scheduler topology")
        values["job"] = matches[0]["scheduler_job_name"]
        result = _invoke_bridge(self.config, "fetch_job_detail", values)
        detail = _detail_source(result.payload)
        if not detail:
            return {"job": None}
        returned_name = _ci_get(detail, "Name", "job_name", "jobName")
        if not returned_name or str(returned_name).strip() != values["job"]:
            raise ConnectorError("job_detail_identity_mismatch", "Job detail name does not match requested job")
        detail = {str(key): _safe_detail_value(str(key), value) for key, value in detail.items()}
        topology = values["topology"]
        normalized = _normalize_topology({"jobs": [detail]}, context, topology)
        jobs = normalized["jobs"]
        if jobs:
            jobs[0]["job_uid"] = matches[0]["job_uid"]
            jobs[0]["scheduler_native_id"] = matches[0]["scheduler_native_id"]
        return {"job": jobs[0] if jobs else None}


def diagnose(context: dict[str, Any], topology: str = "") -> int:
    try:
        config = _load_config()
        launcher = _resolve_launcher(config)
        hints = _source_hints(config)
        provider = ProcessSchedulerProvider()
        roots = provider.list_roots(context)["roots"]
        selected = topology.strip()
        if selected and selected not in roots:
            raise ConnectorError("topology_not_found", "Requested topology was not returned by TopoBrowse.Bridge")

        print("PROCESS SCHEDULER CONNECTOR DIAGNOSTICS v1")
        print(f"Environment       : {context.get('environment') or context.get('environment_id')}")
        print(f"Bridge directory  : {_bridge_dir(config)}")
        print(f"Launcher          : {launcher.kind}")
        print(f"Program.cs        : {'YES' if hints['program_cs'] else 'NO'}")
        print(f"Contract hints    : stdin-json={'YES' if hints['stdin_json'] else 'NO'}, args={'YES' if hints['args'] else 'NO'}")
        print(f"Topologies        : {len(roots)}")

        result_state = "READY"
        if selected:
            probe_context = dict(context)
            probe_context["topology_id"] = selected
            probe_context["root_box"] = selected
            data = provider.fetch_topology(probe_context)
            jobs = data.get("jobs") or []
            metadata = data.get("metadata") or {}
            native_fields: set[str] = set()
            statuses: set[str] = set()
            for job in jobs[: min(len(jobs), 200)]:
                native = job.get("process_scheduler") or {}
                if isinstance(native, dict):
                    native_fields.update(str(key) for key in native)
                if job.get("status_raw"):
                    statuses.add(str(job["status_raw"]))
            print(f"Topology fetch    : OK")
            print(f"Jobs              : {len(jobs)}")
            print(f"Detail fields     : {'YES' if metadata.get('native_detail_fields_observed') else 'NO'}")
            print(f"Explicit deps     : {metadata.get('explicit_dependency_count', 0)}")
            print(f"Statuses observed : {len(statuses)}")
            print(f"Native field keys : {', '.join(sorted(native_fields)[:40]) or '-'}")
            if not metadata.get("native_detail_fields_observed"):
                result_state = "INCOMPLETE"
        print(f"Result            : {result_state}")
        return 0 if result_state == "READY" else 2
    except ConnectorError as exc:
        print("PROCESS SCHEDULER CONNECTOR DIAGNOSTICS v1")
        print(f"Environment       : {context.get('environment') or context.get('environment_id')}")
        print(f"Failure code      : {exc.code}")
        print(f"Failure           : {exc.message}")
        if exc.details:
            for key in sorted(exc.details):
                value = exc.details[key]
                if key == "attempt_trace" and isinstance(value, str):
                    print("CLI attempts       :")
                    for i, item in enumerate(value.split("; ")[:12], 1):
                        print(f"  {i:2d}. {item}")
                elif isinstance(value, (str, int, float, bool)):
                    print(f"{key:<18}: {value}")
        print("Result            : FAILED")
        return 1


if __name__ == "__main__":
    raise SystemExit(run(ProcessSchedulerProvider()))
