"""Out-of-process scheduler adapter using the frozen scheduler-bridge v1 protocol."""

from __future__ import annotations

import json
import os
import subprocess
import threading
import sys
from pathlib import Path
from uuid import uuid4

from pydantic import ValidationError

from app.adapters.base import SchedulerAdapter
from app.adapters.bridge_contract import (
    BRIDGE_PROTOCOL,
    BRIDGE_VERSION,
    BridgeHealthDataV1,
    BridgeJobDetailDataV1,
    BridgeOperation,
    BridgeRequestV1,
    BridgeResponseV1,
    BridgeRootsDataV1,
    BridgeTopologyDataV1,
    capabilities_to_engine,
    dependency_to_engine,
    job_to_engine,
    request_context_from_engine,
)
from app.adapters.builder import TopologySnapshotBuilder
from app.config import EnvironmentEntry, get_settings
from app.services.runtime_diagnostics import log_event
from app.services.snapshot_jobs import current_progress, report_progress
from app.models import AdapterCapabilities, ComparisonContext, SchedulerType, SnapshotJob, TopologySnapshot

_SCRIPT_BY_SCHEDULER = {
    SchedulerType.AUTOSYS: "autosys_connector.py",
    SchedulerType.PROCESS_SCHEDULER: "process_scheduler_connector.py",
}


class BridgeProtocolError(RuntimeError):
    """Connector process ran, but violated the bridge protocol."""


class BridgeConnectorError(RuntimeError):
    """Connector returned a structured source-system failure."""


class ExternalBridgeAdapter(SchedulerAdapter):
    """Generic adapter for bank-local connector scripts.

    The scripts are separate processes and must not import ``app``. They receive one
    JSON request on stdin and return one JSON response on stdout. Diagnostics belong on
    stderr. This keeps bank-only connector code independent from web-engine internals.
    """

    def __init__(self, environment: EnvironmentEntry, scheduler_type: SchedulerType) -> None:
        self.environment = environment
        self.scheduler_type = scheduler_type
        settings = get_settings()
        self._connector_dir = settings.connector_dir.resolve()
        self._python = settings.connector_python or sys.executable
        # Older bank workstations can retain a .env with the previous 120s global
        # limit. Full AutoSys ingestion fetches thousands of JILs; use a dedicated
        # minimum unless the operator explicitly configures a longer value.
        self._timeout_sec = (
            max(settings.connector_timeout_sec,
                max(1, int(os.getenv('PS_TOOL_AUTOSYS_SNAPSHOT_TIMEOUT_SEC', '1800'))))
            if scheduler_type == SchedulerType.AUTOSYS
            else settings.connector_timeout_sec
        )
        self._ps_snapshot_timeout_sec = max(
            self._timeout_sec,
            max(1, int(os.getenv('PS_TOOL_PROCESS_SCHEDULER_SNAPSHOT_TIMEOUT_SEC', '1800'))),
        ) if scheduler_type == SchedulerType.PROCESS_SCHEDULER else self._timeout_sec
        self._max_response_bytes = settings.connector_max_response_mb * 1024 * 1024
        self._capabilities = AdapterCapabilities(strict_parameter_support=False)

    @property
    def script_path(self) -> Path:
        filename = _SCRIPT_BY_SCHEDULER[self.scheduler_type]
        return self._connector_dir / filename

    def capabilities(self) -> AdapterCapabilities:
        return self._capabilities

    def health_check(self, environment_id: str) -> bool:
        context = ComparisonContext(environment_id=environment_id, scheduler=self.scheduler_type)
        response = self._call(BridgeOperation.HEALTH, context)
        data = BridgeHealthDataV1.model_validate(response.data)
        return data.healthy

    def list_roots(self, context: ComparisonContext) -> list[str]:
        response = self._call(BridgeOperation.LIST_ROOTS, context)
        return BridgeRootsDataV1.model_validate(response.data).roots

    def fetch_topology(self, context: ComparisonContext) -> TopologySnapshot:
        response = self._call(BridgeOperation.FETCH_TOPOLOGY, context)
        payload = BridgeTopologyDataV1.model_validate(response.data)
        builder = TopologySnapshotBuilder(
            context,
            capabilities=self._capabilities,
            metadata={
                **payload.metadata,
                "connector_protocol": f"{BRIDGE_PROTOCOL}/v{BRIDGE_VERSION}",
            },
        )
        for item in payload.jobs:
            builder.add_job(job_to_engine(item))
        for item in payload.dependencies:
            edge = dependency_to_engine(item)
            builder.add_dependency(
                edge.from_uid,
                edge.to_uid,
                kind=edge.kind,
                condition=edge.condition,
            )
        snapshot = builder.build()
        if payload.fetched_at is not None:
            snapshot.fetched_at = payload.fetched_at
        return snapshot

    def fetch_job_detail(self, context: ComparisonContext, job_uid: str) -> SnapshotJob | None:
        response = self._call(BridgeOperation.FETCH_JOB_DETAIL, context, job_uid=job_uid)
        data = BridgeJobDetailDataV1.model_validate(response.data)
        return job_to_engine(data.job) if data.job is not None else None

    def _call(
        self,
        operation: BridgeOperation,
        context: ComparisonContext,
        *,
        job_uid: str | None = None,
    ) -> BridgeResponseV1:
        timeout_sec = (self._ps_snapshot_timeout_sec
                       if operation == BridgeOperation.FETCH_TOPOLOGY else self._timeout_sec)
        script = self.script_path
        if not script.is_file():
            raise FileNotFoundError(
                f"Workstation connector is missing: {script}. "
                "AutoSys connector files ship with the project; restore the full project archive "
                "or configure PS_TOOL_CONNECTOR_DIR to a complete connector directory."
            )

        request = BridgeRequestV1(
            request_id=str(uuid4()),
            operation=operation,
            context=request_context_from_engine(
                context,
                environment=self.environment.environment,
                host=self.environment.endpoint_url,
            ),
            job_uid=job_uid,
        )
        raw_request = request.model_dump_json(exclude_none=True)
        reporter = current_progress()
        report_progress('connector', 'Starting isolated scheduler connector')
        log_event('connector_start', operation=operation.value,
                  scheduler=self.scheduler_type.value, timeout_sec=timeout_sec,
                  request_id=request.request_id)
        try:
            # stdout is the frozen JSON bridge protocol. stderr carries only
            # optional prefixed, allowlisted progress messages, never source DTOs.
            process = subprocess.Popen(
                [self._python, str(script)],
                stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                cwd=str(self._connector_dir),
                env={**os.environ, "PS_TOOL_PROGRESS_ENABLED": "1"} if reporter else None,
            )
        except OSError as exc:
            log_event('connector_launch_failed', always=True, error_type=type(exc).__name__)
            raise BridgeConnectorError('Failed to start isolated scheduler connector') from exc

        chunks: list[bytes] = []
        output_bytes = 0
        too_large = False

        def consume_stdout() -> None:
            nonlocal output_bytes, too_large
            assert process.stdout is not None
            for piece in iter(lambda: process.stdout.read(65536), b''):
                output_bytes += len(piece)
                if output_bytes <= self._max_response_bytes:
                    chunks.append(piece)
                else:
                    too_large = True
            process.stdout.close()

        def consume_stderr() -> None:
            assert process.stderr is not None
            for raw in process.stderr:
                if not raw.startswith(b'PS_TOOL_PROGRESS '):
                    continue
                try:
                    payload = json.loads(raw[len(b'PS_TOOL_PROGRESS '):][:1024])
                    stage = payload.get('stage')
                    done = payload.get('done')
                    total = payload.get('total')
                    failed = payload.get('failed', 0)
                    if (stage in {'runtime', 'jil', 'building', 'details'}
                            and type(done) is int and done >= 0
                            and type(total) is int and 0 <= total <= 1000000
                            and done <= total
                            and type(failed) is int and 0 <= failed <= done):
                        if reporter is not None:
                            labels = {'runtime': 'Reading AutoSys runtime report',
                                      'jil': 'Fetching JIL definitions',
                                      'building': 'Building job graph',
                                      'details': 'Fetching Process Scheduler job details'}
                            suffix = f" ({failed} failed)" if failed else ""
                            reporter(stage, labels[stage] + suffix, done, total)
                except (ValueError, TypeError, AttributeError):
                    pass
            process.stderr.close()

        out_reader = threading.Thread(target=consume_stdout, name='connector-stdout', daemon=True)
        err_reader = threading.Thread(target=consume_stderr, name='connector-progress', daemon=True)
        out_reader.start()
        err_reader.start()
        try:
            assert process.stdin is not None
            try:
                process.stdin.write(raw_request.encode('utf-8'))
                process.stdin.close()
            except BrokenPipeError:
                pass
            try:
                return_code = process.wait(timeout=timeout_sec)
            except subprocess.TimeoutExpired as exc:
                process.kill()
                process.wait()
                log_event('connector_timeout', always=True, operation=operation.value,
                          scheduler=self.scheduler_type.value, timeout_sec=timeout_sec,
                          request_id=request.request_id)
                raise BridgeConnectorError(
                    f'{self.scheduler_type.value} connector timed out after {timeout_sec}s'
                ) from exc
        finally:
            out_reader.join(timeout=5)
            err_reader.join(timeout=5)
        if too_large:
            raise BridgeProtocolError(
                f'Connector response exceeds {get_settings().connector_max_response_mb} MB limit'
            )
        try:
            stdout = b''.join(chunks).decode('utf-8', errors='strict')
        except UnicodeDecodeError as exc:
            raise BridgeProtocolError('Connector returned invalid UTF-8') from exc
        log_event('connector_finished', operation=operation.value, scheduler=self.scheduler_type.value,
                  return_code=return_code, request_id=request.request_id)
        if return_code != 0:
            raise BridgeConnectorError(
                f'{self.scheduler_type.value} connector exited with code {return_code}'
            )
        if not stdout.strip():
            raise BridgeProtocolError("Connector returned empty stdout")

        try:
            response = BridgeResponseV1.model_validate_json(stdout)
        except (ValidationError, json.JSONDecodeError) as exc:
            # Do not echo the raw connector response or Pydantic input values into
            # application errors: source DTOs may contain sensitive bank data.
            if isinstance(exc, ValidationError):
                locations = [".".join(str(part) for part in item["loc"]) for item in exc.errors(include_input=False)]
                reason = ", ".join(locations[:5]) or "schema mismatch"
            else:
                reason = "invalid JSON"
            raise BridgeProtocolError(
                f"Invalid scheduler-bridge/v1 response ({reason})"
            ) from exc

        if response.request_id != request.request_id:
            raise BridgeProtocolError("Connector response request_id does not match request")
        if response.capabilities is not None:
            self._capabilities = capabilities_to_engine(response.capabilities)
        if not response.ok:
            if response.error is None:
                raise BridgeProtocolError("Connector returned ok=false without error payload")
            log_event("connector_source_error", always=True, operation=operation.value,
                      scheduler=self.scheduler_type.value, request_id=request.request_id,
                      error_code=response.error.code)
            # Expected failure counters are safe; never log per-job error details.
            counters = (response.error.details or {}).get('definition_error_counts', {})
            if isinstance(counters, dict):
                for code, count in list(counters.items())[:15]:
                    if isinstance(code, str) and isinstance(count, int) and count >= 0:
                        log_event('connector_definition_failure', always=True,
                                  error_code=code, failures=count,
                                  request_id=request.request_id)
            raise BridgeConnectorError(
                f"{response.error.code}: {response.error.message}"
                + (" [retryable]" if response.error.retryable else "")
            )
        if response.error is not None:
            raise BridgeProtocolError("Connector returned ok=true together with error payload")
        return response
