# TopoBrowse.Bridge `Program.cs` — CLI and DTO reference

**Scope:** Reference implementation of the TopoBrowse.Bridge CLI entry point and JSON DTO mapping (Program.cs, lines 1–274). Formatting is normalized. Use the deployed C# implementation as authoritative if behavior differs; this reference does not establish WCF endpoint reachability or validate responses from the service.

## Program.cs reference text

```csharp
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.ServiceModel;
using System.Xml;
using System.Xml.Linq;
using RAIT.ProcessScheduler.Common.Dtos;

namespace TopoBrowse.Bridge;

/// <summary>
/// CLI entry point. Talks to the real PS <c>IDbAccessService</c> WCF endpoint the same way
/// reference/sandbox/DayStatus does (netTcpBinding, SecurityMode.None, no credentials) and
/// prints the result as JSON on stdout for the Python <c>sources/wcf</c> package to parse.
///
/// Usage:
///   TopoBrowse.Bridge list-contexts --address host:port [--service-name DbAccessService] [--timeout 60] [--max-mb 200]
///   TopoBrowse.Bridge get-contexts  --address host:port --names NAME1,NAME2 [--service-name DbAccessService] [--timeout 60] [--max-mb 200]
///   TopoBrowse.Bridge describe-job  --address host:port --context NAME --job JOBNAME [--service-name DbAccessService] [--timeout 60] [--max-mb 200]
///
/// On success: {"ok": true, ...} on stdout, exit code 0.
/// On failure: {"ok": false, "error": "..."} on stderr, non-zero exit code. Never throws past
/// Main — an unreachable/firewalled environment is the expected common case, not a crash.
/// </summary>
internal static class Program
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        DefaultIgnoreCondition = JsonIgnoreCondition.Never,
    };

    private static int Main(string[] args)
    {
        try
        {
            if (args.Length == 0)
            {
                throw new ArgumentException("missing command (list-contexts | get-contexts | describe-job)");
            }

            var command = args[0];
            var options = ParseOptions(args.Skip(1));
            var address = Require(options, "address");
            var serviceName = options.GetValueOrDefault("service-name", "DbAccessService");
            var timeoutSeconds = int.Parse(options.GetValueOrDefault("timeout", "60"), CultureInfo.InvariantCulture);
            var maxMessageMb = long.Parse(options.GetValueOrDefault("max-mb", "200"), CultureInfo.InvariantCulture);

            using var client = new DbAccessBridgeClient(address, serviceName, timeoutSeconds, maxMessageMb);

            switch (command)
            {
                case "list-contexts":
                    return RunListContexts(client, address);
                case "get-contexts":
                    var names = Require(options, "names").Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
                    return RunGetContexts(client, address, names);
                case "describe-job":
                    var contextName = Require(options, "context");
                    var jobName = Require(options, "job");
                    return RunDescribeJob(client, address, contextName, jobName);
                default:
                    throw new ArgumentException($"unknown command '{command}' (expected list-contexts | get-contexts | describe-job)");
            }
        }
        catch (Exception ex)
        {
            WriteError(ex);
            return 2;
        }
    }

    private static int RunListContexts(DbAccessBridgeClient client, string address)
    {
        var names = client.Service.GetContextNames().ToArray();
        WriteOk(new { ok = true, address, contexts = names });
        return 0;
    }

    private static int RunGetContexts(DbAccessBridgeClient client, string address, string[] names)
    {
        var contexts = client.Service.GetContexts(names)
            .Select(ToContextJson)
            .ToArray();
        WriteOk(new { ok = true, address, contexts });
        return 0;
    }

    private static object ToContextJson(ContextDto context)
    {
        var topology = context.TopologyDto;
        return new
        {
            name = topology?.Name,
            revisionNumber = topology?.RevisionNumber ?? 0,
            saveSnapshotTime = context.SaveSnapshotTime,
            boxes = (topology?.Boxes ?? Array.Empty<BoxJobDto>()).Select(ToJobJson),
            commands = (topology?.Commands ?? Array.Empty<CommandJobDto>()).Select(ToCommandJson),
        };
    }

    private static object ToJobJson(BoxJobDto job) => new
    {
        name = job.Name,
        box = job.Box,
        context = job.Context,
        status = job.Status.ToString(),
        jobType = job.JobType.ToString(),
        lastStartTime = NullIfMin(job.LastStartTime),
        lastFinishTime = NullIfMin(job.LastFinishTime),
        startAtTime = job.StartAtTime,
        schedule = job.Schedule,
    };

    private static object ToCommandJson(CommandJobDto job) => new
    {
        name = job.Name,
        box = job.Box,
        context = job.Context,
        status = job.Status.ToString(),
        jobType = job.JobType.ToString(),
        lastStartTime = NullIfMin(job.LastStartTime),
        lastFinishTime = NullIfMin(job.LastFinishTime),
        startAtTime = job.StartAtTime,
        schedule = job.Schedule,
        machine = job.Machine,
        command = job.Command,
    };

    /// <summary>
    /// Full detail for one named job in one topology instance: the already-parsed summary fields
    /// (same shape as get-contexts) plus a <c>raw</c> dump of literally everything the server sent
    /// for that job (see <see cref="DescribeRaw"/>) — known fields and, thanks to
    /// <c>IExtensibleDataObject</c> on <c>JobBaseDto</c>, any fields this bridge's trimmed DTOs
    /// don't explicitly declare (e.g. whatever "modules invoked" / "resolved parameters" are
    /// actually called on the wire).
    /// </summary>
    private static int RunDescribeJob(DbAccessBridgeClient client, string address, string contextName, string jobName)
    {
        var context = client.Service.GetContexts(new[] { contextName }).FirstOrDefault();
        var topology = context?.TopologyDto;
        if (topology is null)
        {
            throw new InvalidOperationException($"topology instance '{contextName}' not found");
        }

        var box = (topology.Boxes ?? Array.Empty<BoxJobDto>())
            .FirstOrDefault(b => string.Equals(b.Name, jobName, StringComparison.OrdinalIgnoreCase));
        var command = (topology.Commands ?? Array.Empty<CommandJobDto>())
            .FirstOrDefault(c => string.Equals(c.Name, jobName, StringComparison.OrdinalIgnoreCase));

        if (box is null && command is null)
        {
            throw new InvalidOperationException($"job '{jobName}' not found in topology '{contextName}'");
        }

        var kind = command is not null ? "command" : "box";
        object summary = command is not null ? ToCommandJson(command) : ToJobJson(box!);
        var raw = command is not null ? DescribeRaw(command) : DescribeRaw(box!);

        WriteOk(new
        {
            ok = true,
            address,
            context = contextName,
            job = jobName,
            kind,
            summary,
            raw,
        });
        return 0;
    }

    /// <summary>
    /// Round-trips <paramref name="dto"/> back through <see cref="DataContractSerializer"/> (the
    /// same contract it was deserialized with, including any <c>IExtensibleDataObject</c> extension
    /// data captured from fields this bridge doesn't explicitly declare) and walks the resulting XML
    /// into a plain name -&gt; value tree. This is the only way to surface fields we don't know the
    /// name of ahead of time without guessing at the real DTO shape.
    /// </summary>
    private static object? DescribeRaw(object dto)
    {
        var serializer = new DataContractSerializer(dto.GetType());
        using var stream = new MemoryStream();
        using (var writer = XmlDictionaryWriter.CreateTextWriter(stream, Encoding.UTF8, ownsStream: false))
        {
            serializer.WriteObject(writer, dto);
            writer.Flush();
        }

        stream.Position = 0;
        var element = XElement.Load(stream);
        return ToRawValue(element);
    }

    private static object? ToRawValue(XElement element)
    {
        if (!element.HasElements)
        {
            var text = element.Value;
            return string.IsNullOrEmpty(text) ? null : text;
        }

        var dict = new Dictionary<string, object?>();
        foreach (var group in element.Elements().GroupBy(e => e.Name.LocalName))
        {
            var values = group.Select(ToRawValue).ToList();
            dict[group.Key] = values.Count == 1 ? values[0] : values;
        }

        return dict;
    }

    private static DateTime? NullIfMin(DateTime value) => value == DateTime.MinValue ? null : value;

    private static Dictionary<string, string> ParseOptions(IEnumerable<string> args)
    {
        var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        var list = args.ToArray();
        for (var i = 0; i < list.Length; i++)
        {
            var token = list[i];
            if (!token.StartsWith("--", StringComparison.Ordinal))
            {
                throw new ArgumentException($"unexpected argument '{token}'");
            }

            var key = token[2..];
            if (i + 1 >= list.Length)
            {
                throw new ArgumentException($"missing value for --{key}");
            }

            result[key] = list[++i];
        }

        return result;
    }

    private static string Require(Dictionary<string, string> options, string key)
    {
        if (!options.TryGetValue(key, out var value) || string.IsNullOrWhiteSpace(value))
        {
            throw new ArgumentException($"missing required --{key}");
        }

        return value;
    }

    private static void WriteOk(object payload)
    {
        Console.Out.Write(JsonSerializer.Serialize(payload, JsonOptions));
    }

    private static void WriteError(Exception ex)
    {
        var payload = new { ok = false, error = Describe(ex) };
        Console.Error.Write(JsonSerializer.Serialize(payload, JsonOptions));
    }

    private static string Describe(Exception ex) => ex switch
    {
        EndpointNotFoundException => $"endpoint not reachable: {ex.Message}",
        TimeoutException => $"timed out: {ex.Message}",
        CommunicationException => $"WCF communication error: {ex.Message}",
        _ => ex.Message,
    };
}
```

## CLI and JSON contract

- **Transport:** WCF is owned exclusively by C# `DbAccessBridgeClient`; the Python wrapper calls the CLI, not WCF.
- **CLI:** command in `args[0]`, followed by `--key value` pairs. `--address host:port` is required on every operation; no positional environment, no `--host` / `--environment` / `--json` switch.
- **Verbs:** `list-contexts`, `get-contexts --names CSV`, `describe-job --context NAME --job JOBNAME`.
- **Defaults:** `service-name=DbAccessService`, `timeout=60` seconds, `max-mb=200`.
- **List response:** `{ "ok": true, "address": "...", "contexts": ["name", ...] }`.
- **Topology response:** `{ "ok": true, "address": "...", "contexts": [{ "name": "...", "revisionNumber": 0, "saveSnapshotTime": "...", "boxes": [...], "commands": [...] }] }`.
- **Job response:** `{ "ok": true, "address": "...", "context": "...", "job": "...", "kind": "command|box", "summary": {...}, "raw": {...} }`.
- **Failure:** JSON `{ "ok": false, "error": "..." }` on **stderr**, exit code `2`. This is a caught exception, not evidence by itself of an unknown command.

**Scope limitation:** `DbAccessBridgeClient.cs`, runtime WCF responses, and successful service execution are not included in this reference. CLI and JSON structures are documented; endpoint reachability and topology content require runtime verification.
