# Reference contracts

This directory contains scheduler endpoint and bridge contract documentation.

## Immutable specifications

The following files are preserved verbatim and must never be modified, renamed,
reformatted, or replaced:

- `AUTOSYS_SELFHELP_ENDPOINT_SPEC.md`
- `PROCESS_SCHEDULER_TOPOBROWSE_BRIDGE.md`

Run `python scripts/verify_reference_docs.py` to verify their fixed SHA-256 digests.

## Additional technical references

- `TOPOBROWSE_PROGRAM_CS_REFERENCE.md` — C# CLI entry point, DTO mapping,
  argument validation, JSON responses, and error semantics.

References must describe technical interfaces and behavior only. Do not record
where or how supporting diagnostic material was acquired. Keep unrelated
implementation notes under `docs/` and preserve the two immutable specs.
