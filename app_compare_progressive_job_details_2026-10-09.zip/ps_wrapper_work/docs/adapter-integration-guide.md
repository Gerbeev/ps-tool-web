# Workstation Integration Guide

The supported real-integration path is `scheduler-bridge/v1`. Source connectivity remains out of process so the web engine can evolve independently.

## AutoSys: shipped connector

AutoSys is not a workstation coding task. The project ships:

```text
workstation_connectors/bridge_v1_runtime.py
workstation_connectors/autosys_connector.py
workstation_connectors/autosys_connector.json
```

`autosys_connector.py` calls the configured AutoSys web/self-help endpoint directly. It supports Windows SSO through curl, bounded HTTP reads, runtime table/fixed-width parsing, JIL/detail parsing, pagination, status normalization, box containment, dependency extraction from JIL conditions, and compact value-safe diagnostics.

The endpoint-specific request shape is declarative in `autosys_connector.json`: route, GET/POST, query parameters, form field names/value formats and optional JIL URL template. No Python edit is required on the workstation.

The default runtime mode first requests the configured environment host and can discover a normal HTML form. It refuses to publish a snapshot unless both the job pattern and COB/date have actually been bound to the source request. This avoids accidentally ingesting an unscoped report.

AutoSys COB is provided by the Snapshots workflow as local `today - 1 day`. The connector passes it to the source endpoint; it does not reinterpret `Last Start`/`Last End` as an as-of filter.

## First real AutoSys run

Set `USE_MOCK_ADAPTERS=false`, configure the AutoSys environment host in `config/autosys_environments.yaml`, then run:

```cmd
scripts\diagnose-autosys.cmd --environment autosys-prod
python -m app.adapters.check --environment autosys-u1 --scheduler autosys --as-of 2026-10-07
```

Diagnostics print only field names/counts/status codes and mapping coverage; they do not print job names, commands or raw endpoint payloads. If the internal page uses non-standard parameter names/routes, update only `workstation_connectors/autosys_connector.json` and rerun diagnostics.

`READY` is emitted only when runtime retrieval succeeds and, when definitions are required, the sampled JIL/definition reads are complete. A JIL failure is reported as `INCOMPLETE` with a non-zero exit code so a partial source connection cannot be mistaken for snapshot readiness.


## Process Scheduler: shipped TopoBrowse.Bridge wrapper

Process Scheduler is not a workstation coding task. The project ships:

```text
workstation_connectors/process_scheduler_connector.py
workstation_connectors/process_scheduler_connector.json
```

The Python connector does **not** implement WCF. It invokes the existing C# `TopoBrowse.Bridge`, which owns WCF bindings, service contracts and native Process Scheduler retrieval. Copy the complete C# bridge directory to `workstation_connectors/TopoBrowse.Bridge/` or configure `PROCESS_SCHEDULER_BRIDGE_DIR`.

The wrapper auto-discovers a built EXE/DLL and can fall back to the `.csproj` through `dotnet run`. The known CLI contract is pinned in `process_scheduler_connector.json` using `--address`, `--names`, `--context` and `--job` as appropriate; update that configuration if a different bridge is installed.

Run:

```cmd
scripts\diagnose-process-scheduler.cmd --environment ps-u5
scripts\diagnose-process-scheduler.cmd --environment ps-u5 --topology <exact-topology-name>
```

A topology response that declares more rows than it returned fails as `partial_topology`. Native fields are preserved. Verified `ConditionExpression` predicates (`ConditionDto.ConditionType` and `DependsOnJobName`) create dependency edges. Multiple predicates without an explicit operator remain `UNVERIFIED`; `Box`/`Context` containment alone is not an execution dependency.

## Snapshot-only source access

Snapshots is the only web workflow allowed to read scheduler sources. AutoSys calls `fetch_topology` for the previous local calendar day. Process Scheduler uses `list_roots` for its topology selector and then `fetch_topology` for the chosen topology. Browse, Compare, Search and Export consume persisted snapshots only.

## Stable handoff

The frozen wire contract is documented in `docs/workstation-connector-protocol-v1.md`. Source connector modules do not import `app.models`, `app.adapters` or `app.services`; `app/adapters/bridge_contract.py` translates bridge DTOs into current internal models.

Containment and dependencies remain separate: AutoSys `box_name` maps to parent containment, while explicit JIL `condition` references map to dependency edges where semantics are known.

A source error, authentication failure, timeout, incompatible schema, oversized response or incomplete pagination returns `ok=false`; it must never be converted into an apparently valid empty/partial snapshot.
