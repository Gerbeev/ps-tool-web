# AutoSys endpoint source examples

These fixtures model AutoSys runtime-report and JIL source formats. They are source-oriented fixtures used by the shipped `workstation_connectors/autosys_connector.py` parser and tests.

The endpoint has two distinct data layers that must stay separate:

1. **Runtime/user report** — one row per job with last start/end, native state code, run/try information, priority/exit column and timezone.
2. **Static JIL definition** — job type, box membership, command, machine, owner, permissions, conditions, logs, alarms, profile, timezone, group and application.

Files:

- `runtime_user_report.sample.yaml` — representative parsed rows from the AutoSys self-help user report.
- `job_definition.sample.jil` — raw JIL text for `IB_CT_CVA_1109_U1_DP_ADP_Accounts_Load`, with display line wrapping normalized without changing the JIL command.
- `job_definition.parsed.sample.yaml` — structured parse of the same JIL plus the matching runtime row from the report.

## Important contract notes

- This folder is **not** an invented HTTP/JSON API. The shipped connector reads the observed HTML runtime/JIL shapes directly; endpoint URL/query/form names are declarative in `workstation_connectors/autosys_connector.json`.
- Native values are preserved. `ST/Ex`, `Run/Ntry`, and `Pri/Xit` remain available as raw source values; only documented status codes are additionally normalized.
- `box_name` is structural containment. It must not be converted into an execution dependency.
- The JIL `condition` is execution/dependency semantics and should later be parsed into dependency edges where safe.
- Static definition and runtime state must not be collapsed into one source object inside the adapter.
- The report contains native status codes such as `SU`, `RU`, `IN`, `OI`, and `AC`; the connector normalizes known AutoSys codes while preserving `status_raw`.
