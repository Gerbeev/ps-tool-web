@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if errorlevel 1 (
    set "EXIT_CODE=1"
    goto :finish
)

set "EXIT_CODE=0"
echo ==================================
echo       JOB LOG ANALYZER SETUP
echo ==================================
echo.

python -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)" >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python 3.11+ is required and the `python` command must be available on PATH.
    echo Install Python 3.11 or newer and add python.exe to PATH.
    set "EXIT_CODE=1"
    goto :finish
)

echo Found compatible Python.
echo No third-party packages are needed.
echo Checking configuration...
python "%~dp0menu.py" --check
if errorlevel 1 (
    echo ERROR: Configuration validation failed.
    set "EXIT_CODE=1"
    goto :finish
)

echo.
echo Setup complete. Open start.cmd to launch the menu.

:finish
echo.
echo [log-analyzer] Exit code: %EXIT_CODE%
pause
endlocal & exit /b %EXIT_CODE%
