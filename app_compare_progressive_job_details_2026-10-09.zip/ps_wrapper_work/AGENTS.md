# Agent Instructions: Scheduler Snapshot + Workstation Bridge Architecture

## Non-negotiable boundary

The portable web project must remain independent from bank-local AutoSys and Process Scheduler implementation code.

Real connectivity is out-of-process only:

```text
Snapshots UI
  -> app.services.snapshot_generation
  -> SchedulerAdapter
  -> ExternalBridgeAdapter
  -> scheduler-bridge/v1 (stdin/stdout JSON)
  -> workstation_connectors/autosys_connector.py
     -> AutoSys web/self-help endpoint directly
     or workstation_connectors/process_scheduler_connector.py
     -> TopoBrowse.Bridge
     -> WCF / Process Scheduler
```

Never add `bank_autosys*.py`, `bank_process_scheduler*.py`, dynamic adapter imports, direct Cosmos access, or bank-only imports under `app/`.

## Snapshot architecture

`Snapshots` is the only web workflow allowed to access scheduler sources.

- AutoSys: choose environment, capture the previous local calendar day as COB (today - 1 day).
- Process Scheduler: choose environment, call `list_roots` through the bridge, select an existing topology, then capture it.
- Every successful capture becomes a new immutable catalog entry with its own `snapshot_id`.
- Runtime snapshot files live under `SNAPSHOT_DIR` and are git-ignored.

Browse, Compare, Search, and Export are snapshot consumers only. They must not import or call:

```text
get_adapter
fetch_snapshot
ExternalBridgeAdapter
list_roots
```

Browse selects `environment + snapshot_id`. Compare selects `environment + snapshot_id` independently for both sides. Neither view owns business-date/topology source controls and neither view refreshes data.

## Frozen workstation contract

`scheduler-bridge/v1` is the stable handoff. Existing v1 field meanings and operation semantics must not be changed incompatibly. If an incompatible change is unavoidable, introduce `scheduler-bridge/v2` rather than silently changing v1.

The workstation connector files must not import:

```text
app.models
app.adapters
app.services
```

Only the portable translator in `app/adapters/bridge_contract.py` maps the frozen wire DTO into current internal models.

## Workstation implementation surface

`workstation_connectors/autosys_connector.py` and `autosys_connector.json` are shipped application components. The AutoSys connector must be complete before delivery: it calls the configured AutoSys web/self-help endpoint directly and must not require workstation-side Python edits. Endpoint-specific URL/query/form mapping belongs in JSON configuration, not in web routes or adapters.

`bridge_v1_runtime.py` remains frozen. `workstation_connectors/process_scheduler_connector.py` and `process_scheduler_connector.json` are shipped application components. The Process Scheduler connector must not implement WCF. It invokes the existing bank-local C# `TopoBrowse.Bridge`, which owns WCF/service-contract details, and translates its read-only output into `scheduler-bridge/v1`. No workstation-side Python development is part of deployment.

Source providers may authenticate using approved local mechanisms, paginate/retry bounded idempotent reads, and map source responses into bridge-v1 dictionaries. They must not implement comparison logic, identity matching, UI behavior, or snapshot persistence.

## Mapping rules

- Stable source ID -> `job_uid`.
- Scheduler display name -> `scheduler_job_name`.
- Container/box/topology membership -> `parent_uid`.
- Native status -> normalized `status` plus unchanged `status_raw`.
- Explicit execution predecessor/trigger -> `dependencies[]`.
- Verified AutoSys/JIL equivalent -> `autosys_jil`.
- Verified runtime equivalent -> `autosys_run`.
- Process Scheduler native detail -> `process_scheduler`.
- Non-comparison source fields -> `attributes`.

Containment is not execution dependency. Never infer dependency edges from tree position, ordering, or naming.

## Failure semantics

A connector must return `ok=false` instead of an empty/partial snapshot when retrieval is incomplete, including authentication failure, timeout, incompatible schema, parse failure, or incomplete pagination.

The Snapshots workflow validates the normalized snapshot before catalog publication. Failed generation must leave all existing snapshots untouched.

## Security and data handling

- No credentials/tokens/certificates in the repository, environment YAML, bridge payloads, or logs.
- Do not log raw source DTOs or sensitive command output.
- Runtime snapshots are bank-sensitive and remain under git-ignored `data/runtime/` (or configured `SNAPSHOT_DIR`).
- The shipped AutoSys and Process Scheduler Python connectors contain no credentials or bank-only secrets. `TopoBrowse.Bridge` remains the bank-local C# transport component and is copied into `workstation_connectors/TopoBrowse.Bridge/` for deployment.
- The bridge launcher must keep `shell=False`, bounded timeout, response-size limits, protocol/version checks, and request-ID validation.

## Required validation

```bash
python -m app.adapters.check --environment <autosys-env> --scheduler autosys --as-of <YYYY-MM-DD>
python -m app.adapters.check --environment <ps-env> --scheduler process_scheduler --as-of <YYYY-MM-DD>
python -m scripts.verify_checkout --runtime
python -m pytest -q
```

The test suite includes a source-isolation regression guard. Do not remove or weaken it: Browse, Compare, and Export must continue to function after generated snapshots exist even when adapter access is made to fail deliberately.

## Immutable endpoint reference documents (MANDATORY)

`docs/reference/AUTOSYS_SELFHELP_ENDPOINT_SPEC.md` and
`docs/reference/PROCESS_SCHEDULER_TOPOBROWSE_BRIDGE.md` are **read-only evidence**.
Never edit, reformat, rename, move or delete them, even during cleanup or refactoring.
All implementation notes and adaptations belong outside `docs/reference/`.
`python scripts/verify_reference_docs.py` must pass before packaging any release.
When new original evidence is supplied, create a NEW filename; do not replace either file.

## Publication and reference hygiene (MANDATORY)

Describe diagnostics and reference material strictly in terms of the technical
contract, behavior, version, and limitations. Never disclose or infer acquisition
channels, device/location details, or circumstances of material collection in
file names, document headings, metadata, code comments, examples, or reports.
Name references after the component and purpose, without collection-method suffixes.
Keep all technical fields and source code intact when correcting metadata.

Run `python scripts/verify_publication_hygiene.py` and
`python scripts/verify_reference_docs.py` before delivering an archive.
