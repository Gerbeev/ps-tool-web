@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if errorlevel 1 (
  set "EXIT_CODE=1"
  goto :finish
)

set "EXIT_CODE=0"
echo [ps-tool-web] Checking project files ...
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)" >nul 2>&1
if errorlevel 1 (
  echo ERROR: Python 3.11+ is required and the python command must be available in PATH.
  set "EXIT_CODE=1"
  goto :finish
)

echo [ps-tool-web] Using python
python -m scripts.verify_checkout --source
if errorlevel 1 (
  echo ERROR: Incomplete project checkout. Fix the files reported above before installing.
  set "EXIT_CODE=1"
  goto :finish
)

if not exist ".venv\Scripts\python.exe" (
  echo [ps-tool-web] Creating .venv ...
  python -m venv ".venv"
  if errorlevel 1 (
    echo ERROR: Cannot create .venv with python.
    set "EXIT_CODE=1"
    goto :finish
  )
)

if not exist ".venv\Scripts\python.exe" (
  echo ERROR: .venv\Scripts\python.exe is missing.
  set "EXIT_CODE=1"
  goto :finish
)

".venv\Scripts\python.exe" -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)"
if errorlevel 1 (
  echo ERROR: Existing .venv uses an unsupported Python version. Remove .venv and rerun setup-env.cmd.
  set "EXIT_CODE=1"
  goto :finish
)

echo [ps-tool-web] Installing dependencies ...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
  echo ERROR: Dependency installation failed. Check pip output/network settings.
  set "EXIT_CODE=1"
  goto :finish
)

if not exist ".env" (
  if exist ".env.example" (
    copy /Y ".env.example" ".env" >nul
    if errorlevel 1 (
      echo ERROR: Cannot create .env from .env.example.
      set "EXIT_CODE=1"
      goto :finish
    )
    echo [ps-tool-web] Created .env from .env.example
  )
)

echo [ps-tool-web] Verifying imports and runtime ...
".venv\Scripts\python.exe" -m scripts.verify_checkout --runtime
if errorlevel 1 (
  echo ERROR: Project verification failed. Fix the reported missing modules/files.
  set "EXIT_CODE=1"
  goto :finish
)

echo.
echo [ps-tool-web] Setup complete. Run start-server.cmd to start the app.

:finish
echo.
echo [ps-tool-web] Exit code: %EXIT_CODE%
pause
endlocal & exit /b %EXIT_CODE%
