"""Regression coverage for the Snapshots document structure."""

from __future__ import annotations

import re
from html.parser import HTMLParser

from fastapi.testclient import TestClient

from app.main import app


class _SnapshotHeadParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__()
        self.in_title = False
        self.title_parts: list[str] = []
        self.scripts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag == "title":
            self.in_title = True
        if tag == "script":
            src = dict(attrs).get("src")
            if src:
                self.scripts.append(src)

    def handle_endtag(self, tag: str) -> None:
        if tag == "title":
            self.in_title = False

    def handle_data(self, data: str) -> None:
        if self.in_title:
            self.title_parts.append(data)


def test_snapshots_title_and_single_progress_script() -> None:
    with TestClient(app) as client:
        response = client.get("/snapshots")
        script_response = client.get("/static/js/snapshot-progress.js")

    assert response.status_code == 200
    assert script_response.status_code == 200
    assert "javascript" in script_response.headers["content-type"]

    html = response.text
    title = re.search(r"<title>(.*?)</title>", html, flags=re.DOTALL | re.IGNORECASE)
    assert title is not None
    assert title.group(1).strip() == "Snapshots — ps-tool-web"
    assert "<script" not in title.group(1).lower()

    parsed = _SnapshotHeadParser()
    parsed.feed(html)
    assert "".join(parsed.title_parts).strip() == "Snapshots — ps-tool-web"
    assert parsed.scripts.count("/static/js/snapshot-progress.js") == 1
    assert html.find('src="/static/js/snapshot-progress.js"') > html.find("</title>")
