"""Browse filter must search the snapshot, not the lazy-loaded browser DOM."""

from __future__ import annotations

import re

from fastapi.testclient import TestClient

from app.main import app
from app.models import (
    ComparisonContext,
    JobNode,
    JobStatus,
    SchedulerType,
    SnapshotJob,
    TopologySnapshot,
)
from app.services.browse_tree_filter import filter_browse_tree
from app.session_store import BrowseSession, session_store


client = TestClient(app)


def _job(uid: str, name: str, status: JobStatus = JobStatus.SUCCESS) -> SnapshotJob:
    return SnapshotJob(job_uid=uid, scheduler_job_name=name, status=status)


def _snapshot() -> TopologySnapshot:
    root = _job('root', 'Pipeline')
    box = _job('box', 'Overnight_Box', JobStatus.RUNNING)
    leaf = _job('leaf', 'Admin_Extract', JobStatus.FAILURE)
    others = [_job(f'extra-{n}', f'Other_{n}') for n in range(250)]
    return TopologySnapshot(
        context=ComparisonContext(environment_id='test', scheduler=SchedulerType.AUTOSYS),
        roots=[
            JobNode(job=root, children=[JobNode(job=box, children=[JobNode(job=leaf)])]),
            *[JobNode(job=other) for other in others],
        ],
        flat_jobs=[root, box, leaf, *others],
    )


def _session(snapshot: TopologySnapshot) -> str:
    sid = session_store.new_id()
    session_store.put_browse(BrowseSession(
        session_id=sid, context=snapshot.context, snapshot=snapshot
    ))
    return sid


def test_nested_job_found_with_its_ancestors_and_open_branches():
    sid = _session(_snapshot())
    response = client.get('/api/browse/filter', params={
        'session_id': sid, 'query': 'admin_extract'
    })
    assert response.status_code == 200
    html = response.text
    assert 'Showing 1 of 1 matching jobs' in html
    assert [n for n in re.findall(r'data-job-name="([^"]+)"', html)] == [
        'Pipeline', 'Overnight_Box', 'Admin_Extract',
    ]
    assert html.count('<details class="browse-tree-branch" open>') == 2
    assert 'hx-trigger="revealed once"' not in html
    assert f'/api/browse/job/leaf?session_id={sid}' in html
    # Normal tree remains lazy when no filter is applied.
    regular = client.get('/api/browse/tree', params={'session_id': sid})
    assert regular.status_code == 200
    assert 'Admin_Extract' not in regular.text
    assert 'hx-trigger="revealed once"' in regular.text


def test_status_filter_finds_nested_failure_and_preserves_ancestors():
    sid = _session(_snapshot())
    response = client.get('/api/browse/filter', params={
        'session_id': sid, 'statuses': 'failure',
    })
    assert response.status_code == 200
    assert re.findall(r'data-job-name="([^"]+)"', response.text) == [
        'Pipeline', 'Overnight_Box', 'Admin_Extract',
    ]
    bad_match = client.get('/api/browse/filter', params={
        'session_id': sid, 'statuses': 'success', 'query': 'Admin_Extract'
    })
    assert 'No jobs match' in bad_match.text


def test_browse_filter_caps_matched_rows_before_rendering():
    snap = _snapshot()
    result = filter_browse_tree(snap, query='Other_', limit=20)
    assert result.match_count == 250
    assert result.shown_count == 20
    assert len(result.roots) == 20
    sid = _session(snap)
    response = client.get('/api/browse/filter', params={
        'session_id': sid, 'query': 'Other_', 'limit': 20,
    })
    assert response.status_code == 200
    assert response.text.count('data-job-name=') == 20
    assert 'Showing 20 of 250 matching jobs' in response.text
    assert 'data-next-limit="220"' in response.text
    more = client.get('/api/browse/filter', params={
        'session_id': sid, 'query': 'Other_', 'limit': 250,
    })
    assert more.text.count('data-job-name=') == 250
    assert 'browse-filter-load-more' not in more.text


def test_no_results_and_invalid_requests_do_not_leak_data():
    sid = _session(_snapshot())
    assert 'No jobs match' in client.get('/api/browse/filter', params={
        'session_id': sid, 'query': 'absent-name',
    }).text
    assert client.get('/api/browse/filter', params={
        'session_id': sid, 'statuses': 'bogus',
    }).status_code == 400
    assert client.get('/api/browse/filter', params={
        'session_id': 'unknown', 'query': 'Admin_Extract',
    }).status_code == 404
    assert client.get('/api/browse/filter', params={
        'session_id': sid, 'limit': 10001,
    }).status_code == 422
