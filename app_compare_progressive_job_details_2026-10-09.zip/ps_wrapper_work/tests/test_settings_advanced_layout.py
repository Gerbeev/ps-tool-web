"""Advanced Settings must keep long configuration values within the panel."""

from __future__ import annotations

from pathlib import Path

from bs4 import BeautifulSoup
from fastapi.testclient import TestClient

from app.main import app


ROOT = Path(__file__).resolve().parents[1]


def test_advanced_settings_keeps_complete_configuration_values(monkeypatch):
    from app.routes import settings as settings_routes

    settings = settings_routes.get_settings()
    long_path = Path('/' + 'nested-directory-' * 32 + '/reference.jsonl')
    long_log_path = Path('/' + 'logs-directory-' * 32 + '/application.log')
    monkeypatch.setattr(
        settings_routes,
        'get_settings',
        lambda: settings.model_copy(update={
            'mock_reference_path': long_path,
            'log_dir': long_log_path,
        }),
    )
    long_yaml_value = 'long-yaml-value-' * 50
    yaml_content = f'source: {long_yaml_value}\n  enabled: true\n'
    monkeypatch.setattr(settings_routes, '_read_config_text', lambda _path: yaml_content)

    response = TestClient(app).get('/settings#advanced')
    assert response.status_code == 200
    panel = BeautifulSoup(response.text, 'html.parser').select_one('#advanced-panel')
    assert panel is not None
    assert str(long_path) in panel.get_text(' ', strip=True)
    assert str(long_log_path) in panel.get_text(' ', strip=True)
    previews = panel.select('.config-preview code')
    assert len(previews) == 3
    assert all(preview.get_text() == yaml_content for preview in previews)


def test_advanced_layout_styles_scope_wrapping_to_advanced_panel():
    css = (ROOT / 'app/static/css/custom.css').read_text(encoding='utf-8')
    assert '#advanced-panel p,' in css
    assert '#advanced-panel .box-disclosure__summary { overflow-wrap: anywhere; }' in css
    assert '#advanced-panel .config-preview {' in css
    advanced_rules = css.split('#advanced-panel .config-preview {', 1)[1].split('}', 1)[0]
    assert 'max-width: 100%;' in advanced_rules
    assert 'white-space: pre-wrap;' in advanced_rules
    assert 'overflow-wrap: anywhere;' in advanced_rules
    # Keep this scoped to Advanced; connection tables retain local horizontal scrolling.
    assert '.settings-connections-table { width: 100%; min-width: 54rem;' in css
