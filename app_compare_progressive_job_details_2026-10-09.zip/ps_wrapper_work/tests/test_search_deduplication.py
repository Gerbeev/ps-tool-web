"""Search must return distinct job identities, with session-correct side labels."""

from __future__ import annotations

import importlib

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.models import (
    AsOf,
    AsOfKind,
    ComparisonContext,
    ComparisonResult,
    JobStatus,
    SchedulerType,
    SnapshotJob,
    TopologySnapshot,
)
from app.search.sqlite_fts import SQLiteFTSSearchIndex
from app.session_store import BrowseSession, CompareSession, session_store


def _snapshot(snapshot_id: str, jobs: list[tuple[str, str]]) -> TopologySnapshot:
    context = ComparisonContext(
        environment_id="uat-rd",
        scheduler=SchedulerType.AUTOSYS,
        as_of=AsOf(kind=AsOfKind.BUSINESS_DATE, value="2026-10-08"),
    )
    return TopologySnapshot(
        snapshot_id=snapshot_id,
        context=context,
        flat_jobs=[
            SnapshotJob(
                job_uid=uid,
                scheduler_job_name=name,
                status=JobStatus.SUCCESS,
                path_labels=["RISK_BOX", name],
            )
            for uid, name in jobs
        ],
    )


@pytest.fixture
def index(tmp_path):
    search = SQLiteFTSSearchIndex(tmp_path / "search.sqlite")
    yield search
    search._conn.close()


def test_deduplicates_across_index_sides_before_limit(index):
    snap = _snapshot("first", [("a", "RISK_MAIN"), ("b", "RISK_SECONDARY")])
    index.rebuild(snap, "left")
    index.rebuild(snap, "right")
    hits = index.search("RISK", limit=2, snapshot_ids=["first"])
    assert {(h.snapshot_id, h.job_uid) for h in hits} == {("first", "a"), ("first", "b")}
    assert len(hits) == 2


def test_same_names_with_distinct_uids_and_snapshots_are_not_collapsed(index):
    first = _snapshot("first", [("a", "RISK_SAME"), ("b", "RISK_SAME")])
    second = _snapshot("second", [("a", "RISK_SAME")])
    index.rebuild(first, "left")
    index.rebuild(first, "right")
    index.rebuild(second, "right")
    hits = index.search("RISK", limit=10, snapshot_ids=["first", "second"])
    assert {(h.snapshot_id, h.job_uid) for h in hits} == {
        ("first", "a"), ("first", "b"), ("second", "a")
    }
    assert len(hits) == 3


def test_compare_search_labels_sides_from_current_session_not_stale_index(index, monkeypatch):
    left = _snapshot("search-left", [("a", "RISK_SAME")])
    right = _snapshot("search-right", [("a", "RISK_SAME")])
    for snap in (left, right):
        index.rebuild(snap, "right")
        index.rebuild(snap, "left")
    route = importlib.import_module("app.routes.search")
    monkeypatch.setattr(route, "search_index", index)
    sid = session_store.new_id()
    session_store.put(
        CompareSession(
            session_id=sid,
            left=left.context,
            right=right.context,
            left_snapshot=left,
            right_snapshot=right,
            result=ComparisonResult(left_snapshot_id=left.snapshot_id, right_snapshot_id=right.snapshot_id),
        )
    )

    with TestClient(app) as client:
        response = client.get("/api/search", params={"session_id": sid, "q": "RISK", "format": "json"})
        assert response.status_code == 200
        assert {(hit["snapshot_id"], hit["side"]) for hit in response.json()} == {
            ("search-left", "left"), ("search-right", "right")
        }
        assert len(response.json()) == 2

        only_right = client.get(
            "/api/search", params={"session_id": sid, "q": "RISK", "format": "json", "side": "right"}
        )
        assert [(hit["snapshot_id"], hit["side"]) for hit in only_right.json()] == [
            ("search-right", "right")
        ]


def test_browse_search_correct_side_even_if_indexed_as_right(index, monkeypatch):
    snap = _snapshot("browse-id", [("a", "RISK_BROWSE")])
    index.rebuild(snap, "right")
    route = importlib.import_module("app.routes.search")
    monkeypatch.setattr(route, "search_index", index)
    sid = session_store.new_id()
    session_store.put_browse(BrowseSession(session_id=sid, context=snap.context, snapshot=snap))
    with TestClient(app) as client:
        resp = client.get("/api/search", params={"session_id": sid, "q": "RISK", "format": "json"})
        assert [(h["snapshot_id"], h["side"]) for h in resp.json()] == [("browse-id", "left")]
        resp = client.get(
            "/api/search", params={"session_id": sid, "q": "RISK", "format": "json", "side": "right"}
        )
        assert resp.json() == []


def test_same_snapshot_on_both_sides_is_one_result(index, monkeypatch):
    snap = _snapshot("same", [("a", "RISK_DUPLICATE")])
    index.rebuild(snap, "left")
    index.rebuild(snap, "right")
    route = importlib.import_module("app.routes.search")
    monkeypatch.setattr(route, "search_index", index)
    sid = session_store.new_id()
    session_store.put(
        CompareSession(
            session_id=sid,
            left=snap.context,
            right=snap.context,
            left_snapshot=snap,
            right_snapshot=snap,
            result=ComparisonResult(left_snapshot_id=snap.snapshot_id, right_snapshot_id=snap.snapshot_id),
        )
    )
    with TestClient(app) as client:
        resp = client.get("/api/search", params={"session_id": sid, "q": "RISK", "format": "json"})
        assert [(h["snapshot_id"], h["side"]) for h in resp.json()] == [("same", "left")]
        html = client.get("/api/search", params={"session_id": sid, "q": "RISK"})
        assert html.status_code == 200
        assert html.text.count("RISK_DUPLICATE</strong>") == 1
        right = client.get("/api/search", params={"session_id": sid, "q": "RISK", "format": "json", "side": "right"})
        assert [(h["snapshot_id"], h["side"]) for h in right.json()] == [("same", "right")]
