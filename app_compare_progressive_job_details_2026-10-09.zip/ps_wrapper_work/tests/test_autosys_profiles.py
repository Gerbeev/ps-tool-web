"""AutoSys PROD/UAT operator profiles and selfhelp query binding."""
from __future__ import annotations

import yaml
from fastapi.testclient import TestClient
from unittest.mock import patch

from app import config
from app.adapters.bridge import ExternalBridgeAdapter
from app.adapters.bridge_contract import BridgeRequestV1, request_context_from_engine
from app.main import app
from app.models import ComparisonContext, SchedulerType
from workstation_connectors import autosys_connector as autosys


PROD_ROW = "IB_CT_CVA_1109_P1_Admin_Box"


class ProdClient:
    calls: list[dict[str, str]] = []

    def __init__(self, _config):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        pass

    def request(self, method, url, params=None):
        assert method == "GET"
        assert url == "https://autosys.ldn.swissbank.com/selfhelp/tool.cgi"
        params = dict(params or {})
        self.calls.append(params)
        assert params["i"] == "IL2"
        if params["t"] == "job":
            assert params["q"] == "IB_CT_CVA_1109_%"
            body = ("<pre>Job Name  Last Start  Last End  ST/Ex Run/Ntry Pri/Xit TimeZone\n"
                    "----------------------------------------------------------------\n"
                    + PROD_ROW + "  10/06/2026 23:32:50  10/06/2026 23:48:48 SU 38912674/1 0 (London)\n</pre>")
            return autosys.HttpResult(url, 200, "text/html", body)
        assert params["t"] == "jil"
        assert params["q"] == PROD_ROW
        return autosys.HttpResult(url, 200, "text/html", f"<pre>insert_job: {PROD_ROW} job_type: BOX\n</pre>")


def _context(entry: config.EnvironmentEntry) -> dict:
    request_context = request_context_from_engine(
        ComparisonContext(environment_id=entry.id, scheduler=SchedulerType.AUTOSYS),
        environment=entry.environment,
        host=entry.host,
        autosys_instance=entry.autosys_instance,
        autosys_job_pattern=entry.autosys_job_pattern,
    )
    return BridgeRequestV1(request_id="test", operation="fetch_topology", context=request_context).model_dump()["context"]


def test_prod_instance_and_mask_flow_through_bridge_and_both_cgi_calls():
    entry = config.get_environment("autosys-prod")
    assert entry and entry.enabled
    adapter = ExternalBridgeAdapter(entry, SchedulerType.AUTOSYS)
    assert adapter.environment.autosys_instance == "IL2"
    ctx = _context(entry)
    ctx.update(as_of_kind="business_date", as_of_value="2026-10-08")
    assert ctx["autosys_instance"] == "IL2"
    assert ctx["autosys_job_pattern"] == "IB_CT_CVA_1109_%"
    ProdClient.calls = []
    with patch.object(autosys, "AutoSysHttpClient", ProdClient):
        result = autosys.AutoSysProvider().fetch_topology(ctx)
    assert len(result["jobs"]) == 1
    assert len(ProdClient.calls) == 2
    assert result["metadata"]["job_pattern"] == "IB_CT_CVA_1109_%"
    assert result["jobs"][0]["scheduler_job_name"] == PROD_ROW


def test_settings_ui_persists_autosys_instance_and_mask_without_touching_ps(tmp_path, monkeypatch):
    monkeypatch.setenv("PS_TOOL_CONFIG_DIR", str(tmp_path))
    monkeypatch.setenv("ALLOW_CONNECTION_CONFIG_EDIT", "true")
    for name in ("autosys_environments.yaml", "process_scheduler_environments.yaml"):
        source = config._repo_root() / "config" / name
        (tmp_path / name).write_bytes(source.read_bytes())
    original_ps = (tmp_path / "process_scheduler_environments.yaml").read_bytes()
    config.get_settings.cache_clear()
    config.invalidate_environment_cache()
    try:
        with TestClient(app) as client:
            html = client.get("/settings").text
            assert 'name="instance_autosys-prod"' in html
            assert 'name="job_pattern_autosys-prod"' in html
            assert 'value="IL2"' in html
            assert 'value="IB_CT_CVA_1109_%"' in html
            response = client.post("/api/settings/environments/autosys", data={
                "present_autosys-prod": "1", "enabled_autosys-prod": "on",
                "host_autosys-prod": "autosys.ldn.swissbank.com",
                "environment_autosys-prod": "PROD",
                "instance_autosys-prod": "IL9",
                "job_pattern_autosys-prod": "IB_CT_CVA_1109_P1_%",
            }, follow_redirects=False)
            assert response.status_code == 303
            row = yaml.safe_load((tmp_path / "autosys_environments.yaml").read_text())["environments"][0]
            assert row["autosys_instance"] == "IL9"
            assert row["autosys_job_pattern"] == "IB_CT_CVA_1109_P1_%"
            assert row["enabled"] is True
            assert config.get_environment("autosys-prod").autosys_instance == "IL9"
            assert (tmp_path / "process_scheduler_environments.yaml").read_bytes() == original_ps

            before = (tmp_path / "autosys_environments.yaml").read_bytes()
            invalid = client.post("/api/settings/environments/autosys", data={
                "instance_autosys-prod": "IL2&bad=1",
                "job_pattern_autosys-prod": "%",
            }, follow_redirects=False)
            assert invalid.status_code == 400
            assert (tmp_path / "autosys_environments.yaml").read_bytes() == before
    finally:
        config.invalidate_environment_cache()
        config.get_settings.cache_clear()


def test_u1_is_disabled_and_prod_is_enabled_without_test_override():
    entries = config.load_scheduler_environments("autosys")
    assert {entry.id: entry.enabled for entry in entries} == {
        "autosys-prod": True, "autosys-u1": False,
    }
    with TestClient(app) as client:
        assert client.post("/api/snapshots/start", data={"environment_id": "autosys-u1"}).status_code == 400
