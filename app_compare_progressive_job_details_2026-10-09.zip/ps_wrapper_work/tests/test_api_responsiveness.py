"""Slow local snapshot work must not block the FastAPI event loop."""

from __future__ import annotations

import asyncio
import inspect
import threading
import time

import httpx
import pytest

from app.main import app
from app.routes import browse, compare, search


@pytest.mark.parametrize(
    'endpoint, form',
    [
        ('/api/browse/load', {'environment_id': 'autosys-u1', 'snapshot_id': 'test-id'}),
        ('/api/compare', {
            'left_env': 'autosys-u1', 'left_snapshot_id': 'left-id',
            'right_env': 'ps-u5', 'right_snapshot_id': 'right-id',
        }),
    ],
)
def test_long_snapshot_load_does_not_block_progress_polling(monkeypatch, endpoint, form):
    started = threading.Event()
    release = threading.Event()

    def slow_load(_snapshot_id):
        started.set()
        if not release.wait(timeout=5):
            raise TimeoutError('Test storage worker did not receive release signal')
        return None

    monkeypatch.setattr(browse.snapshot_catalog, 'load', slow_load)

    async def scenario():
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app),
            base_url='http://testserver',
            timeout=8,
        ) as client:
            task = asyncio.create_task(client.post(endpoint, data=form))
            try:
                assert await asyncio.wait_for(asyncio.to_thread(started.wait, 3), timeout=4)
                start = time.perf_counter()
                response = await asyncio.wait_for(client.get('/api/snapshots/current'), timeout=1)
                elapsed = time.perf_counter() - start
                assert response.status_code == 200
                assert elapsed < 0.5
            finally:
                release.set()
                result = await task
                assert result.status_code == 200

    asyncio.run(scenario())


def test_large_result_routes_use_fastapi_threadpool():
    assert not inspect.iscoroutinefunction(browse.browse_load)
    assert not inspect.iscoroutinefunction(compare.run_compare)
    assert not inspect.iscoroutinefunction(compare.compare_table)
    assert not inspect.iscoroutinefunction(search.search_jobs)
