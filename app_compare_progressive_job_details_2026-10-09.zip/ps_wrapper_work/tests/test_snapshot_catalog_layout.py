"""Catalog table keeps the primary action accessible and metadata readable."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from bs4 import BeautifulSoup
from fastapi.testclient import TestClient

from app.main import app
from app.models import SchedulerType
from app.services.snapshot_catalog import CatalogHealth, SnapshotRecord


ROOT = Path(__file__).resolve().parents[1]


def _record(snapshot_id: str, scheduler: SchedulerType) -> SnapshotRecord:
    return SnapshotRecord.model_construct(
        snapshot_id=snapshot_id,
        snapshot_name='Daily & Risk <reconciliation> ' + ('long-' * 24),
        environment_name='Risk Analytics U5 Long Environment',
        environment_id='ps-u5',
        captured_at=datetime(2026, 10, 9, 13, 45, 12, tzinfo=timezone.utc),
        scheduler=scheduler,
        topology_id='very.long.topology.identifier.with.deep.structure',
        business_date='2026-10-08',
        job_count=2511,
        edge_count=7220,
    )


def test_catalog_preserves_all_metadata_and_delete_action(monkeypatch):
    records = [_record('snapshot-auto-123', SchedulerType.AUTOSYS),
               _record('snapshot-ps-456', SchedulerType.PROCESS_SCHEDULER)]
    monkeypatch.setattr('app.routes.snapshots.snapshot_catalog.list', lambda: records)
    monkeypatch.setattr('app.routes.snapshots.snapshot_catalog.health', lambda: CatalogHealth())

    response = TestClient(app).get('/api/snapshots/catalog')
    assert response.status_code == 200
    soup = BeautifulSoup(response.text, 'html.parser')
    table = soup.select_one('table.snapshot-table')
    assert table is not None
    assert [th.get_text(strip=True) for th in table.select('thead th')] == [
        'Snapshot', 'Captured', 'Source', 'Scope', 'Counts', 'Actions',
    ]
    assert len(table.select('tbody tr')) == 2
    for record, row in zip(records, table.select('tbody tr')):
        assert len(row.select('td')) == 6
        assert row.select_one('td.snapshot-cell-name strong').get_text() == record.label
        assert row.select_one('details.snapshot-record-id code').get_text() == record.snapshot_id
        assert row.select_one('td.snapshot-cell-captured time').get('datetime') == record.captured_at.isoformat()
        assert record.source_scope in row.select_one('td.snapshot-cell-scope').get_text()
        assert '2511 jobs' in row.select_one('td.snapshot-cell-counts').get_text()
        assert '7220 dependencies' in row.select_one('td.snapshot-cell-counts').get_text()
        assert row.select_one('td.snapshot-cell-actions button[type="submit"]').get_text(strip=True) == 'Delete'
        form = row.select_one('td.snapshot-cell-actions form')
        assert form['hx-post'] == '/api/snapshots/delete'
        assert form['hx-target'] == '#snapshots-workspace'
        assert form.select_one('input[name="snapshot_id"]')['value'] == record.snapshot_id
    assert table.select_one('.snapshot-cell-source .snapshot-record-secondary').get_text(strip=True) == 'AutoSys'
    assert table.select('tbody tr')[1].select_one('.snapshot-record-secondary').get_text(strip=True) == 'Process Scheduler'
    assert '&lt;reconciliation&gt;' in response.text


def test_catalog_styles_have_bounded_columns_and_compact_cards():
    css = (ROOT / 'app/static/css/custom.css').read_text(encoding='utf-8')
    assert '.snapshot-table { width: 100%; table-layout: fixed;' in css
    assert '.snapshot-table { width: 100%; min-width:' not in css
    assert '@media (max-width: 1200px)' in css
    assert '.snapshot-cell-actions { grid-column: 2; grid-row: 1; justify-self: end; }' in css
    assert 'overflow-wrap: anywhere' in css


def test_empty_catalog_keeps_unchanged_state(monkeypatch):
    monkeypatch.setattr('app.routes.snapshots.snapshot_catalog.list', lambda: [])
    monkeypatch.setattr('app.routes.snapshots.snapshot_catalog.health', lambda: CatalogHealth())
    response = TestClient(app).get('/api/snapshots/catalog')
    assert response.status_code == 200
    assert 'No snapshots yet' in response.text
    assert not BeautifulSoup(response.text, 'html.parser').select('table.snapshot-table')
