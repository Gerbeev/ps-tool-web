"""Compare must filter the full result before returning paginated HTML."""

import re

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.models import (
    AsOf, ComparisonContext, ComparisonResult, JobPair, JobStatus,
    MatchConfidence, ParameterMismatch, SchedulerType, SnapshotJob, TopologySnapshot,
)
from app.services.table_rows import filter_visible_table_rows, iter_table_rows
from app.session_store import CompareSession, session_store


def make_job(name: str, status: JobStatus = JobStatus.SUCCESS) -> SnapshotJob:
    return SnapshotJob(job_uid=name, logical_id=name, scheduler_job_name=name, status=status)


@pytest.fixture
def large_session():
    context = ComparisonContext(environment_id="test", scheduler=SchedulerType.AUTOSYS, as_of=AsOf(value="2026-10-02"))
    pairs = [
        JobPair(
            logical_id=f"JOB_{i:04d}",
            left=make_job(f"JOB_{i:04d}"),
            right=make_job(f"JOB_{i:04d}", JobStatus.FAILURE if i % 20 == 0 else JobStatus.SUCCESS),
            confidence=MatchConfidence.MAPPED,
        )
        for i in range(550)
    ]
    result = ComparisonResult(
        left_snapshot_id="left", right_snapshot_id="right", pairs=pairs,
        left_only=[make_job("LEFT_ONLY")],
        right_only=[make_job("RIGHT_ONLY")],
        parameter_mismatches=[ParameterMismatch(logical_id="JOB_0001", parameter="machine")],
        execution_time_deltas=[pairs[2]],
    )
    sid = session_store.new_id()
    snap = TopologySnapshot(context=context)
    session_store.put(CompareSession(sid, context, context, snap, snap, result))
    return sid, result


def logical_ids(html: str) -> list[str]:
    return re.findall(r'<td><code>(JOB_\d{4}|LEFT_ONLY|RIGHT_ONLY)</code></td>', html)


def test_default_returns_only_first_200_and_can_reach_every_row(large_session):
    sid, result = large_session
    client = TestClient(app)
    found = []
    for offset, expected in ((0, 200), (200, 200), (400, 152)):
        response = client.get('/api/compare/table', params={'session_id': sid, 'offset': offset})
        assert response.status_code == 200
        assert 'data-total="552"' in response.text
        names = logical_ids(response.text)
        assert len(names) == expected
        found.extend(names)
        if offset < 400:
            assert 'id="compare-load-more"' in response.text
        else:
            assert 'id="compare-load-more"' in response.text
            assert re.search(r'id="compare-load-more"[^>]*hidden', response.text)
    assert len(found) == len(set(found)) == 552
    assert 'LEFT_ONLY' in found and 'RIGHT_ONLY' in found
    assert client.get('/api/compare/table', params={'session_id': sid}).text.count('data-compare-tags=') == 200


def test_search_full_dataset_before_pagination_and_matches_substring(large_session):
    sid, _ = large_session
    client = TestClient(app)
    response = client.get('/api/compare/table', params={'session_id': sid, 'q': 'b_0549', 'limit': 200})
    assert response.status_code == 200
    assert logical_ids(response.text) == ['JOB_0549']
    assert 'data-total="1"' in response.text


def test_category_or_semantics_and_reset_offset(large_session):
    sid, result = large_session
    client = TestClient(app)
    response = client.get('/api/compare/table', params={
        'session_id': sid, 'categories': 'left_only,status_delta', 'offset': 0, 'limit': 10,
    })
    assert response.status_code == 200
    assert 'data-total="29"' in response.text  # 28 status deltas + one left-only
    first = logical_ids(response.text)
    assert len(first) == 10
    assert 'RIGHT_ONLY' not in response.text
    next_page = client.get('/api/compare/table', params={
        'session_id': sid, 'categories': 'left_only,status_delta', 'offset': 10, 'limit': 10,
    })
    assert not set(first).intersection(logical_ids(next_page.text))

    rows = iter_table_rows(result)
    param = filter_visible_table_rows(rows, result, categories=frozenset({'param_delta'}))
    timing = filter_visible_table_rows(rows, result, categories=frozenset({'exec_time_delta'}))
    assert [x.logical_id for x in param] == ['JOB_0001']
    assert [x.logical_id for x in timing] == ['JOB_0002']


def test_invalid_categories_do_not_return_data(large_session):
    sid, _ = large_session
    response = TestClient(app).get('/api/compare/table', params={'session_id': sid, 'categories': 'unknown'})
    assert response.status_code == 400


def test_legacy_explicit_unlimited_query_still_supported(large_session):
    sid, _ = large_session
    response = TestClient(app).get('/api/compare/table', params={'session_id': sid, 'limit': 0})
    assert response.status_code == 200
    assert len(logical_ids(response.text)) == 552
