"""Read-only Progressive Job Details contract tests for both scheduler sources."""
from __future__ import annotations

from fastapi.testclient import TestClient

from app.main import app
from app.models import ComparisonContext, JobStatus, SchedulerType, SnapshotJob, TopologySnapshot
from app.process_scheduler_reference import ProcessSchedulerJobReference
from app.services.job_detail_view import build_job_detail_view
from app.session_store import BrowseSession, session_store


def _job(**overrides):
    data = {"job_uid": "job-1", "scheduler_job_name": "LOAD_X", "status": JobStatus.FAILURE,
            "status_raw": "Failed", "path_labels": ["ROOT", "LOAD_X"]}
    data.update(overrides)
    return SnapshotJob.model_validate(data)


def _route(scheduler: SchedulerType, job: SnapshotJob) -> str:
    snap = TopologySnapshot(context=ComparisonContext(environment_id="u5", scheduler=scheduler), flat_jobs=[job])
    sid = session_store.new_id()
    session_store.put_browse(BrowseSession(session_id=sid, context=snap.context, snapshot=snap))
    result = TestClient(app).get(f"/api/browse/job/{job.job_uid}?session_id={sid}")
    assert result.status_code == 200
    return result.text


def test_ps_summary_deduplicates_command_and_preserves_raw_fields():
    job = _job(
        process_scheduler=ProcessSchedulerJobReference.from_wire({
            "Command": "C:\\bin\\workflow.exe --run", "Machine": "ps-host", "StdOutputFile": "C:\\logs\\out.log",
            "StdErrorFile": "C:\\logs\\err.log", "Schedule": "Monday,Tuesday", "StartAtTime": "00:01",
            "ConditionExpression": "Success(A) AND Failure(B)", "ResourceName": "pool-a",
            "StartAtTimeForce": False, "ExtraEmpty": "", "Retries": 0,
        }),
        attributes={"ps_condition_predecessors": ["A", "B"], "ps_condition_status": "verified"},
    )
    view = build_job_detail_view(job, SchedulerType.PROCESS_SCHEDULER, "u5")
    assert view["command"] == "C:\\bin\\workflow.exe --run"
    assert view["output"] == "C:\\logs\\out.log"
    assert view["error"] == "C:\\logs\\err.log"
    assert {x["label"]: x["value"] for x in view["dependencies"]}["Depends on"] == "A, B"
    assert {x["label"]: x["value"] for x in view["schedule"]}["Force start at"] == "false"
    assert any(x["label"] == "Resource" for x in view["technical"])
    rows = view["raw_sections"][0]["rows"]
    assert next(x for x in rows if x["label"] == "ExtraEmpty")["empty"] is True
    assert next(x for x in rows if x["label"] == "Retries")["value"] == "0"
    html = _route(SchedulerType.PROCESS_SCHEDULER, job)
    assert html.count('data-copy-value') == 3
    assert html.count("C:\\bin\\workflow.exe --run") >= 1
    assert 'data-detail-disclosure="raw"' in html
    assert 'data-show-empty' in html
    assert 'data-empty-field hidden' in html
    assert 'Process Scheduler source detail' in html
    assert 'JIL definition' not in html


def test_autosys_renders_native_command_jil_and_box_rules():
    job = _job(autosys={"jil": {"command": "run.bat", "std_out_file": "result.txt", "condition": "s(A)",
                                         "box_success": "s(B)", "date_conditions": 0,
                                         "alarm_if_fail": False},
                               "run": {"resolved_command": "run.bat --actual", "exit_code": 0}},
               exit_code=0)
    view = build_job_detail_view(job, SchedulerType.AUTOSYS, "prod")
    assert view["command"] == "run.bat --actual"
    assert any(x["label"] == "Box success rule" for x in view["dependencies"])
    assert any(x["label"] == "Date conditions" and x["value"] == "0" for x in view["schedule"])
    assert any(x["label"] == "Exit code" and x["value"] == "0" for x in view["execution"])
    html = _route(SchedulerType.AUTOSYS, job)
    assert 'JIL definition' in html
    assert 'Run instance' in html
    assert 'Process Scheduler source detail' not in html
    assert 'data-copy-detail' in html
    assert 'run.bat --actual' in html


def test_empty_optional_fields_not_repeated_in_summary_and_explicit_false_preserved():
    job = _job(process_scheduler=ProcessSchedulerJobReference.from_wire({
        "ConditionExpression": None, "StartAtTimeForce": False,
        "Command": None, "StdOutputFile": "", "StdErrorFile": None,
    }))
    view = build_job_detail_view(job, SchedulerType.PROCESS_SCHEDULER, "u5")
    assert view["command"] is None and view["output"] is None
    assert not view["dependencies"]
    assert any(x["value"] == "false" for x in view["schedule"])
    html = _route(SchedulerType.PROCESS_SCHEDULER, job)
    assert 'Command &amp; logs' not in html
    assert 'No execution data in this snapshot' in html  # The header carries status independently.
    assert 'data-empty-field hidden' in html


def test_user_supplied_values_are_html_escaped():
    job = _job(process_scheduler=ProcessSchedulerJobReference.from_wire({
        "Command": '<img src=x onerror=alert(1)>', "Description": '<script>bad()</script>',
    }))
    html = _route(SchedulerType.PROCESS_SCHEDULER, job)
    assert '<script>bad()</script>' not in html
    assert '<img src=x onerror=alert(1)>' not in html
    assert '&lt;img src=x onerror=alert(1)&gt;' in html
