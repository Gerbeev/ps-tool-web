"""Settings must not erase unexposed connection options or extension fields."""

from __future__ import annotations

from pathlib import Path

import yaml
from fastapi.testclient import TestClient

from app import config
from app.main import app


def _configure(tmp_path: Path, monkeypatch, scheduler: str = "process_scheduler") -> Path:
    monkeypatch.setenv("PS_TOOL_CONFIG_DIR", str(tmp_path))
    monkeypatch.setenv("ALLOW_CONNECTION_CONFIG_EDIT", "true")
    config.get_settings.cache_clear()
    config.invalidate_environment_cache()
    return config.scheduler_config_path(scheduler)


def test_settings_preserves_known_and_unknown_fields_and_top_level_metadata(tmp_path, monkeypatch):
    path = _configure(tmp_path, monkeypatch)
    initial = {
        "scheduler": "process_scheduler",
        "schema_version": 17,
        "extensions": {"tags": ["alpha", "beta"]},
        "environments": [
            {
                "id": "ps-u5", "environment": "U5", "host": "node:9001",
                "description": "Original", "enabled": True,
                "region": "eu", "connector_profile": "native_ps",
                "transport": "wcf", "source": "configured", "notes": "do not overwrite",
                "deployment_options": {"retry": 3, "flag": False},
            },
            {
                "id": "ps-dv", "environment": "DV", "endpoint_url": "legacy:9001",
                "description": "Dev", "enabled": False,
                "extra_option": [1, 2, 3],
            },
        ],
    }
    path.write_text(yaml.safe_dump(initial), encoding="utf-8")
    # The other scheduler is not part of the requested update.
    other = tmp_path / "autosys_environments.yaml"
    other.write_text("scheduler: autosys\nenvironments: []\n", encoding="utf-8")
    config.invalidate_environment_cache()

    try:
        with TestClient(app) as client:
            response = client.post(
                "/api/settings/environments/process_scheduler",
                data={
                    "present_ps-u5": "1",
                    "environment_ps-u5": "U5",
                    "host_ps-u5": "new-node:9001",
                    "description_ps-u5": "Revised",
                    # No enabled_ps-u5: intentionally disabled.
                    # ps-dv row was not submitted: leave it completely unchanged.
                },
                follow_redirects=False,
            )
        assert response.status_code == 303
        result = yaml.safe_load(path.read_text(encoding="utf-8"))
        assert result["schema_version"] == 17
        assert result["extensions"] == initial["extensions"]
        row = result["environments"][0]
        assert row == {
            **initial["environments"][0],
            "host": "new-node:9001",
            "description": "Revised",
            "enabled": False,
        }
        assert result["environments"][1] == initial["environments"][1]
        assert other.read_text(encoding="utf-8") == "scheduler: autosys\nenvironments: []\n"
        config.invalidate_environment_cache()
        reloaded = config.load_scheduler_environments("process_scheduler")
        assert reloaded[0].region == "eu"
        assert reloaded[0].connector_profile == "native_ps"
        assert reloaded[0].transport == "wcf"
        assert reloaded[0].notes == "do not overwrite"
    finally:
        config.invalidate_environment_cache()


def test_settings_preserves_legacy_endpoint_alias_and_clears_description(tmp_path, monkeypatch):
    path = _configure(tmp_path, monkeypatch, "autosys")
    data = {
        "scheduler": "autosys",
        "environments": [{
            "id": "autosys-u1", "environment": "U1",
            "endpoint_url": "before.example", "description": "Old",
            "enabled": False, "notes": "maintain",
        }],
    }
    path.write_text(yaml.safe_dump(data), encoding="utf-8")
    config.invalidate_environment_cache()
    try:
        with TestClient(app) as client:
            response = client.post("/api/settings/environments/autosys", data={
                "present_autosys-u1": "1", "host_autosys-u1": "after.example",
                "description_autosys-u1": "", "environment_autosys-u1": "U1",
                "enabled_autosys-u1": "on",
            }, follow_redirects=False)
        assert response.status_code == 303
        row = yaml.safe_load(path.read_text(encoding="utf-8"))["environments"][0]
        assert row["endpoint_url"] == "after.example"
        assert "host" not in row
        assert row["description"] == ""
        assert row["enabled"] is True
        assert row["notes"] == "maintain"
    finally:
        config.invalidate_environment_cache()


def test_partial_update_keeps_other_fields_and_no_change_does_not_rewrite(tmp_path, monkeypatch):
    path = _configure(tmp_path, monkeypatch, "autosys")
    original = (
        "# keep this file exactly as-is for a no-op\n"
        "scheduler: autosys\n"
        "environments:\n"
        "- id: autosys-u1\n"
        "  environment: U1\n"
        "  host: old-host\n"
        "  description: example\n"
        "  enabled: true\n"
        "  connector_profile: custom\n"
    )
    path.write_text(original, encoding="utf-8")
    config.invalidate_environment_cache()
    try:
        with TestClient(app) as client:
            response = client.post("/api/settings/environments/autosys", data={
                "host_autosys-u1": "old-host",
            }, follow_redirects=False)
            assert response.status_code == 303
            assert path.read_text(encoding="utf-8") == original
            response = client.post("/api/settings/environments/autosys", data={
                "host_autosys-u1": "new-host",
                # Missing presence marker means enabled was not edited.
            }, follow_redirects=False)
        assert response.status_code == 303
        row = yaml.safe_load(path.read_text(encoding="utf-8"))["environments"][0]
        assert row["host"] == "new-host"
        assert row["enabled"] is True
        assert row["description"] == "example"
        assert row["connector_profile"] == "custom"
    finally:
        config.invalidate_environment_cache()


def test_invalid_yaml_cannot_be_overwritten_by_save(tmp_path, monkeypatch):
    path = _configure(tmp_path, monkeypatch, "autosys")
    original = "scheduler: autosys\nenvironments: [unclosed\n"
    path.write_text(original, encoding="utf-8")
    try:
        entry = config.EnvironmentEntry(id="autosys-u1", environment="U1", endpoint_url="new")
        import pytest
        with pytest.raises(yaml.YAMLError):
            config.save_scheduler_environments("autosys", [entry])
        assert path.read_text(encoding="utf-8") == original
    finally:
        config.invalidate_environment_cache()


def test_save_new_entry_retains_its_explicit_technical_fields(tmp_path, monkeypatch):
    path = _configure(tmp_path, monkeypatch, "autosys")
    entry = config.EnvironmentEntry(
        id="autosys-u1", environment="U1", endpoint_url="host",
        connector_profile="custom", transport="https", notes="memo", region="eu",
    )
    config.save_scheduler_environments("autosys", [entry])
    row = yaml.safe_load(path.read_text(encoding="utf-8"))["environments"][0]
    assert row["connector_profile"] == "custom"
    assert row["transport"] == "https"
    assert row["notes"] == "memo"
    assert row["region"] == "eu"
    config.invalidate_environment_cache()
