"""Contract tests for describe-job enrichment of saved Process Scheduler snapshots."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest

from app.adapters.bridge_contract import BridgeJobV1, job_to_engine
from app.models import SnapshotJob
from app.models import AsOf, AsOfKind, ComparisonContext, JobNode, SchedulerType, TopologySnapshot
from app.services.snapshot_catalog import snapshot_catalog
from workstation_connectors import process_scheduler_connector as ps


_CONTEXT = {
    "environment_id": "ps-u5", "environment": "U5", "scheduler": "process_scheduler",
    "host": "127.0.0.1:9001", "topology_id": "Topology_Test",
}


def _fake_bridge(tmp_path: Path, *, format: str) -> Path:
    path = tmp_path / "bridge.py"
    path.write_text('''import json, sys
args = sys.argv[1:]
verb = args[0]
if verb == 'get-contexts':
    print(json.dumps({'name':'Topology_Test', 'jobs':[
       {'Name':'JOB_A','Kind':'COMMAND','Status':'Running', 'Machine':None,
        'LastStartTime':'2026-10-08T11:00:00+02:00'},
       {'Name':'JOB_B','Kind':'COMMAND','Status':'Waiting'},
       {'Name':'JOB_C','Kind':'COMMAND','Status':'Waiting'}]}))
elif verb == 'describe-job':
    name = args[args.index('--job')+1]
    if name == 'JOB_B':
        sys.stderr.write('simulated unavailable detail')
        sys.exit(2)
    elif name == 'JOB_C':
        print(json.dumps({'summary':{'name':'WRONG_JOB', 'status':'Success'}}))
    elif ''' + repr(format) + ''' == 'text':
        print("Job: JOB_A (command)\\nstatus : Success\\nraw wire fields (everything the server sent for this job):\\n"
              "Name: JOB_A\\nStatus: Success\\nJobType: Command\\nMachine: host-test\\n"
              "Command: python pipeline.py --token secret123\\n"
              "ResourceName: test_resource\\nStdOutputFile: C:\\\\logs\\\\test.log\\n"
              "StdErrorFile: C:\\\\logs\\\\error.log\\nEnvironmentVariables: PASSWORD=bad\\n"
              "Schedule: Monday,Tuesday\\nStartAtTime: 00:02\\n")
    else:
        print(json.dumps({'summary':{'name':'JOB_A', 'status':'Success','jobType':'Command'},
                          'raw':{'Name':'JOB_A','Machine':'host-test',
                                 'Command':'python pipeline.py', 'StdOutputFile':'C:/logs/test.log',
                                 'StdErrorFile':'C:/logs/error.log','EnvironmentVariables':'TOKEN=bad',
                                 'ResourceName':'test_resource'}}))
else: sys.exit(2)
''', encoding="utf-8")
    return path


@pytest.mark.parametrize("format", ["text", "json"])
def test_enriches_each_job_without_losing_runtime_or_other_jobs(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, format: str,
) -> None:
    script = _fake_bridge(tmp_path, format=format)
    conf = tmp_path / "conf.json"
    conf.write_text(json.dumps({
        "launcher": [sys.executable, str(script)], "protocol_mode": "args",
        "enable_job_detail": True, "job_detail_workers": 2, "timeout_sec": 5,
        "commands": {
            "fetch_topology": ["get-contexts", "--address", "{host}", "--names", "{topology}"],
            "fetch_job_detail": ["describe-job", "--address", "{host}", "--context", "{topology}", "--job", "{job}"],
        },
    }), encoding="utf-8")
    monkeypatch.setenv("PROCESS_SCHEDULER_CONNECTOR_CONFIG", str(conf))
    provider = ps.ProcessSchedulerProvider()
    result = provider.fetch_topology(_CONTEXT)
    assert len(result["jobs"]) == 3
    assert result["metadata"]["job_details"]["requested"] == 3
    assert result["metadata"]["job_details"]["enriched"] == 1
    assert result["metadata"]["job_details"]["failed"] == 2
    assert result["metadata"]["job_details"]["errors"] == {
        "job_detail_identity_mismatch": 1, "topobrowse_contract_mismatch": 1,
    }
    a, b, c = result["jobs"]
    assert a["status"] == "running"  # pinned to topology capture, not later detail
    assert a["actual_start"] == "2026-10-08T11:00:00+02:00"
    assert b["scheduler_job_name"] == "JOB_B"
    assert c["scheduler_job_name"] == "JOB_C"
    assert a["autosys_jil"]["machine"] == "host-test"
    assert a["autosys_jil"]["command"].startswith("python pipeline.py")
    assert "secret123" not in json.dumps(result)
    assert "TOKEN=bad" not in json.dumps(result)
    assert "PASSWORD=bad" not in json.dumps(result)
    assert a["autosys_jil"]["std_out_file"].endswith("test.log")
    assert a["autosys_jil"]["std_err_file"].endswith("error.log")
    assert a["process_scheduler"]["ResourceName"] == "test_resource"
    assert a["process_scheduler"]["EnvironmentVariables"] == "[REDACTED]"

    # Verify all new data survives the frozen bridge schema and durable snapshot model.
    engine = job_to_engine(BridgeJobV1.model_validate(a))
    restored = SnapshotJob.model_validate_json(engine.model_dump_json())
    assert restored.log_path == a["autosys_jil"]["std_out_file"]
    assert restored.process_scheduler is not None
    assert restored.process_scheduler.model_extra["ResourceName"] == "test_resource"
    assert restored.autosys.jil.command == a["autosys_jil"]["command"]


def test_job_detail_absent_when_enrichment_disabled(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    script = _fake_bridge(tmp_path, format="json")
    conf = tmp_path / "conf.json"
    conf.write_text(json.dumps({
        "launcher": [sys.executable, str(script)], "protocol_mode": "args",
        "enable_job_detail": False,
        "commands": {"fetch_topology": ["get-contexts", "--address", "{host}", "--names", "{topology}"]},
    }), encoding="utf-8")
    monkeypatch.setenv("PROCESS_SCHEDULER_CONNECTOR_CONFIG", str(conf))
    result = ps.ProcessSchedulerProvider().fetch_topology(_CONTEXT)
    assert result["metadata"]["job_details"]["requested"] == 0
    assert all("Command" not in job["process_scheduler"] for job in result["jobs"])


def test_parse_native_text_detail_retains_paths() -> None:
    text = '''Job: JOB_Z (command)
raw wire fields (everything the server sent for this job):
Name: JOB_Z
Command: C:\\Tools\\Worker.exe /run
StdOutputFile: C:\\RA\\Logs\\job.log
StdErrorFile: C:\\RA\\Logs\\job.err
EnvironmentVariables: None
UsePutty: true
'''
    parsed = ps._detail_source(text)
    assert parsed is not None
    assert parsed["Command"].endswith("/run")
    assert parsed["StdOutputFile"] == r"C:\RA\Logs\job.log"
    assert parsed["UsePutty"] is True


def test_enriched_fields_persist_in_immutable_snapshot(tmp_path: Path) -> None:
    job = job_to_engine(BridgeJobV1.model_validate({
        "job_uid": "job-test", "scheduler_job_name": "JOB_A", "status": "success",
        "autosys_jil": {"job_type": "CMD", "command": "python worker.py",
                        "machine": "host-test", "std_out_file": "C:/logs/job.log"},
        "process_scheduler": {"Name": "JOB_A", "Command": "python worker.py",
                              "ResourceName": "resource-test", "StdOutputFile": "C:/logs/job.log"},
        "attributes": {"job_detail_capture": "complete"},
    }))
    snapshot = TopologySnapshot(
        context=ComparisonContext(
            environment_id="ps-u5", scheduler=SchedulerType.PROCESS_SCHEDULER,
            as_of=AsOf(kind=AsOfKind.LATEST),
        ),
        roots=[JobNode(job=job)], flat_jobs=[job],
        metadata={"job_details": {"requested": 1, "enriched": 1, "failed": 0, "errors": {}}},
    )
    record = snapshot_catalog.save(snapshot)
    loaded = snapshot_catalog.load(record.snapshot_id)
    assert loaded is not None
    saved = loaded[0].flat_jobs[0]
    assert saved.autosys.jil.command == "python worker.py"
    assert saved.log_path == "C:/logs/job.log"
    assert saved.process_scheduler is not None
    assert saved.process_scheduler.model_extra["ResourceName"] == "resource-test"
    assert saved.attributes["job_detail_capture"] == "complete"
    assert loaded[0].metadata["job_details"]["enriched"] == 1
