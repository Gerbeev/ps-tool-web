"""Favicon references resolve locally for all full page views."""

from pathlib import Path
from xml.etree import ElementTree

from bs4 import BeautifulSoup
from fastapi.testclient import TestClient

from app.main import app

ROOT = Path(__file__).resolve().parents[1]


def test_favicon_assets_are_valid_and_served() -> None:
    svg = ROOT / "app/static/favicon.svg"
    assert ElementTree.parse(svg).getroot().tag.endswith("svg")
    with TestClient(app) as client:
        svg_response = client.get("/static/favicon.svg")
        ico_response = client.get("/static/favicon.ico")
        default_response = client.get("/favicon.ico")
    assert svg_response.status_code == 200
    assert "image/svg+xml" in svg_response.headers["content-type"]
    assert ico_response.status_code == default_response.status_code == 200
    assert ico_response.content == default_response.content
    assert ico_response.content[:4] == b"\x00\x00\x01\x00"


def test_full_pages_link_to_favicon() -> None:
    with TestClient(app) as client:
        for page in ("/snapshots", "/browse", "/compare", "/settings"):
            response = client.get(page)
            assert response.status_code == 200
            head = BeautifulSoup(response.text, "html.parser").head
            assert head.select_one('link[rel="icon"][href="/static/favicon.svg"]') is not None
            assert head.select_one('link[rel="alternate icon"][href="/static/favicon.ico"]') is not None
