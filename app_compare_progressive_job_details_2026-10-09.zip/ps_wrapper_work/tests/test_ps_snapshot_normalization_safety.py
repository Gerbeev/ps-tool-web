"""Regressions for failures after the Process Scheduler detail progress reaches 100%."""

from __future__ import annotations

import pytest

from workstation_connectors import process_scheduler_connector as ps


@pytest.mark.parametrize(
    ("start", "end"),
    [
        ("2026-10-08T12:00:00+02:00", "2026-10-08T12:10:00"),
        ("2026-10-08T12:00:00", "2026-10-08T12:10:00+02:00"),
    ],
)
def test_mixed_timezone_timestamps_do_not_abort_topology(start: str, end: str) -> None:
    source = {
        "jobs": [
            {
                "Name": "COMMAND_A",
                "Kind": "COMMAND",
                "Status": "Success",
                "LastStartTime": start,
                "LastFinishTime": end,
            },
            {"Name": "COMMAND_B", "Kind": "COMMAND", "Status": "Waiting"},
        ]
    }
    context = {"environment_id": "ps-u5", "topology_id": "Topology_Test"}

    result = ps._normalize_topology(source, context, "Topology_Test")

    assert len(result["jobs"]) == 2
    assert result["jobs"][0]["actual_start"] == start
    assert result["jobs"][0]["actual_end"] == end
    assert result["jobs"][0]["duration_sec"] is None
    assert result["jobs"][1]["status"] == "pending"


def test_consistent_timezone_timestamps_compute_duration() -> None:
    assert ps._duration_seconds(
        "2026-10-08T12:00:00+02:00",
        "2026-10-08T12:05:30+02:00",
    ) == 330.0


def test_unexpected_normalizer_error_returns_safe_stage_specific_code(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    provider = ps.ProcessSchedulerProvider()
    provider.config = {"enable_job_detail": False}
    monkeypatch.setattr(
        ps,
        "_invoke_bridge",
        lambda *_args, **_kwargs: ps.BridgeResult(
            payload={"jobs": [{"Name": "JOB_A", "Status": "Failed"}]},
            mode="args",
            command_label="get-contexts",
            stdout_bytes=0,
        ),
    )

    def broken_normalizer(*_args: object) -> dict[str, object]:
        raise TypeError("raw bank data MUST NOT reach the log")

    monkeypatch.setattr(ps, "_normalize_topology", broken_normalizer)
    context = {"environment_id": "ps-u5", "topology_id": "Topology_Test"}

    with pytest.raises(ps.ConnectorError) as exc:
        provider.fetch_topology(context)
    assert exc.value.code == "ps_normalization_typeerror"
    assert exc.value.message == "Process Scheduler topology normalization failed (TypeError)"
    assert "raw bank data" not in exc.value.message
