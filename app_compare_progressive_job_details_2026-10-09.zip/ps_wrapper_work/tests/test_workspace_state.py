"""Snapshot identity and browser workspace-state UI contracts."""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.services.snapshot_jobs import _source_identity


ROOT = Path(__file__).resolve().parents[1]


def test_snapshot_run_identifies_exact_source_and_scope():
    autosys = _source_identity('autosys-u1', '')
    assert autosys['scheduler'] == 'autosys'
    assert 'U1' in autosys['source_label']
    assert 'AutoSys' in autosys['source_label']
    assert 'COB: ' in autosys['source_label']

    process_scheduler = _source_identity('ps-u5', 'DataPlatform_20261001_Friday')
    assert process_scheduler['scheduler'] == 'process_scheduler'
    assert 'U5' in process_scheduler['source_label']
    assert 'Process Scheduler' in process_scheduler['source_label']
    assert 'Topology: DataPlatform_20261001_Friday' in process_scheduler['source_label']
    assert process_scheduler['topology_id'] == 'DataPlatform_20261001_Friday'
    assert 'https' not in process_scheduler['source_label']


def test_snapshot_progress_identity_and_browser_state_markup():
    with TestClient(app) as client:
        pages = {page: client.get('/' + page) for page in ('snapshots', 'browse', 'blockers', 'compare')}
        script = client.get('/static/js/workspace-state.js')
    assert script.status_code == 200
    assert 'sessionStorage' in script.text
    assert 'session_id' not in script.text
    for page, response in pages.items():
        assert response.status_code == 200, page
        assert response.text.count('/static/js/workspace-state.js') == 1
    assert 'id="snapshot-progress-source"' in pages['snapshots'].text
    assert 'id="snapshot-topology"' in (ROOT / 'app/templates/partials/snapshot_source_fields.html').read_text()


def test_sidebar_order_and_compact_debug_control():
    with TestClient(app) as client:
        sidebar = client.get('/snapshots').text
        css = client.get('/static/css/custom.css').text
    assert sidebar.index('href="/snapshots"') < sidebar.index('href="/browse"')
    assert sidebar.index('href="/browse"') < sidebar.index('href="/compare"')
    assert sidebar.index('href="/compare"') < sidebar.index('href="/blockers"')
    assert '.snapshot-debug-limit { width: min(100%, 16rem);' in css


def test_workspace_state_javascript_behavior():
    if not shutil.which('node'):
        pytest.skip('Node.js is optional for JS-only browser behavior checks')
    result = subprocess.run(
        ['node', str(ROOT / 'tests/js/test_workspace_state.js')],
        cwd=ROOT, capture_output=True, text=True, timeout=15, check=False,
    )
    assert result.returncode == 0, result.stderr or result.stdout
    assert 'workspace state tests passed' in result.stdout
