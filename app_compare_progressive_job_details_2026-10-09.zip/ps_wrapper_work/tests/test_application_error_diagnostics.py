"""Application error diagnostics: actionable call sites, safe values, stable responses."""

from __future__ import annotations

import json
import time

import pytest
from fastapi.testclient import TestClient

from app.config import get_settings, invalidate_environment_cache
from app.main import app
from app.services.runtime_diagnostics import log_exception, set_debug_enabled
from app.services.snapshot_jobs import SnapshotJobs


@pytest.fixture(autouse=True)
def _isolate_configuration_cache():
    invalidate_environment_cache()
    yield
    invalidate_environment_cache()
    get_settings.cache_clear()


def _logs(tmp_path):
    return [json.loads(line) for line in (tmp_path / 'logs' / 'application.log').read_text().splitlines()]


def test_exception_location_and_root_cause_never_log_exception_message(monkeypatch, tmp_path):
    monkeypatch.setenv('PS_TOOL_LOG_DIR', str(tmp_path / 'logs'))
    monkeypatch.setenv('PS_TOOL_CONFIG_DIR', str(tmp_path / 'config'))
    get_settings.cache_clear()
    set_debug_enabled(False)

    def fake_business_logic():
        raise OSError('password=confidential; bank-host=classified')

    try:
        try:
            fake_business_logic()
        except OSError as error:
            raise RuntimeError('credential=hidden') from error
    except RuntimeError as wrapped:
        log_exception('test_error', wrapped, operation='unit_test', request_id='test-123')

    record = _logs(tmp_path)[-1]
    assert record['event'] == 'test_error'
    assert record['error_type'] == 'OSError'
    assert record['operation'] == 'unit_test'
    assert record['request_id'] == 'test-123'
    assert isinstance(record['line'], int)
    assert record['line'] >= 0
    payload = (tmp_path / 'logs' / 'application.log').read_text()
    assert 'confidential' not in payload
    assert 'classified' not in payload
    assert 'hidden' not in payload


def test_unexpected_api_error_gets_correlatable_safe_response(monkeypatch, tmp_path):
    monkeypatch.setenv('PS_TOOL_LOG_DIR', str(tmp_path / 'logs'))
    monkeypatch.setenv('PS_TOOL_CONFIG_DIR', str(tmp_path / 'config'))
    get_settings.cache_clear()

    from app.routes import snapshots

    def broken_catalog():
        raise OSError('private-endpoint-password=not-for-output')

    monkeypatch.setattr(snapshots.snapshot_catalog, 'list', broken_catalog)
    with TestClient(app, raise_server_exceptions=False) as client:
        response = client.get('/api/snapshots/catalog')
        assert response.status_code == 500
        data = response.json()
        assert data['request_id'] in data['detail']
        assert 'private-endpoint-password' not in response.text
        htmx = client.get('/api/snapshots/catalog', headers={'HX-Request': 'true'})
        assert htmx.status_code == 500
        assert htmx.headers['content-type'].startswith('text/html')
        assert 'private-endpoint-password' not in htmx.text
        page = client.get('/snapshots')
        assert page.status_code == 500
        assert 'private-endpoint-password' not in page.text

    errors = [entry for entry in _logs(tmp_path) if entry['event'] == 'application_request_failed']
    assert len(errors) == 3  # one event per actual failure, never duplicate layers
    assert errors[0]['request_id'] == data['request_id']
    assert errors[0]['error_type'] == 'OSError'
    assert errors[0]['module'] == 'app.routes.snapshots'
    assert errors[0]['function'] == '_catalog_context'
    assert errors[0]['line'] > 0
    assert 'private-endpoint-password' not in (tmp_path / 'logs' / 'application.log').read_text()


def test_snapshot_failure_has_run_id_and_root_application_location(monkeypatch, tmp_path):
    monkeypatch.setenv('PS_TOOL_LOG_DIR', str(tmp_path / 'logs'))
    monkeypatch.setenv('PS_TOOL_CONFIG_DIR', str(tmp_path / 'config'))
    get_settings.cache_clear()
    from app.services.snapshot_generation import SnapshotGenerationError

    def fake_generation(environment_id: str, *, topology_id: str = ''):
        try:
            raise OSError('sensitive=classified')
        except OSError as error:
            raise SnapshotGenerationError('sensitive-user-message') from error

    monkeypatch.setattr('app.services.snapshot_generation.generate_snapshot', fake_generation)
    worker = SnapshotJobs()
    run_id, started = worker.start('autosys-u1', '')
    assert started is True
    status = worker.status(run_id)
    for _ in range(100):
        status = worker.status(run_id)
        if status['state'] == 'failed':
            break
        time.sleep(0.01)
    assert status['state'] == 'failed'
    assert status['run_id'] == run_id
    assert 'Run ID' in status['error']
    assert 'sensitive' not in str(status)
    entries = [entry for entry in _logs(tmp_path) if entry['event'] == 'snapshot_failed'
               and entry['run_id'] == run_id]
    assert len(entries) == 1
    assert entries[0]['error_type'] == 'OSError'
    assert entries[0]['module'] == 'app.services.snapshot_jobs'
    assert entries[0]['function'] == '_run'
    assert entries[0]['line'] > 0
    assert 'sensitive' not in (tmp_path / 'logs' / 'application.log').read_text()
    worker._executor.shutdown(wait=True)


def test_catalog_failure_shows_safe_short_message(monkeypatch, tmp_path):
    monkeypatch.setenv('PS_TOOL_LOG_DIR', str(tmp_path / 'logs'))
    monkeypatch.setenv('PS_TOOL_CONFIG_DIR', str(tmp_path / 'config'))
    get_settings.cache_clear()
    from app.routes import snapshots

    def broken_delete(_snapshot_id: str):
        raise OSError('secret-token-from-storage')

    monkeypatch.setattr(snapshots.snapshot_catalog, 'delete', broken_delete)
    with TestClient(app) as client:
        response = client.post('/api/snapshots/delete', data={'snapshot_id': 'sample'})
    assert response.status_code == 200
    assert 'Could not delete snapshot. See logs/application.log.' in response.text
    assert 'secret-token-from-storage' not in response.text
    entries = [entry for entry in _logs(tmp_path) if entry['event'] == 'snapshot_catalog_delete_failed']
    assert len(entries) == 1
    assert entries[0]['operation'] == 'catalog_delete'
    assert entries[0]['error_type'] == 'OSError'
    assert 'secret-token-from-storage' not in (tmp_path / 'logs' / 'application.log').read_text()
