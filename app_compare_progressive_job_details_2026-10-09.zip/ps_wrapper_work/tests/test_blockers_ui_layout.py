"""Keep Blockers comfortable on wide/narrow screens without changing analysis APIs."""
from pathlib import Path

from fastapi.testclient import TestClient

from app.main import app


ROOT = Path(__file__).resolve().parents[1]


def test_blockers_capture_action_is_compact_and_snapshot_dependent():
    with TestClient(app) as client:
        page = client.get('/blockers')
        script = client.get('/static/js/blockers-ui.js')
    assert page.status_code == 200
    assert page.text.count('id="blockers-analyze-button"') == 1
    assert 'blockers-capture-form' in page.text
    assert 'id="blockers-snapshot-field"' in page.text
    assert script.status_code == 200
    assert 'updateCaptureAction' in script.text
    assert 'blockers-snapshot-field' in script.text
    assert 'scrollIntoView' in script.text


def test_recovery_and_advanced_controls_remain_available():
    results = (ROOT / 'app/templates/partials/blockers_results.html').read_text()
    recovery = (ROOT / 'app/templates/partials/blockers_recovery.html').read_text()
    metrics = (ROOT / 'app/templates/partials/blockers_metrics.html').read_text()
    for form_name in ('view', 'query', 'classification', 'scope', 'critical_only'):
        assert f'name="{form_name}"' in results
    assert 'id="blockers-list"' in results
    assert 'id="blockers-detail"' in results
    assert "partials/blockers_recovery.html" in results
    assert 'blockers-filter-disclosure' in results
    assert 'blockers-recovery-disclosure' in recovery
    assert 'hx-post="/api/blockers/recovery"' in recovery
    assert 'name="target_uid"' in recovery
    assert 'blockers-recovery-action' in recovery
    assert 'blockers-secondary-metrics' in metrics
    for metric in ('condition_gate_count', 'suspected', 'fully_explained_count', 'partially_explained_count'):
        assert metric in metrics


def test_mobile_rows_include_accessible_labels_and_actions():
    listing = (ROOT / 'app/templates/partials/blockers_list.html').read_text()
    css = (ROOT / 'app/static/css/custom.css').read_text()
    assert listing.count('data-label="Job"') == 3
    assert listing.count('data-label="Actions"') == 3
    assert '.blockers-table tbody tr { display: grid;' in css
    assert '.blockers-recovery-form { display: flex;' in css
    assert '.blockers-capture-form { display: grid;' in css


def test_snapshot_controls_share_a_top_aligned_row_even_with_helper_text():
    page = (ROOT / 'app/templates/blockers.html').read_text()
    fragment = (ROOT / 'app/templates/partials/blockers_snapshot_select.html').read_text()
    css = (ROOT / 'app/static/css/custom.css').read_text()
    assert 'align-items: start; }' in next(
        line for line in css.splitlines() if line.startswith('.blockers-capture-form {')
    )
    assert 'class="box-field-stack blockers-capture-action"' in page
    assert 'class="box-field-label blockers-capture-action-spacer"' in page
    assert '.blockers-capture-action-spacer { visibility: hidden; }' in css
    assert '.blockers-capture-action-spacer { display: none; }' in css
    assert 'No saved snapshots for this environment' in fragment
