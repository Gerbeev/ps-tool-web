"""Structural Browse disclosure and full snapshot search regression checks."""

from fastapi.testclient import TestClient

from app.main import app
from app.models import ComparisonContext, JobNode, JobStatus, SchedulerType, SnapshotJob, TopologySnapshot
from app.services.browse_expansion import expanded_rows
from app.session_store import BrowseSession, session_store

client = TestClient(app)


def make_snapshot() -> TopologySnapshot:
    a = SnapshotJob(job_uid="a", scheduler_job_name="ROOT_BOX", status=JobStatus.RUNNING)
    b = SnapshotJob(job_uid="b", scheduler_job_name="INNER_BOX", status=JobStatus.RUNNING)
    c = SnapshotJob(job_uid="c", scheduler_job_name="FAILED_JOB", status=JobStatus.FAILURE)
    d = SnapshotJob(job_uid="d", scheduler_job_name="OTHER_JOB", status=JobStatus.SUCCESS)
    return TopologySnapshot(
        context=ComparisonContext(environment_id="test", scheduler=SchedulerType.AUTOSYS),
        roots=[JobNode(job=a, children=[JobNode(job=b, children=[JobNode(job=c)]), JobNode(job=d)])],
        flat_jobs=[a, b, c, d],
    )


def session(snapshot: TopologySnapshot) -> str:
    sid = session_store.new_id()
    session_store.put_browse(BrowseSession(session_id=sid, context=snapshot.context, snapshot=snapshot))
    return sid


def test_expanded_tree_depth_and_all_nodes_in_one_response():
    snapshot = make_snapshot()
    sid = session(snapshot)
    response = client.get('/api/browse/tree/all', params={'session_id': sid})
    assert response.status_code == 200
    html = response.text
    assert [name for name in ['ROOT_BOX', 'INNER_BOX', 'FAILED_JOB', 'OTHER_JOB'] if name in html] == ['ROOT_BOX', 'INNER_BOX', 'FAILED_JOB', 'OTHER_JOB']
    assert html.count('class="browse-tree-node browse-tree-node--flat"') == 4
    for depth, uid in ((0, 'a'), (1, 'b'), (2, 'c'), (1, 'd')):
        assert f'data-depth="{depth}" data-tree-uid="{uid}"' in html
    assert html.count('data-browse-flat-toggle') == 2
    assert f'/api/browse/job/c?session_id={sid}' in html
    assert 'data-job-uid="c"' in html
    assert 'hx-trigger="revealed once"' not in html
    assert client.get('/api/browse/job/c', params={'session_id': sid}).status_code == 200


def test_search_keeps_ancestors_and_lazy_mode():
    sid = session(make_snapshot())
    filtered = client.get('/api/browse/filter', params={'session_id': sid, 'query': 'FAILED_JOB'})
    assert filtered.status_code == 200
    assert [filtered.text.index(f'data-job-uid="{uid}"') for uid in ('a','b','c')] == sorted([
        filtered.text.index(f'data-job-uid="{uid}"') for uid in ('a','b','c')
    ])
    assert 'data-job-uid="d"' not in filtered.text
    assert 'open>' in filtered.text
    lazy = client.get('/api/browse/tree', params={'session_id': sid})
    assert lazy.status_code == 200
    assert 'data-job-uid="c"' not in lazy.text
    assert 'hx-trigger="revealed once"' in lazy.text


def test_full_expansion_is_iterative_and_bounded():
    snapshot = make_snapshot()
    rows, truncated = expanded_rows(snapshot, max_rows=3)
    assert [row.job.job_uid for row in rows] == ['a', 'b', 'c']
    assert truncated
    rows, truncated = expanded_rows(snapshot)
    assert [row.job.job_uid for row in rows] == ['a', 'b', 'c', 'd']
    assert not truncated


def test_deep_chain_does_not_recurse():
    jobs = [SnapshotJob(job_uid=str(i), scheduler_job_name=f'J{i}', status=JobStatus.PENDING) for i in range(1600)]
    root = JobNode(job=jobs[-1])
    for job in reversed(jobs[:-1]):
        root = JobNode(job=job, children=[root])
    snap = TopologySnapshot(context=ComparisonContext(environment_id='test', scheduler=SchedulerType.AUTOSYS), roots=[root], flat_jobs=jobs)
    rows, truncated = expanded_rows(snap)
    assert len(rows) == 1600
    assert rows[-1].depth == 1599
    assert not truncated


def test_expanded_tree_rejects_missing_session():
    assert client.get('/api/browse/tree/all', params={'session_id': 'not-a-session'}).status_code == 404


def test_controls_present_in_existing_browse_layout():
    from pathlib import Path
    template = Path('app/templates/partials/tree_side.html').read_text(encoding='utf-8')
    js = Path('app/static/js/browse-filters.js').read_text(encoding='utf-8')
    assert 'id="browse-expand-all"' in template
    assert 'id="browse-collapse-all"' in template
    assert "treeMode = 'expanded'" in js
    assert "setNestedBranches(body, false)" in js
    assert 'selectedJobUid' in js
