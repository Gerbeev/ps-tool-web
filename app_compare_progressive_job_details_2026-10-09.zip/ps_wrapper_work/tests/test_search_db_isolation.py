"""Pytest must never update the packaged search index."""

from __future__ import annotations

import os
from pathlib import Path

from app.search.sqlite_fts import search_index


def test_test_suite_uses_isolated_search_db():
    db_path = Path(os.environ["SEARCH_DB_PATH"]).resolve()
    assert db_path == Path(search_index._path).resolve()
    assert db_path.name == "search.db"
    assert db_path.parent.name.startswith("ps-tool-pytest-fts-")
    assert db_path != (Path(__file__).resolve().parents[1] / "data" / "search.db").resolve()
