"""Counterfactual diagnosis: exact bounded sets, conservative unknowns, and UI."""
from __future__ import annotations

import json
from datetime import datetime, timezone

from fastapi.testclient import TestClient

from app.main import app
from app.models import (AdapterCapabilities, ComparisonContext, DependencyEdge,
                        JobStatus as S, SchedulerType, SnapshotJob, TopologySnapshot)
from app.routes import blockers as route
from app.services.blockers import Truth, analyze_blockers
from app.services.blockers_recovery import (InvalidRecoverySelection, MAX_INTERVENTIONS,
                                            plan_recovery, simulate_what_if)


def make_report(statuses, targets, *, scheduler=SchedulerType.AUTOSYS, job_fields=None):
    job_fields = job_fields or {}
    jobs = [SnapshotJob(job_uid=uid, scheduler_job_name=uid, status=status,
                        **job_fields.get(uid, {})) for uid, status in statuses.items()]
    edges = [DependencyEdge(from_uid=source, to_uid=target, condition=expr)
             for source, target, expr in targets]
    snapshot = TopologySnapshot(context=ComparisonContext(environment_id='test',scheduler=scheduler),
                                flat_jobs=jobs, edges=edges, fetched_at=datetime(2026,10,9,tzinfo=timezone.utc),
                                capabilities=AdapterCapabilities(dependencies=True))
    return analyze_blockers(snapshot, critical_names=['T', 'Z'])


def test_minimal_and_or_options_are_exact_and_unique():
    expr = 's(A) AND (s(B) OR s(C))'
    report = make_report({'A':S.FAILURE,'B':S.FAILURE,'C':S.FAILURE,'T':S.PENDING},
                         [(uid,'T',expr) for uid in 'ABC'])
    result = plan_recovery(report,'T')
    assert result.status == 'plans_found' and result.complete
    assert {frozenset(plan.assumptions) for plan in result.plans} == {
        frozenset(['A','B']), frozenset(['A','C'])}
    assert all(plan.impact.target_result == Truth.TRUE for plan in result.plans)
    assert all(plan.impact.critical_reachable == ('T',) for plan in result.plans)
    assert all(plan.impact.directly_ready == ('T',) for plan in result.plans)
    assert all(plan.impact.potentially_reachable == ('T',) for plan in result.plans)
    assert result.explored > 3


def test_or_successful_alternative_is_already_ready():
    expr = 's(A) OR s(B)'
    r = make_report({'A':S.FAILURE,'B':S.SUCCESS,'T':S.PENDING},
                    [('A','T',expr),('B','T',expr)])
    assert plan_recovery(r,'T').status == 'already_ready'


def test_counterfactual_separates_immediately_ready_and_propagated_reach():
    r = make_report({'A':S.FAILURE,'M':S.PENDING,'T':S.PENDING,'Z':S.PENDING},
                    [('A','M','s(A)'), ('M','T','s(M)'),('T','Z','s(T)')])
    result = plan_recovery(r,'T')
    assert len(result.plans) == 1
    impact = result.plans[0].impact
    assert impact.assumptions == ('A',)
    assert impact.directly_ready == ('M',)
    assert impact.potentially_reachable == ('M','T','Z')
    assert impact.critical_reachable == ('T','Z')


def test_unknown_required_condition_never_implied_ready():
    expr = 's(A) AND s(U)'
    r = make_report({'A':S.FAILURE,'U':S.UNKNOWN,'T':S.PENDING},
                    [('A','T',expr),('U','T',expr)])
    result = plan_recovery(r,'T')
    assert result.baseline is Truth.FALSE
    assert not result.plans
    assert simulate_what_if(r,'T',['A']).target_result is Truth.UNKNOWN


def test_missing_dependency_edges_never_inferred():
    r = make_report({'A':S.FAILURE,'T':S.PENDING},
                    [('A','T','s(A) AND s(MISSING)')])
    assert not r.conditions['T'].supported
    result = plan_recovery(r,'T')
    assert not result.plans
    assert result.baseline is Truth.UNKNOWN


def test_negative_predicate_does_not_call_success_a_recovery():
    r = make_report({'A':S.SUCCESS,'T':S.PENDING}, [('A','T','f(A)')])
    result = plan_recovery(r,'T')
    assert result.candidates == () and result.plans == []


def test_unknown_unverified_branch_does_not_prevent_verified_or_success():
    expr = 's(A) OR s(U)'
    r = make_report({'A':S.FAILURE,'U':S.UNKNOWN,'T':S.PENDING},
                    [('A','T',expr),('U','T',expr)])
    result = plan_recovery(r,'T')
    assert [p.assumptions for p in result.plans] == [('A',)]


def test_multiple_targets_counted_once_and_shared_intervention():
    r = make_report({'A':S.FAILURE,'T':S.PENDING,'Z':S.PENDING},
                    [('A','T','s(A)'),('A','Z','s(A)')])
    impact = simulate_what_if(r,'T',['A'])
    assert set(impact.potentially_reachable) == {'T','Z'}
    assert set(impact.critical_reachable) == {'T','Z'}


def test_budget_cap_reports_incomplete_and_refuses_invalid_selection():
    statuses = {f'J{i}':S.FAILURE for i in range(5)} | {'T':S.PENDING}
    expr = ' AND '.join(f's(J{i})' for i in range(5))
    r = make_report(statuses, [(f'J{i}','T',expr) for i in range(5)])
    result = plan_recovery(r,'T')
    assert result.complete is False
    assert not result.plans and result.explored > 0
    try:
        simulate_what_if(r,'T',[f'J{i}' for i in range(5)])
    except InvalidRecoverySelection:
        pass
    else:
        assert False, 'must reject excessive interventions'


def test_many_candidates_over_limit_reports_incomplete_without_exponential_search():
    statuses = {f'J{i}':S.FAILURE for i in range(13)} | {'T':S.PENDING}
    expr = ' OR '.join(f's(J{i})' for i in range(13))
    r = make_report(statuses, [(f'J{i}','T',expr) for i in range(13)])
    result = plan_recovery(r,'T')
    assert result.status == 'limit_reached' and not result.complete and result.explored == 0


def test_cycle_does_not_create_recovery_proof():
    r = make_report({'A':S.PENDING,'B':S.PENDING,'T':S.PENDING},
                    [('A','B','s(A)'), ('B','A','s(B)'), ('A','T','s(A)')])
    assert plan_recovery(r,'T').plans == []


def test_long_chain_without_recursive_overflow():
    n = 1300
    statuses = {'A':S.FAILURE} | {f'N{i}':S.PENDING for i in range(n)}
    edges = [('A','N0','s(A)')] + [(f'N{i-1}',f'N{i}',f's(N{i-1})') for i in range(1,n)]
    r = make_report(statuses, edges)
    result = plan_recovery(r,f'N{n-1}')
    assert len(result.plans) == 1
    assert result.plans[0].assumptions == ('A',)


def test_html_routes_use_cached_snapshot_and_never_write(monkeypatch):
    r = make_report({'A':S.FAILURE,'T':S.PENDING}, [('A','T','s(A)')])
    sess = route._Session(snapshot_id='unit',environment_id='test', report=r,record=type('R',(),{'label':'unit','source_scope':'test'})())
    sid = route._put(sess)
    assert sid
    client = TestClient(app)
    response = client.post('/api/blockers/recovery',data={'session_id':sid,'target_uid':'T'})
    assert response.status_code == 200
    assert 'Option 1' in response.text
    assert 'what-if' in response.text
    assert 'Custom what-if' in response.text
    valid = client.post('/api/blockers/what-if',data={'session_id':sid, 'target_uid':'T', 'assumed_uids':json.dumps(['A'])})
    assert valid.status_code == 200 and 'SUCCESS' in valid.text and 'Newly directly ready' in valid.text
    manual = client.post('/api/blockers/what-if',data={'session_id':sid, 'target_uid':'T', 'assumption':['A']})
    assert manual.status_code == 200 and 'SUCCESS' in manual.text
    bad = client.post('/api/blockers/what-if',data={'session_id':sid,'target_uid':'T','assumed_uids':json.dumps(['T'])})
    assert bad.status_code == 400
    assert client.post('/api/blockers/recovery',data={'session_id':sid,'target_uid':'not-found'}).status_code == 400
    route._sessions.pop(sid,None)


def test_nested_autosys_box_success_rule_produces_internal_recovery():
    r = make_report(
        {'ROOT':S.RUNNING,'INNER':S.RUNNING,'BAD':S.FAILURE,'T':S.PENDING},
        [('ROOT','T','s(ROOT)')],
        job_fields={
            'ROOT': {'parent_uid':None},
            'INNER': {'parent_uid':'ROOT'},
            'BAD': {'parent_uid':'INNER'},
        },
    )
    r.jobs['ROOT'].autosys.jil.job_type = 'BOX'
    r.jobs['INNER'].autosys.jil.job_type = 'BOX'
    r.jobs['ROOT'].autosys.jil.box_success = 's(INNER)'
    r.jobs['INNER'].autosys.jil.box_success = 's(BAD)'
    r = analyze_blockers(r.snapshot, critical_names=['T'])
    result = plan_recovery(r,'T')
    assert [plan.assumptions for plan in result.plans] == [('BAD',)]
    assert result.plans[0].impact.potentially_reachable == ('T',)
    assert result.plans[0].impact.directly_ready == ()


def test_failed_unverified_box_does_not_gain_internal_proof():
    r = make_report({'BOX':S.FAILURE,'BAD':S.FAILURE,'T':S.PENDING},
                    [('BOX','T','s(BOX)')],job_fields={'BAD':{'parent_uid':'BOX'}})
    result = plan_recovery(r,'T')
    assert [p.assumptions for p in result.plans] == [('BOX',)]
    assert 'BAD' not in result.candidates


def test_cyclic_branch_can_be_bypassed_by_known_or_alternative():
    r = make_report({'A':S.PENDING,'B':S.PENDING,'ROOT':S.SUCCESS,'T':S.PENDING}, [
        ('B','A','s(B) OR s(ROOT)'), ('ROOT','A','s(B) OR s(ROOT)'),
        ('A','B','s(A)'), ('A','T','s(A)'),
    ])
    assert plan_recovery(r,'T').status == 'already_ready'


def test_cyclic_branch_with_independent_failed_alternative_has_recovery():
    r = make_report({'A':S.PENDING,'B':S.PENDING,'ROOT':S.FAILURE,'T':S.PENDING}, [
        ('B','A','s(B) OR s(ROOT)'), ('ROOT','A','s(B) OR s(ROOT)'),
        ('A','B','s(A)'), ('A','T','s(A)'),
    ])
    result = plan_recovery(r,'T')
    assert [p.assumptions for p in result.plans] == [('ROOT',)]


def test_recovery_planner_is_rendered_after_snapshot_analysis(monkeypatch):
    r = make_report({'A':S.FAILURE,'T':S.PENDING}, [('A','T','s(A)')])
    class Record:
        snapshot_id = r.snapshot.snapshot_id
        environment_id = 'test'
        label = 'Recovery fixture'
        source_scope = 'unit'
    class Catalog:
        def load(self, snapshot_id):
            return (r.snapshot, Record()) if snapshot_id == r.snapshot.snapshot_id else None
    monkeypatch.setattr(route,'snapshot_catalog',Catalog())
    client = TestClient(app)
    response = client.post('/api/blockers/analyze',data={
        'snapshot_id':r.snapshot.snapshot_id,'environment_id':'test'})
    assert response.status_code == 200, response.text[:300]
    assert 'Recovery Planner' in response.text
    assert 'Find recovery options' in response.text
    assert 'T</option>' in response.text


def test_plans_rank_critical_impact_before_name_and_do_not_miss_later_options():
    statuses = {f'J{i}':S.FAILURE for i in range(6)} | {
        'T':S.PENDING, 'Z':S.PENDING,
    }
    expr = ' OR '.join(f's(J{i})' for i in range(6))
    edges = [(f'J{i}','T',expr) for i in range(6)] + [('J5','Z','s(J5)')]
    r = make_report(statuses,edges)
    result = plan_recovery(r,'T')
    assert result.available_plans == 6
    assert len(result.plans) == 5 and result.complete is False
    assert result.plans[0].assumptions == ('J5',)
    assert result.plans[0].impact.critical_reachable == ('T','Z')
