import pytest
"""Contract tests for non-blocking ingestion, source-safe logs and settings."""
import json
import time
from threading import Event

from fastapi.testclient import TestClient

from app.main import app
from app.config import get_settings
from app.services.runtime_diagnostics import debug_enabled, log_event, set_debug_enabled
from app.services.snapshot_jobs import SnapshotJobs, report_progress


pytestmark = pytest.mark.usefixtures("legacy_autosys_u1")

def test_debug_on_by_default_and_toggle_persists(monkeypatch, tmp_path):
    monkeypatch.setenv('PS_TOOL_CONFIG_DIR', str(tmp_path / 'cfg'))
    monkeypatch.setenv('PS_TOOL_LOG_DIR', str(tmp_path / 'logs'))
    monkeypatch.delenv('PS_TOOL_DEBUG', raising=False)
    get_settings.cache_clear()
    assert debug_enabled() is True
    set_debug_enabled(False)
    assert debug_enabled() is False
    log_event('suppressed_debug_event')
    log_event('critical_event', always=True, run_id='test', error_type='SomeError')
    assert 'suppressed_debug_event' not in (tmp_path / 'logs' / 'application.log').read_text()
    assert 'critical_event' in (tmp_path / 'logs' / 'application.log').read_text()
    set_debug_enabled(True)
    assert debug_enabled() is True
    log_event('safe_event', run_id='test', invalid='token=secret', message='some raw JIL')
    log = (tmp_path / 'logs' / 'application.log').read_text()
    assert 'safe_event' in log
    assert 'token=secret' not in log
    assert 'some raw JIL' not in log
    assert json.loads(log.splitlines()[-1])['event'] == 'safe_event'


def test_status_run_progress_and_single_active(monkeypatch, tmp_path):
    monkeypatch.setenv('PS_TOOL_LOG_DIR', str(tmp_path / 'logs'))
    get_settings.cache_clear()
    worker = SnapshotJobs()
    waiting = Event()
    release = Event()

    def fake_generate(_environment_id, *, topology_id=''):
        report_progress('runtime', 'Read runtime rows', 2511, 2511)
        report_progress('jil', 'Fetching JIL definitions', 25, 2511)
        waiting.set()
        release.wait(timeout=3)
        class Record:
            snapshot_id = 'test-snapshot'
            job_count = 2511
            edge_count = 3000
        class Generated:
            record = Record()
        return Generated()

    monkeypatch.setattr('app.services.snapshot_generation.generate_snapshot', fake_generate)
    run_id, created = worker.start('autosys-u1', '')
    try:
        assert created
        assert waiting.wait(timeout=3)
        status = worker.status(run_id)
        assert status['state'] == 'running'
        assert status['stage'] == 'jil'
        assert status['done'] == 25 and status['total'] == 2511
        assert status['elapsed_seconds'] >= 0
        assert status['updated_at']
        assert worker.current()['run_id'] == run_id
        duplicate, second_created = worker.start('autosys-u1', '')
        assert duplicate == run_id and not second_created
    finally:
        release.set()
    for _ in range(100):
        if worker.status(run_id)['state'] == 'succeeded':
            break
        time.sleep(.01)
    assert worker.status(run_id)['state'] == 'succeeded'
    assert worker.status(run_id)['snapshot_id'] == 'test-snapshot'
    assert worker.current() is None


def test_api_background_start_progress_and_settings(monkeypatch, tmp_path):
    monkeypatch.setenv('PS_TOOL_LOG_DIR', str(tmp_path / 'logs'))
    monkeypatch.setattr('app.services.runtime_diagnostics._config_file',
                        lambda: tmp_path / 'cfg' / 'runtime_settings.json')
    get_settings.cache_clear()
    client = TestClient(app)
    try:
        from app.services.snapshot_jobs import snapshot_jobs
        gate = Event()
        started = Event()

        def fake_generate(_environment_id, *, topology_id=''):
            report_progress('jil', 'Fetching JIL definitions', 100, 2511)
            started.set()
            gate.wait(timeout=3)
            raise RuntimeError('internal PII token=do-not-log')

        monkeypatch.setattr('app.services.snapshot_generation.generate_snapshot', fake_generate)
        response = client.post('/api/snapshots/start', data={'environment_id': 'autosys-u1'})
        assert response.status_code == 202
        run_id = response.json()['run_id']
        assert started.wait(timeout=3)
        status = client.get('/api/snapshots/progress/' + run_id).json()
        assert status['stage'] == 'jil' and status['done'] == 100
        assert client.get('/api/snapshots/current').json()['run_id'] == run_id
        assert client.post('/api/snapshots/start', data={'environment_id': 'autosys-u1'}).status_code == 409
    finally:
        gate.set()
    for _ in range(100):
        status = client.get('/api/snapshots/progress/' + run_id).json()
        if status['state'] == 'failed':
            break
        time.sleep(.01)
    assert status['state'] == 'failed'
    assert status['last_reported_stage'] == 'jil'
    assert status['source_label'].startswith('U1 · AutoSys · COB: ')
    assert 'do-not-log' not in str(status)
    assert 'do-not-log' not in (tmp_path / 'logs' / 'application.log').read_text()
    assert client.get('/api/snapshots/catalog').status_code == 200
    settings = client.get('/settings')
    assert settings.status_code == 200 and 'Enable detailed debug logging' in settings.text
    toggled = client.post('/api/settings/debug', data={}, follow_redirects=False)
    assert toggled.status_code == 303 and debug_enabled() is False
    toggled_on = client.post('/api/settings/debug', data={'debug': 'on'}, follow_redirects=False)
    assert toggled_on.status_code == 303 and debug_enabled() is True


def test_legacy_and_current_routes_share_one_running_worker(monkeypatch, tmp_path):
    monkeypatch.setenv('PS_TOOL_LOG_DIR', str(tmp_path / 'logs'))
    get_settings.cache_clear()
    client = TestClient(app)
    started = Event()
    release = Event()

    def fake_generate(_environment_id, *, topology_id=''):
        report_progress('fetching', 'Reading scheduler source', 2, 10)
        started.set()
        if not release.wait(timeout=5):
            raise TimeoutError('Test worker was not released')

        class Record:
            snapshot_id = 'unified-run-snapshot'
            job_count = 10
            edge_count = 9

        class Generated:
            record = Record()

        return Generated()

    monkeypatch.setattr('app.services.snapshot_generation.generate_snapshot', fake_generate)
    try:
        legacy = client.post('/api/snapshots/generate', data={'environment_id': 'autosys-u1'})
        assert legacy.status_code == 202
        assert legacy.headers['content-type'].startswith('application/json')
        run_id = legacy.json()['run_id']
        assert started.wait(timeout=3)
        assert client.get(f'/api/snapshots/progress/{run_id}').json()['done'] == 2

        for endpoint in ('/api/snapshots/start', '/api/snapshots/generate'):
            busy = client.post(endpoint, data={'environment_id': 'autosys-u1'})
            assert busy.status_code == 409
            assert busy.json() == {
                'error': 'Another snapshot is being generated', 'run_id': run_id,
            }
        assert client.get('/api/snapshots/current').json()['run_id'] == run_id
    finally:
        release.set()

    for _ in range(100):
        status = client.get(f'/api/snapshots/progress/{run_id}').json()
        if status['state'] != 'running':
            break
        time.sleep(0.02)
    assert status['state'] == 'succeeded'
    assert status['snapshot_id'] == 'unified-run-snapshot'
    assert client.get('/api/snapshots/current').json()['state'] == 'idle'


def test_legacy_and_current_routes_reject_invalid_environment_without_running(monkeypatch):
    def forbidden_start(*_args, **_kwargs):
        raise AssertionError('Invalid input must not allocate background work')

    monkeypatch.setattr('app.routes.snapshots.snapshot_jobs.start', forbidden_start)
    client = TestClient(app)
    for endpoint in ('/api/snapshots/start', '/api/snapshots/generate'):
        response = client.post(endpoint, data={'environment_id': 'invalid-environment'})
        assert response.status_code == 400
        assert 'Unknown or disabled environment' in response.text
