from __future__ import annotations

from pathlib import Path

from scripts.verify_publication_hygiene import verify


def test_project_reference_metadata_is_neutral():
    assert verify() == []


def test_hygiene_guard_rejects_unwanted_reference_metadata(tmp_path: Path):
    path = tmp_path / 'docs' / 'reference'
    path.mkdir(parents=True)
    (path / 'TOPOBROWSE_PROGRAM_CS_REFERENCE.md').write_text('# CLI contract\n', encoding='utf-8')
    (path / 'reference.md').write_text('source ' + 'screen' + 'shot', encoding='utf-8')
    assert any('docs/reference/reference.md' in issue for issue in verify(tmp_path))
