"""Windows server startup contract: stable default and explicit dev reload."""

from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]


def test_server_startup_defaults_to_no_reload():
    script = (ROOT / "start-server.cmd").read_text(encoding="ascii")
    assert re.search(r'^set "RELOAD="\s*$', script, re.MULTILINE)
    assert '".venv\\Scripts\\python.exe" -m uvicorn app.main:app %RELOAD% --host %HOST% --port %PORT%' in script
    assert 'echo [ps-tool-web] Reload: DISABLED' in script
    assert 'echo [ps-tool-web] Reload: ENABLED' in script
    assert re.search(r'\bpause\s*\nendlocal & exit /b %EXIT_CODE%', script, re.IGNORECASE)


def test_reload_is_opt_in_via_env_and_is_reset_for_false():
    script = (ROOT / "start-server.cmd").read_text(encoding="ascii")
    block = re.search(r'if /i "%%A"=="PS_TOOL_WEB_RELOAD" \((.*?)\n    \)', script, re.DOTALL)
    assert block is not None
    body = block.group(1)
    assert 'set "RELOAD="' in body
    enables = re.findall(r'if /i "%%B"=="([^"]+)" set "RELOAD=--reload"', body)
    assert set(enables) == {"true", "1", "yes", "on"}
    assert len(enables) == 4
    # All other values, including false, 0, no, and an absent key, stay disabled.
    assert 'set "RELOAD=--reload"' not in script[:script.index('if exist ".env"')]


def test_new_install_and_documentation_match_stable_mode():
    env_example = (ROOT / ".env.example").read_text(encoding="utf-8")
    assert re.search(r'^PS_TOOL_WEB_RELOAD=false\s*$', env_example, re.MULTILINE)
    assert not re.search(r'^PS_TOOL_WEB_RELOAD=true\s*$', env_example, re.MULTILINE)
    readme = (ROOT / "README.md").read_text(encoding="utf-8")
    assert "Existing installations:" in readme
    assert "PS_TOOL_WEB_RELOAD=true" in readme
    assert "Do not manually restart while snapshot ingestion is in progress" in readme
