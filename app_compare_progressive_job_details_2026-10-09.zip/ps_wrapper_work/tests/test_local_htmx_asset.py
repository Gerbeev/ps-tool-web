"""Static frontend assets must work without external network access."""

from __future__ import annotations

import hashlib
import re
from pathlib import Path

from fastapi.testclient import TestClient

from app.main import app


ROOT = Path(__file__).resolve().parents[1]
ASSET = ROOT / "app" / "static" / "vendor" / "htmx.min.js"
TEMPLATE = ROOT / "app" / "templates" / "base.html"


def test_htmx_is_bundled_and_served_locally() -> None:
    assert ASSET.is_file()
    bundled = ASSET.read_bytes()
    assert len(bundled) > 40_000
    assert b"htmx" in bundled.lower()
    assert hashlib.sha256(bundled).hexdigest() == "e209dda5c8235479f3166defc7750e1dbcd5a5c1808b7792fc2e6733768fb447"
    with TestClient(app) as client:
        response = client.get("/static/vendor/htmx.min.js")
    assert response.status_code == 200
    assert hashlib.sha256(response.content).digest() == hashlib.sha256(bundled).digest()
    assert "javascript" in response.headers["content-type"]


def test_pages_reference_local_htmx_without_external_script() -> None:
    base = TEMPLATE.read_text(encoding="utf-8")
    assert '<script src="/static/vendor/htmx.min.js"></script>' in base
    assert not re.search(r'<script[^>]+src=["\']https?://', base)
    with TestClient(app) as client:
        for page in ("/snapshots", "/browse", "/compare", "/settings"):
            response = client.get(page)
            assert response.status_code == 200
            assert '/static/vendor/htmx.min.js' in response.text
            assert 'unpkg.com' not in response.text
