"""Compare keeps context readable without losing complete metadata."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace

from bs4 import BeautifulSoup
from fastapi.testclient import TestClient

from app.main import app
from app.models import AsOf, ComparisonContext, SchedulerType, TopologySnapshot
from app.services.snapshot_catalog import SnapshotRecord

ROOT = Path(__file__).resolve().parents[1]


def _record(snapshot_id: str, label: str, environment_id: str) -> SnapshotRecord:
    return SnapshotRecord.model_construct(
        snapshot_id=snapshot_id,
        snapshot_name=label,
        environment_name="Long Environment <Name>",
        environment_id=environment_id,
        captured_at=datetime(2026, 10, 9, 12, 34, 56, 123456, tzinfo=timezone.utc),
    )


def test_compare_selector_preserves_full_names_and_disclosure(monkeypatch):
    name = "Risk Analytics & Treasury <Production> " + "Very-Long-Environment-" * 8
    label = "Daily Snapshot & Reconciliation <Exact> " + "long-snapshot-name-" * 8
    env = SimpleNamespace(id="custom-test-env", display_name=name)
    record = _record("snapshot-" + "1234" * 12, label, env.id)
    monkeypatch.setattr("app.routes.compare._env_options", lambda: [env])
    monkeypatch.setattr("app.routes.compare._snapshot_options", lambda _: [record])
    client = TestClient(app)
    response = client.get("/compare")
    assert response.status_code == 200
    soup = BeautifulSoup(response.text, "html.parser")
    assert soup.select_one('#compare-left-env option')['title'] == name
    option = soup.select_one('#compare-left-snapshot option')
    assert option['title'] == label
    assert option.get_text() == label
    assert soup.select_one('#compare-left-context-fields .compare-selection-details summary').text.strip() == 'Full selection details'
    assert soup.select_one('script[src="/static/js/compare-selection-details.js"]') is not None
    assert '&lt;Production&gt;' in response.text
    partial = client.get('/api/compare/side-form', params={'side': 'right', 'right_env': env.id})
    assert partial.status_code == 200
    partial_soup = BeautifulSoup(partial.text, 'html.parser')
    assert partial_soup.select_one('option[title]')['title'] == label
    assert partial_soup.select_one('.compare-selection-details [data-compare-full-snapshot-id]') is not None


def test_compare_results_compact_display_and_exact_details(monkeypatch):
    left = _record("left-uuid-unique-12345", "Full Left <Daily> & Snapshot " + 'X' * 140, "left-env")
    right = _record("right-uuid-unique-67890", "Full Right <Daily> & Snapshot " + 'Y' * 140, "right-env")
    left_context = ComparisonContext(environment_id="left-env", scheduler=SchedulerType.AUTOSYS, as_of=AsOf(value="2026-10-09"))
    right_context = ComparisonContext(environment_id="right-env", scheduler=SchedulerType.PROCESS_SCHEDULER, as_of=AsOf(value="2026-10-09"))
    snaps = {left.snapshot_id: (TopologySnapshot(context=left_context), left), right.snapshot_id: (TopologySnapshot(context=right_context), right)}
    monkeypatch.setattr('app.routes.compare.snapshot_catalog.load', lambda sid: snaps.get(sid))
    monkeypatch.setattr('app.routes.compare.search_index.rebuild', lambda *args: None)
    response = TestClient(app).post('/api/compare', data={
        'left_env': 'left-env', 'left_snapshot_id': left.snapshot_id,
        'right_env': 'right-env', 'right_snapshot_id': right.snapshot_id,
    })
    assert response.status_code == 200
    soup = BeautifulSoup(response.text, 'html.parser')
    summary = soup.select_one('.snapshot-result-meta')
    assert summary is not None
    assert len(summary.select('.compare-record-summary')) == 2
    assert summary.select_one('.compare-record-name')['title'] == left.label
    assert [x.get_text(strip=True) for x in summary.select('.compare-record-summary time')] == [
        '2026-10-09 12:34 UTC', '2026-10-09 12:34 UTC',
    ]
    exact = summary.select_one('details.compare-technical-details')
    assert exact is not None and not exact.has_attr('open')
    assert [x.get_text(strip=True) for x in exact.select('code')] == [left.snapshot_id, right.snapshot_id]
    assert [x.get_text(strip=True) for x in exact.select('time')] == [
        '2026-10-09T12:34:56.123456+00:00', '2026-10-09T12:34:56.123456+00:00',
    ]
    assert left.snapshot_id not in summary.get_text(' ', strip=True).split('Exact snapshot metadata')[0]
    assert 'No scheduler fetch was performed' in response.text
    assert '&lt;Daily&gt;' in response.text
    assert 'id="compare-table-panel"' in response.text


def test_compare_assets_are_scoped_and_available():
    css = (ROOT / 'app/static/css/custom.css').read_text(encoding='utf-8')
    assert '#compare-context-panel .context-fields' in css
    assert 'overflow-wrap: anywhere' in css
    asset = TestClient(app).get('/static/js/compare-selection-details.js')
    assert asset.status_code == 200
    assert asset.headers['content-type'].startswith('text/javascript')
    assert 'htmx:afterSwap' in asset.text
