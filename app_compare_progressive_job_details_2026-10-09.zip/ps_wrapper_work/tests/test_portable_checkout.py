"""Regression checks for clean-machine install and Git-ready packaging."""

from pathlib import Path

from scripts.verify_checkout import REQUIRED_FILES, PROJECT_ROOT, verify_checkout


def test_all_required_project_files_are_in_checkout():
    assert not verify_checkout(runtime=False)
    assert "app/time_utils.py" in REQUIRED_FILES
    assert "data/mock/reference_topology_2500.jsonl" in REQUIRED_FILES


def test_windows_install_requires_python_from_path_without_launcher_fallback():
    content = (PROJECT_ROOT / "setup-env.cmd").read_text(encoding="utf-8")
    assert 'python -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)"' in content
    assert "python -m scripts.verify_checkout --source" in content
    assert 'python -m venv ".venv"' in content
    assert '".venv\\Scripts\\python.exe" -m pip install -r requirements.txt' in content
    assert '".venv\\Scripts\\python.exe" -m scripts.verify_checkout --runtime' in content
    assert "if errorlevel 1" in content
    assert "if not defined PYTHON_CMD" not in content
    assert "PYTHON_CMD" not in content
    assert "goto :finish" in content
    assert "pause\nendlocal & exit /b %EXIT_CODE%" in content


def test_every_windows_launcher_uses_python_only_and_pauses_before_exit():
    import re

    launchers = sorted(PROJECT_ROOT.rglob("*.cmd"))
    assert len(launchers) >= 12
    assert {p.name for p in PROJECT_ROOT.glob("*.cmd")} == {"setup-env.cmd", "start-server.cmd", "open-app.cmd"}
    assert {p.name for p in PROJECT_ROOT.glob("*.cmd")} == {"setup-env.cmd", "start-server.cmd", "open-app.cmd"}
    forbidden_launcher = re.compile(r"(?<![\w.])py(?:\.exe)?\s+-3\b", re.IGNORECASE)
    for script in launchers:
        content = script.read_text(encoding="utf-8")
        assert forbidden_launcher.search(content) is None, script
        assert re.search(
            r"\bpause\s*\nendlocal & exit /b %EXIT_CODE%\s*$",
            content,
            re.IGNORECASE,
        ), script


def test_server_checks_runtime_before_starting():
    content = (PROJECT_ROOT / "start-server.cmd").read_text(encoding="utf-8")
    assert "-m scripts.verify_checkout --runtime" in content
    assert content.index("-m scripts.verify_checkout --runtime") < content.index("-m uvicorn")


def test_gitignore_does_not_hide_critical_sources_and_mocks():
    content = (PROJECT_ROOT / ".gitignore").read_text(encoding="utf-8")
    patterns = {line.strip() for line in content.splitlines() if line.strip() and not line.startswith("#")}
    assert "data/" not in patterns
    assert "app/" not in patterns
    assert "*.py" not in patterns
    assert (PROJECT_ROOT / "app/time_utils.py").is_file()
    assert all((PROJECT_ROOT / relative).is_file() for relative in REQUIRED_FILES)


def test_diagnostics_use_project_virtualenv_and_pause():
    for filename in (
        "scripts/diagnose-autosys.cmd",
        "scripts/diagnose-process-scheduler.cmd",
        "scripts/RUN-FULL-DIAGNOSTICS.cmd",
        "scripts/RUN-AUTOSYS-DIAGNOSTICS.cmd",
        "scripts/RUN-PROCESS-SCHEDULER-DIAGNOSTICS.cmd",
    ):
        content = (PROJECT_ROOT / filename).read_text(encoding="utf-8")
        assert 'cd /d "%~dp0.."' in content
        assert 'cd /d "%~dp0.."' in content
        assert 'set "PYTHON_EXE=.venv\\Scripts\\python.exe"' in content
        assert '"%PYTHON_EXE%" -c "import yaml, pydantic"' in content
        assert '"%PYTHON_EXE%" -m scripts.' in content
        assert "pause" in content.lower()
        assert "python -m scripts." not in content.replace('"%PYTHON_EXE%" -m scripts.', "")


def test_new_install_defaults_to_real_connector_mode():
    content = (PROJECT_ROOT / ".env.example").read_text(encoding="utf-8")
    assert "USE_MOCK_ADAPTERS=false" in content


def test_server_prints_effective_adapter_mode():
    content = (PROJECT_ROOT / "start-server.cmd").read_text(encoding="utf-8")
    assert "Effective runtime configuration" in content
    assert "Adapter mode:" in content


def test_root_has_only_three_launchers_and_all_maintenance_cmds_resolve_project_root():
    assert {p.name for p in PROJECT_ROOT.glob("*.cmd")} == {
        "setup-env.cmd", "start-server.cmd", "open-app.cmd"
    }
    for name in (
        "diagnose-autosys.cmd",
        "diagnose-process-scheduler.cmd",
        "RUN-FULL-DIAGNOSTICS.cmd",
        "RUN-AUTOSYS-DIAGNOSTICS.cmd",
        "RUN-PROCESS-SCHEDULER-DIAGNOSTICS.cmd",
        "setup-workstation-connectors.cmd",
    ):
        content = (PROJECT_ROOT / "scripts" / name).read_text(encoding="utf-8")
        assert 'cd /d "%~dp0.."' in content
        assert "pause\nendlocal & exit /b %EXIT_CODE%" in content
