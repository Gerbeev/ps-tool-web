"""Compare must degrade gracefully when clocks or the optional search index differ."""

from __future__ import annotations

import re
import sqlite3
from datetime import datetime, timedelta, timezone

from fastapi.testclient import TestClient

from app.main import app
from app.models import AsOf, ComparisonContext, JobStatus, SchedulerType, SnapshotJob, TopologySnapshot
from app.routes import compare as compare_routes
from app.services.snapshot_catalog import SnapshotRecord
from app.time_utils import execution_time_seconds, timestamp_difference_seconds


def _sample_pair():
    utc_start = datetime(2026, 10, 9, 8, 0, tzinfo=timezone.utc)
    naive_start = datetime(2026, 10, 9, 8, 0)
    snapshots = []
    for scheduler, env, start in [
        (SchedulerType.AUTOSYS, "autosys-test", utc_start),
        (SchedulerType.PROCESS_SCHEDULER, "ps-test", naive_start),
    ]:
        context = ComparisonContext(environment_id=env, scheduler=scheduler, as_of=AsOf(value="2026-10-09"))
        job = SnapshotJob(
            job_uid=env,
            logical_id="shared-job",
            scheduler_job_name="SHARED_JOB",
            status=JobStatus.SUCCESS,
            actual_start=start,
            actual_end=start + timedelta(minutes=5),
        )
        snapshot = TopologySnapshot(context=context, flat_jobs=[job])
        record = SnapshotRecord(
            snapshot_id=snapshot.snapshot_id,
            environment_id=env,
            scheduler=scheduler,
            context=context,
            fetched_at=snapshot.fetched_at,
            captured_at=datetime.now(timezone.utc),
            job_count=1,
            edge_count=0,
            filename="fixture.json.gz",
            sha256="fixture",
        )
        snapshots.append((snapshot, record))
    return snapshots


def _post_data(snapshots):
    left, right = snapshots
    return {
        "left_env": left[1].environment_id,
        "left_snapshot_id": left[0].snapshot_id,
        "right_env": right[1].environment_id,
        "right_snapshot_id": right[0].snapshot_id,
    }


def test_mixed_timestamp_offsets_never_raise_or_fabricate_a_duration():
    aware = datetime(2026, 10, 9, 8, 0, tzinfo=timezone.utc)
    naive = datetime(2026, 10, 9, 8, 0)
    assert timestamp_difference_seconds(aware, naive) is None
    assert execution_time_seconds(naive, aware) is None
    assert execution_time_seconds(aware, naive) is None
    assert timestamp_difference_seconds(aware, aware + timedelta(minutes=2)) == -120
    assert timestamp_difference_seconds(naive, naive + timedelta(minutes=2)) == -120
    offset = timezone(timedelta(hours=2))
    assert timestamp_difference_seconds(aware, aware.astimezone(offset)) == 0


def test_compare_mixed_timezone_snapshots_reports_incomplete_timing(monkeypatch):
    snapshots = _sample_pair()
    monkeypatch.setattr(compare_routes.snapshot_catalog, "load", lambda sid: next((pair for pair in snapshots if pair[0].snapshot_id == sid), None))
    monkeypatch.setattr(compare_routes.search_index, "rebuild", lambda *_: None)
    res = TestClient(app).post("/api/compare", data=_post_data(snapshots))
    assert res.status_code == 200
    assert "Compared generated snapshots" in res.text
    assert "Partial coverage" in res.text
    assert "Request ID" not in res.text


def test_search_index_failure_does_not_prevent_comparison(monkeypatch):
    snapshots = _sample_pair()
    monkeypatch.setattr(compare_routes.snapshot_catalog, "load", lambda sid: next((pair for pair in snapshots if pair[0].snapshot_id == sid), None))

    def unavailable(*_args):
        raise sqlite3.OperationalError("database is locked")

    monkeypatch.setattr(compare_routes.search_index, "rebuild", unavailable)
    res = TestClient(app).post("/api/compare", data=_post_data(snapshots))
    assert res.status_code == 200
    assert "Comparison completed, but job search is temporarily unavailable" in res.text
    assert "search.disabled = true;" in res.text


def test_stale_environment_selection_has_actionable_inline_message(monkeypatch):
    snapshots = _sample_pair()
    monkeypatch.setattr(compare_routes.snapshot_catalog, "load", lambda sid: next((pair for pair in snapshots if pair[0].snapshot_id == sid), None))
    data = _post_data(snapshots)
    data["left_env"] = "another-environment"
    res = TestClient(app).post("/api/compare", data=data)
    assert res.status_code == 200
    assert "Snapshot/environment mismatch" in res.text
    assert "Choose the snapshots again" in res.text


def test_compare_error_has_request_id_in_html_and_feedback_js(monkeypatch):
    snapshots = _sample_pair()
    monkeypatch.setattr(compare_routes.snapshot_catalog, "load", lambda sid: next((pair for pair in snapshots if pair[0].snapshot_id == sid), None))

    def fail(*_args):
        raise RuntimeError("private scheduler content - do not reveal")

    monkeypatch.setattr(compare_routes, "compare_snapshots", fail)
    res = TestClient(app, raise_server_exceptions=False).post(
        "/api/compare", data=_post_data(snapshots), headers={"HX-Request": "true"}
    )
    assert res.status_code == 500
    assert re.search(r"Request ID: [0-9a-f]{12}", res.text)
    assert "private scheduler content" not in res.text
    js = TestClient(app).get("/static/js/app-shell.js")
    assert "Could not compare the selected snapshots" in js.text
    assert "Check logs/application.log" in js.text
