"""End-to-end normalization contract tests using synthetic CGI responses only."""
from __future__ import annotations

import unittest
from unittest.mock import patch
from urllib.parse import parse_qs, urlencode, urlsplit

from workstation_connectors import autosys_connector as a
from scripts.verify_reference_docs import verify


BODY = """<html><body><pre>Job Name                                                          Last Start           Last End             ST/Ex Run/Ntry Pri/Xit TimeZone
----------------------------------------------------------------- -------------------- -------------------- ----- -------- -------
IB_CT_CVA_1109_U1_Admin_Box                                        10/06/2026 23:32:50  10/06/2026 23:48:48  SU    38912674/1 0 (London)
 IB_CT_CVA_1109_U1_DP_ADP_Accounts_Load                              10/06/2026 23:32:52  10/06/2026 23:47:13  FA    38912674/1 2 (London)
</pre></body></html>"""


class FakeClient:
    calls: list[tuple[str, str, dict[str, str]]] = []
    mismatched_jil = False
    empty = False

    def __init__(self, _config):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        pass

    def request(self, method: str, url: str, params: dict[str, str] | None = None):
        params = dict(params or {})
        self.calls.append((method, url, params))
        assert method == 'GET'
        assert url == 'https://autosys.ldn.swissbank.com/selfhelp/tool.cgi'
        assert set(params) == {'t', 'i', 'q'}, params
        assert params['i'] == 'IUT'
        if params['t'] == 'job':
            assert params['q'] == 'IB_CT_CVA_1109_U1_%'
            return a.HttpResult(url, 200, 'text/html', '<pre>No matching jobs</pre>' if self.empty else BODY)
        assert params['t'] == 'jil'
        assert params['q'].startswith('IB_CT_CVA_1109_U1_') and '%' not in params['q']
        name = 'WRONG_JOB' if self.mismatched_jil else params['q']
        parent = 'IB_CT_CVA_1109_U1_Admin_Box' if 'Accounts' in name else ''
        condition = 's(IB_CT_CVA_1109_U1_Admin_Box)' if parent else ''
        definition = (
            f'<html><pre>insert_job: {name} job_type: CMD\nbox_name: {parent}\n'
            f'condition: {condition}\ncommand: echo ok\ntimezone: London\n</pre></html>'
        )
        return a.HttpResult(url, 200, 'text/html', definition)


def ctx(env: str = 'U1') -> dict[str, str]:
    return {
        'environment_id': f'autosys-{env.lower()}', 'environment': env,
        'scheduler': 'autosys', 'host': 'autosys.ldn.swissbank.com',
        'as_of_kind': 'business_date', 'as_of_value': '2026-10-06',
    }


class SelfhelpContractTests(unittest.TestCase):
    def setUp(self) -> None:
        FakeClient.calls = []
        FakeClient.mismatched_jil = False
        FakeClient.empty = False

    def test_immutable_refs_unchanged(self) -> None:
        self.assertEqual(verify(), [])

    def test_environment_instance_mapping(self) -> None:
        self.assertEqual(a._instance_for_environment('U1'), 'IUT')
        self.assertEqual(a._instance_for_environment('U5'), 'IUT')
        self.assertEqual(a._instance_for_environment('P1'), 'IL2')
        self.assertEqual(a._instance_for_environment('PROD'), 'IL2')
        with self.assertRaises(a.ConnectorError):
            a._instance_for_environment('SOMETHING')

    def test_query_wildcard_percent_is_url_encoded(self) -> None:
        assert 'q=IB_CT_CVA_1109_U1_%25' in urlencode({'q': 'IB_CT_CVA_1109_U1_%'})

    def test_fixed_width_indented_rows_keep_all_fields(self) -> None:
        rows, _, _ = a.parse_runtime_report(BODY, 'https://autosys.ldn.swissbank.com/selfhelp/tool.cgi')
        self.assertEqual(len(rows), 2)
        self.assertEqual(rows[1].st_ex_raw, 'FA')
        self.assertEqual(rows[1].run_ntry_raw, '38912674/1')
        self.assertEqual(rows[1].pri_xit_raw, '2')
        self.assertEqual(rows[1].timezone_raw, 'London')
        self.assertEqual(rows[1].last_end_raw, '10/06/2026 23:47:13')

    def test_snapshots_use_exact_endpoints_without_cob_query(self) -> None:
        with patch.object(a, 'AutoSysHttpClient', FakeClient):
            provider = a.AutoSysProvider()
            result = provider.fetch_topology(ctx())
        self.assertEqual(len(result['jobs']), 2)
        self.assertEqual(len(FakeClient.calls), 3)
        self.assertEqual(result['jobs'][1]['status'], 'failure')
        self.assertEqual(result['jobs'][1]['parent_uid'], result['jobs'][0]['job_uid'])
        self.assertEqual(len(result['dependencies']), 1)
        self.assertTrue(result['metadata']['definition_complete'])
        self.assertFalse(result['metadata']['cob_used_in_http_request'])
        self.assertEqual(result['metadata']['cob_date'], '2026-10-06')

    def test_incomplete_jil_prevents_snapshot(self) -> None:
        FakeClient.mismatched_jil = True
        with patch.object(a, 'AutoSysHttpClient', FakeClient):
            with self.assertRaises(a.ConnectorError) as raised:
                a.AutoSysProvider().fetch_topology(ctx())
        self.assertEqual(raised.exception.code, 'source_incomplete')

    def test_no_matching_rows_is_not_source_error(self) -> None:
        FakeClient.empty = True
        with patch.object(a, 'AutoSysHttpClient', FakeClient):
            result = a.AutoSysProvider().fetch_topology(ctx())
        self.assertEqual(result['jobs'], [])
        self.assertEqual(len(FakeClient.calls), 1)


if __name__ == '__main__':
    unittest.main()
