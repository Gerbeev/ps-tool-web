import os
import tempfile
from pathlib import Path

import pytest

# Existing unit tests exercise the compact fixture unless a test explicitly opts into
# the canonical 2500-job dataset. Runtime default remains reference_2500.
os.environ.setdefault("MOCK_DATASET", "legacy_small")

# Global search_index is constructed when app.search.sqlite_fts is imported,
# often during test collection. Isolate it before any app imports can occur.
# Never let pytest write synthetic snapshot indices to data/search.db.
_TEST_SEARCH_DB_DIR = tempfile.TemporaryDirectory(prefix="ps-tool-pytest-fts-")
os.environ["SEARCH_DB_PATH"] = str(Path(_TEST_SEARCH_DB_DIR.name) / "search.db")


@pytest.fixture(autouse=True)
def _reset_cached_settings(monkeypatch, tmp_path):
    from app.config import get_settings

    monkeypatch.setenv("SNAPSHOT_DIR", str(tmp_path / "snapshots"))
    get_settings.cache_clear()
    yield
    get_settings.cache_clear()


@pytest.fixture
def legacy_autosys_u1(monkeypatch, tmp_path):
    """Opt-in historical U1 test profile; production defaults stay PROD-on/U1-off."""
    import yaml
    from app import config

    source_dir = config._repo_root() / "config"
    target_dir = tmp_path / "test-connection-profiles"
    target_dir.mkdir(exist_ok=True)
    for source in source_dir.glob("*.yaml"):
        (target_dir / source.name).write_bytes(source.read_bytes())
    autosys_path = target_dir / "autosys_environments.yaml"
    payload = yaml.safe_load(autosys_path.read_text(encoding="utf-8"))
    for row in payload["environments"]:
        if row["id"] == "autosys-u1":
            row["enabled"] = True
    autosys_path.write_text(yaml.safe_dump(payload), encoding="utf-8")
    monkeypatch.setenv("PS_TOOL_CONFIG_DIR", str(target_dir))
    config.get_settings.cache_clear()
    config.invalidate_environment_cache()
    config.load_identity_map.cache_clear()
    config.load_job_naming_rules.cache_clear()
    from app.autosys_reference import load_compare_parameters
    load_compare_parameters.cache_clear()
    try:
        yield
    finally:
        config.invalidate_environment_cache()
        config.load_identity_map.cache_clear()
        config.load_job_naming_rules.cache_clear()
        load_compare_parameters.cache_clear()
        config.get_settings.cache_clear()
