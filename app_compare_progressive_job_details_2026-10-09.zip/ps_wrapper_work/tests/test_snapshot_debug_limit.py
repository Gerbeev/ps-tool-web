"""Debug sample never causes full per-job fetches or impersonates a complete snapshot."""
from __future__ import annotations

from datetime import datetime, timezone
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.models import ComparisonContext, JobNode, JobStatus, SnapshotJob, TopologySnapshot
from app.services.snapshot_catalog import snapshot_catalog
from app.services.snapshot_generation import SnapshotGenerationError, generate_snapshot
from workstation_connectors import autosys_connector, process_scheduler_connector


pytestmark = pytest.mark.usefixtures("legacy_autosys_u1")

def test_limit_form_and_server_validation(monkeypatch):
    import app.routes.snapshots as routes

    client = TestClient(app)
    calls = []
    monkeypatch.setattr(routes.snapshot_jobs, 'start', lambda env, top, **kw: (calls.append((env, top, kw)) or ('run', True)))
    monkeypatch.setattr(routes.snapshot_catalog, 'assert_writable', lambda: None)
    monkeypatch.setattr(routes, 'debug_enabled', lambda: True)

    html = client.get('/snapshots').text
    assert '<select id="snapshot-job-limit" name="job_limit"' in html
    for value in ('50', '100', '500', '5000', 'full'):
        assert f'value="{value}"' in html
    assert html.index('value="50" selected') < html.index('value="100"')
    for value in ('50', '100', '500', '5000', '0', 'full'):
        response = client.post('/api/snapshots/start', data={'environment_id': 'autosys-u1', 'job_limit': value})
        assert response.status_code == 202, response.text
    assert calls == [
        ('autosys-u1', '', {'job_limit': 50}),
        ('autosys-u1', '', {'job_limit': 100}),
        ('autosys-u1', '', {'job_limit': 500}),
        ('autosys-u1', '', {'job_limit': 5000}),
        ('autosys-u1', '', {}),
        ('autosys-u1', '', {}),
    ]

    for value in ('-1', '1', '99', '777', '10001', 'abc', '1.5', '50;DROP', '9' * 5000):
        assert client.post('/api/snapshots/start', data={'environment_id': 'autosys-u1', 'job_limit': value}).status_code == 400
    monkeypatch.setattr(routes, 'debug_enabled', lambda: False)
    assert 'name="job_limit" value="full"' in client.get('/snapshots').text
    assert client.post('/api/snapshots/start', data={'environment_id': 'autosys-u1', 'job_limit': '50'}).status_code == 400
    assert client.post('/api/snapshots/start', data={'environment_id': 'autosys-u1', 'job_limit': '0'}).status_code == 202


def test_generate_snapshot_saves_sample_metadata_and_catalog_label(monkeypatch):
    import app.services.snapshot_generation as generation

    monkeypatch.setattr(generation, 'debug_enabled', lambda: True)
    captured = []

    def fake_fetch(context, *, force_refresh):
        captured.append(context)
        job = SnapshotJob(job_uid='A', scheduler_job_name='A', status=JobStatus.SUCCESS)
        snap = TopologySnapshot(
            context=context, fetched_at=datetime.now(timezone.utc),
            roots=[JobNode(job=job)], flat_jobs=[job],
            metadata={'debug_sample': {'requested_limit': 50, 'selected_jobs': 1,
                                       'source_total_jobs': 2370, 'partial': True}},
        )
        return snap, 'key'

    monkeypatch.setattr(generation, 'fetch_snapshot', fake_fetch)
    record = generate_snapshot('autosys-u1', job_limit=50).record
    assert captured[0].filters.debug_job_limit == 50
    assert record.debug_job_limit == 50 and record.source_job_count == 2370
    assert record.label.endswith('_DEBUG_50')
    loaded, restored = snapshot_catalog.load(record.snapshot_id)
    assert restored.debug_job_limit == 50
    assert loaded.metadata['debug_sample']['partial'] is True
    assert len(loaded.flat_jobs) == 1

    monkeypatch.setattr(generation, 'debug_enabled', lambda: False)
    with pytest.raises(SnapshotGenerationError, match='Debug Mode'):
        generate_snapshot('autosys-u1', job_limit=50)


def test_process_scheduler_limit_applies_before_detail_requests(monkeypatch):
    provider = process_scheduler_connector.ProcessSchedulerProvider()
    provider.config['enable_job_detail'] = True
    rows = [{'Name': f'JOB_{i}', 'JobType': 'Command', 'Status': 'Waiting'} for i in range(120)]
    original = {'jobs': rows, 'total_job_rows': 120,
                'dependencies': [{'from': 'JOB_99', 'to': 'JOB_0', 'condition': 'success(JOB_99)'},
                                 {'from': 'JOB_0', 'to': 'JOB_1', 'condition': 'success(JOB_0)'}]}
    monkeypatch.setattr(process_scheduler_connector, '_invoke_bridge',
                        lambda *_a: SimpleNamespace(payload=original, mode='args', command_label='test'))
    detail_calls = []

    def fake_details(_cfg, _ctx, _topology, source):
        subset = source['jobs']
        detail_calls.extend(item['Name'] for item in subset)
        return {'requested': len(subset), 'enriched': len(subset), 'failed': 0, 'errors': {}}

    monkeypatch.setattr(process_scheduler_connector, '_enrich_topology_details', fake_details)
    context = {'environment_id': 'ps-u5', 'environment': 'U5', 'topology_id': 'TOPO',
               'host': 'host', 'debug_job_limit': 50}
    result = provider.fetch_topology(context)
    assert len(detail_calls) == 50 and len(result['jobs']) == 50
    assert result['metadata']['job_details']['requested'] == 50
    assert result['metadata']['debug_sample'] == {
        'requested_limit': 50, 'source_total_jobs': 120,
        'selected_jobs': 50, 'partial': True, 'method': 'first_source_rows',
    }
    assert len(result['dependencies']) == 1
    assert result['dependencies'][0]['to_uid'] == result['jobs'][1]['job_uid']


def test_process_scheduler_debug_does_not_hide_partial_source(monkeypatch):
    provider = process_scheduler_connector.ProcessSchedulerProvider()
    monkeypatch.setattr(process_scheduler_connector, '_invoke_bridge',
                        lambda *_a: SimpleNamespace(payload={'jobs': [{'Name': 'A'}], 'job_count': 3},
                                                    mode='args', command_label='test'))
    context = {'environment_id': 'ps-u5', 'environment': 'U5', 'topology_id': 'TOPO',
               'host': 'host', 'debug_job_limit': 1}
    with pytest.raises(process_scheduler_connector.ConnectorError) as exc:
        provider.fetch_topology(context)
    assert exc.value.code == 'partial_topology'


def test_autosys_limit_applies_before_jil(monkeypatch):
    html = '''<table><tr><th>Job Name</th><th>Last Start</th><th>Last End</th><th>ST/Ex</th><th>Run/Ntry</th><th>Pri/Xit</th><th>TimeZone</th></tr>
    <tr><td>JOB_A</td><td>10/07/2026 01:02:03</td><td>10/07/2026 01:03:04</td><td>SU</td><td>1/1</td><td>0</td><td>London</td></tr>
    <tr><td>JOB_B</td><td>10/07/2026 01:02:03</td><td>10/07/2026 01:03:04</td><td>SU</td><td>1/1</td><td>0</td><td>London</td></tr></table>'''
    rows, headers, _ = autosys_connector.parse_runtime_report(html, 'https://example.org/report')

    class FakeClient:
        def __init__(self, _config): pass
        def __enter__(self): return self
        def __exit__(self, *_args): pass

    monkeypatch.setattr(autosys_connector, 'AutoSysHttpClient', FakeClient)
    monkeypatch.setattr(autosys_connector, '_runtime_request',
                        lambda *_args: (rows, headers, {'job_pattern': '*'}))
    jil_targets = []

    def fake_definitions(_cfg, _ctx, selected, _pattern):
        jil_targets.extend(row.job_name for row in selected)
        return {row.job_name: {'job_name': row.job_name, 'job_type': 'CMD'} for row in selected}, {}

    monkeypatch.setattr(autosys_connector, '_fetch_definitions', fake_definitions)
    provider = autosys_connector.AutoSysProvider()
    context = {'environment_id': 'autosys-u1', 'environment': 'U1',
               'host': 'https://example.org', 'as_of_kind': 'business_date',
               'as_of_value': '2026-10-08', 'debug_job_limit': 1}
    result = provider.fetch_topology(context)
    assert jil_targets == ['JOB_A']
    assert len(result['jobs']) == 1
    assert result['metadata']['debug_sample']['source_total_jobs'] == 2
    assert result['metadata']['debug_sample']['partial'] is True


def test_bridge_context_includes_limit_and_old_context_is_unchanged():
    from app.adapters.bridge_contract import request_context_from_engine
    from app.models import ContextFilters, SchedulerType
    context = ComparisonContext(environment_id='autosys-u1', scheduler=SchedulerType.AUTOSYS,
                                filters=ContextFilters(debug_job_limit=50))
    wire = request_context_from_engine(context, environment='U1', host='https://host')
    assert wire.model_dump(exclude_none=True)['debug_job_limit'] == 50
    regular = ComparisonContext(environment_id='autosys-u1', scheduler=SchedulerType.AUTOSYS)
    old = request_context_from_engine(regular, environment='U1', host='https://host')
    assert 'debug_job_limit' not in old.model_dump(exclude_none=True)


def test_worker_exposes_debug_identity_and_forwards_selected_limit(monkeypatch):
    from app.services.snapshot_jobs import SnapshotJobs
    from app.services import snapshot_generation
    from time import sleep
    received = []

    def fake_generate(env, *, topology_id='', job_limit=None):
        received.append((env, topology_id, job_limit))
        return SimpleNamespace(record=SimpleNamespace(snapshot_id='id', job_count=50,
                                                      edge_count=4, label='U1-AutoSys_DEBUG_50'))

    monkeypatch.setattr(snapshot_generation, 'generate_snapshot', fake_generate)
    worker = SnapshotJobs()
    run_id, started = worker.start('autosys-u1', '', job_limit=50)
    assert started
    for _ in range(200):
        result = worker.status(run_id)
        if result['state'] != 'running':
            break
        sleep(0.005)
    assert result['state'] == 'succeeded', result
    assert result['debug_job_limit'] == 50
    assert 'DEBUG sample: 50 jobs' in result['source_label']
    assert received == [('autosys-u1', '', 50)]
