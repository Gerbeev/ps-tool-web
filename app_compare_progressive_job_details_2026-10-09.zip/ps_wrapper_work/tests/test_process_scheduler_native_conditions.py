"""Real-world DTO shape regression: Process Scheduler ConditionExpression trees."""
from __future__ import annotations

import json
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

from app.adapters.bridge_contract import BridgeJobV1, job_to_engine
from app.models import AdapterCapabilities, AsOf, AsOfKind, ComparisonContext, SchedulerType, TopologySnapshot
from app.services.blockers import analyze_blockers
from workstation_connectors import process_scheduler_connector as ps


CTX = {"environment_id": "ps-u5", "environment": "U5", "scheduler": "process_scheduler",
       "host": "test-host:9001", "topology_id": "Topology_Test"}


def _snapshot(normalized: dict) -> TopologySnapshot:
    context = ComparisonContext(environment_id="ps-u5", scheduler=SchedulerType.PROCESS_SCHEDULER,
                                as_of=AsOf(kind=AsOfKind.LATEST, value=""))
    return TopologySnapshot(
        context=context,
        flat_jobs=[job_to_engine(BridgeJobV1.model_validate(job)) for job in normalized["jobs"]],
        edges=normalized["dependencies"],
        metadata=normalized["metadata"],
        capabilities=AdapterCapabilities(dependencies=bool(normalized["dependencies"])),
    )


def test_text_native_condition_is_parsed_and_blocks_downstream() -> None:
    text = """Job: REPORT (command)
raw wire fields (everything the server sent for this job):
  Name: REPORT
  Context: Topology_Test
  ConditionExpression:
    Conditions:
      ConditionDto:
        ConditionType: Success
        DependsOnJobName: SOURCE
  JobType: Command
  Status: Waiting
"""
    detail = ps._detail_source(text)
    assert detail is not None
    assert detail["ConditionExpression"]["Conditions"]["ConditionDto"] == {
        "ConditionType": "Success", "DependsOnJobName": "SOURCE"
    }
    normalized = ps._normalize_topology({"jobs": [{"Name": "SOURCE", "Status": "Failed"}, detail]}, CTX, "Topology_Test")
    assert normalized["metadata"]["native_conditions"]["resolved_edges"] == 1
    assert normalized["metadata"]["native_conditions"]["verified_syntax"] == 1
    assert normalized["jobs"][1]["process_scheduler"]["NativeConditionExpression"]["Conditions"]["ConditionDto"]["DependsOnJobName"] == "SOURCE"
    assert normalized["jobs"][1]["autosys_jil"]["condition"] == "success(SOURCE)"
    report = analyze_blockers(_snapshot(normalized))
    assert [(root.uid, root.impact_count) for root in report.roots] == [(normalized["jobs"][0]["job_uid"], 1)]
    assert report.quality.verified_targets == 1


def test_explicit_or_condition_produces_two_edges_but_successful_alternative_unblocks() -> None:
    rows = [
        {"Name": "A", "Status": "Failed"},
        {"Name": "B", "Status": "Success"},
        {"Name": "T", "Status": "Waiting", "ConditionExpression": {
            "Operator": "OR", "Conditions": [
                {"ConditionDto": {"ConditionType": "Success", "DependsOnJobName": "A"}},
                {"ConditionDto": {"ConditionType": "Success", "DependsOnJobName": "B"}},
            ],
        }},
    ]
    normalized = ps._normalize_topology({"jobs": rows}, CTX, "Topology_Test")
    assert len(normalized["dependencies"]) == 2
    assert len({edge["condition"] for edge in normalized["dependencies"]}) == 1
    report = analyze_blockers(_snapshot(normalized))
    assert report.roots == []
    assert report.quality.verified_targets == 1


def test_multiple_conditions_without_explicit_logic_are_unverified() -> None:
    detail = ps._detail_source("""raw wire fields (everything the server sent for this job):
Name: T
ConditionExpression:
  Conditions:
    ConditionDto:
      ConditionType: Success
      DependsOnJobName: A
    ConditionDto:
      ConditionType: Success
      DependsOnJobName: B
Status: Waiting
""")
    assert detail is not None
    assert len(detail["ConditionExpression"]["Conditions"]["ConditionDto"]) == 2
    normalized = ps._normalize_topology({"jobs": [{"Name": "A", "Status": "Failed"},
                                                 {"Name": "B", "Status": "Failed"}, detail]}, CTX, "Topology_Test")
    assert normalized["metadata"]["native_conditions"]["unverified"] == 1
    assert len(normalized["dependencies"]) == 2
    assert all(edge["condition"] == "PS_UNVERIFIED_NATIVE_CONDITION" for edge in normalized["dependencies"])
    report = analyze_blockers(_snapshot(normalized))
    assert not report.roots
    assert report.quality.unverified_targets == 1
    assert any("native conditions" in warning for warning in report.quality.warnings)
    assert normalized["jobs"][2]["attributes"]["ps_condition_predecessors"] == ["A", "B"]


def test_missing_predecessor_does_not_confirm_partial_graph() -> None:
    normalized = ps._normalize_topology({"jobs": [
        {"Name": "A", "Status": "Failed"},
        {"Name": "T", "Status": "Waiting", "ConditionExpression": {
            "Operator": "AND", "Conditions": [
                {"ConditionType": "Success", "DependsOnJobName": "A"},
                {"ConditionType": "Success", "DependsOnJobName": "EXTERNAL"},
            ],
        }},
    ]}, CTX, "Topology_Test")
    assert len(normalized["dependencies"]) == 1
    assert normalized["dependencies"][0]["condition"] == "PS_UNVERIFIED_NATIVE_CONDITION"
    assert normalized["metadata"]["native_conditions"]["missing_references"] == 1
    report = analyze_blockers(_snapshot(normalized))
    assert report.roots == []
    assert report.quality.unverified_targets == 1


def test_unsupported_condition_type_does_not_guess_success() -> None:
    normalized = ps._normalize_topology({"jobs": [
        {"Name": "A", "Status": "Failed"},
        {"Name": "T", "Status": "Waiting", "ConditionExpression": {
            "Conditions": {"ConditionDto": {"ConditionType": "CustomEvent", "DependsOnJobName": "A"}}
        }},
    ]}, CTX, "Topology_Test")
    assert normalized["jobs"][1]["attributes"]["ps_condition_reason"] == "unsupported_condition_type_or_job_name"
    assert normalized["dependencies"][0]["condition"] == "PS_UNVERIFIED_NATIVE_CONDITION"
    assert analyze_blockers(_snapshot(normalized)).roots == []


def test_native_json_condition_survives_serialization_and_catalog(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    normalized = ps._normalize_topology({"jobs": [
        {"Name": "A", "Status": "Failed"},
        {"Name": "T", "Status": "Waiting", "ConditionExpression": {
            "Conditions": {"ConditionDto": {"ConditionType": "Success", "DependsOnJobName": "A"}}
        }},
    ]}, CTX, "Topology_Test")
    snap = _snapshot(normalized)
    restored = TopologySnapshot.model_validate_json(snap.model_dump_json())
    assert restored.edges[0].condition == "success(A)"
    assert restored.flat_jobs[1].process_scheduler.model_extra["NativeConditionExpression"]["Conditions"]["ConditionDto"]["DependsOnJobName"] == "A"
    # Current catalog implementation persists the existing model without migration.
    from app.services.snapshot_catalog import SnapshotCatalogStore
    monkeypatch.setattr("app.services.snapshot_catalog.get_settings", lambda: SimpleNamespace(snapshot_dir=tmp_path))
    catalog = SnapshotCatalogStore()
    # Persist and load through the same durable format as the application.
    record = catalog.save(snap)
    loaded_result = catalog.load(record.snapshot_id)
    assert loaded_result is not None
    loaded, _ = loaded_result
    assert loaded.edges[0].condition == "success(A)"
    assert loaded.flat_jobs[1].process_scheduler.model_extra["NativeConditionExpression"]["Conditions"]["ConditionDto"]["DependsOnJobName"] == "A"


def test_conflicting_native_and_explicit_topology_edges_preserves_explicit() -> None:
    normalized = ps._normalize_topology({"jobs": [
        {"Name": "A", "Status": "Failed"},
        {"Name": "B", "Status": "Success"},
        {"Name": "T", "Status": "Waiting", "ConditionExpression": {
            "Conditions": {"ConditionDto": {"ConditionType": "Success", "DependsOnJobName": "A"}}
        }},
    ], "dependencies": [{"from": "B", "to": "T", "condition": "success(B)"}]}, CTX, "Topology_Test")
    assert len(normalized["dependencies"]) == 1
    assert normalized["metadata"]["native_conditions"]["explicit_targets_preserved"] == 1
    assert normalized["metadata"]["native_conditions"]["source_conflicts"] == 1
    assert normalized["dependencies"][0]["condition"] == "PS_UNVERIFIED_NATIVE_CONFLICT"
    assert analyze_blockers(_snapshot(normalized)).roots == []


def test_describe_job_text_end_to_end_reaches_blockers(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Native detail indentation through the read-only bridge wrapper."""
    bridge = tmp_path / "bridge.py"
    bridge.write_text('''import json, sys
args = sys.argv[1:]
if args[0] == "get-contexts":
    print(json.dumps({"name": "Topology_Test", "jobs": [
        {"Name": "SOURCE", "Status": "Failed", "Kind": "COMMAND"},
        {"Name": "REPORT", "Status": "Waiting", "Kind": "COMMAND"}]}))
elif args[0] == "describe-job":
    name = args[args.index("--job") + 1]
    if name == "SOURCE":
        print(json.dumps({"summary": {"name": "SOURCE", "status": "Failed", "jobType": "Command"}}))
    else:
        print("Job: REPORT (command)\\nraw wire fields (everything the server sent for this job):\\n"
              "Name: REPORT\\nContext: Topology_Test\\nConditionExpression:\\n"
              "  Conditions:\\n    ConditionDto:\\n      ConditionType: Success\\n"
              "      DependsOnJobName: SOURCE\\nStatus: Waiting\\nJobType: Command\\n")
else: sys.exit(2)
''', encoding="utf-8")
    config = tmp_path / "connector.json"
    config.write_text(json.dumps({
        "launcher": [sys.executable, str(bridge)], "protocol_mode": "args",
        "enable_job_detail": True, "job_detail_workers": 2,
        "commands": {"fetch_topology": ["get-contexts", "--address", "{host}", "--names", "{topology}"],
                     "fetch_job_detail": ["describe-job", "--address", "{host}",
                                          "--context", "{topology}", "--job", "{job}"]},
    }), encoding="utf-8")
    monkeypatch.setenv("PROCESS_SCHEDULER_CONNECTOR_CONFIG", str(config))
    provider = ps.ProcessSchedulerProvider()
    payload = provider.fetch_topology(CTX)
    assert payload["metadata"]["job_details"] == {"requested": 2, "enriched": 2, "failed": 0, "errors": {}}
    assert payload["metadata"]["native_dependency_count"] == 1
    assert provider.capabilities()["dependencies"] is True
    assert len(payload["dependencies"]) == 1
    result = analyze_blockers(_snapshot(payload))
    assert len(result.roots) == 1
    assert result.quality.verified_targets == 1
    assert result.roots[0].impact_count == 1


def test_malformed_expression_is_never_published_as_verified() -> None:
    normalized = ps._normalize_topology({"jobs": [
        {"Name": "A", "Status": "Failed"},
        {"Name": "T", "Status": "Waiting", "ConditionExpression": "success(A) OR"},
    ]}, CTX, "Topology_Test")
    assert normalized["metadata"]["native_conditions"]["unverified"] == 1
    assert normalized["dependencies"][0]["condition"] == "PS_UNVERIFIED_NATIVE_CONDITION"
    assert analyze_blockers(_snapshot(normalized)).roots == []


def test_parent_operator_is_applied_to_wrapped_list() -> None:
    normalized = ps._normalize_topology({"jobs": [
        {"Name": "A", "Status": "Failed"},
        {"Name": "B", "Status": "Success"},
        {"Name": "T", "Status": "Waiting", "ConditionExpression": {
            "Operator": "OR", "Conditions": {"ConditionDto": [
                {"ConditionType": "Success", "DependsOnJobName": "A"},
                {"ConditionType": "Success", "DependsOnJobName": "B"},
            ]},
        }},
    ]}, CTX, "Topology_Test")
    assert len(normalized["dependencies"]) == 2
    assert analyze_blockers(_snapshot(normalized)).roots == []


def test_text_none_condition_is_not_reported_as_invalid() -> None:
    detail = ps._detail_source("""raw wire fields (everything the server sent for this job):
Name: T
ConditionExpression: None
Status: Waiting
""")
    assert detail is not None
    normalized = ps._normalize_topology({"jobs": [detail]}, CTX, "Topology_Test")
    assert normalized["metadata"]["native_conditions"]["jobs_with_conditions"] == 0
    assert normalized["jobs"][0]["process_scheduler"]["ConditionExpression"] is None
    assert normalized["jobs"][0]["attributes"].get("ps_condition_status") is None
