'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const script = fs.readFileSync('app/static/js/workspace-state.js', 'utf8');

function makePage(page, oldStorage) {
  const handlers = new Map();
  const values = new Map(Object.entries(oldStorage || {}));
  const elements = new Map();
  let local;
  class FakeEvent {
    constructor(type, params = {}) { this.type = type; this.bubbles = !!params.bubbles; }
  }
  function on(type, fn) { const list = handlers.get(type) || []; list.push(fn); handlers.set(type, list); }
  const document = {
    readyState: 'loading',
    getElementById: (id) => elements.get(id) || null,
    addEventListener: on,
    querySelectorAll: () => [],
  };
  const fire = (type, target, detail) => (handlers.get(type) || []).forEach((fn) => fn({type, target, detail}));
  function select(id, options, selected) {
    const element = {
      id, tagName: 'SELECT', disabled: false,
      options: options.map((value) => ({value, disabled: false})),
      value: selected,
      dispatchEvent(event) { fire(event.type, element); },
    };
    elements.set(id, element);
    return element;
  }
  const sessionStorage = {
    getItem: (key) => values.get(key) ?? null,
    setItem: (key, val) => values.set(key, val),
  };
  local = {
    document, sessionStorage, location: {pathname: '/' + page}, Event: FakeEvent,
    window: {addEventListener: () => {}}, setTimeout: (cb) => cb(),
  };
  function run() { vm.runInNewContext(script, local); fire('DOMContentLoaded', document); }
  return {select, run, fire, elements, values};
}

const browseKey = 'ps-tool-workspace-selection-v1:browse';
const original = JSON.stringify({'browse-env': 'ps-u5', 'browse-snapshot': 'saved-u5'});
const ui = makePage('browse', {[browseKey]: original});
const env = ui.select('browse-env', ['autosys-u1', 'ps-u5'], 'autosys-u1');
ui.select('browse-snapshot', ['initial'], 'initial');
ui.run();
assert.equal(env.value, 'ps-u5');
assert.equal(ui.values.get(browseKey), original, 'restore must not overwrite the selected snapshot');
ui.select('browse-snapshot', ['saved-u5', 'new-u5'], 'new-u5');
ui.fire('htmx:afterSwap', {id: 'browse-context-fields'}, {target: {id: 'browse-context-fields'}});
assert.equal(ui.elements.get('browse-snapshot').value, 'saved-u5');
assert.equal(JSON.parse(ui.values.get(browseKey))['browse-snapshot'], 'saved-u5');

// User-driven environment changes must not revive a snapshot from the previous environment.
env.value = 'autosys-u1';
ui.fire('change', env);
assert.equal(JSON.parse(ui.values.get(browseKey))['browse-snapshot'], '');
ui.select('browse-snapshot', ['autosys-current'], 'autosys-current');
ui.fire('htmx:afterSwap', {id: 'browse-context-fields'}, {target: {id: 'browse-context-fields'}});
assert.equal(ui.elements.get('browse-snapshot').value, 'autosys-current');
assert.equal(JSON.parse(ui.values.get(browseKey))['browse-snapshot'], 'autosys-current');

const compareKey = 'ps-tool-workspace-selection-v1:compare';
const compare = makePage('compare', {[compareKey]: JSON.stringify({
  'compare-left-env': 'ps-u5', 'compare-left-snapshot': 'left-u5',
  'compare-right-env': 'autosys-u1', 'compare-right-snapshot': 'right-u1',
})});
compare.select('compare-left-env', ['ps-u5', 'autosys-u1'], 'ps-u5');
compare.select('compare-right-env', ['ps-u5', 'autosys-u1'], 'autosys-u1');
compare.select('compare-left-snapshot', ['left-u5'], 'left-u5');
compare.select('compare-right-snapshot', ['right-u1'], 'right-u1');
compare.run();
assert.equal(compare.elements.get('compare-left-snapshot').value, 'left-u5');
assert.equal(compare.elements.get('compare-right-snapshot').value, 'right-u1');

const snapshotsKey = 'ps-tool-workspace-selection-v1:snapshots';
const snapshots = makePage('snapshots', {[snapshotsKey]: JSON.stringify({'snapshot-job-limit': '500'})});
const size = snapshots.select('snapshot-job-limit', ['50', '100', '500', '5000', 'full'], '50');
snapshots.run();
assert.equal(size.value, '500', 'debug select should restore a supported value');
size.value = 'full';
snapshots.fire('change', size);
assert.equal(JSON.parse(snapshots.values.get(snapshotsKey))['snapshot-job-limit'], 'full');

const stale = makePage('snapshots', {[snapshotsKey]: JSON.stringify({'snapshot-job-limit': '777'})});
stale.select('snapshot-job-limit', ['50', '100', '500', '5000', 'full'], '50');
stale.run();
assert.equal(stale.elements.get('snapshot-job-limit').value, '50', 'obsolete custom limits must be ignored');
console.log('workspace state tests passed');
