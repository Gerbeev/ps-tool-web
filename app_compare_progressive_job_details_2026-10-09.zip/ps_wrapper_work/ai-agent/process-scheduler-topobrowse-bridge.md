# Process Scheduler Integration — TopoBrowse.Bridge Boundary

## Status

`TopoBrowse.Bridge` is the existing bank-local C# transport component for Process Scheduler. The Python/web project does **not** implement WCF and must not depend on WCF bindings, generated service proxies, Cosmos DB, or Process Scheduler storage internals.

The production integration boundary is:

```text
Snapshots UI
  -> snapshot_generation
  -> ExternalBridgeAdapter
  -> scheduler-bridge/v1
  -> workstation_connectors/process_scheduler_connector.py
  -> TopoBrowse.Bridge
  -> WCF
  -> Process Scheduler
```

`process_scheduler_connector.py` is a shipped application component. It is not a workstation TODO and must not be rewritten during deployment.

## Deployment layout

Copy the complete `TopoBrowse.Bridge` directory into:

```text
workstation_connectors/
  bridge_v1_runtime.py
  autosys_connector.py
  process_scheduler_connector.py
  process_scheduler_connector.json
  TopoBrowse.Bridge/
    TopoBrowse.Bridge.csproj
    Program.cs
    DbAccessBridgeClient.cs
    Contracts/
    bin/
    ...
```

The default wrapper auto-discovers, in order:

1. `bin/**/TopoBrowse.Bridge.exe`
2. `bin/**/TopoBrowse.Bridge.dll` and launches it with `dotnet`
3. `TopoBrowse.Bridge.csproj` through `dotnet run` when no built artifact exists

A different location can be configured with `PROCESS_SCHEDULER_BRIDGE_DIR` or `process_scheduler_connector.json`.

## Responsibilities

### TopoBrowse.Bridge owns

- WCF transport and binding;
- Process Scheduler authentication/session behavior;
- Process Scheduler service contracts and native DTO retrieval;
- source-side operations for topology listing and topology/job reads.

### process_scheduler_connector.py owns

- safe subprocess invocation of TopoBrowse.Bridge;
- Process Scheduler environment/host context forwarding;
- conversion of topology names into `list_roots`;
- conversion of native topology/job data into `scheduler-bridge/v1`;
- status normalization;
- deterministic fallback job IDs when no native stable ID exists;
- preservation of native Process Scheduler fields;
- conservative AutoSys-equivalent projection;
- compact diagnostics.

### Web engine owns

- immutable snapshot persistence;
- Browse/Compare/Search/Export over saved snapshots;
- identity matching and comparison rules.

Browse and Compare must never invoke TopoBrowse.Bridge directly.

## Wrapper contract strategy

The exact CLI shape of the copied C# bridge is intentionally isolated from the web application. The wrapper supports:

- argument-based commands;
- JSON request over stdin;
- JSON responses;
- the observed text topology/topology-detail shapes as a compatibility fallback.

`process_scheduler_connector.json` can pin an exact CLI contract later without changing Python code. `protocol_mode` may be `auto`, `args`, or `stdin_json`.

Default read-only logical operations are:

```text
health
list_topologies
fetch_topology
fetch_job_detail (optional)
```

The snapshot workflow requires only `list_topologies` and `fetch_topology`.

## Normalization rules

Known native fields are preserved in `BridgeJobV1.process_scheduler` / `SnapshotJob.process_scheduler`.

Observed fields include:

```text
Name
Status
LastStartTime
LastFinishTime
JobType
Schedule
StartAtTime
StartAtTimeForce
Owner
Description
Box
ConditionExpression
Context
```

The wrapper may safely project verified equivalents such as runtime timestamps, machine, job type, weekday schedule, start time and owner.

It must **not** infer:

- execution dependencies from row order;
- dependency edges from `ConditionExpression` until its grammar is verified;
- parent hierarchy from `Box` or `Context` until their nested semantics are verified.

Explicit parent/dependency DTO fields returned by TopoBrowse.Bridge may be mapped directly.

## Completeness

A topology response must contain the complete topology. If the bridge output declares a larger total than the returned row count, the wrapper fails with `partial_topology` instead of publishing an incomplete snapshot.

Missing migration-parity fields are represented through strict support metadata as `unknown` or `unsupported`; they are never fabricated to make a comparison pass.

## Diagnostics

Run:

```cmd
diagnose-process-scheduler.cmd --environment ps-u5
```

This validates bridge discovery and topology listing.

To inspect one exact topology end-to-end:

```cmd
diagnose-process-scheduler.cmd --environment ps-u5 --topology DataPlatform_20261001_Friday
```

Result semantics:

- `READY`: bridge invocation, topology listing and selected topology/detail surface are usable;
- `INCOMPLETE`: topology can be read but only a reduced detail surface was observed;
- `FAILED`: bridge discovery, invocation, source access or response parsing failed.

Diagnostics print structural information only: launcher type, operation mode, counts, field names and failure categories. Raw source payloads, job commands and credentials are not emitted.

## First integration objective

The first real integration run should establish only the C# bridge invocation contract and returned DTO shape. WCF internals are out of scope for the Python project. Once the exact TopoBrowse.Bridge CLI/JSON shape is known, pin it in `process_scheduler_connector.json` and keep `scheduler-bridge/v1` unchanged.
