@echo off
setlocal EnableExtensions
cd /d "%~dp0.."
set "EXIT_CODE=0"
set "PYTHON_EXE=.venv\Scripts\python.exe"

echo ================================================================
echo PS TOOL - AUTOSYS DIAGNOSTICS
echo ================================================================
echo.

if not exist "%PYTHON_EXE%" (
  echo ERROR: Project virtual environment is missing.
  echo Run setup-env.cmd from the project root once, then double-click this file again.
  set "EXIT_CODE=1"
  goto :finish
)

"%PYTHON_EXE%" -c "import yaml, pydantic" >nul 2>&1
if errorlevel 1 (
  echo ERROR: Project dependencies are incomplete in .venv.
  echo Run setup-env.cmd from the project root once, then double-click this file again.
  set "EXIT_CODE=1"
  goto :finish
)

"%PYTHON_EXE%" -m scripts.diagnose_all --scope autosys
set "EXIT_CODE=%ERRORLEVEL%"

:finish
echo.
echo [ps-tool-web] AutoSys diagnostics exit code: %EXIT_CODE%
pause
endlocal & exit /b %EXIT_CODE%
