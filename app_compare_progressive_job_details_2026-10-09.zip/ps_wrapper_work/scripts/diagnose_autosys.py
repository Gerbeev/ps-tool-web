"""Run compact AutoSys source diagnostics for one configured environment."""

from __future__ import annotations

import argparse
from datetime import date

from app.config import endpoint_for_environment, get_environment, scheduler_for_environment
from app.models import SchedulerType
from app.services.snapshot_generation import autosys_business_date
from workstation_connectors.autosys_connector import diagnose


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--environment", default="autosys-u1", help="Configured environment id, e.g. autosys-u1")
    parser.add_argument("--cob", default="", help="Optional YYYY-MM-DD override; default is local today minus one day")
    args = parser.parse_args()

    entry = get_environment(args.environment)
    if entry is None or not entry.enabled:
        parser.error(f"Unknown or disabled environment: {args.environment}")
    if scheduler_for_environment(args.environment) != SchedulerType.AUTOSYS:
        parser.error(f"Environment is not AutoSys: {args.environment}")

    cob = args.cob or autosys_business_date(date.today())
    context = {
        "environment_id": entry.id,
        "environment": entry.environment,
        "scheduler": "autosys",
        "host": endpoint_for_environment(entry.id),
        "as_of_kind": "business_date",
        "as_of_value": cob,
        "root_box": None,
        "topology_id": None,
    }
    return diagnose(context)


if __name__ == "__main__":
    raise SystemExit(main())
