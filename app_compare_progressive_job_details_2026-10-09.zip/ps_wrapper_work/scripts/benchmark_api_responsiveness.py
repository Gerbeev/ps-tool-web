"""Synthetic, connector-free API latency and event-loop responsiveness benchmark.

Run from the project root: python scripts/benchmark_api_responsiveness.py
Uses only temporary snapshot storage and search indexes; never calls a scheduler.
"""
from __future__ import annotations

import asyncio
import os
import re
import sys
import tempfile
import time
from pathlib import Path

import httpx

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def build_snapshot(count: int, scheduler, environment: str):
    from app.models import ComparisonContext, JobNode, JobStatus, SnapshotJob, TopologySnapshot

    jobs = [
        SnapshotJob(
            job_uid=f"job-{i}",
            logical_id=f"RISK_JOB_{i:05d}",
            scheduler_job_name=f"RISK_JOB_{i:05d}",
            status=JobStatus.SUCCESS,
            path_labels=["RISK_BOX", f"RISK_JOB_{i:05d}"],
        )
        for i in range(count)
    ]
    return TopologySnapshot(
        context=ComparisonContext(environment_id=environment, scheduler=scheduler),
        roots=[JobNode(job=jobs[0], children=[JobNode(job=job) for job in jobs[1:]])],
        flat_jobs=jobs,
    )


async def measure(client: httpx.AsyncClient, path: str, *, data=None, params=None):
    stop = asyncio.Event()
    lags: list[float] = []

    async def heartbeat():
        while not stop.is_set():
            due = time.perf_counter() + 0.02
            await asyncio.sleep(0.02)
            lags.append(max(0.0, time.perf_counter() - due))

    monitor = asyncio.create_task(heartbeat())
    await asyncio.sleep(0.04)
    start = time.perf_counter()
    try:
        if data is not None:
            response = await client.post(path, data=data)
        else:
            response = await client.get(path, params=params)
        duration = (time.perf_counter() - start) * 1000
    finally:
        stop.set()
        await monitor

    response.raise_for_status()
    max_lag = max(lags, default=0.0) * 1000
    print(f"{path:24} elapsed_ms={duration:8.1f} loop_lag_ms={max_lag:8.1f} bytes={len(response.content)}", flush=True)
    return response


async def run(app, catalog):
    from app.models import SchedulerType
    async with httpx.AsyncClient(
        transport=httpx.ASGITransport(app=app),
        base_url="http://localhost",
        timeout=90,
    ) as client:
        for count in (2500, 10000):
            print(f"\nSynthetic snapshot size: {count} jobs per side")
            left = catalog.save(build_snapshot(count, SchedulerType.AUTOSYS, "autosys-u1"))
            right = catalog.save(build_snapshot(count, SchedulerType.PROCESS_SCHEDULER, "ps-u5"))
            browse = await measure(client, "/api/browse/load", data={
                "environment_id": "autosys-u1", "snapshot_id": left.snapshot_id,
            })
            browse_sid = re.search(r'id="session-id"[^>]*value="([^"]+)', browse.text)
            assert browse_sid is not None
            await measure(client, "/api/search", params={
                "session_id": browse_sid.group(1), "q": "RISK", "limit": 100, "format": "json",
            })
            compare = await measure(client, "/api/compare", data={
                "left_env": "autosys-u1", "left_snapshot_id": left.snapshot_id,
                "right_env": "ps-u5", "right_snapshot_id": right.snapshot_id,
            })
            compare_sid = re.search(r'id="session-id"[^>]*value="([^"]+)', compare.text)
            assert compare_sid is not None
            await measure(client, "/api/compare/table", params={
                "session_id": compare_sid.group(1), "filter": "all", "limit": 0,
            })


def main():
    # Set environment before importing app/config/search singletons.
    with tempfile.TemporaryDirectory(prefix="api-perf-") as temp:
        os.environ["SEARCH_DB_PATH"] = str(Path(temp) / "search.db")
        os.environ["SNAPSHOT_DIR"] = str(Path(temp) / "snapshots")
        from app.main import app
        from app.search.sqlite_fts import search_index
        from app.services.snapshot_catalog import snapshot_catalog
        try:
            asyncio.run(run(app, snapshot_catalog))
        finally:
            # Release the temporary SQLite database before removal on Windows.
            search_index._conn.close()


if __name__ == "__main__":
    main()
