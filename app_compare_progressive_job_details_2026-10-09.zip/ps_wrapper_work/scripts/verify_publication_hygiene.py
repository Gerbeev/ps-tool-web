"""Validate neutral reference naming and release documentation metadata.

Run as part of checkout verification and before publishing a distribution.
This check does not modify files or the two immutable endpoint specifications.
"""
from __future__ import annotations

import re
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
EXTENSIONS = {'.md', '.py', '.yaml', '.yml', '.json', '.txt', '.cmd', '.html', '.js', '.css'}
SCAN_AREAS = ('docs', 'examples', 'app', 'workstation_connectors', 'scripts', 'tests', 'ai-agent', 'tools')
EXCLUDED_FILES = {
    'docs/reference/AUTOSYS_SELFHELP_ENDPOINT_SPEC.md',
    'docs/reference/PROCESS_SCHEDULER_TOPOBROWSE_BRIDGE.md',
    'scripts/verify_publication_hygiene.py',
    'tests/test_publication_hygiene.py',
}
# Build terms from parts to avoid embedding acquisition-language in release metadata.
DISALLOWED = re.compile('|'.join((
    r'screen' + r'[-_ ]?shot(?:s)?',
    r'photo' + r'graph(?:s|ed|ic)?',
    r'trans' + r'cri(?:ption|bed|bing)',
    r'IMG_' + r'\d{3,}',
)), re.IGNORECASE)
EXPECTED_REFERENCE = 'docs/reference/TOPOBROWSE_PROGRAM_CS_REFERENCE.md'


def verify(root: Path = PROJECT_ROOT) -> list[str]:
    issues: list[str] = []
    if not (root / EXPECTED_REFERENCE).is_file():
        issues.append(f'Missing contract reference: {EXPECTED_REFERENCE}')
    candidates = [root / 'AGENTS.md', root / 'README.md']
    for area in SCAN_AREAS:
        if (root / area).is_dir():
            candidates.extend((root / area).rglob('*'))
    for path in candidates:
        if not path.is_file() or path.suffix.lower() not in EXTENSIONS:
            continue
        relative = path.relative_to(root).as_posix()
        if relative in EXCLUDED_FILES:
            continue
        if DISALLOWED.search(relative):
            issues.append(f'Non-neutral file name: {relative}')
        try:
            content = path.read_text(encoding='utf-8')
        except (UnicodeError, OSError):
            continue
        match = DISALLOWED.search(content)
        if match:
            line = content.count('\n', 0, match.start()) + 1
            issues.append(f'Non-neutral reference metadata: {relative}:{line}')
    return issues


def main() -> int:
    issues = verify()
    for issue in issues:
        print('ERROR:', issue)
    if not issues:
        print('OK: publication hygiene verified')
    return int(bool(issues))


if __name__ == '__main__':
    raise SystemExit(main())
