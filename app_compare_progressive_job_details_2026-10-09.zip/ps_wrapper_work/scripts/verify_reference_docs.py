"""Fail if preserved reference documents are changed or deleted.

Never regenerate these digests during normal implementation or refactoring.
Reference originals are immutable inputs, not maintained product documentation.
"""

from __future__ import annotations

import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
REFERENCE_DIGESTS = {
    'AUTOSYS_SELFHELP_ENDPOINT_SPEC.md': '79076388bf1635731f947262e2936628368210978838e3b9afce482c420aa895',
    'PROCESS_SCHEDULER_TOPOBROWSE_BRIDGE.md': 'cad82b8fd568a9184f5f0ba6953ec8acbccadedf1d34b2957ad8c68249f8d961',
}


def verify() -> list[str]:
    errors: list[str] = []
    for name, expected in REFERENCE_DIGESTS.items():
        path = ROOT / 'docs' / 'reference' / name
        if not path.is_file():
            errors.append(f'MISSING immutable reference: {name}')
        elif hashlib.sha256(path.read_bytes()).hexdigest() != expected:
            errors.append(f'MODIFIED immutable reference: {name}')
    return errors


def main() -> int:
    errors = verify()
    if errors:
        for error in errors:
            print('ERROR:', error)
        return 1
    print(f'OK: {len(REFERENCE_DIGESTS)} immutable references verified')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
