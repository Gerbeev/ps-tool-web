"""Run compact Process Scheduler / TopoBrowse.Bridge diagnostics."""

from __future__ import annotations

import argparse

from app.config import endpoint_for_environment, get_environment, scheduler_for_environment
from app.models import SchedulerType
from workstation_connectors.process_scheduler_connector import diagnose


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--environment", default="ps-u5", help="Configured environment id, e.g. ps-u5")
    parser.add_argument("--topology", default="", help="Optional exact topology name to fetch and inspect")
    args = parser.parse_args()

    entry = get_environment(args.environment)
    if entry is None or not entry.enabled:
        parser.error(f"Unknown or disabled environment: {args.environment}")
    if scheduler_for_environment(args.environment) != SchedulerType.PROCESS_SCHEDULER:
        parser.error(f"Environment is not Process Scheduler: {args.environment}")

    context = {
        "environment_id": entry.id,
        "environment": entry.environment,
        "scheduler": "process_scheduler",
        "host": endpoint_for_environment(entry.id),
        "as_of_kind": "latest",
        "as_of_value": "",
        "root_box": None,
        "topology_id": None,
    }
    return diagnose(context, topology=args.topology)


if __name__ == "__main__":
    raise SystemExit(main())
