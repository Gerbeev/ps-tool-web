"""Durable immutable snapshot catalog used by Snapshots, Browse, and Compare."""

from __future__ import annotations

import gzip
import hashlib
import json
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from threading import RLock
from uuid import uuid4

from pydantic import BaseModel, Field

from app.config import get_environment, get_settings
from app.models import ComparisonContext, SchedulerType, TopologySnapshot
from app.services.runtime_diagnostics import log_event
from app.services.topology_index import ensure_topology_indexes


class SnapshotRecord(BaseModel):
    """Small durable catalog entry for one immutable topology snapshot."""

    schema_version: int = 1
    snapshot_id: str
    snapshot_name: str = ""
    environment_name: str = ""
    captured_at: datetime
    fetched_at: datetime
    scheduler: SchedulerType
    environment_id: str
    context: ComparisonContext
    job_count: int
    edge_count: int
    topology_id: str | None = None
    business_date: str | None = None
    filename: str
    sha256: str
    debug_job_limit: int | None = None
    source_job_count: int | None = None

    @property
    def source_scope(self) -> str:
        if self.scheduler == SchedulerType.PROCESS_SCHEDULER:
            return self.topology_id or "—"
        return self.business_date or self.context.as_of.value or "—"

    @property
    def label(self) -> str:
        if self.snapshot_name:
            return self.snapshot_name
        scheduler = "AutoSys" if self.scheduler == SchedulerType.AUTOSYS else "PS"
        environment = self.environment_name or self.environment_id
        captured = self.captured_at.astimezone().strftime("%Y-%m-%d_%H-%M-%S")
        if self.scheduler == SchedulerType.PROCESS_SCHEDULER:
            return f"{environment}-{scheduler}_{self.captured_at.astimezone().date().isoformat()}_{self.source_scope}"
        return f"{environment}-{scheduler}_{captured}"


class SnapshotCatalogIndex(BaseModel):
    schema_version: int = 1
    snapshots: list[SnapshotRecord] = Field(default_factory=list)


class SnapshotCatalogError(RuntimeError):
    """An unsafe catalog operation was stopped without modifying stored snapshots."""


@dataclass(frozen=True)
class CatalogHealth:
    status: str = "healthy"
    recovered_count: int = 0
    invalid_count: int = 0
    message: str = ""

    @property
    def read_only(self) -> bool:
        return self.status != "healthy"

    @property
    def can_restore(self) -> bool:
        return self.status == "recovery_available"


class SnapshotCatalogStore:
    """Persist snapshots as immutable gzip payloads with an atomically written index."""

    _EPHEMERAL_METADATA_KEYS = {
        "children_index",
        "jobs_by_uid",
        "match_confidence_by_uid",
    }

    def __init__(self) -> None:
        self._lock = RLock()
        self._last_catalog_alert: tuple[str, str, int] | None = None

    @property
    def root(self) -> Path:
        return get_settings().snapshot_dir

    @property
    def index_path(self) -> Path:
        return self.root / "index.json"

    @classmethod
    def _snapshot_bytes(cls, snapshot: TopologySnapshot) -> bytes:
        payload = snapshot.model_dump(mode="json")
        metadata = dict(payload.get("metadata") or {})
        for key in cls._EPHEMERAL_METADATA_KEYS:
            metadata.pop(key, None)
        payload["metadata"] = metadata
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return gzip.compress(raw, compresslevel=6, mtime=0)

    @staticmethod
    def _snapshot_from_bytes(data: bytes) -> TopologySnapshot:
        # Validate JSON directly to avoid constructing a second full Python object graph.
        snapshot = TopologySnapshot.model_validate_json(gzip.decompress(data))
        ensure_topology_indexes(snapshot)
        return snapshot

    @staticmethod
    def _sha256(data: bytes) -> str:
        return hashlib.sha256(data).hexdigest()

    @staticmethod
    def _write_bytes_atomic(path: Path, data: bytes) -> None:
        tmp = path.with_name(f".{path.name}.{uuid4().hex}.tmp")
        tmp.write_bytes(data)
        os.replace(tmp, path)

    def _read_index(self) -> SnapshotCatalogIndex:
        """Read only a valid index; never interpret corruption as an empty catalog."""
        return self._catalog_view()[0]

    def _catalog_view(self) -> tuple[SnapshotCatalogIndex, CatalogHealth]:
        """Provide a read-only reconstructed view if the index cannot be used."""
        try:
            raw = self.index_path.read_text(encoding="utf-8")
        except FileNotFoundError:
            if not any(self.root.glob("*.snapshot.json.gz")):
                self._last_catalog_alert = None
                return SnapshotCatalogIndex(), CatalogHealth()
            reason = "missing"
        except OSError:
            reason = "unreadable"
        else:
            try:
                index = SnapshotCatalogIndex.model_validate_json(raw)
            except ValueError:
                reason = "invalid"
            else:
                self._last_catalog_alert = None
                return index, CatalogHealth()

        recovered: list[SnapshotRecord] = []
        invalid = 0
        for path in sorted(self.root.glob("*.snapshot.json.gz")):
            try:
                data = path.read_bytes()
                # Use the payload's canonical identity, never a filename-derived ID.
                snapshot = TopologySnapshot.model_validate(
                    json.loads(gzip.decompress(data).decode("utf-8"))
                )
                if path.name != f"{snapshot.snapshot_id}.snapshot.json.gz":
                    raise ValueError("Snapshot identity does not match payload filename")
                recovered.append(self._record_for_snapshot(
                    snapshot,
                    data=data,
                    captured_at=datetime.fromtimestamp(path.stat().st_mtime, timezone.utc),
                    filename=path.name,
                ))
            except (OSError, ValueError, TypeError, EOFError, OverflowError):
                invalid += 1

        status = "recovery_available" if invalid == 0 and recovered else "recovery_blocked"
        message = (
            "Catalog index is missing or cannot be read. Existing snapshot files are "
            "available in read-only recovery mode; confirm Restore catalog to rebuild "
            "the index while preserving the original."
            if status == "recovery_available" else
            "Catalog index is missing or cannot be read, and there are no fully "
            "recoverable snapshot files or some files failed validation. No files "
            "were changed. Check application.log and repair the catalog before restoring."
        )
        health = CatalogHealth(status, len(recovered), invalid, message)
        signature = (str(self.index_path), reason, invalid)
        if signature != self._last_catalog_alert:
            self._last_catalog_alert = signature
            log_event("snapshot_catalog_recovery_required", always=True,
                      stage="catalog_recovery", error_code=reason,
                      failures=invalid, done=len(recovered))
        return SnapshotCatalogIndex(snapshots=recovered), health

    def health(self) -> CatalogHealth:
        with self._lock:
            return self._catalog_view()[1]

    def _require_writable_index(self) -> SnapshotCatalogIndex:
        index, health = self._catalog_view()
        if health.read_only:
            raise SnapshotCatalogError(
                "Snapshot catalog requires recovery. Open Snapshots and restore the "
                "catalog before creating or deleting snapshots."
            )
        return index

    def assert_writable(self) -> None:
        with self._lock:
            self._require_writable_index()

    def restore_index(self) -> int:
        """Rebuild on explicit request; keep the original index as a separate backup."""
        with self._lock:
            index, health = self._catalog_view()
            if not health.read_only:
                raise SnapshotCatalogError("Catalog is healthy; restoration is not needed.")
            if not health.can_restore:
                raise SnapshotCatalogError(
                    "Restoration blocked: not all snapshot files could be validated. "
                    "The original index and snapshot files were preserved."
                )

            backup: Path | None = None
            if self.index_path.exists():
                backup = self.root / f"index.corrupt.{uuid4().hex}.json"
                os.replace(self.index_path, backup)
            try:
                self._write_index(index)
            except Exception:
                if backup is not None and backup.exists() and not self.index_path.exists():
                    os.replace(backup, self.index_path)
                raise
            self._last_catalog_alert = None
            log_event("snapshot_catalog_restored", always=True,
                      stage="catalog_recovery", done=len(index.snapshots))
            return len(index.snapshots)

    def _write_index(self, index: SnapshotCatalogIndex) -> None:
        data = json.dumps(index.model_dump(mode="json"), indent=2, sort_keys=True).encode("utf-8")
        self._write_bytes_atomic(self.index_path, data)


    @staticmethod
    def _build_snapshot_name(
        *,
        scheduler: SchedulerType,
        environment_name: str,
        captured_at: datetime,
        topology_id: str | None,
    ) -> str:
        local_capture = captured_at.astimezone()
        if scheduler == SchedulerType.PROCESS_SCHEDULER:
            return (
                f"{environment_name}-ProcessScheduler_{local_capture.date().isoformat()}_"
                f"{topology_id or 'topology'}"
            )
        return f"{environment_name}-AutoSys_{local_capture.strftime('%Y-%m-%d_%H-%M-%S')}"

    def _record_for_snapshot(
        self, snapshot: TopologySnapshot, *, data: bytes,
        captured_at: datetime, filename: str,
    ) -> SnapshotRecord:
        topology_id = snapshot.context.filters.topology_id or snapshot.context.filters.root_box
        environment = get_environment(snapshot.context.environment_id)
        environment_name = (environment.environment if environment else snapshot.context.environment_id).strip()
        business_date = (
            snapshot.context.as_of.value
            if snapshot.context.scheduler == SchedulerType.AUTOSYS
            else None
        )
        debug_sample = snapshot.metadata.get("debug_sample") or {}
        limit = debug_sample.get("requested_limit") if isinstance(debug_sample, dict) else None
        source_total = debug_sample.get("source_total_jobs") if isinstance(debug_sample, dict) else None
        return SnapshotRecord(
            snapshot_id=snapshot.snapshot_id,
            snapshot_name=self._build_snapshot_name(
                scheduler=snapshot.context.scheduler,
                environment_name=environment_name,
                captured_at=captured_at,
                topology_id=topology_id,
            ) + (f"_DEBUG_{limit}" if isinstance(limit, int) and limit > 0 else ""),
            debug_job_limit=limit if isinstance(limit, int) and limit > 0 else None,
            source_job_count=source_total if isinstance(source_total, int) else None,
            environment_name=environment_name,
            captured_at=captured_at,
            fetched_at=snapshot.fetched_at,
            scheduler=snapshot.context.scheduler,
            environment_id=snapshot.context.environment_id,
            context=snapshot.context,
            job_count=len(snapshot.flat_jobs),
            edge_count=len(snapshot.edges),
            topology_id=(
                topology_id
                if snapshot.context.scheduler == SchedulerType.PROCESS_SCHEDULER
                else None
            ),
            business_date=business_date,
            filename=filename,
            sha256=self._sha256(data),
        )

    def save(self, snapshot: TopologySnapshot) -> SnapshotRecord:
        """Persist a new immutable snapshot and append it to the catalog."""
        data = self._snapshot_bytes(snapshot)
        snapshot_id = snapshot.snapshot_id
        filename = f"{snapshot_id}.snapshot.json.gz"

        with self._lock:
            self.root.mkdir(parents=True, exist_ok=True)
            # Validate the index before writing a new payload: no orphan files on failure.
            index = self._require_writable_index()
            target = self.root / filename
            if target.exists():
                raise ValueError(f"Snapshot {snapshot_id!r} already exists")
            if any(item.snapshot_id == snapshot_id for item in index.snapshots):
                raise ValueError(f"Snapshot {snapshot_id!r} already exists in catalog")
            record = self._record_for_snapshot(
                snapshot, data=data, captured_at=datetime.now(timezone.utc), filename=filename
            )
            self._write_bytes_atomic(target, data)
            index.snapshots.append(record)
            try:
                self._write_index(index)
            except Exception:
                # The original catalog is still valid; remove the unindexed new payload.
                target.unlink(missing_ok=True)
                raise
        return record

    def list(
        self,
        *,
        environment_id: str | None = None,
        scheduler: SchedulerType | None = None,
    ) -> list[SnapshotRecord]:
        with self._lock:
            records = list(self._read_index().snapshots)
        if environment_id is not None:
            records = [item for item in records if item.environment_id == environment_id]
        if scheduler is not None:
            records = [item for item in records if item.scheduler == scheduler]
        records.sort(key=lambda item: item.captured_at, reverse=True)
        return records

    def get_record(self, snapshot_id: str) -> SnapshotRecord | None:
        with self._lock:
            for item in self._read_index().snapshots:
                if item.snapshot_id == snapshot_id:
                    return item
        return None

    def load(self, snapshot_id: str) -> tuple[TopologySnapshot, SnapshotRecord] | None:
        with self._lock:
            record = self.get_record(snapshot_id)
            if record is None:
                return None
            try:
                data = (self.root / record.filename).read_bytes()
            except OSError:
                return None
            if self._sha256(data) != record.sha256:
                return None
            try:
                snapshot = self._snapshot_from_bytes(data)
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                return None
        return snapshot, record

    def delete(self, snapshot_id: str) -> SnapshotRecord | None:
        """Delete exactly one catalog snapshot and its immutable payload."""
        with self._lock:
            index = self._require_writable_index()
            record = next((item for item in index.snapshots if item.snapshot_id == snapshot_id), None)
            if record is None:
                return None

            filename = Path(record.filename)
            if filename.name != record.filename or filename.suffixes[-3:] != [".snapshot", ".json", ".gz"]:
                raise ValueError("Invalid snapshot catalog filename")

            target = self.root / record.filename
            tombstone = self.root / f".{record.filename}.{uuid4().hex}.deleting"
            renamed = False
            if target.exists():
                os.replace(target, tombstone)
                renamed = True

            updated = SnapshotCatalogIndex(
                snapshots=[item for item in index.snapshots if item.snapshot_id != snapshot_id]
            )
            try:
                self._write_index(updated)
            except Exception:
                if renamed and tombstone.exists():
                    os.replace(tombstone, target)
                raise

            if renamed:
                try:
                    tombstone.unlink()
                except OSError:
                    pass
            return record

    def clear(self) -> None:
        """Test/admin helper. Runtime UI does not delete historical snapshots."""
        with self._lock:
            if not self.root.exists():
                return
            for path in self.root.iterdir():
                if path.is_file():
                    try:
                        path.unlink()
                    except OSError:
                        pass


snapshot_catalog = SnapshotCatalogStore()
