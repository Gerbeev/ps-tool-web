"""Read-only presentation model for Browse job details.

Only restructures captured snapshot fields; it never infers a missing dependency
or changes the full source payload used by comparison and diagnostics.
"""
from __future__ import annotations

import json
from datetime import datetime
from typing import Any

from app.models import SchedulerType, SnapshotJob


def _present(value: Any) -> bool:
    """False and zero are real source values; absent/empty collections are not."""
    return value is not None and value != "" and value != [] and value != {}


def _text(value: Any) -> str:
    if isinstance(value, datetime):
        return value.isoformat(sep=" ", timespec="seconds")
    if isinstance(value, (list, dict)):
        return json.dumps(value, ensure_ascii=False, indent=2, default=str)
    if isinstance(value, bool):
        return "true" if value else "false"
    return str(value)


def _field(label: str, value: Any) -> dict[str, str] | None:
    return {"label": label, "value": _text(value)} if _present(value) else None


def _fields(*pairs: tuple[str, Any]) -> list[dict[str, str]]:
    return [item for label, value in pairs if (item := _field(label, value))]


def _native(native: dict[str, Any], *names: str) -> Any:
    """Match source field spellings without discarding explicit false/zero."""
    for name in names:
        if name in native and _present(native[name]):
            return native[name]
    lowercase = {str(k).lower(): k for k in native}
    for name in names:
        key = lowercase.get(name.lower())
        if key is not None and _present(native[key]):
            return native[key]
    return None


def _first(*values: Any) -> Any:
    return next((value for value in values if _present(value)), None)


def _raw_entries(data: dict[str, Any]) -> list[dict[str, Any]]:
    rows = []
    for key, value in sorted(data.items(), key=lambda item: str(item[0]).casefold()):
        empty = not _present(value)
        rows.append({
            "label": str(key),
            "value": _text(value) if not empty else "—",
            "empty": empty,
            "structured": isinstance(value, (dict, list)),
        })
    return rows


def build_job_detail_view(job: SnapshotJob, scheduler: SchedulerType, environment_id: str) -> dict[str, Any]:
    """Produce an ordered, deduplicated summary plus untouched raw source sections."""
    ps = scheduler == SchedulerType.PROCESS_SCHEDULER
    native = job.process_scheduler.model_dump(by_alias=True, mode="json") if ps and job.process_scheduler else {}
    jil = job.autosys.jil
    run = job.autosys.run
    attrs = job.attributes
    command = _first(
        _native(native, "Command", "CommandLine", "ExecutableCommand"),
        jil.command,
    ) if ps else _first(run.resolved_command, jil.command)
    output = _first(_native(native, "StdOutputFile", "StdOutFile", "StandardOutputFile"), jil.std_out_file)
    error = _first(_native(native, "StdErrorFile", "StdErrFile", "StandardErrorFile"), jil.std_err_file)
    machine = _first(_native(native, "Machine"), job.machine)
    job_type = _first(_native(native, "JobType", "Kind"), jil.job_type, attrs.get("native_job_type"), attrs.get("native_kind"))
    parent = _first(job.box_name, _native(native, "Box"))
    duration = job.exec_time
    if duration is None and job.duration_sec is not None:
        from app.time_utils import format_duration_hms
        duration = format_duration_hms(job.duration_sec)

    execution = _fields(
        ("Start", job.actual_start),
        ("End", job.actual_end),
        ("Duration", duration),
        ("Machine", machine),
        ("Exit code", job.exit_code),
    )
    # Only display dependency evidence that the captured snapshot actually includes.
    if ps:
        condition = _first(_native(native, "NativeConditionExpression", "ConditionExpression"), jil.condition)
        deps = _fields(
            ("Condition", condition),
            ("Depends on", ", ".join(str(item) for item in attrs["ps_condition_predecessors"])
             if isinstance(attrs.get("ps_condition_predecessors"), list) else attrs.get("ps_condition_predecessors")),
            ("Evidence", attrs.get("ps_condition_status")),
            ("Unverified reason", attrs.get("ps_condition_reason") if attrs.get("ps_condition_status") == "unverified" else None),
            ("Missing predecessors", attrs.get("ps_condition_missing_predecessors")),
        )
        schedule = _fields(
            ("Days / schedule", _first(_native(native, "Schedule"), jil.days_of_week)),
            ("Start at", _first(_native(native, "StartAtTime"), jil.start_times)),
            ("Force start at", _native(native, "StartAtTimeForce")),
            ("Scheduled start", job.scheduled_start),
        )
    else:
        deps = _fields(
            ("Condition", jil.condition),
            ("Box success rule", jil.box_success),
            ("Box failure rule", jil.box_failure),
        )
        schedule = _fields(
            ("Days of week", jil.days_of_week),
            ("Start times", jil.start_times),
            ("Start minutes", jil.start_mins),
            ("Date conditions", jil.date_conditions),
            ("Run calendar", jil.run_calendar),
            ("Exclude calendar", jil.exclude_calendar),
            ("Run window", jil.run_window),
            ("Must start", jil.must_start_times),
            ("Must complete", jil.must_complete_times),
            ("Timezone", jil.timezone),
            ("Scheduled start", job.scheduled_start),
        )

    technical = _fields(
        ("Context", _first(_native(native, "Context"), attrs.get("topology"))),
        ("Capture", attrs.get("job_detail_capture") if ps else None),
        ("Capture issue", attrs.get("job_detail_error") if ps else None),
        ("Native ID", job.scheduler_native_id),
        ("Logical ID", job.logical_id),
        ("Job UID", job.job_uid),
        ("Parent UID", job.parent_uid),
        ("Path", "/".join(job.path_labels) if job.path_labels else None),
        ("Owner", _first(_native(native, "Owner"), jil.owner)),
        ("Resource", _first(_native(native, "ResourceName"), jil.resources)),
        ("Priority", jil.priority),
        ("Profile", jil.profile),
        ("Application", jil.application),
        ("Mock migration issue", attrs.get("mock_migration_issue")),
    )

    if ps:
        raw_sections = [
            {"name": "Process Scheduler source detail", "rows": _raw_entries(native)},
            {"name": "Adapter attributes", "rows": _raw_entries(attrs)},
        ]
    else:
        raw_sections = [
            {"name": "JIL definition", "rows": _raw_entries(jil.model_dump(mode="json"))},
            {"name": "Run instance", "rows": _raw_entries(run.model_dump(mode="json"))},
            {"name": "Adapter attributes", "rows": _raw_entries(attrs)},
        ]
    return {
        "scheduler_name": "Process Scheduler" if ps else "AutoSys",
        "environment_id": environment_id,
        "job_type": _text(job_type) if _present(job_type) else None,
        "parent": _text(parent) if _present(parent) else None,
        "description": _first(_native(native, "Description"), jil.description),
        "capture_unavailable": ps and attrs.get("job_detail_capture") == "unavailable",
        "execution": execution,
        "command": _text(command) if _present(command) else None,
        "output": _text(output) if _present(output) else None,
        "error": _text(error) if _present(error) else None,
        "dependencies": deps,
        "schedule": schedule,
        "technical": technical,
        "raw_sections": raw_sections,
    }
