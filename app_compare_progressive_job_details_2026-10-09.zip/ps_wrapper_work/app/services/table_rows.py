"""Comparison table row materialization and paging."""

from __future__ import annotations

from dataclasses import dataclass

from app.models import ComparisonResult, JobPair, ParameterMismatch, SnapshotJob


@dataclass(frozen=True)
class TableRow:
    kind: str  # pair | left_only | right_only
    logical_id: str
    pair: JobPair | None = None
    job: SnapshotJob | None = None

    @property
    def is_mismatch_row(self) -> bool:
        if self.kind == "left_only" or self.kind == "right_only":
            return True
        if self.pair and self.pair.left and self.pair.right:
            return self.pair.left.status != self.pair.right.status
        return False


def parameter_mismatches_by_logical_id(
    result: ComparisonResult,
) -> dict[str, list[ParameterMismatch]]:
    grouped: dict[str, list[ParameterMismatch]] = {}
    for mismatch in result.parameter_mismatches:
        if mismatch.logical_id:
            grouped.setdefault(mismatch.logical_id, []).append(mismatch)
    return grouped


def parameter_mismatches_for_pair(
    result: ComparisonResult, logical_id: str | None
) -> list[ParameterMismatch]:
    if not logical_id:
        return []
    return [
        mismatch
        for mismatch in result.parameter_mismatches
        if mismatch.logical_id == logical_id
    ]


def iter_table_rows(
    result: ComparisonResult,
    *,
    filter_name: str = "all",
    q_prefix: str = "",
) -> list[TableRow]:
    prefix = q_prefix.strip().lower()
    rows: list[TableRow] = []
    parameter_mismatch_ids = {
        mismatch.logical_id
        for mismatch in result.parameter_mismatches
        if mismatch.logical_id
    }
    execution_time_mismatch_ids = {
        pair.logical_id
        for pair in result.execution_time_deltas
        if pair.logical_id
    }

    def name_matches(job: SnapshotJob | None) -> bool:
        if not prefix or not job:
            return True
        return job.scheduler_job_name.lower().startswith(prefix) or (
            (job.logical_id or "").lower().startswith(prefix)
        )

    if filter_name in ("all", "matched", "mismatches", "status_delta"):
        for pair in result.pairs:
            if filter_name == "status_delta" and (
                not pair.left or not pair.right or pair.left.status == pair.right.status
            ):
                continue
            if filter_name == "mismatches" and pair.left and pair.right:
                has_param_delta = pair.logical_id in parameter_mismatch_ids
                has_exec_delta = pair.logical_id in execution_time_mismatch_ids
                if (
                    pair.left.status == pair.right.status
                    and not has_param_delta
                    and not has_exec_delta
                ):
                    continue
            if not name_matches(pair.left) and not name_matches(pair.right):
                continue
            rows.append(
                TableRow(
                    kind="pair",
                    logical_id=pair.logical_id or "",
                    pair=pair,
                )
            )

    if filter_name in ("all", "mismatches", "left_only"):
        for job in result.left_only:
            if not name_matches(job):
                continue
            rows.append(
                TableRow(
                    kind="left_only",
                    logical_id=job.logical_id or job.scheduler_job_name,
                    job=job,
                )
            )

    if filter_name in ("all", "mismatches", "right_only"):
        for job in result.right_only:
            if not name_matches(job):
                continue
            rows.append(
                TableRow(
                    kind="right_only",
                    logical_id=job.logical_id or job.scheduler_job_name,
                    job=job,
                )
            )

    return rows


def page_table_rows(
    rows: list[TableRow],
    *,
    offset: int = 0,
    limit: int | None = None,
) -> tuple[list[TableRow], int]:
    total = len(rows)
    if offset < 0:
        offset = 0
    if limit is None or limit <= 0:
        return rows[offset:], total
    return rows[offset : offset + limit], total


def filter_visible_table_rows(
    rows: list[TableRow],
    result: ComparisonResult,
    *,
    query: str = "",
    categories: frozenset[str] = frozenset(),
) -> list[TableRow]:
    """Apply Compare UI filters to the entire result *before* pagination.

    Category selection uses OR semantics, matching the previous client filters.
    Search is a case-insensitive substring of the logical ID and either job name.
    """
    needle = query.strip().lower()
    if not needle and not categories:
        return rows

    parameter_ids = {m.logical_id for m in result.parameter_mismatches if m.logical_id}
    execution_ids = {p.logical_id for p in result.execution_time_deltas if p.logical_id}
    visible = []
    for row in rows:
        if row.kind == "pair" and row.pair:
            pair = row.pair
            names = (
                pair.logical_id or "",
                pair.left.scheduler_job_name if pair.left else "",
                pair.right.scheduler_job_name if pair.right else "",
            )
            tags = {"matched"}
            if pair.left and pair.right and pair.left.status != pair.right.status:
                tags.add("status_delta")
            if pair.logical_id in parameter_ids:
                tags.add("param_delta")
            if pair.logical_id in execution_ids:
                tags.add("exec_time_delta")
        elif row.job:
            names = (row.logical_id, row.job.scheduler_job_name)
            tags = {row.kind}
        else:
            continue

        if needle and not any(needle in name.lower() for name in names):
            continue
        if categories and not categories.intersection(tags):
            continue
        visible.append(row)
    return visible
