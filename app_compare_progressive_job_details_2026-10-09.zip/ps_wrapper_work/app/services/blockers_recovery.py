"""Bounded counterfactual dependency analysis on an immutable Blockers report.

A recovery intervention is an *assumption* that an observed failed/killed/running
job later reaches SUCCESS, never an instruction to change a scheduler. Predicted
success for waiting jobs requires verified dependencies and assumes those jobs
then run and complete successfully; this is *not* a scheduling or SLA forecast.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from itertools import combinations
from typing import Iterable

from app.models import JobStatus
from app.services.blockers import (
    BlockersReport, Condition, Expr, Truth, _predicate,
)

MAX_CANDIDATES = 12
MAX_INTERVENTIONS = 4
MAX_SCENARIOS = 1200
MAX_PLANS = 5
MAX_ANCESTORS = 3000
MAX_SNAPSHOT_JOBS = 12000
_RECOVERABLE = frozenset({JobStatus.FAILURE, JobStatus.KILLED, JobStatus.RUNNING})
_WAITING = frozenset({JobStatus.PENDING, JobStatus.NOT_RUN})


@dataclass(frozen=True)
class WhatIfImpact:
    assumptions: tuple[str, ...]
    target_result: Truth
    directly_ready: tuple[str, ...]
    potentially_reachable: tuple[str, ...]
    critical_reachable: tuple[str, ...]


@dataclass(frozen=True)
class RecoveryPlan:
    assumptions: tuple[str, ...]
    impact: WhatIfImpact


@dataclass
class RecoveryAnalysis:
    target_uid: str
    baseline: Truth
    candidates: tuple[str, ...] = ()
    plans: list[RecoveryPlan] = field(default_factory=list)
    status: str = "insufficient_evidence"
    detail: str = ""
    explored: int = 0
    available_plans: int = 0
    complete: bool = True


class InvalidRecoverySelection(ValueError):
    pass


class _Evaluator:
    """Iterative, cycle-safe evaluation of verified ASTs; no state mutation.

    A verified OR branch may resolve even if a different branch is unknown.
    Successful hypothetical completion of a waiting predecessor is assumed only
    after its own verified start condition evaluates TRUE.
    """

    def __init__(self, report: BlockersReport, assumptions: Iterable[str]):
        self.report = report
        self.assumptions = frozenset(assumptions)
        self.memo: dict[str, Truth] = {}

    def _condition_for(self, uid: str) -> Condition | None:
        job = self.report.jobs[uid]
        if uid in self.report.boxes and job.status == JobStatus.RUNNING:
            box = self.report.boxes[uid]
            if box.supported and box.rule == "box_success":
                return box.condition
            return None
        if job.status in _WAITING:
            return self.report.conditions.get(uid)
        return None

    def _dependencies(self, uid: str) -> set[str]:
        condition = self._condition_for(uid)
        return set(condition.references.values()) if condition and condition.supported else set()

    def _evaluate_expression(self, ast: Expr, condition: Condition) -> Truth:
        # Iterative postorder avoids stack overflow on deep or nested graphs.
        results: dict[int, Truth] = {}
        stack = [(ast, False)]
        while stack:
            node, done = stack.pop()
            if not done:
                stack.append((node, True))
                stack.extend((child, False) for child in node.children)
                continue
            if not node.children:
                referenced = condition.references.get(node.value)
                if referenced is None:
                    results[id(node)] = Truth.UNKNOWN
                    continue
                job = self.report.jobs[referenced]
                if referenced in self.assumptions:
                    status = JobStatus.SUCCESS
                    results[id(node)] = _predicate(node.op, status)
                elif job.status in _WAITING or (job.status == JobStatus.RUNNING and job.job_type in ("box", "b")):
                    future = self.memo.get(referenced, Truth.UNKNOWN)
                    if future is Truth.TRUE:
                        results[id(node)] = _predicate(node.op, JobStatus.SUCCESS)
                    elif future is Truth.FALSE:
                        results[id(node)] = _predicate(node.op, job.status)
                    else:
                        results[id(node)] = Truth.UNKNOWN
                else:
                    results[id(node)] = _predicate(node.op, job.status)
                continue
            children = [results[id(child)] for child in node.children]
            if node.op == "and":
                results[id(node)] = (Truth.FALSE if Truth.FALSE in children else
                                     Truth.UNKNOWN if Truth.UNKNOWN in children else Truth.TRUE)
            elif node.op == "or":
                results[id(node)] = (Truth.TRUE if Truth.TRUE in children else
                                     Truth.UNKNOWN if Truth.UNKNOWN in children else Truth.FALSE)
            else:
                results[id(node)] = Truth.UNKNOWN
        return results[id(ast)]

    def evaluate(self, uid: str) -> Truth:
        if uid not in self.report.jobs:
            return Truth.UNKNOWN
        if uid in self.memo:
            return self.memo[uid]
        # Explicit DFS: cycle members remain UNKNOWN. We never assume their
        # states just because they are located before the target in a graph.
        active: set[str] = set()
        stack: list[tuple[str, bool]] = [(uid, False)]
        while stack:
            current, done = stack.pop()
            if current in self.memo:
                continue
            job = self.report.jobs[current]
            if current in self.assumptions:
                self.memo[current] = Truth.TRUE
                continue
            if job.status == JobStatus.SUCCESS:
                self.memo[current] = Truth.TRUE
                continue
            cond = self._condition_for(current)
            if cond is None or not cond.supported or cond.ast is None:
                self.memo[current] = (Truth.FALSE if job.status in _RECOVERABLE else Truth.UNKNOWN)
                continue
            if done:
                active.discard(current)
                self.memo[current] = self._evaluate_expression(cond.ast, cond)
                continue
            if current in active:
                self.memo[current] = Truth.UNKNOWN
                continue
            active.add(current)
            stack.append((current, True))
            for predecessor in self._dependencies(current):
                if predecessor in self.memo:
                    continue
                if predecessor not in active:
                    stack.append((predecessor, False))
                # A cyclic reference stays unresolved in the current proof,
                # without poisoning the ancestor's memo: its independent OR
                # branch can still prove TRUE.
        return self.memo.get(uid, Truth.UNKNOWN)

    def immediately_ready(self, uid: str) -> Truth:
        """Check only observed direct predecessor states + assumed completions."""
        job = self.report.jobs[uid]
        if job.status not in _WAITING:
            return Truth.FALSE
        condition = self.report.conditions.get(uid)
        if not condition or not condition.supported or condition.ast is None:
            return Truth.UNKNOWN
        # Leaf evaluation uses *observed* scheduler states, not recursive
        # predicted completions of intermediate waiting jobs.
        def walk(node: Expr) -> Truth:
            if not node.children:
                source = condition.references.get(node.value)
                if source is None:
                    return Truth.UNKNOWN
                if source in self.assumptions:
                    return _predicate(node.op, JobStatus.SUCCESS)
                return _predicate(node.op, self.report.jobs[source].status)
            values = [walk(child) for child in node.children]
            if node.op == "and":
                return (Truth.FALSE if Truth.FALSE in values else
                        Truth.UNKNOWN if Truth.UNKNOWN in values else Truth.TRUE)
            return (Truth.TRUE if Truth.TRUE in values else
                    Truth.UNKNOWN if Truth.UNKNOWN in values else Truth.FALSE)
        return walk(condition.ast)


def _candidate_ancestors(report: BlockersReport, target_uid: str) -> tuple[tuple[str, ...], str]:
    if target_uid not in report.jobs:
        raise InvalidRecoverySelection("Unknown target")
    visited: set[str] = set()
    pending = [target_uid]
    candidates: set[str] = set()
    while pending:
        uid = pending.pop()
        if uid in visited:
            continue
        visited.add(uid)
        if len(visited) > MAX_ANCESTORS:
            return (), "Dependency ancestry exceeds the planner limit. Select a narrower target."
        job = report.jobs[uid]
        if uid != target_uid and job.status in _RECOVERABLE:
            # A running AutoSys box with a verified explicit completion rule
            # is modeled via its children, rather than proposed as a magic fix.
            box = report.boxes.get(uid)
            if not (box and box.rule == "box_success" and box.supported):
                candidates.add(uid)
                continue
        cond = report.conditions.get(uid)
        if job.status == JobStatus.RUNNING and uid in report.boxes:
            box = report.boxes[uid]
            if box.rule == "box_success" and box.supported:
                cond = box.condition
        if cond and cond.supported:
            pending.extend(cond.references.values())
    if len(candidates) > MAX_CANDIDATES:
        return tuple(sorted(candidates)), (f"Found {len(candidates)} possible interventions; "
                                           f"limit is {MAX_CANDIDATES}. Narrow the target.")
    return tuple(sorted(candidates, key=lambda uid: report.jobs[uid].scheduler_job_name.casefold())), ""


def simulate_what_if(report: BlockersReport, target_uid: str, assumed_uids: Iterable[str]) -> WhatIfImpact:
    candidates, error = _candidate_ancestors(report, target_uid)
    if error:
        raise InvalidRecoverySelection(error)
    selected = tuple(dict.fromkeys(assumed_uids))
    if len(selected) > MAX_INTERVENTIONS or not set(selected).issubset(candidates):
        raise InvalidRecoverySelection("Interventions must be eligible upstream jobs within the plan limit")
    if len(report.jobs) > MAX_SNAPSHOT_JOBS:
        raise InvalidRecoverySelection("Snapshot exceeds bounded what-if analysis size")
    baseline = _Evaluator(report, ())
    simulated = _Evaluator(report, selected)
    affected = []
    directly_ready = []
    for uid, job in report.jobs.items():
        if job.status not in _WAITING:
            continue
        if (baseline.evaluate(uid) is not Truth.TRUE and simulated.evaluate(uid) is Truth.TRUE):
            affected.append(uid)
        if (baseline.immediately_ready(uid) is not Truth.TRUE and
                simulated.immediately_ready(uid) is Truth.TRUE):
            directly_ready.append(uid)
    return WhatIfImpact(
        assumptions=selected,
        target_result=simulated.evaluate(target_uid),
        directly_ready=tuple(sorted(directly_ready)),
        potentially_reachable=tuple(sorted(affected)),
        critical_reachable=tuple(sorted(set(affected) & report.critical_uids)),
    )


def plan_recovery(report: BlockersReport, target_uid: str) -> RecoveryAnalysis:
    if target_uid not in report.jobs or report.jobs[target_uid].status not in _WAITING:
        raise InvalidRecoverySelection("Select a waiting or not-run target")
    baseline = _Evaluator(report, ()).evaluate(target_uid)
    result = RecoveryAnalysis(target_uid=target_uid, baseline=baseline)
    if report.quality.level == "unavailable":
        result.status = "insufficient_evidence"
        result.complete = False
        result.detail = "Snapshot does not provide validated dependency coverage."
        return result
    if len(report.jobs) > MAX_SNAPSHOT_JOBS:
        result.status = "limit_reached"
        result.detail = f"Snapshot exceeds {MAX_SNAPSHOT_JOBS} jobs; bounded analysis is unavailable."
        return result
    if baseline is Truth.TRUE:
        result.status = "already_ready"
        result.detail = "Recorded dependency conditions are already satisfied; another scheduler gate may apply."
        return result
    candidates, error = _candidate_ancestors(report, target_uid)
    result.candidates = candidates
    if error:
        result.status = "limit_reached"
        result.complete = False
        result.detail = error
        return result
    minimum_sets: list[frozenset[str]] = []
    truncated = False
    for cardinality in range(1, min(MAX_INTERVENTIONS, len(candidates)) + 1):
        for group in combinations(candidates, cardinality):
            if any(found.issubset(group) for found in minimum_sets):
                continue
            if result.explored >= MAX_SCENARIOS:
                truncated = True
                break
            result.explored += 1
            if _Evaluator(report, group).evaluate(target_uid) is Truth.TRUE:
                minimum_sets.append(frozenset(group))
        if truncated:
            break
    ranked = [RecoveryPlan(
        assumptions=tuple(uid for uid in candidates if uid in group),
        impact=simulate_what_if(report, target_uid, (uid for uid in candidates if uid in group)),
    ) for group in minimum_sets]
    # Rank by impact on user-marked critical targets, then total unique
    # downstream reach, then number of intervention assumptions. Ranking is
    # deterministic, not an estimate of recovery time or likelihood.
    ranked.sort(key=lambda plan: (
        -len(plan.impact.critical_reachable),
        -len(plan.impact.potentially_reachable),
        len(plan.assumptions),
        plan.assumptions,
    ))
    result.available_plans = len(ranked)
    result.plans = ranked[:MAX_PLANS]
    result.complete = not truncated and len(candidates) <= MAX_INTERVENTIONS and len(ranked) <= MAX_PLANS
    # Even with <=12 candidates, a 4-intervention limit cannot prove global
    # completeness for minimal sets with >4 assumptions.
    if len(candidates) > MAX_INTERVENTIONS:
        result.complete = False
    if result.plans:
        result.status = "plans_found"
        result.detail = ("Minimal-by-inclusion sets within the configured bounds. "
                         "Results are incomplete." if not result.complete else
                         "All inclusion-minimal sets within the searched candidates have been enumerated.")
    else:
        result.status = "insufficient_evidence" if baseline is Truth.UNKNOWN else "no_plan_within_limits"
        result.detail = ("No verified recovery combination within the configured bounds; "
                         "unknown conditions or additional interventions may still be required.")
    return result
