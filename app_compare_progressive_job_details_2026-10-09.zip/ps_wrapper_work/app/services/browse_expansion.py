"""Bounded iterative expansion of a snapshot's structural hierarchy for Browse.

Dependency edges are deliberately excluded: a structural parent is not an
execution prerequisite. The output is flat to avoid recursive HTML templates
on unusually deep topologies.
"""
from __future__ import annotations

from dataclasses import dataclass

from app.models import SnapshotJob, TopologySnapshot
from app.services.topology_index import ensure_topology_indexes

MAX_EXPANDED_ROWS = 10000


@dataclass(frozen=True)
class BrowseExpandedRow:
    job: SnapshotJob
    depth: int
    children_count: int


def expanded_rows(snapshot: TopologySnapshot, *, max_rows: int = MAX_EXPANDED_ROWS) -> tuple[list[BrowseExpandedRow], bool]:
    if max_rows < 1:
        raise ValueError("max_rows must be positive")
    ensure_topology_indexes(snapshot)
    by_uid: dict[str, SnapshotJob] = snapshot.metadata["jobs_by_uid"]
    children: dict[str, list[str]] = snapshot.metadata["children_index"]
    stack: list[tuple[str, int]] = [(node.job.job_uid, 0) for node in reversed(snapshot.roots)]
    visited: set[str] = set()
    rows: list[BrowseExpandedRow] = []
    truncated = False
    while stack:
        uid, depth = stack.pop()
        if uid in visited or uid not in by_uid:
            continue
        if len(rows) >= max_rows:
            truncated = True
            break
        visited.add(uid)
        child_uids = [child for child in children.get(uid, []) if child in by_uid and child not in visited]
        rows.append(BrowseExpandedRow(job=by_uid[uid], depth=depth, children_count=len(child_uids)))
        stack.extend((child, depth + 1) for child in reversed(child_uids))
    # Additional disconnected nodes should remain accessible in search, rather
    # than silently modifying the structural hierarchy here.
    return rows, truncated
