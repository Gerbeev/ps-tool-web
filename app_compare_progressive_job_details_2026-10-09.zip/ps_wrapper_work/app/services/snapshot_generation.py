"""The only application service allowed to read scheduler source systems."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta

from app.adapters.factory import get_adapter
from app.config import endpoint_for_environment, get_environment, scheduler_for_environment
from app.models import AsOf, AsOfKind, ComparisonContext, ContextFilters, SchedulerType
from app.services.comparison import fetch_snapshot
from app.services.snapshot_catalog import SnapshotRecord, snapshot_catalog
from app.services.snapshot_jobs import report_progress
from app.services.runtime_diagnostics import debug_enabled, log_event


class SnapshotGenerationError(RuntimeError):
    pass


def autosys_business_date(today: date | None = None) -> str:
    """Return the AutoSys COB date: local calendar date minus one day."""
    current = today or date.today()
    return (current - timedelta(days=1)).isoformat()


@dataclass(frozen=True)
class GeneratedSnapshot:
    record: SnapshotRecord


def _require_environment(environment_id: str, scheduler: SchedulerType | None = None):
    environment = get_environment(environment_id)
    if environment is None or not environment.enabled:
        raise SnapshotGenerationError(f"Unknown or disabled environment: {environment_id}")
    configured = scheduler_for_environment(environment_id)
    if scheduler is not None and configured != scheduler:
        raise SnapshotGenerationError(
            f"Environment {environment_id!r} is configured for {configured.value}, not {scheduler.value}"
        )
    return environment, configured


def list_process_scheduler_topologies(environment_id: str) -> list[str]:
    """Read topology names from Process Scheduler through the adapter/bridge boundary."""
    _require_environment(environment_id, SchedulerType.PROCESS_SCHEDULER)
    context = ComparisonContext(
        environment_id=environment_id,
        endpoint_url=endpoint_for_environment(environment_id),
        scheduler=SchedulerType.PROCESS_SCHEDULER,
        as_of=AsOf(kind=AsOfKind.BUSINESS_DATE, value=date.today().isoformat()),
    )
    try:
        roots = get_adapter(SchedulerType.PROCESS_SCHEDULER, environment_id).list_roots(context)
    except Exception as exc:
        raise SnapshotGenerationError(str(exc)) from exc
    # Preserve source ordering while removing accidental duplicates/blank values.
    return list(dict.fromkeys(item.strip() for item in roots if item and item.strip()))


def generate_snapshot(environment_id: str, *, topology_id: str = "", job_limit: int | None = None) -> GeneratedSnapshot:
    """Fetch one source snapshot, validate it, then persist it immutably."""
    _environment, scheduler = _require_environment(environment_id)
    if job_limit is not None:
        if isinstance(job_limit, bool) or not isinstance(job_limit, int) or not 1 <= job_limit <= 10000:
            raise SnapshotGenerationError("Debug job limit must be between 1 and 10000")
        if not debug_enabled():
            raise SnapshotGenerationError("Limited snapshots require Debug Mode enabled in Settings")
    filters = ContextFilters(debug_job_limit=job_limit)

    if scheduler == SchedulerType.AUTOSYS:
        business_date = autosys_business_date()
        if topology_id:
            raise SnapshotGenerationError("AutoSys snapshot generation does not accept a topology")
    else:
        business_date = date.today().isoformat()
        topology_id = topology_id.strip()
        if not topology_id:
            raise SnapshotGenerationError("Select a Process Scheduler topology")
        filters.topology_id = topology_id
        filters.root_box = topology_id

    context = ComparisonContext(
        environment_id=environment_id,
        endpoint_url=endpoint_for_environment(environment_id),
        scheduler=scheduler,
        as_of=AsOf(kind=AsOfKind.BUSINESS_DATE, value=business_date),
        filters=filters,
    )

    report_progress("fetching", "Reading scheduler source")
    try:
        snapshot, _ = fetch_snapshot(context, force_refresh=True)
    except Exception as exc:
        raise SnapshotGenerationError(str(exc)) from exc

    report_progress("validating", "Validating jobs and dependencies", len(snapshot.flat_jobs), len(snapshot.flat_jobs))
    log_event("snapshot_validated", job_count=len(snapshot.flat_jobs))
    report = snapshot.metadata.get("validation_report") or {}
    if report.get("is_valid") is False:
        log_event('snapshot_validation_failed', always=True,
                  failures=int(report.get('error_count', 0)))
        raise SnapshotGenerationError(
            f"Snapshot validation failed ({report.get('error_count', 0)} errors)"
        )

    snapshot.metadata["generated_via"] = "snapshots_tab"
    if job_limit is not None:
        capture = snapshot.metadata.get("debug_sample") or {}
        if not isinstance(capture, dict) or capture.get("requested_limit") != job_limit:
            raise SnapshotGenerationError("Connector did not acknowledge the debug job limit")
        if len(snapshot.flat_jobs) > job_limit:
            raise SnapshotGenerationError("Connector returned more jobs than debug limit")
    report_progress("saving", "Persisting immutable snapshot")
    record = snapshot_catalog.save(snapshot)
    report_progress("indexing", "Finalizing snapshot catalog")
    return GeneratedSnapshot(record=record)
