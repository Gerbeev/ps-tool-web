"""Build bounded, complete-snapshot Browse filter results without scheduler reads."""

from __future__ import annotations

from dataclasses import dataclass

from app.models import JobNode, TopologySnapshot
from app.services.topology_index import ensure_topology_indexes


@dataclass(frozen=True)
class BrowseFilteredTree:
    roots: list[JobNode]
    match_count: int
    shown_count: int


def filter_browse_tree(
    snapshot: TopologySnapshot,
    *,
    query: str = "",
    statuses: frozenset[str] = frozenset(),
    limit: int = 200,
) -> BrowseFilteredTree:
    """Include name/status matches and every ancestor, in source-tree order.

    Searches the whole snapshot, not just nodes currently loaded in the DOM.
    Limits *matches* before constructing HTML; shared ancestors appear only once.
    """
    if limit < 1:
        raise ValueError("limit must be positive")

    ensure_topology_indexes(snapshot)
    by_uid = snapshot.metadata["jobs_by_uid"]
    children: dict[str, list[str]] = snapshot.metadata["children_index"]
    parents = {child: parent for parent, child_uids in children.items() for child in child_uids}
    roots = [root.job.job_uid for root in snapshot.roots]

    # Traverse without recursion to support arbitrarily nested source trees.
    order: list[str] = []
    visited: set[str] = set()
    stack = list(reversed(roots))
    while stack:
        uid = stack.pop()
        if uid in visited or uid not in by_uid:
            continue
        visited.add(uid)
        order.append(uid)
        stack.extend(reversed(children.get(uid, [])))
    # A malformed/incomplete source hierarchy must not make indexed jobs unsearchable.
    order.extend(uid for uid in by_uid if uid not in visited)

    needle = query.strip().casefold()
    matches = [
        uid for uid in order
        if (not needle or needle in by_uid[uid].scheduler_job_name.casefold())
        and (not statuses or by_uid[uid].status.value in statuses)
    ]
    selected = matches[:limit]
    kept: set[str] = set()
    for uid in selected:
        current = uid
        while current in by_uid and current not in kept:
            kept.add(current)
            current = parents.get(current, "")

    filtered_nodes = {uid: JobNode(job=by_uid[uid]) for uid in kept}
    result_roots: list[JobNode] = []
    for uid in order:
        node = filtered_nodes.get(uid)
        if node is None:
            continue
        parent = parents.get(uid)
        if parent in filtered_nodes:
            filtered_nodes[parent].children.append(node)
        else:
            result_roots.append(node)

    return BrowseFilteredTree(
        roots=result_roots,
        match_count=len(matches),
        shown_count=len(selected),
    )
