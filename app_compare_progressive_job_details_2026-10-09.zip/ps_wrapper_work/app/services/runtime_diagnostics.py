"""Bounded, value-safe local diagnostics. Never logs source DTOs or HTTP bodies."""
from __future__ import annotations

import json
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
from threading import RLock
from typing import Any

from app.config import get_settings

_lock = RLock()
_logger = logging.getLogger('ps_tool.runtime')
_logger.setLevel(logging.INFO)
_logger.propagate = False
_INITIALIZED_PATH: Path | None = None


def _config_file() -> Path:
    return get_settings().config_dir / 'runtime_settings.json'


def debug_enabled() -> bool:
    path = _config_file()
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
        if isinstance(data, dict) and isinstance(data.get('debug'), bool):
            return data['debug']
    except (OSError, ValueError):
        pass
    return get_settings().debug


def set_debug_enabled(enabled: bool) -> None:
    target = _config_file()
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_suffix('.json.tmp')
    with _lock:
        temp.write_text(json.dumps({'debug': bool(enabled)}, indent=2) + '\n', encoding='utf-8')
        temp.replace(target)


def _get_logger() -> logging.Logger:
    global _INITIALIZED_PATH
    path = get_settings().log_dir.resolve()
    with _lock:
        if _INITIALIZED_PATH != path:
            for handler in list(_logger.handlers):
                _logger.removeHandler(handler)
                handler.close()
            path.mkdir(parents=True, exist_ok=True)
            handler = RotatingFileHandler(path / 'application.log', maxBytes=5 * 1024 * 1024,
                                          backupCount=5, encoding='utf-8')
            handler.setFormatter(logging.Formatter('%(message)s'))
            _logger.addHandler(handler)
            _INITIALIZED_PATH = path
    return _logger


# Only callers' explicit, type-checked summary fields enter disk logs.
_SAFE_FIELDS = {'run_id', 'scheduler', 'environment_id', 'stage', 'done', 'total',
                'elapsed_sec', 'duration_ms', 'operation', 'return_code',
                'error_type', 'error_code', 'timeout_sec', 'job_count',
                'edge_count', 'failures', 'warnings', 'request_id',
                'module', 'function', 'line'}


def log_event(event: str, *, always: bool = False, **values: Any) -> None:
    if not (always or debug_enabled()):
        return
    allowed: dict[str, Any] = {}
    for k, v in values.items():
        if k in _SAFE_FIELDS and (v is None or isinstance(v, (int, float, bool, str))):
            # Avoid unbounded arbitrary source values and newline injection.
            allowed[k] = v[:64] if isinstance(v, str) else v
    from datetime import datetime, timezone
    entry = {'at': datetime.now(timezone.utc).isoformat(), 'event': event, **allowed}
    severity = logging.ERROR if 'error_type' in allowed else logging.INFO
    _get_logger().log(severity, json.dumps(entry, ensure_ascii=True, separators=(',', ':')))


def log_exception(event: str, exc: Exception, *, operation: str,
                  run_id: str | None = None, request_id: str | None = None,
                  elapsed_sec: int | None = None) -> None:
    """Record the root error type and application call site, never traceback values.

    Chained exception messages may contain source records or credentials. Only
    static code identifiers, a line number and correlation IDs are persisted.
    """
    root: BaseException = exc
    visited: set[int] = set()
    while root.__cause__ is not None and id(root) not in visited:
        visited.add(id(root))
        root = root.__cause__

    def application_frame(error: BaseException) -> tuple[str, str, int] | None:
        selected = None
        tb = error.__traceback__
        while tb is not None:
            candidate = tb.tb_frame.f_globals.get('__name__', '')
            if isinstance(candidate, str) and (candidate == 'app' or candidate.startswith('app.')):
                selected = (candidate, tb.tb_frame.f_code.co_name, tb.tb_lineno)
            tb = tb.tb_next
        return selected

    # Prefer the original failure site, falling back to the application boundary
    # if the underlying exception was raised by a dependency or injected test code.
    module, function, line = (application_frame(root) or application_frame(exc)
                              or ('external', 'unknown', 0))

    log_event(event, always=True, operation=operation, run_id=run_id,
              request_id=request_id, error_type=type(root).__name__,
              module=module, function=function, line=line, elapsed_sec=elapsed_sec)
