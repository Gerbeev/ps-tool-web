"""Local critical-target preferences, stored separately from immutable snapshots."""
from __future__ import annotations

import json
import os
from pathlib import Path
from threading import RLock
from uuid import uuid4

from app.config import get_settings
from app.models import TopologySnapshot

_lock = RLock()


def _path() -> Path:
    return get_settings().data_dir / "blockers_critical_targets.json"


def _key(snapshot: TopologySnapshot) -> str:
    scope = (snapshot.context.filters.topology_id or snapshot.context.filters.root_box or "all")
    return json.dumps([snapshot.context.scheduler.value, snapshot.context.environment_id, scope])


def _read(path: Path) -> dict[str, list[str]]:
    if not path.exists():
        return {}
    raw = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict) or any(not isinstance(v, list) for v in raw.values()):
        raise ValueError("Invalid critical targets configuration")
    return raw


def get_critical_targets(snapshot: TopologySnapshot) -> frozenset[str]:
    with _lock:
        values = _read(_path()).get(_key(snapshot), [])
    return frozenset(str(value) for value in values if isinstance(value, str))


def set_critical_target(snapshot: TopologySnapshot, uid: str, enabled: bool) -> frozenset[str]:
    job = next((job for job in snapshot.flat_jobs if job.job_uid == uid), None)
    if job is None:
        raise ValueError("Selected job does not exist in snapshot")
    if sum(entry.scheduler_job_name == job.scheduler_job_name for entry in snapshot.flat_jobs) != 1:
        raise ValueError("Target job name is ambiguous in this snapshot")
    with _lock:
        path = _path()
        data = _read(path)
        values = {name for name in data.get(_key(snapshot), []) if isinstance(name, str)}
        if enabled:
            values.add(job.scheduler_job_name)
        else:
            values.discard(job.scheduler_job_name)
        data[_key(snapshot)] = sorted(values)
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(path.name + "." + uuid4().hex + ".tmp")
        try:
            with temporary.open("w", encoding="utf-8") as stream:
                json.dump(data, stream, ensure_ascii=False, indent=2, sort_keys=True)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
        finally:
            temporary.unlink(missing_ok=True)
    return frozenset(values)
