"""FastAPI application entrypoint."""

from __future__ import annotations

from pathlib import Path
from uuid import uuid4

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from app.routes import blockers, browse, compare, export, search, settings, snapshots
from app.services.runtime_diagnostics import log_exception

app = FastAPI(title="ps-tool-web", description="AutoSys vs Process Scheduler comparison UI")

static_dir = Path(__file__).resolve().parent / "static"
app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

app.include_router(snapshots.router)
app.include_router(browse.router)
app.include_router(blockers.router)
app.include_router(compare.router)
app.include_router(search.router)
app.include_router(export.router)
app.include_router(settings.router)


@app.get("/")
async def root():
    return RedirectResponse(url="/snapshots", status_code=302)


@app.get("/favicon.ico", include_in_schema=False)
async def favicon():
    return FileResponse(static_dir / "favicon.ico", media_type="image/x-icon")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.exception_handler(Exception)
async def unhandled_application_error(request: Request, exc: Exception):
    """Keep raw exception details out of API responses and diagnostic files."""
    request_id = uuid4().hex[:12]
    log_exception('application_request_failed', exc, operation='api_request',
                  request_id=request_id)
    message = f'Unexpected application error. Check logs/application.log (Request ID: {request_id}).'
    if request.url.path.startswith('/api/') and request.headers.get('HX-Request') == 'true':
        # HTMX fragments must remain HTML; do not inject raw exception text.
        return HTMLResponse(f'<p>Unexpected application error. Request ID: {request_id}.</p>',
                            status_code=500)
    if request.url.path.startswith('/api/'):
        return JSONResponse({'detail': message, 'request_id': request_id}, status_code=500)
    return HTMLResponse(f'<h1>Application error</h1><p>Request ID: {request_id}</p>',
                        status_code=500)
