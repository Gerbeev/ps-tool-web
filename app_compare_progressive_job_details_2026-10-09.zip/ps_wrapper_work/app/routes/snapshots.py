"""Snapshot generation and catalog UI.

This router is the only web surface that may call scheduler adapters/bridge operations.
Browse and Compare consume the durable snapshot catalog only.
"""

from __future__ import annotations

from dataclasses import dataclass

from fastapi import APIRouter, Form, Query, Request, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates

from app.config import load_environments, scheduler_for_environment
from app.models import SchedulerType
from app.search.sqlite_fts import search_index
from app.services.snapshot_catalog import SnapshotCatalogError, snapshot_catalog
from app.services.snapshot_jobs import snapshot_jobs
from app.services.runtime_diagnostics import debug_enabled, log_exception
from app.services.snapshot_generation import (
    SnapshotGenerationError,
    autosys_business_date,
    list_process_scheduler_topologies,
)

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")


@dataclass(frozen=True)
class SnapshotEnvironmentOption:
    id: str
    label: str


def _env_options() -> list[SnapshotEnvironmentOption]:
    options: list[SnapshotEnvironmentOption] = []
    for env in load_environments():
        scheduler = scheduler_for_environment(env.id)
        suffix = "PS" if scheduler == SchedulerType.PROCESS_SCHEDULER else "AutoSys"
        options.append(SnapshotEnvironmentOption(id=env.id, label=f"{env.environment}-{suffix}"))
    return options


def _source_form_context(environment_id: str, *, load_topologies: bool) -> dict:
    scheduler = scheduler_for_environment(environment_id)
    topologies: list[str] = []
    topology_error = ""
    if scheduler == SchedulerType.PROCESS_SCHEDULER and load_topologies:
        try:
            topologies = list_process_scheduler_topologies(environment_id)
        except SnapshotGenerationError as exc:
            topology_error = str(exc)
    return {
        "environment_id": environment_id,
        "scheduler": scheduler.value,
        "autosys_business_date": autosys_business_date(),
        "topologies": topologies,
        "topology_error": topology_error,
        "debug_enabled": debug_enabled(),
    }


def _catalog_context(**extra: object) -> dict:
    return {
        "snapshots": snapshot_catalog.list(),
        "catalog_health": snapshot_catalog.health(),
        **extra,
    }


@router.get("/snapshots", response_class=HTMLResponse)
async def snapshots_page(request: Request):
    environments = _env_options()
    default_env = environments[0].id if environments else ""
    context = _source_form_context(default_env, load_topologies=True) if default_env else {
        "environment_id": "",
        "scheduler": "",
        "autosys_business_date": autosys_business_date(),
        "topologies": [],
        "topology_error": "",
        "debug_enabled": debug_enabled(),
    }
    return templates.TemplateResponse(
        request,
        "snapshots.html",
        {
            "environments": environments,
            **context,
            **_catalog_context(),
        },
    )


@router.get("/api/snapshots/source-form", response_class=HTMLResponse)
async def snapshot_source_form(
    request: Request,
    environment_id: str = Query(...),
):
    context = _source_form_context(environment_id, load_topologies=True)
    return templates.TemplateResponse(
        request,
        "partials/snapshot_source_fields.html",
        context,
    )


@router.post('/api/snapshots/generate')
@router.post('/api/snapshots/start')
async def snapshot_start(environment_id: str = Form(...), topology_id: str = Form(''),
                         job_limit: str = Form('full')):
    """Both the current and legacy entrypoints use the same background worker."""
    # Fail fast for invalid environments before allocating background work.
    from app.services.snapshot_generation import _require_environment
    try:
        _require_environment(environment_id)
    except SnapshotGenerationError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    value = job_limit.strip().lower()
    if value in ("", "full", "0"):
        limit = None
    elif value in ('50', '100', '500', '5000'):
        limit = int(value)
    else:
        raise HTTPException(status_code=400, detail="Job limit must be Full, 50, 100, 500, or 5000")
    if limit is not None and not debug_enabled():
        raise HTTPException(status_code=400, detail="Enable Debug Mode in Settings to limit snapshot jobs")
    try:
        snapshot_catalog.assert_writable()
    except SnapshotCatalogError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    run_id, created = (snapshot_jobs.start(environment_id, topology_id) if limit is None else
                       snapshot_jobs.start(environment_id, topology_id, job_limit=limit))
    if not created:
        return JSONResponse(status_code=409, content={
            'error': 'Another snapshot is being generated', 'run_id': run_id,
        })
    return JSONResponse(status_code=202, content={'run_id': run_id})


@router.get('/api/snapshots/current')
async def current_snapshot_job():
    return snapshot_jobs.current() or {'state': 'idle'}


@router.get('/api/snapshots/progress/{run_id}')
async def snapshot_progress(run_id: str):
    status = snapshot_jobs.status(run_id)
    if status is None:
        raise HTTPException(status_code=404, detail='Unknown snapshot run')
    return status


@router.get('/api/snapshots/catalog', response_class=HTMLResponse)
async def snapshot_catalog_fragment(request: Request):
    return templates.TemplateResponse(request, 'partials/snapshot_catalog.html', {
        **_catalog_context(),
    })


@router.post('/api/snapshots/restore-catalog', response_class=HTMLResponse)
def snapshot_restore_catalog(request: Request):
    try:
        restored_count = snapshot_catalog.restore_index()
        return templates.TemplateResponse(request, 'partials/snapshot_catalog.html',
                                          _catalog_context(restored_count=restored_count))
    except (SnapshotCatalogError, OSError) as exc:
        log_exception('snapshot_catalog_restore_failed', exc, operation='catalog_restore')
        message = (str(exc) if isinstance(exc, SnapshotCatalogError) else
                   'Could not restore catalog. See logs/application.log.')
        return templates.TemplateResponse(request, 'partials/snapshot_catalog.html',
                                          _catalog_context(catalog_error=message))


@router.post("/api/snapshots/delete", response_class=HTMLResponse)
async def snapshot_delete(
    request: Request,
    snapshot_id: str = Form(...),
):
    try:
        deleted = snapshot_catalog.delete(snapshot_id)
    except (OSError, ValueError, SnapshotCatalogError) as exc:
        log_exception('snapshot_catalog_delete_failed', exc, operation='catalog_delete')
        message = (str(exc) if isinstance(exc, SnapshotCatalogError) else
                   'Could not delete snapshot. See logs/application.log.')
        return templates.TemplateResponse(
            request,
            "partials/snapshot_catalog.html",
            _catalog_context(catalog_error=message, deleted=None),
        )

    if deleted is not None:
        search_index.delete_snapshot(deleted.snapshot_id)

    return templates.TemplateResponse(
        request,
        "partials/snapshot_catalog.html",
        _catalog_context(catalog_error="" if deleted else "Snapshot was not found.",
                         deleted=deleted),
    )
