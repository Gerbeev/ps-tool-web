"""Search API and HTMX partial."""

from __future__ import annotations

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates

from app.search.sqlite_fts import search_index
from app.session_store import session_store

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")


def _snapshot_sides_for_session(session_id: str, side: str | None) -> dict[str, str]:
    """Resolve side labels from the active view, not shared search-index rows."""
    if side not in (None, "left", "right"):
        return {}
    compare = session_store.get(session_id)
    if compare:
        sides: dict[str, str] = {}
        if side in (None, "left"):
            sides[compare.left_snapshot.snapshot_id] = "left"
        if side in (None, "right"):
            # If a snapshot is on both sides, show it once in unfiltered search.
            snapshot_id = compare.right_snapshot.snapshot_id
            if side == "right" or snapshot_id not in sides:
                sides[snapshot_id] = "right"
        return sides
    browse = session_store.get_browse(session_id)
    if browse and side in (None, "left"):
        return {browse.snapshot.snapshot_id: "left"}
    return {}


@router.get("/api/search")
def search_jobs(
    request: Request,
    q: str = "",
    limit: int = 50,
    format: str = "html",
    session_id: str | None = None,
    side: str | None = None,
):
    if not session_id:
        hits = []
    else:
        snapshot_sides = _snapshot_sides_for_session(session_id, side)
        if not snapshot_sides:
            hits = []
        else:
            hits = search_index.search(
                q,
                limit=limit,
                snapshot_ids=list(snapshot_sides),
            )
            for hit in hits:
                hit.side = snapshot_sides[hit.snapshot_id]
    if format == "json":
        return JSONResponse([h.model_dump() for h in hits])
    return templates.TemplateResponse(
        request,
        "partials/search_results.html",
        {"hits": hits, "query": q},
    )
