"""Runtime duration helpers shared by models, UI, and exports."""

from __future__ import annotations

from datetime import datetime


def execution_time_seconds(start: datetime | None, end: datetime | None) -> float | None:
    """Return execution duration derived from actual timestamps, or None when incomplete/invalid."""
    if start is None or end is None:
        return None
    seconds = timestamp_difference_seconds(end, start)
    if seconds is None or seconds < 0:
        return None
    return seconds


def timestamp_difference_seconds(first: datetime, second: datetime) -> float | None:
    """Compute a difference only when both datetimes have compatible timezone information.

    Assuming a timezone for a naive scheduler timestamp would invent an offset and
    could turn a valid batch run into a false timing mismatch.
    """
    first_aware = first.utcoffset() is not None
    second_aware = second.utcoffset() is not None
    if first_aware != second_aware:
        return None
    return (first - second).total_seconds()


def format_duration_hms(seconds: float | int | None, *, signed: bool = False) -> str:
    """Format a duration as HH:MM:SS without wrapping hours at 24."""
    if seconds is None:
        return ""
    value = int(round(float(seconds)))
    sign = ""
    if value < 0:
        sign = "-"
        value = abs(value)
    elif signed and value > 0:
        sign = "+"

    hours, remainder = divmod(value, 3600)
    minutes, secs = divmod(remainder, 60)
    return f"{sign}{hours:02d}:{minutes:02d}:{secs:02d}"
