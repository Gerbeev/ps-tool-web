/* Browse detail actions survive HTMX swaps of selected jobs. */
(function () {
  'use strict';
  if (window.__browseJobDetailsBound) return;
  window.__browseJobDetailsBound = true;
  var storageKey = 'ps-browse-detail-preferences-v1';
  var defaults = { schedule: false, technical: false, raw: false, showEmpty: false };

  function readPreferences() {
    try {
      var saved = JSON.parse(sessionStorage.getItem(storageKey) || '{}');
      return Object.assign({}, defaults, saved && typeof saved === 'object' ? saved : {});
    } catch (_) { return Object.assign({}, defaults); }
  }
  function savePreferences(value) {
    try { sessionStorage.setItem(storageKey, JSON.stringify(value)); } catch (_) { /* Optional preference storage. */ }
  }
  function initialise(root) {
    if (!root || root.getAttribute('data-detail-ready') === 'true') return;
    root.setAttribute('data-detail-ready', 'true');
    var preferences = readPreferences();
    root.querySelectorAll('[data-detail-disclosure]').forEach(function (details) {
      details.open = preferences[details.getAttribute('data-detail-disclosure')] === true;
    });
    var empty = root.querySelector('[data-show-empty]');
    if (empty) {
      empty.checked = preferences.showEmpty === true;
      toggleEmpty(root, empty.checked);
    }
  }
  function toggleEmpty(root, visible) {
    root.querySelectorAll('[data-empty-field]').forEach(function (row) {
      row.hidden = !visible;
    });
  }
  // HTMX events are emitted after new HTML has been swapped into the panel.
  document.addEventListener('htmx:afterSwap', function (event) {
    var target = event.detail && event.detail.target;
    if (target && target.id === 'job-detail-panel') initialise(target.querySelector('[data-job-detail]'));
  });
  document.addEventListener('toggle', function (event) {
    var node = event.target;
    if (!node.matches || !node.matches('[data-detail-disclosure]') || !node.closest('[data-job-detail]')) return;
    var preferences = readPreferences();
    preferences[node.getAttribute('data-detail-disclosure')] = node.open;
    savePreferences(preferences);
  }, true);
  document.addEventListener('change', function (event) {
    if (!event.target.matches('[data-show-empty]')) return;
    var root = event.target.closest('[data-job-detail]');
    if (!root) return;
    toggleEmpty(root, event.target.checked);
    var preferences = readPreferences();
    preferences.showEmpty = event.target.checked;
    savePreferences(preferences);
  });
  document.addEventListener('click', function (event) {
    var button = event.target.closest('[data-copy-detail]');
    if (!button) return;
    var field = button.closest('.progressive-detail__copy-field');
    var value = field && field.querySelector('[data-copy-value]');
    if (!value) return;
    function feedback(ok) {
      button.textContent = ok ? 'Copied' : 'Copy failed';
      button.setAttribute('aria-label', ok ? 'Copied to clipboard' : 'Unable to copy');
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(value.textContent).then(function () { feedback(true); }, function () { feedback(false); });
    } else {
      // Clipboard API may be unavailable in non-secure corporate localhost contexts.
      var selection = window.getSelection();
      var range = document.createRange();
      range.selectNodeContents(value);
      selection.removeAllRanges();
      selection.addRange(range);
      try { feedback(document.execCommand('copy')); } catch (_) { feedback(false); }
      selection.removeAllRanges();
    }
  });
})();
