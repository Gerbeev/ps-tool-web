/* Remember operator selections across workspace navigation in this browser tab.
   Never persist run/session IDs or whole snapshot/report data. */
(() => {
  'use strict';
  const page = location.pathname.replace(/^\//, '');
  const configs = {
    snapshots: {
      roots: [{id: 'snapshot-environment', dependent: 'snapshot-source-fields', child: 'snapshot-topology'}],
    },
    browse: {
      roots: [{id: 'browse-env', dependent: 'browse-context-fields', child: 'browse-snapshot'}],
      result: 'browse-output',
    },
    blockers: {
      roots: [{id: 'blockers-environment', dependent: 'blockers-snapshot-field', child: 'blockers-snapshot'}],
      result: 'blockers-output',
    },
    compare: {
      roots: [
        {id: 'compare-left-env', dependent: 'compare-left-context-fields', child: 'compare-left-snapshot'},
        {id: 'compare-right-env', dependent: 'compare-right-context-fields', child: 'compare-right-snapshot'},
      ],
      result: 'compare-output',
    },
  };
  const config = configs[page];
  if (!config) return;
  const selectKey = `ps-tool-workspace-selection-v1:${page}`;
  const filterKeyPrefix = `ps-tool-workspace-filters-v1:${page}:`;
  const pending = new Set();
  let restoring = false;

  function read(key) {
    try {
      const value = JSON.parse(sessionStorage.getItem(key) || 'null');
      return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
    } catch (_) { return {}; }
  }
  function write(key, value) {
    try { sessionStorage.setItem(key, JSON.stringify(value)); } catch (_) { /* storage disabled */ }
  }
  function element(id) { return document.getElementById(id); }
  function selectValid(select, value) {
    if (!select || select.disabled || typeof value !== 'string') return false;
    return Array.from(select.options).some((option) => option.value === value && !option.disabled);
  }
  function selectSaved(id, value) {
    const select = element(id);
    if (!selectValid(select, value)) return false;
    select.value = value;
    // Refresh existing side detail/summary bindings; no scheduler request for child selects.
    select.dispatchEvent(new Event('change', {bubbles: true}));
    return true;
  }
  function selectedContext() {
    return config.roots.map((root) => {
      const env = element(root.id);
      const child = element(root.child);
      return `${env ? env.value : ''}/${child && !child.disabled ? child.value : ''}`;
    }).join('|');
  }
  function filterStorageKey() { return filterKeyPrefix + selectedContext(); }
  function saveSelections() {
    if (restoring || pending.size) return;
    const values = read(selectKey);
    config.roots.forEach((root) => {
      const env = element(root.id);
      const child = element(root.child);
      if (env) values[root.id] = env.value;
      if (child && !child.disabled) values[root.child] = child.value;
    });
    if (page === 'snapshots') {
      const limit = element('snapshot-job-limit');
      if (selectValid(limit, limit?.value)) values['snapshot-job-limit'] = limit.value;
    }
    write(selectKey, values);
  }
  function saveFilters() {
    if (restoring || !config.result || !element(config.result)) return;
    const values = {};
    if (page === 'browse') {
      const search = element('browse-filter-search');
      if (!search) return;
      values.query = search.value;
      values.statuses = Array.from(document.querySelectorAll('.browse-status-checkbox:checked')).map((el) => el.value);
    } else if (page === 'compare') {
      const search = element('compare-filter-search');
      if (!search) return;
      values.query = search.value;
      values.limit = element('compare-filter-limit')?.value || '200';
      values.categories = Array.from(document.querySelectorAll('.compare-category-checkbox:checked')).map((el) => el.value);
    } else if (page === 'blockers') {
      const form = element('blockers-filters');
      if (!form) return;
      for (const name of ['view', 'query', 'classification', 'scope']) {
        const control = form.elements.namedItem(name);
        if (control) values[name] = control.value;
      }
      values.critical_only = Boolean(form.elements.namedItem('critical_only')?.checked);
    }
    write(filterStorageKey(), values);
  }
  function restoreFilters() {
    if (!config.result || !element(config.result)) return;
    const values = read(filterStorageKey());
    if (!Object.keys(values).length) return;
    restoring = true;
    let changed = false;
    if (page === 'browse') {
      const input = element('browse-filter-search');
      if (input && typeof values.query === 'string') { input.value = values.query; changed = true; }
      if (Array.isArray(values.statuses)) {
        document.querySelectorAll('.browse-status-checkbox').forEach((el) => {
          el.checked = values.statuses.includes(el.value);
        });
        changed = true;
      }
    } else if (page === 'compare') {
      const input = element('compare-filter-search');
      if (input && typeof values.query === 'string') { input.value = values.query; changed = true; }
      const limit = element('compare-filter-limit');
      if (selectValid(limit, values.limit)) { limit.value = values.limit; changed = true; }
      if (Array.isArray(values.categories)) {
        document.querySelectorAll('.compare-category-checkbox').forEach((el) => {
          el.checked = values.categories.includes(el.value);
        });
        changed = true;
      }
    } else if (page === 'blockers') {
      const form = element('blockers-filters');
      if (form) {
        for (const name of ['view', 'query', 'classification', 'scope']) {
          const control = form.elements.namedItem(name);
          if (!control || typeof values[name] !== 'string') continue;
          if (control.tagName !== 'SELECT' || selectValid(control, values[name])) {
            control.value = values[name];
            changed = true;
          }
        }
        const checkbox = form.elements.namedItem('critical_only');
        if (checkbox && typeof values.critical_only === 'boolean') {
          checkbox.checked = values.critical_only;
          changed = true;
        }
      }
    }
    restoring = false;
    if (!changed) return;
    if (page === 'browse' && window.psBrowseApplyFilters) {
      // One event synchronizes the custom status picker label.
      const checkbox = document.querySelector('.browse-status-checkbox');
      if (checkbox) checkbox.dispatchEvent(new Event('change', {bubbles: true}));
      else window.psBrowseApplyFilters();
    } else if (page === 'compare' && window.psCompareTableApplyFilters) {
      // The comparison table is loaded separately; only re-fetch its rows.
      const checkbox = document.querySelector('.compare-category-checkbox');
      if (checkbox) checkbox.dispatchEvent(new Event('change', {bubbles: true}));
      else window.psCompareTableApplyFilters();
    } else if (page === 'blockers' && window.htmx) {
      const form = element('blockers-filters');
      if (form) window.htmx.trigger(form, 'change');
    }
  }
  function restoreSelections() {
    const saved = read(selectKey);
    if (page === 'snapshots') {
      const limit = element('snapshot-job-limit');
      const savedLimit = saved['snapshot-job-limit'];
      if (selectValid(limit, savedLimit)) limit.value = savedLimit;
    }
    config.roots.forEach((root) => {
      const select = element(root.id);
      const value = saved[root.id];
      if (!selectValid(select, value)) return;
      if (select.value === value) {
        restoring = true;
        selectSaved(root.child, saved[root.child]);
        restoring = false;
        return;
      }
      pending.add(root.dependent);
      restoring = true;
      select.value = value;
      select.dispatchEvent(new Event('change', {bubbles: true}));
      restoring = false;
    });
  }
  document.addEventListener('change', (event) => {
    const root = config.roots.find((entry) => event.target.id === entry.id);
    if (root) {
      if (restoring) return;
      const values = read(selectKey);
      values[root.id] = event.target.value;
      values[root.child] = ''; // Do not apply a snapshot from another environment.
      write(selectKey, values);
      return;
    }
    if (page === 'snapshots' && event.target.id === 'snapshot-job-limit') {
      saveSelections();
      return;
    }
    if (config.roots.some((entry) => event.target.id === entry.child)) {
      saveSelections();
      return;
    }
    if (config.result && element(config.result)?.contains(event.target)) saveFilters();
  });
  document.addEventListener('input', (event) => {
    if (page === 'snapshots' && event.target.id === 'snapshot-job-limit') saveSelections();
    if (config.result && element(config.result)?.contains(event.target)) saveFilters();
  });
  // Preset buttons modify checkboxes programmatically without emitting change events.
  document.addEventListener('click', (event) => {
    if (event.target.closest('[data-status-preset], [data-category-preset], [data-compare-preset]')) {
      setTimeout(saveFilters, 0);
    }
  });
  document.addEventListener('htmx:afterSwap', (event) => {
    const target = event.detail?.target;
    if (!target) return;
    const root = config.roots.find((entry) => entry.dependent === target.id);
    if (root) {
      if (pending.delete(target.id)) {
        restoring = true;
        selectSaved(root.child, read(selectKey)[root.child]);
        restoring = false;
      }
      saveSelections();
    }
    if (target.id === config.result) restoreFilters();
  });
  window.addEventListener('pagehide', () => { saveSelections(); saveFilters(); });
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', restoreSelections);
  } else {
    restoreSelections();
  }
})();
