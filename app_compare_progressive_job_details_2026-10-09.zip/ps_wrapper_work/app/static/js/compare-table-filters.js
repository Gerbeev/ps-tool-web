(function () {
  if (window.__psCompareTableFiltersBootstrapped) {
    return;
  }
  window.__psCompareTableFiltersBootstrapped = true;

  var pickerListenersBound = false;

  function categoryCheckboxes() {
    return Array.prototype.slice.call(document.querySelectorAll('.compare-category-checkbox'));
  }

  function getSelectedCategories() {
    var checked = categoryCheckboxes().filter(function (el) {
      return el.checked;
    });
    if (!checked.length) {
      return null;
    }
    return checked.map(function (el) {
      return el.value;
    });
  }

  function updateCategoryLabel() {
    var labelEl = document.getElementById('compare-category-picker-label');
    if (!labelEl) {
      return;
    }
    var selected = getSelectedCategories();
    if (!selected) {
      labelEl.textContent = 'All row types';
      return;
    }
    if (selected.length === 1) {
      categoryCheckboxes().forEach(function (box) {
        if (box.checked) {
          var row = box.closest('.browse-status-picker-row');
          var span = row ? row.querySelector('.browse-status-picker-row-label') : null;
          if (span) {
            labelEl.textContent = span.textContent.trim();
          }
        }
      });
      return;
    }
    labelEl.textContent = selected.length + ' selected';
  }

  function getPopover() {
    return document.getElementById('compare-category-picker-popover');
  }

  function getTrigger() {
    return document.getElementById('compare-category-picker-trigger');
  }

  function setPopoverOpen(open) {
    var trigger = getTrigger();
    var popover = getPopover();
    if (!trigger || !popover) {
      return;
    }
    if (open) {
      popover.removeAttribute('hidden');
      trigger.setAttribute('aria-expanded', 'true');
    } else {
      popover.setAttribute('hidden', '');
      trigger.setAttribute('aria-expanded', 'false');
    }
  }

  function applyCategoryPreset(preset) {
    categoryCheckboxes().forEach(function (box) {
      if (preset === 'all') {
        box.checked = false;
      } else if (preset === 'mismatches') {
        box.checked = ['status_delta', 'left_only', 'right_only', 'param_delta', 'exec_time_delta'].indexOf(box.value) !== -1;
      } else if (preset === 'matched') {
        box.checked = box.value === 'matched';
      } else if (preset === 'status_delta') {
        box.checked = box.value === 'status_delta';
      } else if (preset === 'exec_time_delta') {
        box.checked = box.value === 'exec_time_delta';
      } else if (preset === 'left_only') {
        box.checked = box.value === 'left_only';
      } else if (preset === 'right_only') {
        box.checked = box.value === 'right_only';
      }
    });
    document.querySelectorAll('.summary-card').forEach(function (card) {
      card.setAttribute('aria-pressed', card.getAttribute('data-compare-preset') === preset ? 'true' : 'false');
    });
    updateCategoryLabel();
    applyCompareTableFilters();
  }

  function bindPickerGlobalListeners() {
    if (pickerListenersBound) {
      return;
    }
    pickerListenersBound = true;
    document.addEventListener('keydown', function (evt) {
      if (evt.key === 'Escape') { setPopoverOpen(false); }
    });
    document.addEventListener('click', function (evt) {
      var picker = document.getElementById('compare-filter-categories');
      if (!picker || picker.contains(evt.target)) {
        return;
      }
      setPopoverOpen(false);
    });
  }

  function bindCategoryPicker() {
    var trigger = getTrigger();
    var popover = getPopover();
    if (!trigger || !popover || trigger.getAttribute('data-compare-picker-bound') === 'true') {
      return;
    }
    trigger.setAttribute('data-compare-picker-bound', 'true');
    bindPickerGlobalListeners();

    trigger.addEventListener('click', function (evt) {
      evt.stopPropagation();
      setPopoverOpen(popover.hidden);
    });

    popover.querySelectorAll('[data-category-preset]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        applyCategoryPreset(btn.getAttribute('data-category-preset') || 'all');
        setPopoverOpen(false);
      });
    });

    categoryCheckboxes().forEach(function (box) {
      box.addEventListener('change', function () {
        updateCategoryLabel();
        applyCompareTableFilters();
      });
    });
  }

  // The server applies filters before slicing rows. Only one page exists in the DOM.
  var requestVersion = 0;
  var currentRequest = null;
  var searchDebounce = null;

  function getPanel() {
    return document.getElementById('compare-table-panel');
  }

  function getPageSize() {
    var input = document.getElementById('compare-filter-limit');
    var value = input ? parseInt(input.value, 10) : 200;
    return [50, 100, 200, 250, 500].indexOf(value) === -1 ? 200 : value;
  }

  function buildUrl(offset) {
    var panel = getPanel();
    if (!panel || !panel.dataset.sessionId) return null;
    var params = new URLSearchParams();
    params.set('session_id', panel.dataset.sessionId);
    params.set('filter', 'all');
    params.set('limit', String(getPageSize()));
    params.set('offset', String(offset));
    var search = document.getElementById('compare-filter-search');
    if (search && search.value.trim()) params.set('q', search.value.trim());
    var categories = getSelectedCategories();
    if (categories && categories.length) params.set('categories', categories.join(','));
    return '/api/compare/table?' + params.toString();
  }

  function setLoading(loading) {
    var button = document.getElementById('compare-load-more');
    var indicator = document.getElementById('compare-table-loading');
    if (button) button.disabled = loading;
    if (indicator) indicator.hidden = !loading;
  }

  function updateMeta() {
    var body = document.getElementById('compare-table-body');
    if (!body) return;
    var total = Number(body.dataset.total || 0);
    var count = body.querySelectorAll('tr[data-compare-tags]').length;
    var meta = document.getElementById('compare-table-meta');
    if (meta) meta.textContent = 'Showing ' + count + ' of ' + total + ' matching rows';
    var button = document.getElementById('compare-load-more');
    if (button) {
      var remaining = Math.max(0, total - count);
      button.hidden = remaining === 0;
      button.textContent = 'Load next ' + Math.min(getPageSize(), remaining) + ' rows';
    }
  }

  async function fetchPage(append) {
    var panel = getPanel();
    if (!panel) return;
    if (append && currentRequest) return;
    var body = document.getElementById('compare-table-body');
    var offset = append && body ? body.querySelectorAll('tr[data-compare-tags]').length : 0;
    var url = buildUrl(offset);
    if (!url) return;

    if (currentRequest) currentRequest.abort();
    var controller = new AbortController();
    currentRequest = controller;
    var version = ++requestVersion;
    if (!append) panel.innerHTML = '<p class="muted small" role="status">Loading table…</p>';
    else setLoading(true);

    try {
      var response = await fetch(url, { signal: controller.signal, cache: 'no-store' });
      if (!response.ok) throw new Error('HTTP ' + response.status);
      var html = await response.text();
      if (version !== requestVersion || panel !== getPanel()) return;
      if (append) {
        var parsed = new DOMParser().parseFromString(html, 'text/html');
        var nextBody = parsed.getElementById('compare-table-body');
        var existingBody = document.getElementById('compare-table-body');
        if (!nextBody || !existingBody) throw new Error('Invalid table response');
        var fragment = document.createDocumentFragment();
        var rows = nextBody.querySelectorAll('tr[data-compare-tags]');
        rows.forEach(function (row) { fragment.appendChild(row); });
        existingBody.appendChild(fragment);
      } else {
        panel.innerHTML = html; // Same-origin Jinja-rendered HTML endpoint.
      }
      updateMeta();
    } catch (error) {
      if (error.name === 'AbortError' || version !== requestVersion) return;
      if (append) {
        var meta = document.getElementById('compare-table-meta');
        if (meta) meta.textContent += ' · Could not load more rows. Retry.';
      } else {
        panel.innerHTML = '<p class="muted small" role="alert">Could not load the comparison table. Change a filter to retry.</p>';
      }
    } finally {
      if (version === requestVersion) {
        currentRequest = null;
        setLoading(false);
      }
    }
  }

  function applyCompareTableFilters() {
    if (searchDebounce) {
      clearTimeout(searchDebounce);
      searchDebounce = null;
    }
    // A fresh request invalidates previously loaded pages and their offsets.
    return fetchPage(false);
  }

  function bindCompareTableFilters() {
    var root = document.querySelector('.compare-table-filters');
    if (!root || root.getAttribute('data-compare-filters-bound') === 'true') return;
    root.setAttribute('data-compare-filters-bound', 'true');
    setPopoverOpen(false);
    bindCategoryPicker();

    var search = document.getElementById('compare-filter-search');
    if (search) {
      search.addEventListener('input', function () {
        if (searchDebounce) clearTimeout(searchDebounce);
        if (currentRequest) {
          currentRequest.abort();
          currentRequest = null;
          ++requestVersion;
        }
        setLoading(true); // Prevent paging against stale results while search is changing.
        searchDebounce = setTimeout(applyCompareTableFilters, 250);
      });
    }
    var limit = document.getElementById('compare-filter-limit');
    if (limit) limit.addEventListener('change', applyCompareTableFilters);
    applyCompareTableFilters();
  }

  function initCompareTableFilters() {
    bindCompareTableFilters();
  }

  window.psCompareTableApplyPreset = applyCategoryPreset;
  window.psCompareTableFiltersInit = initCompareTableFilters;
  window.psCompareTableApplyFilters = applyCompareTableFilters;

  document.addEventListener('htmx:afterSwap', function (evt) {
    var target = evt.detail && evt.detail.target;
    if (target && target.id === 'compare-output') {
      // Inline result scripts can initialize before this event. Do not cancel their fetch.
      setPopoverOpen(false);
      initCompareTableFilters();
    }
  });

  document.addEventListener('click', function (evt) {
    var more = evt.target.closest('#compare-load-more');
    if (more && !more.disabled) {
      fetchPage(true);
      return;
    }
    var card = evt.target.closest('[data-compare-preset]');
    if (card) {
      var preset = card.getAttribute('data-compare-preset');
      if (preset) applyCategoryPreset(preset);
    }
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCompareTableFilters);
  } else {
    initCompareTableFilters();
  }
})();
