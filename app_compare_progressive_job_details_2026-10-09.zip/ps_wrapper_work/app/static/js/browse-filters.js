(function () {
  if (window.__psBrowseFiltersBootstrapped) {
    return;
  }
  window.__psBrowseFiltersBootstrapped = true;

  var pickerListenersBound = false;

  function inactiveStatuses() {
    var root = document.getElementById('browse-filter-status');
    if (!root) {
      return ['pending', 'not_run', 'disabled', 'killed', 'unknown'];
    }
    return (root.getAttribute('data-inactive-statuses') || '')
      .split(',')
      .map(function (s) {
        return s.trim();
      })
      .filter(Boolean);
  }

  function statusCheckboxes() {
    return Array.prototype.slice.call(document.querySelectorAll('.browse-status-checkbox'));
  }

  function getSelectedStatuses() {
    var checked = statusCheckboxes().filter(function (el) {
      return el.checked;
    });
    if (!checked.length) {
      return null;
    }
    return checked.map(function (el) {
      return el.value;
    });
  }

  function updatePickerLabel() {
    var labelEl = document.getElementById('browse-status-picker-label');
    if (!labelEl) {
      return;
    }
    var selected = getSelectedStatuses();
    if (!selected) {
      labelEl.textContent = 'All statuses';
      return;
    }
    if (selected.length === 1) {
      var text = selected[0];
      statusCheckboxes().forEach(function (box) {
        if (box.checked) {
          var row = box.closest('.browse-status-picker-row');
          var span = row ? row.querySelector('.browse-status-picker-row-label') : null;
          if (span) {
            text = span.textContent.trim();
          }
        }
      });
      labelEl.textContent = text;
      return;
    }
    labelEl.textContent = selected.length + ' selected';
  }

  function getPopover() {
    return document.getElementById('browse-status-picker-popover');
  }

  function getTrigger() {
    return document.getElementById('browse-status-picker-trigger');
  }

  function setPopoverOpen(open) {
    var trigger = getTrigger();
    var popover = getPopover();
    if (!trigger || !popover) {
      return;
    }
    if (open) {
      popover.removeAttribute('hidden');
      trigger.setAttribute('aria-expanded', 'true');
    } else {
      popover.setAttribute('hidden', '');
      trigger.setAttribute('aria-expanded', 'false');
    }
  }

  function applyStatusPreset(preset) {
    var inactive = inactiveStatuses();
    statusCheckboxes().forEach(function (box) {
      if (preset === 'all') {
        box.checked = false;
      } else if (preset === 'inactive') {
        box.checked = inactive.indexOf(box.value) !== -1;
      }
    });
    updatePickerLabel();
    applyBrowseFilters();
  }

  function bindPickerGlobalListeners() {
    if (pickerListenersBound) {
      return;
    }
    pickerListenersBound = true;


    document.addEventListener('click', function (e) {
      var picker = document.getElementById('browse-filter-status');
      if (!picker || picker.contains(e.target)) {
        return;
      }
      setPopoverOpen(false);
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        setPopoverOpen(false);
      }
    });
  }

  function bindStatusPicker() {
    var picker = document.getElementById('browse-filter-status');
    if (!picker || picker.getAttribute('data-browse-status-bound') === 'true') {
      return;
    }
    picker.setAttribute('data-browse-status-bound', 'true');

    bindPickerGlobalListeners();

    var trigger = getTrigger();
    if (trigger) {
      trigger.addEventListener('click', function (e) {
        e.stopPropagation();
        var open = trigger.getAttribute('aria-expanded') === 'true';
        setPopoverOpen(!open);
      });
    }

    statusCheckboxes().forEach(function (box) {
      box.addEventListener('change', function () {
        updatePickerLabel();
        applyBrowseFilters();
      });
    });

    Array.prototype.forEach.call(picker.querySelectorAll('.browse-status-picker-action'), function (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        applyStatusPreset(btn.getAttribute('data-status-preset'));
      });
    });

    updatePickerLabel();
  }

  var activeRequest = null;
  var pendingTimer = null;
  var requestVersion = 0;
  var currentLimit = 200;
  var treeMode = 'lazy'; // lazy, expanded, collapsed; scoped to the loaded snapshot
  var selectedJobUid = null;
  var preservedUnfilteredHtml = null;

  function currentSearchActive() {
    var input = document.getElementById('browse-filter-search');
    return Boolean((input && input.value.trim()) || (getSelectedStatuses() || []).length);
  }

  function setBranchOpen(button, open) {
    button.setAttribute('aria-expanded', String(open));
    var row = button.closest('.browse-job-row');
    if (row) button.setAttribute('aria-label', (open ? 'Collapse ' : 'Expand ') + row.getAttribute('data-job-name'));
  }

  function setNestedBranches(body, open) {
    body.querySelectorAll('details.browse-tree-branch').forEach(function (branch) {
      branch.open = open;
      var node = branch.closest('.browse-tree-node');
      var button = node && node.querySelector(':scope > .browse-job-row > .browse-tree-expand-btn');
      if (button) setBranchOpen(button, open);
    });
  }

  function refreshFlatVisibility(body) {
    var collapsedDepths = [];
    body.querySelectorAll('.browse-tree-node--flat').forEach(function (node) {
      var depth = Number(node.getAttribute('data-depth')) || 0;
      while (collapsedDepths.length && collapsedDepths[collapsedDepths.length - 1] >= depth) {
        collapsedDepths.pop();
      }
      node.hidden = collapsedDepths.length > 0;
      var toggle = node.querySelector(':scope > .browse-job-row > [data-browse-flat-toggle]');
      if (toggle && toggle.getAttribute('aria-expanded') === 'false') collapsedDepths.push(depth);
    });
  }

  window.psBrowseToggleFlat = function (button, event) {
    event.preventDefault();
    event.stopPropagation(); // The row opens details; only the arrow changes expansion.
    setBranchOpen(button, button.getAttribute('aria-expanded') !== 'true');
    var body = button.closest('.browse-tree-body');
    if (body) refreshFlatVisibility(body);
  };

  function setFlatBranches(body, open) {
    body.querySelectorAll('[data-browse-flat-toggle]').forEach(function (button) {
      setBranchOpen(button, open);
    });
    refreshFlatVisibility(body);
  }

  function restoreSelectedRow(body) {
    if (!selectedJobUid) return;
    body.querySelectorAll('.browse-job-row').forEach(function (row) {
      row.classList.toggle('is-selected', row.getAttribute('data-job-uid') === selectedJobUid);
    });
  }

  function getPane() {
    return document.querySelector('.browse-tree-pane');
  }

  function setFeedback(pane, message) {
    var feedback = pane.querySelector('#browse-filter-feedback');
    if (!feedback) return;
    feedback.textContent = message;
    feedback.hidden = !message;
  }

  function applyBrowseFilters(nextLimit) {
    var pane = getPane();
    if (!pane) return;
    var body = pane.querySelector('.browse-tree-body');
    var session = document.getElementById('session-id');
    if (!body || !session) return;

    if (pendingTimer !== null) {
      clearTimeout(pendingTimer);
      pendingTimer = null;
    }
    if (activeRequest) {
      activeRequest.abort();
      activeRequest = null;
    }
    var version = ++requestVersion;
    var query = (document.getElementById('browse-filter-search').value || '').trim();
    var statuses = getSelectedStatuses() || [];
    currentLimit = nextLimit || 200;
    var active = Boolean(query || statuses.length);
    if (active && preservedUnfilteredHtml === null) {
      // Keep the pre-search hierarchy, including user-expanded/collapsed boxes.
      preservedUnfilteredHtml = body.innerHTML;
    }
    if (!active && preservedUnfilteredHtml !== null) {
      ++requestVersion;
      body.innerHTML = preservedUnfilteredHtml;
      preservedUnfilteredHtml = null;
      if (window.htmx && typeof window.htmx.process === 'function') window.htmx.process(body);
      restoreSelectedRow(body);
      setFeedback(pane, '');
      return;
    }
    var params = new URLSearchParams({ session_id: session.value });
    if (active) {
      params.set('query', query);
      params.set('statuses', statuses.join(','));
      params.set('limit', String(currentLimit));
    }
    var url = (active ? '/api/browse/filter' : (treeMode === 'expanded' ? '/api/browse/tree/all' : '/api/browse/tree')) + '?' + params;
    var controller = new AbortController();
    activeRequest = controller;
    setFeedback(pane, 'Filtering jobs…');
    fetch(url, { signal: controller.signal, credentials: 'same-origin' })
      .then(function (response) {
        if (!response.ok) throw new Error('Filter request failed');
        return response.text();
      })
      .then(function (html) {
        if (version !== requestVersion || getPane() !== pane) return;
        body.innerHTML = html;
        if (!active && treeMode === 'collapsed') setNestedBranches(body, false);
        restoreSelectedRow(body);
        // Rebind lazy HTMX expansions in the unfiltered tree.
        if (window.htmx && typeof window.htmx.process === 'function') {
          window.htmx.process(body);
        }
        setFeedback(pane, '');
      })
      .catch(function (error) {
        if (error.name === 'AbortError' || version !== requestVersion || getPane() !== pane) return;
        setFeedback(pane, 'Could not filter jobs. Try again.');
      })
      .finally(function () {
        if (version === requestVersion) activeRequest = null;
      });
  }

  function scheduleBrowseFilters() {
    // Do not allow an older response to overwrite the tree after new input.
    ++requestVersion;
    if (activeRequest) activeRequest.abort();
    activeRequest = null;
    if (pendingTimer !== null) clearTimeout(pendingTimer);
    pendingTimer = setTimeout(function () {
      pendingTimer = null;
      applyBrowseFilters();
    }, 250);
  }

  function bindPane(pane) {
    if (!pane || pane.getAttribute('data-browse-filters-bound') === 'true') return;
    pane.setAttribute('data-browse-filters-bound', 'true');
    setPopoverOpen(false);
    bindStatusPicker();
    var searchEl = pane.querySelector('#browse-filter-search');
    if (searchEl) searchEl.addEventListener('input', scheduleBrowseFilters);
    pane.addEventListener('click', function (event) {
      var flatToggle = event.target.closest('[data-browse-flat-toggle]');
      if (flatToggle) {
        event.preventDefault();
        event.stopPropagation();
        setBranchOpen(flatToggle, flatToggle.getAttribute('aria-expanded') !== 'true');
        refreshFlatVisibility(pane.querySelector('.browse-tree-body'));
        return;
      }
      var expandAll = event.target.closest('#browse-expand-all');
      if (expandAll) {
        event.preventDefault();
        var body = pane.querySelector('.browse-tree-body');
        if (currentSearchActive()) {
          setNestedBranches(body, true);
        } else if (body.querySelector('.browse-tree-node--flat')) {
          treeMode = 'expanded';
          setFlatBranches(body, true);
        } else {
          treeMode = 'expanded';
          applyBrowseFilters();
        }
        return;
      }
      var collapseAll = event.target.closest('#browse-collapse-all');
      if (collapseAll) {
        event.preventDefault();
        var body = pane.querySelector('.browse-tree-body');
        if (body.querySelector('.browse-tree-node--flat')) setFlatBranches(body, false);
        else setNestedBranches(body, false);
        if (!currentSearchActive()) treeMode = 'collapsed';
        return;
      }
      var jobRow = event.target.closest('.browse-job-row');
      if (jobRow && jobRow.getAttribute('data-job-uid')) selectedJobUid = jobRow.getAttribute('data-job-uid');

      var button = event.target.closest('.browse-filter-load-more');
      if (!button) return;
      event.preventDefault();
      var limit = Number(button.getAttribute('data-next-limit'));
      if (limit > currentLimit && limit <= 10000) applyBrowseFilters(limit);
    });
  }

  function initBrowseFilters() {
    var pane = getPane();
    if (pane) bindPane(pane);
  }

  window.psBrowseFiltersInit = initBrowseFilters;
  window.psBrowseApplyFilters = applyBrowseFilters;

  document.addEventListener('htmx:afterSwap', function (event) {
    var target = event.detail && event.detail.target;
    if (!target) return;
    if (target.id === 'browse-output') {
      // A new session invalidates an in-flight search from the previous tree.
      ++requestVersion;
      if (activeRequest) activeRequest.abort();
      if (pendingTimer !== null) clearTimeout(pendingTimer);
      activeRequest = null;
      pendingTimer = null;
      treeMode = 'lazy';
      selectedJobUid = null;
      preservedUnfilteredHtml = null;
      initBrowseFilters();
    }
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initBrowseFilters);
  } else {
    initBrowseFilters();
  }
})();
