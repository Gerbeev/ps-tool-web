/* Keep the operator oriented when HTMX loads a detailed explanation or what-if result. */
(() => {
  'use strict';
  if (!window.htmx) return;
  let expandedMetrics = false;
  function updateCaptureAction() {
    const snapshot = document.getElementById('blockers-snapshot');
    const button = document.getElementById('blockers-analyze-button');
    if (button) button.disabled = !snapshot || snapshot.disabled || !snapshot.value;
  }
  document.addEventListener('DOMContentLoaded', updateCaptureAction);
  document.body.addEventListener('change', (event) => {
    if (event.target?.id === 'blockers-snapshot') updateCaptureAction();
  });
  document.body.addEventListener('htmx:beforeRequest', (event) => {
    if (event.detail?.elt?.id === 'blockers-environment') {
      const button = document.getElementById('blockers-analyze-button');
      if (button) button.disabled = true;
    }
  });
  document.body.addEventListener('htmx:beforeSwap', (event) => {
    if (event.detail?.target?.id === 'blockers-metrics') {
      expandedMetrics = Boolean(document.querySelector('#blockers-metrics .blockers-secondary-metrics[open]'));
    }
  });
  document.body.addEventListener('htmx:afterSwap', (event) => {
    const id = event.detail?.target?.id;
    if (id === 'blockers-snapshot-field') updateCaptureAction();
    if (id === 'blockers-metrics') {
      const disclosure = document.querySelector('#blockers-metrics .blockers-secondary-metrics');
      if (disclosure) disclosure.open = expandedMetrics;
    }
    if (id !== 'blockers-detail' && id !== 'blockers-recovery-output' && id !== 'blockers-what-if-output') return;
    const target = document.getElementById(id);
    if (!target || !target.textContent.trim()) return;
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    target.scrollIntoView({behavior: reducedMotion ? 'instant' : 'smooth', block: 'start'});
    if (id === 'blockers-detail') target.focus({preventScroll: true});
  });
  // A restored advanced filter must stay visible, so the operator can tell it is active.
  document.body.addEventListener('htmx:afterSwap', (event) => {
    if (event.detail?.target?.id !== 'blockers-output') return;
    const form = document.getElementById('blockers-filters');
    if (!form) return;
    const details = form.querySelector('.blockers-filter-disclosure');
    if (details && (form.elements.namedItem('classification')?.value !== 'all' || form.elements.namedItem('scope')?.value)) {
      details.open = true;
    }
  });
})();
