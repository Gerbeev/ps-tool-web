/* Snapshot ingestion progress: all user-visible strings are local constants, no HTML injection. */
(() => {
  const form = document.getElementById('snapshot-generate-form');
  const panel = document.getElementById('snapshot-live-progress');
  if (!form || !panel) return;
  const el = (id) => document.getElementById(id);
  const submit = form.querySelector('button[type="submit"]');
  let runId = null;
  let timer = null;
  let latest = null;
  let lastSeen = 0;

  const formatElapsed = (seconds) => {
    const n = Math.max(0, Math.floor(seconds));
    return `${Math.floor(n / 60)}m ${String(n % 60).padStart(2, '0')}s`;
  };
  const selectedSource = () => {
    const environment = el('snapshot-environment');
    const topology = form.querySelector('select[name="topology_id"]');
    const cob = form.querySelector('.snapshot-source-summary strong');
    const envName = environment?.selectedOptions?.[0]?.textContent.trim() || 'Unknown source';
    const limit = form.querySelector('[name="job_limit"]')?.value;
    const sample = limit && limit !== 'full' && limit !== '0' ? ` · DEBUG sample: ${limit} jobs` : '';
    return envName + (topology && topology.value ? ` · Topology: ${topology.value}` :
      cob ? ` · COB: ${cob.textContent.trim()}` : '') + sample;
  };
  const showError = (message) => {
    panel.hidden = false;
    el('snapshot-progress-title').textContent = 'Snapshot error';
    el('snapshot-progress-state').textContent = 'Failed';
    el('snapshot-progress-info').textContent = message;
    submit.disabled = false;
  };
  async function poll() {
    if (!runId) return;
    try {
      const response = await fetch(`/api/snapshots/progress/${encodeURIComponent(runId)}`, {cache: 'no-store'});
      if (!response.ok) throw new Error(`Status request failed (${response.status})`);
      const data = await response.json();
      latest = data;
      lastSeen = Date.now();
      el('snapshot-progress-title').textContent = 'Generating snapshot';
      el('snapshot-progress-source').textContent = data.saved_snapshot_label || data.source_label || selectedSource();
      el('snapshot-progress-run').textContent = `Run: ${data.run_id.slice(0, 8)}`;
      el('snapshot-progress-state').textContent = data.state;
      el('snapshot-progress-stage').textContent = data.message;
      const count = data.done != null && data.total != null
        ? `${data.done.toLocaleString()} / ${data.total.toLocaleString()}` : 'preparing…';
      el('snapshot-progress-count').textContent = `Current step: ${count}`;
      if (data.done != null && data.total > 0) {
        const pct = Math.max(0, Math.min(100, Math.round(100 * data.done / data.total)));
        el('snapshot-progress-bar').style.width = `${pct}%`;
        el('snapshot-progress-track').setAttribute('aria-valuenow', String(pct));
      } else {
        el('snapshot-progress-bar').style.width = '5%';
        el('snapshot-progress-track').setAttribute('aria-valuenow', '0');
      }
      el('snapshot-progress-info').textContent = data.stage === 'jil'
        ? 'Fetching individual JIL definitions in parallel. The current step may take several minutes.'
        : 'Stage: ' + data.stage;
      if (data.state === 'succeeded' || data.state === 'failed') {
        clearInterval(timer);
        timer = null;
        submit.disabled = false;
        if (data.state === 'failed') {
          const lastStage = data.last_reported_stage ? ` Last reported stage: ${data.last_reported_stage}.` : '';
          el('snapshot-progress-info').textContent = (data.error || 'Snapshot failed. See logs/application.log.') + lastStage;
        } else {
          el('snapshot-progress-bar').style.width = '100%';
          el('snapshot-progress-track').setAttribute('aria-valuenow', '100');
          el('snapshot-progress-info').textContent = 'Snapshot saved successfully.';
          const catalog = await fetch('/api/snapshots/catalog', {cache: 'no-store'});
          if (catalog.ok) {
            const html = await catalog.text();
            const workspace = document.getElementById('snapshots-workspace');
            // This endpoint serves application-generated, escaped Jinja HTML.
            if (workspace) workspace.innerHTML = html;
          }
        }
        runId = null;
      }
    } catch (err) {
      el('snapshot-progress-state').textContent = 'Reconnecting…';
      el('snapshot-progress-info').textContent = 'Cannot reach progress endpoint; snapshot worker may still be running.';
    }
  }
  setInterval(() => {
    if (!latest) return;
    const elapsed = latest.elapsed_seconds + (latest.state === 'running' ? (Date.now() - lastSeen) / 1000 : 0);
    el('snapshot-progress-time').textContent = `Elapsed: ${formatElapsed(elapsed)}`;
    const age = Math.max(0, Math.floor((Date.now() - new Date(latest.updated_at).getTime()) / 1000));
    el('snapshot-progress-update').textContent = `Last update: ${age}s ago`;
    if (latest.state === 'running' && age > 60) {
      el('snapshot-progress-info').textContent = 'No new connector progress for over 60s; the last step may be waiting on an HTTP request.';
    }
  }, 1000);
  // Reattach to an in-progress run after a page refresh or tab change.
  fetch('/api/snapshots/current', {cache: 'no-store'})
    .then((r) => r.ok ? r.json() : null)
    .then((data) => {
      if (!data || data.state !== 'running' || !data.run_id) return;
      panel.hidden = false;
      submit.disabled = true;
      runId = data.run_id;
      poll();
      timer = setInterval(poll, 1500);
    }).catch(() => {});
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (submit.disabled) return;
    submit.disabled = true;
    panel.hidden = false;
    latest = null;
    el('snapshot-progress-title').textContent = 'Generating snapshot';
    el('snapshot-progress-source').textContent = selectedSource();
    el('snapshot-progress-state').textContent = 'Starting…';
    el('snapshot-progress-stage').textContent = 'Starting isolated connector…';
    el('snapshot-progress-count').textContent = 'Records: preparing…';
    el('snapshot-progress-update').textContent = 'Last update: just now';
    el('snapshot-progress-run').textContent = 'Run: preparing…';
    el('snapshot-progress-info').textContent = 'Connecting to source system';
    el('snapshot-progress-bar').style.width = '0%';
    try {
      const response = await fetch('/api/snapshots/start', {method: 'POST', body: new FormData(form)});
      const payload = await response.json();
      if (!response.ok) {
        if (response.status === 409 && payload.run_id) {
          runId = payload.run_id;
        } else {
          showError(payload.detail || payload.error || `HTTP ${response.status}`);
          return;
        }
      } else {
        runId = payload.run_id;
      }
      if (timer) clearInterval(timer);
      await poll();
      if (runId) timer = setInterval(poll, 1500);
    } catch (err) {
      showError('Could not start snapshot. Check server connection.');
    }
  });
})();
