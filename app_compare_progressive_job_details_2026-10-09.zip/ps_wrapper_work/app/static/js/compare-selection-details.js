(function () {
  "use strict";

  function selectedLabel(select) {
    if (!select || select.selectedIndex < 0) return "—";
    return select.options[select.selectedIndex].textContent.trim();
  }

  function refreshSide(side) {
    var environment = document.getElementById("compare-" + side + "-env");
    var snapshot = document.getElementById("compare-" + side + "-snapshot");
    var panel = document.getElementById("compare-" + side + "-context-fields");
    var details = panel && panel.querySelector(".compare-selection-details");
    if (!details || !environment || !snapshot) return;

    var environmentLabel = selectedLabel(environment);
    var snapshotLabel = snapshot.disabled ? "(no generated snapshots)" : selectedLabel(snapshot);
    var snapshotId = snapshot.disabled ? "—" : snapshot.value;
    details.querySelector("[data-compare-full-environment]").textContent = environmentLabel;
    details.querySelector("[data-compare-full-snapshot]").textContent = snapshotLabel;
    details.querySelector("[data-compare-full-snapshot-id]").textContent = snapshotId || "—";
    environment.title = environmentLabel;
    snapshot.title = snapshotLabel;
  }

  function refreshAll() {
    refreshSide("left");
    refreshSide("right");
  }

  document.addEventListener("change", function (event) {
    if (event.target.matches("#compare-left-env, #compare-left-snapshot")) refreshSide("left");
    if (event.target.matches("#compare-right-env, #compare-right-snapshot")) refreshSide("right");
  });
  document.addEventListener("htmx:afterSwap", refreshAll);
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", refreshAll);
  } else {
    refreshAll();
  }
})();
