# Immutable Snapshot Workflow

## Contract

`Snapshots` is the only web workflow allowed to read AutoSys or Process Scheduler.

The runtime dependency direction is fixed:

```text
Snapshots route
  -> snapshot_generation
      -> SchedulerAdapter / scheduler-bridge/v1
      -> validation
      -> SnapshotCatalogStore

Browse route  -> SnapshotCatalogStore
Compare route -> SnapshotCatalogStore
Export route  -> comparison session or SnapshotCatalogStore
Search route  -> loaded Browse/Compare session
```

Browse and Compare must not import `get_adapter`, `fetch_snapshot`, `ExternalBridgeAdapter`, or any connector implementation.

## AutoSys generation

AutoSys generation accepts only an environment. The application creates a `ComparisonContext` using the previous local calendar day as COB (`today - 1 day`) and asks the configured adapter for a topology snapshot. There is no business-date selector in Browse or Compare; the captured date is part of the immutable snapshot metadata.

## Process Scheduler generation

Process Scheduler generation has two source operations, both exposed only from the Snapshots view:

1. `list_roots` retrieves available topology names for the selected environment.
2. `fetch_topology` retrieves the selected topology and normalizes it into the engine model.

The chosen topology is stored in the snapshot context and catalog record. Browse and Compare only select a saved snapshot ID.

## Persistence

`SnapshotCatalogStore` writes runtime state under `SNAPSHOT_DIR`, defaulting to:

```text
data/runtime/snapshots/
  index.json
  <snapshot-id>.snapshot.json.gz
  <snapshot-id>.snapshot.json.gz
  ...
```

Each catalog record contains:

- `snapshot_id`
- capture/fetch timestamps
- scheduler and environment
- frozen `ComparisonContext`
- business date or topology scope
- job/dependency counts
- payload filename and SHA-256 checksum

Snapshot payloads are immutable. A new capture always produces a new ID and file. The index is published atomically after the snapshot payload is complete.

## Failure behavior

Source fetch and validation happen before catalog publication. If adapter/bridge access fails or snapshot validation reports errors, no catalog record is added and all existing snapshots remain unchanged.

A snapshot whose payload is missing or fails its checksum is rejected when Browse/Compare attempt to load it.

## Source isolation

This boundary is deliberate for the bank-workstation deployment model. The web project can evolve independently while the workstation connector scripts remain fixed behind `scheduler-bridge/v1`. Process Scheduler source access continues one layer further through the existing C# `TopoBrowse.Bridge`; Browse/Compare never call it directly.

The test suite contains an explicit regression test that generates snapshots, replaces the adapter factory with a function that raises immediately, and then verifies that Browse and Compare still work. This guards against accidental live-source access being reintroduced later.


## Snapshot naming and deletion

- AutoSys display name: `<ENV>-AutoSys_<YYYY-MM-DD>_<HH-MM-SS>` using local capture time.
- Process Scheduler display name: `<ENV>-ProcessScheduler_<YYYY-MM-DD>_<TOPOLOGY>` using local capture date.
- AutoSys source `business_date` is always the previous local calendar day (`today - 1 day`).
- Snapshots can be deleted only from the Snapshots tab; deletion removes both the catalog entry and payload file.

## Live ingestion and local diagnostics

- Snapshots → **Generate snapshot** immediately starts one controlled background worker;
  `/api/snapshots/progress/<run_id>` reports current stage, count and timestamp.
  The UI polls every 1.5 seconds and refreshes the immutable catalog on completion.
  A reload of the browser page reattaches to the current run via `/api/snapshots/current`.
- AutoSys runtime parsing is followed by **all** JIL definitions (the standalone
  `RUN-AUTOSYS-DIAGNOSTICS.cmd` samples only 8), then model construction,
  validation, and atomic catalog persistence. The JIL connector reports a
  numeric checkpoint every 25 definitions, including failed count. No job names
  or definition contents are sent through progress events.
- The previous global **120-second** process timeout is inadequate for thousands
  of JIL requests. The AutoSys snapshot timeout has a separate minimum of
  **1800 seconds** (`PS_TOOL_AUTOSYS_SNAPSHOT_TIMEOUT_SEC`), even on workstations
  whose existing `.env` still specifies `PS_TOOL_CONNECTOR_TIMEOUT_SEC=120`.
  `PS_TOOL_CONNECTOR_TIMEOUT_SEC` remains the default for Process Scheduler.
  The limit is a safety ceiling, **not** a performance guarantee. Individual
  AutoSys HTTP requests still obey the connector's own 60-second limit.
- **Settings → Advanced → Runtime diagnostics** allows toggling detailed logs.
  Default is **ON**, backed by `PS_TOOL_DEBUG=true` and persisted locally in
  `config/runtime_settings.json`. Logs are in `logs/application.log` (5 MB,
  5 rotated backups). Critical errors and final outcome are logged even when
  debug is off. `PS_TOOL_LOG_DIR` may override the folder.
- Logs include run ID, UTC timestamp, stage, processed/total counters, request ID,
  elapsed seconds, error type/code and numeric JIL error summaries.
  They deliberately exclude credentials, URLs, raw response bodies, source DTOs,
  job names, JIL, stack trace messages and full command lines.
- Only one snapshot generation is active at once; duplicate submissions return
  HTTP 409 with the active run ID. The subprocess and progress state live in the
  app process; **restarting the server terminates in-memory progress** and may
  interrupt the source operation. Avoid restarting during ingestion.
- If work stalls, check **Last update** and `logs/application.log` for the same
  `run_id`. During long JIL fetches the displayed percentage refers to the **current
  step**, not an invented estimate for the entire pipeline.
