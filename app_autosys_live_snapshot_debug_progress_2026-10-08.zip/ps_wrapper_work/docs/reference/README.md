# Read-only source references

The `.md` files in this directory are **frozen evidence**. Do not rewrite, reformat,
rename, delete, shorten, merge, or auto-fix these files. Put corrections, implementation
notes, derived mapping, and commentary in a separate document elsewhere in `docs/`.

- `AUTOSYS_SELFHELP_ENDPOINT_SPEC.md` — preserved from the supplied AutoSys selfhelp spec.
- `PROCESS_SCHEDULER_TOPOBROWSE_BRIDGE.md` — byte-for-byte preserved copy of the
  Process Scheduler bridge documentation present in the current project archive.
  This is not asserted to be the separate original mentioned in the conversation;
  no such additional file was available in this turn.

Verification: `python scripts/verify_reference_docs.py`. Fixed SHA-256 digests are stored
in that checker; an ordinary project refactor must never update them. If new source
material arrives, add it under a **new filename** and preserve both versions.
