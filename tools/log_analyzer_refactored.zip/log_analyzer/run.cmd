@echo off
setlocal
cd /d "%~dp0" || exit /b 1
if "%~1"=="" (
    echo Usage: run.cmd PROD [--mode inventory^|enrich] [--date YYYYMMDD] [--force] [--output-dir PATH] [--no-progress]
    exit /b 2
)
set "PYTHON_CMD="
python -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)" >nul 2>&1
if not errorlevel 1 set "PYTHON_CMD=python"
if not defined PYTHON_CMD (
    py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)" >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=py -3"
)
if not defined PYTHON_CMD (
    echo ERROR: Python 3.11+ not found on PATH. 1>&2
    exit /b 1
)
%PYTHON_CMD% "%~dp0analyze.py" --env %*
exit /b %errorlevel%
