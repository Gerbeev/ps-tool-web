# Process Scheduler `exit_2` follow-up — 2026-10-08

## Diagnostic observations

- AutoSys U1: 2511/2511 runtime rows; required JIL 8/8; READY, process exit 0.
- Process Scheduler U5: `list_roots` still fails before any topology is received. The `TopoBrowse.Bridge` launcher exists, but four `list-contexts` variants and the stdin JSON fallback all return exit 2.
- The native C# bridge is not bundled with the portable ZIP. Exit 2 alone does not distinguish invalid arguments from a caught WCF exception; see the documented CLI contract for correct invocation.

## Changes in this build

`workstation_connectors/process_scheduler_connector.py` now reports value-safe native failure hints on each unsuccessful invocation, without printing stdout, stderr, argv values, job names or hostnames:

- `unknown_command` / `unknown_option` / `missing_argument` / `usage`: evidence of an invalid CLI invocation.
- `authentication` / `transport` / `runtime_exception` / `configuration`: native process reached a different failure class.
- `unclassified` / `no_output`: insufficient evidence; do not assume the cause.

Each CLI attempt also reports `out=yes|no,err=yes|no`. The source-only fingerprint adds:

- `source_dispatch_arg`: zero-based positional index in a recognized `switch(args[N])`, if detectable.
- `source_arg_indexes`: accessed positional argument indices.
- `source_arg_count_tests`: numeric guards such as `<3` or `!=2`.
- `source_exit2_paths`: syntax-only categories near explicit `return 2`/`Environment.Exit(2)` sites.

These are **hints**, not proof of the compiled executable's behavior. Source and compiled binaries may differ. No commands/parameters are invented from the hints; no modifications to the bank-local bridge are required.

## Runtime verification

Keep the existing `workstation_connectors/TopoBrowse.Bridge/` folder. Run `RUN-FULL-DIAGNOSTICS.cmd` and review the `PROCESS SCHEDULER` block, in particular the `CLI attempts`, `source_*`, `program_flags` and `failure_kinds` fields. The AutoSys status needs no further work.

Do not export native stderr/stdout, client configurations, credentials or live job definitions. The two original endpoint specifications in `docs/reference/` remain immutable.
