# Workstation Connector Protocol v1

## Decision

Real AutoSys and Process Scheduler integration is **out of process**. The portable web application never imports bank-local connector code.

```text
Portable web project
  FastAPI / Snapshots ingestion
          |
          v
  ExternalBridgeAdapter
          |
          | scheduler-bridge/v1
          | one JSON request on stdin
          | one JSON response on stdout
          v
workstation_connectors/
  autosys_connector.py ------------> AutoSys web/self-help endpoint
  process_scheduler_connector.py ---> TopoBrowse.Bridge ---> WCF / Process Scheduler
```

This is the compatibility boundary for the project. Protocol v1 is frozen: existing field meanings and operation semantics must not be changed. Future incompatible changes must be introduced as `scheduler-bridge/v2` while v1 remains supported until the workstation scripts are intentionally upgraded.

## Why this boundary

The web project changes frequently outside the bank, so source connectors must not subclass `SchedulerAdapter`, import `app.models`, or depend on the repository's Python package layout. Both Python connectors are developed and shipped with the project and require no workstation-side Python edits. Process Scheduler WCF transport remains inside the existing C# `TopoBrowse.Bridge`.

The bridge DTO is deliberately separate from `TopologySnapshot`. Internal models may evolve; only the translator in `app/adapters/bridge_contract.py` changes.

## Fixed workstation filenames

When `USE_MOCK_ADAPTERS=false`, the application invokes exactly:

```text
workstation_connectors/autosys_connector.py
workstation_connectors/process_scheduler_connector.py
```

The directory is configurable only through `PS_TOOL_CONNECTOR_DIR`; the filenames are not configurable from the UI or environment YAML. `autosys_connector.py`, `autosys_connector.json`, `process_scheduler_connector.py`, `process_scheduler_connector.json`, and `bridge_v1_runtime.py` ship in-repo.

A persistent external connector directory is optional. `setup-workstation-connectors.cmd <persistent-directory>` copies both shipped Python connector surfaces and the bridge runtime. The bank-local C# `TopoBrowse.Bridge` directory is copied separately into `<persistent-directory>/TopoBrowse.Bridge/` or configured with `PROCESS_SCHEDULER_BRIDGE_DIR`.


## Transport rules

Each invocation is a short-lived local child process.

- Request: exactly one UTF-8 JSON object on `stdin`.
- Response: exactly one UTF-8 JSON object on `stdout`.
- Logs/diagnostics: `stderr` only.
- No HTTP listener, local port, socket, shared DB, or web-app import is required.
- The web process uses an argument array, never `shell=True`.
- Default timeout: 120 seconds (`PS_TOOL_CONNECTOR_TIMEOUT_SEC`).
- Default accepted response size: 128 MB (`PS_TOOL_CONNECTOR_MAX_RESPONSE_MB`).
- A connector source/API failure is returned as a structured `ok=false` response. A non-zero process exit code is reserved for launcher/runtime failure.

## Request envelope

```json
{
  "protocol": "scheduler-bridge",
  "version": 1,
  "request_id": "uuid",
  "operation": "fetch_topology",
  "context": {
    "environment_id": "autosys-u1",
    "environment": "U1",
    "scheduler": "autosys",
    "host": "configured-host-or-endpoint",
    "as_of_kind": "business_date",
    "as_of_value": "2026-10-07",
    "root_box": "optional-root",
    "topology_id": null
  },
  "job_uid": null
}
```

`host` is the operator-configured target from the scheduler environment YAML. Credentials, tokens, passwords and certificates must not be passed through this field or stored in YAML; obtain them inside the workstation connector from the bank-approved mechanism.

## Operations

| Operation | Request addition | Success `data` |
|---|---|---|
| `health` | none | `{"healthy": true, "message": ""}` |
| `list_roots` | none | `{"roots": ["root-a", "root-b"]}` |
| `fetch_topology` | none | topology payload below |
| `fetch_job_detail` | `job_uid` required | `{"job": <job-or-null>}` |

## Success response envelope

```json
{
  "protocol": "scheduler-bridge",
  "version": 1,
  "request_id": "same uuid as request",
  "ok": true,
  "data": {},
  "error": null,
  "capabilities": {
    "topology": true,
    "dependencies": true,
    "runtime": true,
    "job_detail": true,
    "root_listing": true,
    "autosys_projection": true,
    "strict_parameter_support": true,
    "parameter_support": {
      "command": "supported",
      "watch_file_min_size": "not_applicable"
    }
  }
}
```

The app validates protocol/version and requires the response `request_id` to match the request.

## Error response envelope

```json
{
  "protocol": "scheduler-bridge",
  "version": 1,
  "request_id": "same uuid as request",
  "ok": false,
  "data": {},
  "error": {
    "code": "source_timeout",
    "message": "AutoSys query timed out",
    "retryable": true,
    "details": {}
  }
}
```

Do not return an empty topology for authentication failure, timeout, incompatible source schema, partial pagination, or any other incomplete retrieval. Return a structured failure instead.

## `fetch_topology` data

```json
{
  "fetched_at": "2026-10-07T12:00:00Z",
  "jobs": [],
  "dependencies": [],
  "metadata": {
    "source": "autosys_web_endpoint"
  }
}
```

A job uses this stable v1 shape:

```json
{
  "job_uid": "stable-native-or-derived-id",
  "scheduler_job_name": "JOB_NAME",
  "scheduler_native_id": "optional-native-id",
  "parent_uid": "optional-container-job-uid",
  "path_labels": ["Root", "Box"],
  "status": "success",
  "status_raw": "SU",
  "scheduled_start": null,
  "actual_start": "2026-10-07T10:00:00Z",
  "actual_end": "2026-10-07T10:03:12Z",
  "duration_sec": 192.0,
  "exit_code": 0,
  "autosys_jil": {
    "job_type": "CMD",
    "machine": "host-a",
    "command": "run-job",
    "condition": "s(PREVIOUS_JOB)"
  },
  "autosys_run": {
    "resolved_command": "run-job --date 2026-10-07",
    "exit_code": 0,
    "actual_start": "2026-10-07T10:00:00Z",
    "actual_end": "2026-10-07T10:03:12Z"
  },
  "process_scheduler": null,
  "attributes": {},
  "comparison_support": {},
  "comparison_evidence": {
    "command": {
      "source": "autosys_tool",
      "locator": "job.command",
      "note": ""
    }
  }
}
```

Allowed normalized status values are `pending`, `running`, `success`, `failure`, `killed`, `unknown`, `not_run`, and `disabled`. Preserve the source status in `status_raw`.

For Process Scheduler, populate `process_scheduler` with observed native fields and populate `autosys_jil` / `autosys_run` only for semantic equivalents that are actually verified. Never fabricate parity values just to make a comparison pass.

## Dependencies vs containment

`parent_uid` is topology/container membership only.

Execution dependencies are returned separately:

```json
{
  "from_uid": "job-a",
  "to_uid": "job-b",
  "kind": "finish_to_start",
  "condition": "optional source condition"
}
```

Allowed kinds: `finish_to_start`, `start_to_start`, `file_trigger`, `custom`.

Never infer `A -> B` merely because A and B are adjacent children of the same box/topology.

## Capability contract

The shipped AutoSys connector uses `strict_parameter_support=true` and declares every comparison field explicitly. Any field not proven from the source remains `unknown` or `unsupported` rather than being treated as implicitly comparable. Process Scheduler connectors must follow the same rule before their parity results are relied on. Required synthetic fields include:

- `status`
- `dependencies`
- `topology_parent`

Values are `supported`, `unsupported`, `unknown`, or `not_applicable`.

## Source connector implementation rule

Keep `bridge_v1_runtime.py` unchanged. `autosys_connector.py` is a shipped stdlib-oriented source client and parser; endpoint-specific request details belong in `autosys_connector.json`. `process_scheduler_connector.py` is a shipped stdlib-oriented wrapper around the existing C# `TopoBrowse.Bridge`; bridge location/invocation policy belongs in `process_scheduler_connector.json`. Connector implementations convert source responses into v1 dictionaries and never contain web/UI/comparison logic.

## Verification

Before first real captures:

```cmd
set USE_MOCK_ADAPTERS=false
diagnose-autosys.cmd --environment autosys-u1
diagnose-process-scheduler.cmd --environment ps-u5
diagnose-process-scheduler.cmd --environment ps-u5 --topology <exact-topology-name>
python -m app.adapters.check --environment autosys-u1 --scheduler autosys --as-of 2026-10-07
python -m app.adapters.check --environment ps-u5 --scheduler process_scheduler --as-of 2026-10-07
```

The source-specific diagnostics must succeed before real snapshots are generated. Process Scheduler diagnostics validate C# bridge discovery, topology listing and, when requested, one full topology read. Browse and Compare then consume only the generated snapshot catalog.

## Security and data handling

- Never store credentials in the project, YAML, request/response payload, or connector logs.
- Do not log full source DTOs or raw job command output.
- Runtime snapshots under `data/runtime/` remain git-ignored because job definitions, paths, owners and commands may be bank-sensitive.
- The shipped Python connector/config files contain no credentials. `TopoBrowse.Bridge` remains bank-local and is git-ignored under `workstation_connectors/TopoBrowse.Bridge/`. Deployment-local secrets remain outside Git; runtime snapshots remain ignored.
