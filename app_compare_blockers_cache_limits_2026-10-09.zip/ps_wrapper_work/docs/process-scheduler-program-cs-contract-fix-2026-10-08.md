# Process Scheduler: native Program.cs CLI contract alignment (2026-10-08)

## Verified CLI contract and fix

The C# entry-point contract is documented in [`reference/TOPOBROWSE_PROGRAM_CS_REFERENCE.md`](reference/TOPOBROWSE_PROGRAM_CS_REFERENCE.md). Previous `topobrowse_contract_mismatch` diagnostics showed `exit_2` for all guessed argument shapes. The `Main` implementation catches exceptions and returns `2` for both CLI and WCF failures; `exit_2` alone does not establish an incompatible command.

The shipped bridge **requires** a `--address host:port` option in every call, and `get-contexts` requires `--names CSV`. The Python connector incorrectly sent `--environment`, `--host`, `--topology`, and `--json`.

The default `workstation_connectors/process_scheduler_connector.json` now pins:

```text
list-contexts --address {host} --timeout 150 --max-mb 200
get-contexts --address {host} --names {topology} --timeout 150 --max-mb 200
describe-job --address {host} --context {topology} --job {job} --timeout 150 --max-mb 200
```

`{host}` is taken from `config/process_scheduler_environments.yaml`; it must already contain the `host:port` required by WCF. `--timeout 150` is the C# WCF timeout; the Python subprocess timeout remains 180 seconds. `--max-mb 200` matches the source's default and the configured subprocess output cap remains 128 MiB.

## Native JSON normalization

- `list-contexts` -> `{"ok":true, "contexts":["..."]}` -> application `list_roots`.
- `get-contexts` -> `{"ok":true, "contexts":[{"name":"...", "revisionNumber":N, "saveSnapshotTime": "...", "boxes": [...], "commands": [...]}]}`.
- Select the requested `context.name` **exactly once**, case-insensitively. Reject wrong / duplicated topology names. Combine `boxes` and `commands` as snapshot jobs with explicit `Kind` values. Preserve the original job fields and topology revision/time.
- Do **not** infer dependency edges or hierarchical parents from `box`, `context`, or `schedule`: the DTO has no verified dependency relation.
- Optional `describe-job` receives the native `job.Name`, not the generated scheduler-bridge `job_uid`. Resolve UID from the selected topology first.
- Failures remain sanitized (`attempt_trace`, `failure_kinds`); do not log raw C# JSON, endpoint address, commands, or financial job data.

## Deployment verification

1. Copy the new project files **without deleting the existing bank-local** `workstation_connectors/TopoBrowse.Bridge/` directory.
2. Run `RUN-FULL-DIAGNOSTICS.cmd` (it pauses at exit).
3. Expect `ps-u5 — list_roots` to show `PASS`; then use the Process Scheduler snapshot UI to select a topology.
4. If diagnostic code `exit_2` still occurs, check the *classification*: after the corrected args, `transport` suggests WCF endpoint reachability/binding rather than a CLI mismatch. Use only the sanitized `CLI attempts` and `failure_kinds` fields for troubleshooting; do not expose credentials or full payloads.

**Scope of verification:** local strict-CLI surrogate and tests pass. WCF access to the internal endpoint cannot be tested outside the bank. No changes have been made to the two original locked reference files or to the bank's C# source.
