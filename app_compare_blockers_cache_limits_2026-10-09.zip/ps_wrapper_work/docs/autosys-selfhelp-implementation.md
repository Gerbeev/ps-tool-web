# AutoSys selfhelp implementation notes (editable)

The immutable source is `reference/AUTOSYS_SELFHELP_ENDPOINT_SPEC.md`.
Never modify that source to document an implementation change.

The shipped `workstation_connectors/autosys_connector.json` now targets the specified
`/selfhelp/tool.cgi` CGI. It calls `GET ?t=job&i=IUT|IL2&q=<pattern>` for the list and
`GET ?t=jil&i=IUT|IL2&q=<exact-name>` for every listed job. The `%` wildcard is
URL-encoded using the HTTP transport. The list is parsed from `<pre>` fixed-width
text or the fallback body; date columns and status suffix are parsed by full
value shape rather than assumed character positions, because indentation shifts
columns. Missing/mismatched JIL aborts snapshot publication.

**COB**: the UI stores the previous calendar date as snapshot context. This CGI
supports only `t`, `i`, and `q`, therefore COB is not transmitted as a parameter
and the data is **not a historical as-of query**. Runtime fields indicate the latest
record reported by the source. Compare should not claim that runtime results are
restricted to the COB calendar date.

**Authentication**: Windows curl Negotiate/SSPI; anonymous fallback is attempted
only on an HTTP authentication failure and only if enabled in the connector JSON.
TLS certificate verification is disabled as specified for the internal endpoint;
redirects are disabled to keep the request on the configured host. Neither
HTTP responses nor JIL commands should appear in diagnostic output.

**Validation**: full `fetch_topology` requires all per-job JIL definitions.
`diagnose-autosys.cmd --environment autosys-u1` checks a bounded sample.
The internal endpoint cannot be exercised outside the corporate network; local
unit tests validate precise requests and parser structure only.
