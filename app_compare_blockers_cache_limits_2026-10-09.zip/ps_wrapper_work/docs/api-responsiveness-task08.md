# API responsiveness verification — Task 08

## Scope

Benchmarked **synthetic** 2,500-job and 10,000-job snapshots using the actual FastAPI routes,
Pydantic snapshot schema, gzip catalog, SQLite FTS and Jinja2 templates. The benchmark does not
connect to any schedulers and uses temporary snapshot and search databases.

Command from the project root:

```cmd
python scripts/benchmark_api_responsiveness.py
```

`elapsed_ms` measures complete HTTP response time; `loop_lag_ms` is the largest delay to a
20 ms asyncio heartbeat during that request. It is an event-loop stall measurement, not
an HTTP response time or guaranteed real-world service-level objective. Results vary across
runs and machines.

## Measurements

| Jobs per snapshot | Endpoint | Initial elapsed | Initial max loop lag | Updated elapsed | Updated max loop lag |
| ---: | --- | ---: | ---: | ---: | ---: |
| 2,500 | Browse Load | 199 ms | 183 ms | 133 ms | 83 ms |
| 2,500 | Compare | 528 ms | 517 ms | 277 ms | 77 ms |
| 10,000 | Browse Load | 772 ms | 762 ms | 704 ms | 414 ms |
| 10,000 | Compare | 1,978 ms | 1,967 ms | 1,553 ms | 413 ms |
| 10,000 | Search, 100 hits | 85 ms | 75 ms | 43 ms | 1 ms |
| 10,000 | Compare Table, all rows | 142 ms | 131 ms | 1,120 ms | 971 ms |

Figures are representative **single-run** observations, not a controlled statistical
speedup estimate. The larger Compare Table variance is caused by rendering and transferring
a multi-megabyte HTML fragment. The updated table result demonstrates **remaining contention**, not
an improvement in that workload. Compare Table produces approximately **6.1 MB HTML** with
10,000 jobs per side when the UI requests `limit=0` (all rows).

## Changes implemented

1. Route heavy snapshot load, comparison, search and table rendering through FastAPI's
   existing worker threadpool by declaring their HTTP handlers as synchronous (`def`).
   No new processes, queues or dependencies.
2. Deserialize persisted gzip JSON using Pydantic's direct `model_validate_json` path,
   avoiding the intermediate `json.loads()` object tree. Isolated 10,000-job decoding:
   previously ~0.55–0.68 s, now ~0.46–0.48 s in three local measurements.
3. Regression tests verify concurrent snapshot-progress polling remains responsive during
   a deliberately blocked snapshot load.

No scheduler connector, connector configuration, snapshot data format, comparison algorithm,
API response shape or table-row limit was changed.

## Remaining limitation

The standard Python worker-thread approach does **not** guarantee an unblocked event loop for
CPU-heavy operations. Python code and native extensions can still compete for the GIL,
and rendering the default unlimited table remains expensive. On 10,000-row tables, a browser
may also pause while parsing and displaying the large HTML payload.

Changing the user-facing `limit=0` / show-all behavior or moving workloads to separate
processes is deliberately **out of scope**. Such changes need a separate decision because
they affect interface behavior or deployment complexity.
