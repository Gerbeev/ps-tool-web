# Workstation connector diagnostics — 2026-10-08

This document is an implementation note, **not** an edit to the immutable `docs/reference/` material.

## Diagnostic observations

**AutoSys / U1:** HTTP 200, `text/html; charset=ISO-8859-1`, 2511 runtime rows parsed and matched, 0 detail links (expected for the CGI `t=jil` route). The required JIL sample was 7/8; the failed sample returned `jil_name_mismatch`.

**Process Scheduler / U5:** the .NET 9 `TopoBrowse.Bridge` starts, but four guessed CLI invocations returned exit 2. Local `Program.cs` showed the command literals `list-contexts`, `get-contexts`, `describe-job`. Exact argument syntax and the relationship between `get-contexts` and a full topology are *not yet verified*; the C# bridge's source was not included in this archive.

## Changes

- `autosys_connector.py`: parse independent JIL `insert_job:` blocks and bind the response to the *exact* requested job name; refuse unrelated definitions. Prefer full first-token job name rather than drifting fixed-width offsets when runtime timestamps are absent; normalize a known status in numbered source cells such as `12 AC` without discarding the raw field. Diagnostics now identify a bad sample by `#index` plus safe error code, without printing bank data.
- `process_scheduler_connector.py`: detect only three known read-only verbs from the copied `Program.cs`. Try conservative alternative argument layouts with these verbs before legacy guesses; retain declarative `commands.*` override for an exact, verified CLI. Reject context-name lists posing as job arrays. On mismatch, record the attempted *verb and option names* and exit/shape categories; do not print arguments, stdout, stderr, host names or payloads.
- `scripts/diagnose_all.py`: format sanitized bridge invocation attempts on separate console lines for readable diagnostics.
- Regression coverage for the above in connector tests.

## Deployment validation

Copy the **whole** new application archive to the workstation, retaining the existing `workstation_connectors/TopoBrowse.Bridge` folder. Run the existing `RUN-FULL-DIAGNOSTICS.cmd`. It uses the `.venv` Python interpreter and ends with `pause`.

Expected paths:

1. AutoSys: `JIL sample : 8/8` and `READY` *only if* the observed mismatch was caused by parsing multiple JIL definitions or the unstable runtime-name fallback. If it remains 7/8, inspect `JIL failed: #N:jil_name_mismatch`. The failed definition is **never** silently attached to a different job.
2. Process Scheduler: if `list-contexts` and `get-contexts` have compatible arguments and actual complete topology output, the diagnostic may pass. Otherwise, inspect the compact `CLI attempts`, `program_flags`, `command_literals`, and `failure_kinds` lines. These are structural clues for pinning the true C# contract in `process_scheduler_connector.json` without WCF changes.

`READY` for the bridge requires a non-empty job list with recognizable job fields. A contexts-only list cannot be used to construct a synthetic topology.

Do not export full responses, runtime job definitions, WCF endpoints or credentials. The original endpoint specifications are hash-checked by `python scripts/verify_reference_docs.py`.
