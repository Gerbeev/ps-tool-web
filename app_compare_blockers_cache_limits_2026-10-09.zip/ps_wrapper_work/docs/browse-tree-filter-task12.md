# Browse tree filtering

Browse filters operate on the **loaded immutable snapshot**. No scheduler connection is made.

## Behavior

- `/api/browse/filter?session_id=...&query=...&statuses=...&limit=200` scans the complete snapshot, including descendants not yet rendered in the browser.
- Name matching is case-insensitive substring matching. Status values are a comma-separated set of canonical `JobStatus` values. Both conditions apply to a matching job.
- The response includes matching jobs and the ancestor chain for each match; the resulting branches are expanded. Ancestors are context, not additional search hits.
- The response initially includes at most 200 matched jobs, plus their shared ancestors. `Show next` requests progressively more matches, without duplicates; filters still examine the full snapshot.
- Clearing the filters restores the original lazy tree via `/api/browse/tree`. Normal unfiltered navigation remains lazy.
- Maximum rendered match count per request is 10,000. Narrow a very broad filter to reach results beyond that limit.
- Session expiry and request failures are reported in the interface. An older request cannot overwrite a newer filter result.

## Boundaries

This feature does not modify stored snapshots, underlying topology, job details, comparison logic, scheduler connectors, or connector configuration.
