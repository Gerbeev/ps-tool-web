# Blockers analysis — implementation and operation

## Start

1. Start the existing application (`start-server.cmd` on Windows, then `open-app.cmd`).
2. Open **Blockers** from the sidebar between Browse and Compare.
3. Choose **Environment** and a saved **Snapshot**, then click **Analyze snapshot**.
4. Inspect **Root blockers** / **Suspected gates** / **Waiting jobs** / **All jobs / critical targets** / **Data quality**.
5. Select **Explore** or **Inspect** for evidence paths or *Why is this waiting?* explanations. Mark important final jobs as critical through the detail panel; rerun / refresh analysis to compare subsequent snapshots.

Blockers cannot create snapshots, read remote schedulers or change job statuses. Only Snapshots invokes connectors. The analysis reflects the normalized snapshot **at fetched_at**, not live status or an AutoSys historical as-of guarantee.

## Findings and terminology

- **Verified root gate**: a predecessor with a supported, evaluated unsatisfied predicate for a `pending` / `not_run` dependent. It proves a dependency gate, **not** an incident or need for remediation. Contributing roots may overlap.
- **Potential incident** (`potential_incident`): a proven contributing root whose recorded status is `failure` or `killed`. This is worth investigating; it is not proof that the outcome was unexpected, that a retry is needed, or that the job is solely responsible.
- **Running gate** (`running_gate`): a proven contributing root whose status is `running`. Normal execution until independent duration/SLA evidence suggests otherwise.
- **Condition gate** (`condition_gate`): a proven contributing root whose status is neither failed/killed nor running (e.g. `success(A)` with `failure(A)` predicate, `disabled` with `success(...)`). The recorded condition is false, but there is no evidence of a failed job; this can be an expected branch or an administrative hold. Do not silently classify it as an incident.
- **Legacy classifications**: `confirmed` (any non-running root) and `active` (running root) remain in diagnostic JSON for compatibility. They represent the original grouping; **operational_kind** is the new triage category.
- **Suspected gate**: a failed/killed/disabled/running upstream job connected by an unverified edge to a waiting job. **No causal proof.** Candidate destinations are not added to confirmed impact totals.
- **Fully explained wait**: a waiting job with one or more proven contributing root gates, and no unresolved relevant predecessor status or incomplete upstream explanation along those gates. Several roots can contribute; this does not designate a unique sole cause.
- **Partially explained wait**: a waiting job with at least one proven contributing root gate **and** other unresolved required predicate states or incomplete upstream wait explanations. The proven roots remain valid contributing gates, not a complete diagnosis.
- **Cyclic dependency boundary**: strongly connected groups in the combined execution-edge / verified-box-rule proof-order graph. Cyclic links are not traversed for proof. An external, independently failed predicate still counts for the specific waiting job, while other unresolved cyclic conditions keep the explanation partial. Verified roots can continue to downstream jobs through acyclic links, but are never propagated around the cycle itself. Cyclic box completion rules do not promote a box to a standalone root.
- **Unexplained wait**: a waiting job with no proven upstream root; includes missing dependency graph, unsupported expressions, conditions already satisfied, and unresolved conditions where none of the known states is sufficient to prove a blocker.
- **Impact**: number of **unique waiting job UIDs** with a verified dependency path from the source. Structural ancestors are not counted as dependent execution jobs. Multiple blockers may overlap on the same waiting target.
- **Critical target**: explicitly marked job. User preferences persist by `[scheduler, environment_id, topology/root_scope]` and native scheduler job **name** in `data/blockers_critical_targets.json`, not inside snapshot files. Ambiguous names cannot be marked.

## Operational triage and filters

Dashboard counters and the **Class** filter expose **Potential incidents**, **Running gates** and **Condition gates**. The **Root blockers** table and Impact Explorer show the operational category separately from the evidence. Sorting prefers impacted critical targets, then potential incidents, running gates and condition gates, then descending impact. The Waiting/All jobs filters select jobs reached by roots of the chosen category. Suspected edges remain **unverified**, in a separate view; no suspected gate is promoted to a proven root.

Example: `A=SUCCESS`, `T=PENDING`, `failure(A)` as `T`'s explicit prerequisite. The condition is false and `A` is a proven **condition gate**, not a failed job or a confirmed operational incident. For `success(A) OR success(B)` with `A=FAILURE`, `B=SUCCESS`, there is no blocker because the alternative is satisfied. A `RUNNING` job is never deemed slow without a measured baseline. No severity/SLA classification is inferred from the snapshot.

`/api/blockers/report` retains original `totals.confirmed`, `totals.active` and each blocker's `classification` values. New totals are `potential_incidents`, `running_gates`, `condition_gates`; each blocker also exposes `operational_kind`. New list classification values use the same snake_case labels, while old `confirmed` and `active` query values are accepted for compatibility. The legacy `confirmed` counter includes **all non-running gates**, including benign condition gates; use `potential_incidents` for operational triage.

## Condition support

Supported **recorded** condition subset: `s(NAME)` / `success(NAME)`, `f(NAME)` / `failure(NAME)`, `d(NAME)` / `done(NAME)`, `AND` / `OR`, `&` / `|`, `&&` / `||`, parentheses; plus legacy, explicitly asserted per-edge bare `success`, `failure` or `done` (treated as a conjunction). Only sources covered exactly by the snapshot's incoming edges are resolved. `start_to_start`, `file_trigger`, unsupported functions, missing/ambiguous refs, unmatched edge/expression sets, conflicting expressions and syntax errors are **unknown**, not false.

Predicate status evaluation uses `TRUE`, `FALSE`, `UNKNOWN` (unknown upstream status becomes unknown). An `OR` branch with a true alternative cannot attribute a blocker to the false branch. For `OR` with all false alternatives, each may be a **contributing** blocker — not a sole cause. Missing or unsupported source conditions do not produce confirmed roots.

For `success(A) AND success(U)` with `A=FAILURE` and `U=UNKNOWN`, the whole expression evaluates `FALSE` and `A` remains a **confirmed contributing gate**, while the wait is **Partially explained** and `U` is listed under unknown predecessor states. An unknown branch already satisfied by an alternative `OR` is not counted as unresolved. In a downstream waiting chain, partial explanation status propagates even when an upstream root can be traced. If an entire condition evaluates `UNKNOWN` and no false gate can be proved, the wait stays **Unexplained**.

Analysis uses separate execution dependency edges and containing box hierarchy. `parent_uid` by itself never implies an execution dependency. **Only an explicit, verified AutoSys box completion rule** permits a causal step through a box.

## AutoSys box resolution

A waiting target which depends on `success(BOX)` can be traced into nested AutoSys boxes when a verifiable **explicit** completion rule exists:

- For a box in **RUNNING**, `box_success` must be present, supported, and evaluated `FALSE`; there must be no conflicting or unverified explicit `box_failure`. Contributing false predicates are traced into referenced child jobs.
- For a box in **FAILURE**, an explicit, **satisfied** `box_failure` rule can explain its recorded failed state; default failure behavior is not inferred from membership.
- Only `success`, `failure`, `done`, `AND`/`OR` and parentheses are evaluated. Referenced names must be unique and inside the containing box (including nested descendants), with no known child events predating the box's actual start.
- Evidence paths can show `FAILED_JOB → INNER_BOX (box_success) → OUTER_BOX (box_success) → REPORT (s(OUTER_BOX))`. Box steps are not counted as additional waiting jobs.
- `FALSE AND UNKNOWN` retains proven contributing gates but marks the explanation **Partially explained**; a satisfied `OR` alternative does not promote failed children. Completion-rule cycles stop proof through their cyclic links, while independently verified incoming gates can still be traced outside the cycle.
- Missing, unsupported, ambiguous, external, temporally stale, or non-matching rules do not promote contained jobs as roots. The box stays an observable gate when it directly blocks a waiting dependent, and its incomplete internal explanation is visible in **Data quality**. A box not yet running is not resolved from old child statuses.

**Process Scheduler completion semantics are not assumed to match AutoSys.** A current box and its child states should belong to the same run; if the snapshot omits run identifiers/timestamps this cannot independently be proven. Default AutoSys box completion, delayed event evaluation and other native scheduler policies are intentionally outside the supported subset. Analysis remains read-only.


## Readiness and diagnostics

The **Data quality** view reports total jobs/edges, supported vs unsupported conditions, invalid or cyclic dependencies, cycle member and downstream counts, adapter capability gaps, and count of currently active/completed jobs whose recorded predecessor conditions evaluate false (potentially a normal retry/timing artifact). It also shows verified/unverified AutoSys box completion rules and the three wait-explanation counts. The **Compact diagnostics (JSON)** link exposes `/api/blockers/report?session_id=<session>` with aggregate counts, blocker identifiers, and up to 30 examples of partially explained waits (UIDs of proven roots, unknown predicates and incomplete upstream explanations), and up to 30 box-resolution diagnostics. `/api/blockers/path` labels explicit box transitions with `box_completion_rule`. It does not persist analysis outputs or introduce new logs with job payloads.

**Coverage labels describe only the recorded edges and supported expressions, not whether all runtime predecessor states are known or whether the source scheduler's full graph was captured.** The label `VERIFIED` can legitimately coexist with a partially explained wait. AutoSys connector may omit referenced jobs outside captured scope, and Process Scheduler snapshots may lack explicit edges entirely. Both can make causal analysis incomplete. Do not interpret no blockers as proof that a batch is unblocked. Full analysis of Process Scheduler `ConditionExpression`, native schedule triggers, external events and default box completion rules requires validated source contracts and is intentionally not inferred here.

## Implementation

- `app/services/blockers.py`: independent pure-Python graph readiness, safe subset parser, three-valued evaluation, guarded explicit AutoSys box resolution, iterative SCC condensation and acyclic causal propagation, compact backpointers and on-demand bounded evidence paths.
- `app/services/blockers_targets.py`: atomic local critical-target preferences, independent of immutable snapshots.
- `app/routes/blockers.py`: selector, analysis, paging/filtering, explanation, critical-target and diagnostics routes.
- `app/templates/blockers.html`, `app/templates/partials/blockers_*.html`, `app/static/css/custom.css`: HTMX-backed diagnostic table and local impact explorer. 100 rows per page; paths rendered only when selected (first 30 targets per blocker).
- `tests/test_blockers.py`: `AND/OR`, fallback, full/partial/unexplained wait classifications, operational triage categories, UI/API filtering and backward-compatible fields, cascading incomplete explanations, nested box rules, stale child timestamps, cycles (including downstream independent roots and explicit box completion cycles), missing edges, ambiguous names, persistence, 5000-deep dependency chain.


## Blockers analysis session cache

The results of **Analyze snapshot** are held in a process-local, in-memory LRU cache.
The stored snapshots and persisted Critical Targets are not removed by cache eviction.
Defaults, configurable through `.env` (restart the application to apply changes):

| Setting | Default | Meaning |
|---|---:|---|
| `BLOCKERS_CACHE_TTL_SEC` | `1200` | Expire after 20 minutes without a cache access |
| `BLOCKERS_CACHE_MAX_SESSIONS` | `12` | Maximum cached analyses per server process |
| `BLOCKERS_CACHE_MAX_MB` | `128` | Approximate cumulative retained heap budget, MiB, per server process |

Every successful list, Impact Explorer, critical-target update, report, or path request
refreshes the session's last-access time. Expired sessions are removed lazily on the
next cache access; least-recently-used sessions are evicted immediately when admission
would breach the count or memory budget. A report larger than the entire budget is
not cached. Following eviction or expiry, the web UI replaces stale results with a
message instructing the operator to click **Analyze snapshot** again. JSON diagnostic
endpoints continue returning a `404` for invalid/expired session IDs. After changing
a Critical Target, the cache updates the memory estimate for the newly computed report.

Memory accounting traverses reachable Python objects without double-counting repeated
references in the same analysis; it is **an estimate, not a hard RSS limit**. Python
allocator overhead, shared module data and temporarily concurrent in-flight analyses
may increase actual process memory. The cache is per process (not shared across
workers), and restarting the server clears it. No timers, external cache service,
persistent analysis reports or background processes are introduced.

## Limitations

No live polling, restarts, auto-remediation, time-to-complete estimate, historical baseline or SLA priority. `running` duration is not classified as anomalous without a separate verified baseline. Criticality comes only from explicitly marked targets. No implicit box-to-child propagation: only supported explicit AutoSys completion rules are used. Real-world connector semantics and completeness must be validated on the workstation's own snapshots.
