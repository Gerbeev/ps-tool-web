# Compare table pagination

The Compare table now renders 200 rows initially, and the **Load next** button appends one additional page at a time. The page size control supports 50, 100, 200, 250 and 500 rows. The default is `TABLE_PAGE_SIZE=200`; older local `.env` files using `TABLE_PAGE_SIZE=0` fall back to 200 in the UI.

`GET /api/compare/table` accepts `session_id`, `offset` (zero-based), `limit` (default 200), `q` (case-insensitive substring of job name or logical ID), and `categories` (comma-separated UI category values). All filters are applied **before** paging, with OR semantics across selected categories. Legacy parameters `filter` and `q_prefix` are preserved; explicit `limit=0` still supports legacy consumers that deliberately request the entire result.

The browser fetches pages from this endpoint, appends new table rows without re-rendering the table header, and resets to offset zero whenever a search term, page size or category selection changes. Search is debounced for 250ms; stale requests cannot overwrite newer results. The user can continue loading until the full filtered result is visible.

CSV exports are unchanged: they are generated from the full comparison session rather than the visible HTML page. The comparison algorithm, stored snapshots, and scheduler connectors were not modified.

Regression tests cover page boundaries, unique rows, the last-page search, combined category filtering, legacy requests, invalid filter validation, and the existing export paths.
