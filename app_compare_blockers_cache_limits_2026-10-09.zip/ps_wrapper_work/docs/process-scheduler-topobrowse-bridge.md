# Process Scheduler through TopoBrowse.Bridge

Process Scheduler connectivity is provided by the existing C# `TopoBrowse.Bridge` component. The Python project does not implement WCF.

```text
Snapshots
  -> ExternalBridgeAdapter
  -> scheduler-bridge/v1
  -> process_scheduler_connector.py
  -> TopoBrowse.Bridge
  -> WCF / Process Scheduler
```

The shipped Python wrapper discovers the C# bridge, invokes only read operations, parses native results and normalizes them into `scheduler-bridge/v1`. Copy the complete C# bridge directory to `workstation_connectors/TopoBrowse.Bridge/` or configure another path with `PROCESS_SCHEDULER_BRIDGE_DIR`.

The wrapper supports an auto-detected CLI/JSON contract because the web engine must remain independent from the exact C# entry-point syntax. Once the real bridge invocation has been validated, the command templates may be pinned declaratively in `workstation_connectors/process_scheduler_connector.json`.

Use:

```cmd
diagnose-process-scheduler.cmd --environment ps-u5
```

and optionally:

```cmd
diagnose-process-scheduler.cmd --environment ps-u5 --topology <exact-topology-name>
```

See `ai-agent/process-scheduler-topobrowse-bridge.md` for the full implementation contract and normalization rules.

## Contract discovery on the workstation

If `TopoBrowse.Bridge` starts but the wrapper reports `topobrowse_contract_mismatch`, the diagnostic does not guess another command. It performs a read-only source-contract inspection of the copied bridge and prints only structural metadata:

- target framework and output type from `TopoBrowse.Bridge.csproj`;
- whether `Program.cs` appears to consume command-line arguments, stdin, interactive input, and/or JSON;
- command-like literals found only in CLI-dispatch-looking source lines;
- public method signatures from `DbAccessBridgeClient.cs` with parameter types but no values;
- public contract type and property names from `Contracts/*.cs`.

No Process Scheduler payload values are emitted by this discovery step. The resulting diagnostics are intended to make the Python wrapper match the actual bridge contract rather than inferred command names.
