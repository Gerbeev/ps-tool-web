"""Regression scenarios for snapshot-only Blockers and its UI."""
from __future__ import annotations

from datetime import datetime, timezone

from fastapi.testclient import TestClient
import pytest

from app.main import app
from app.models import (AdapterCapabilities, ComparisonContext, DependencyEdge,
                        DependencyKind, JobStatus, SchedulerType, SnapshotJob, TopologySnapshot)
from app.routes import blockers as route
from app.services.blockers import ExplanationStatus, Truth, analyze_blockers
from app.services.blockers_targets import get_critical_targets, set_critical_target


def _snapshot(statuses: dict[str, JobStatus], edges: list[tuple[str, str, str]],
              *, scheduler: SchedulerType = SchedulerType.AUTOSYS,
              declared: bool = True, parents: dict[str, str] | None = None) -> TopologySnapshot:
    parents = parents or {}
    jobs = [SnapshotJob(job_uid=uid, scheduler_job_name=uid, status=status,
                        status_raw=status.value.upper(), parent_uid=parents.get(uid))
            for uid, status in statuses.items()]
    return TopologySnapshot(
        context=ComparisonContext(environment_id="unit-test", scheduler=scheduler),
        fetched_at=datetime(2026, 10, 8, 12, tzinfo=timezone.utc),
        flat_jobs=jobs,
        edges=[DependencyEdge(from_uid=source, to_uid=target, condition=condition,
                              kind=DependencyKind.FINISH_TO_START)
               for source, target, condition in edges],
        capabilities=AdapterCapabilities(dependencies=declared),
    )


def test_cascading_waits_group_by_one_root_and_preserve_path():
    snapshot = _snapshot({"ROOT": JobStatus.FAILURE, "INNER": JobStatus.PENDING,
                          "REPORT": JobStatus.PENDING, "BOX": JobStatus.PENDING}, [
        ("ROOT", "INNER", "success(ROOT)"),
        ("INNER", "REPORT", "s(INNER)"),
    ], parents={"ROOT": "BOX", "INNER": "BOX"})
    result = analyze_blockers(snapshot, critical_names=["REPORT"])
    assert result.confirmed_count == 1
    assert result.roots[0].uid == "ROOT"
    assert result.path("ROOT", "REPORT") == ("ROOT", "INNER", "REPORT")
    assert result.roots[0].impact_count == 2
    assert result.roots[0].critical_targets == {"REPORT"}
    assert "BOX" not in result.roots[0].targets
    assert result.impacted_critical_count == 1


def test_or_alternative_success_prevents_false_blocker():
    snap = _snapshot({"BAD": JobStatus.FAILURE, "GOOD": JobStatus.SUCCESS,
                      "TARGET": JobStatus.PENDING}, [
        ("BAD", "TARGET", "s(BAD) OR s(GOOD)"),
        ("GOOD", "TARGET", "s(BAD) OR s(GOOD)"),
    ])
    result = analyze_blockers(snap)
    assert not result.roots
    assert result.waits["TARGET"].result is Truth.TRUE
    assert result.unexplained_count == 1


def test_both_failed_or_branches_contribute_but_are_not_unique():
    snap = _snapshot({"A": JobStatus.FAILURE, "B": JobStatus.FAILURE,
                      "C": JobStatus.PENDING}, [
        ("A", "C", "success(A) | success(B)"),
        ("B", "C", "success(A) | success(B)"),
    ])
    result = analyze_blockers(snap)
    assert {root.uid for root in result.roots} == {"A", "B"}
    assert {result.path(root.uid, "C") for root in result.roots} == {("A", "C"), ("B", "C")}
    assert result.blocked_count == 1


def test_and_failure_and_running_both_gates():
    snap = _snapshot({"FAIL": JobStatus.FAILURE, "RUN": JobStatus.RUNNING,
                      "OUT": JobStatus.PENDING}, [
        ("FAIL", "OUT", "success(FAIL) AND success(RUN)"),
        ("RUN", "OUT", "success(FAIL) AND success(RUN)"),
    ])
    result = analyze_blockers(snap)
    assert result.confirmed_count == 1
    assert result.active_count == 1
    assert {root.uid for root in result.roots} == {"FAIL", "RUN"}


def test_failed_and_unknown_retains_confirmed_gate_but_marks_partial_explanation():
    snap = _snapshot({"A": JobStatus.FAILURE, "U": JobStatus.UNKNOWN,
                      "T": JobStatus.PENDING}, [
        ("A", "T", "s(A) AND s(U)"), ("U", "T", "s(A) AND s(U)"),
    ])
    report = analyze_blockers(snap)
    wait = report.waits["T"]
    assert report.quality.level == "verified"  # Edge integrity != runtime explanation completeness
    assert wait.result is Truth.FALSE
    assert wait.explanation is ExplanationStatus.PARTIALLY_EXPLAINED
    assert wait.root_paths == {"A": "A"}
    assert wait.unresolved_gates == ["U"]
    assert not wait.unresolved_predecessors
    assert report.confirmed_count == 1
    assert report.partially_explained_count == 1
    assert report.fully_explained_count == 0
    assert report.unexplained_count == 0
    assert report.blocked_count == 1


def test_partial_upstream_propagates_without_inventing_extra_root():
    snap = _snapshot({"A": JobStatus.FAILURE, "U": JobStatus.UNKNOWN,
                      "MID": JobStatus.PENDING, "END": JobStatus.PENDING}, [
        ("A", "MID", "s(A) AND s(U)"),
        ("U", "MID", "s(A) AND s(U)"),
        ("MID", "END", "s(MID)"),
    ])
    report = analyze_blockers(snap)
    assert report.waits["END"].explanation is ExplanationStatus.PARTIALLY_EXPLAINED
    assert report.waits["END"].unresolved_predecessors == ["MID"]
    assert report.waits["END"].unresolved_gates == []
    assert report.path("A", "END") == ("A", "MID", "END")
    assert report.roots[0].impact_count == 2
    assert report.partially_explained_count == 2


def test_failed_with_unexplained_waiting_sibling_is_partial():
    snap = _snapshot({"A": JobStatus.FAILURE, "WAIT": JobStatus.PENDING,
                      "T": JobStatus.PENDING}, [
        ("A", "T", "s(A) AND s(WAIT)"),
        ("WAIT", "T", "s(A) AND s(WAIT)"),
    ])
    report = analyze_blockers(snap)
    assert report.waits["T"].root_paths == {"A": "A"}
    assert report.waits["T"].unresolved_predecessors == ["WAIT"]
    assert report.waits["T"].explanation is ExplanationStatus.PARTIALLY_EXPLAINED
    assert report.waits["WAIT"].explanation is ExplanationStatus.UNEXPLAINED


def test_known_failure_without_unknown_is_fully_explained():
    snap = _snapshot({"A": JobStatus.FAILURE, "B": JobStatus.SUCCESS,
                      "T": JobStatus.PENDING}, [
        ("A", "T", "s(A) AND s(B)"), ("B", "T", "s(A) AND s(B)"),
    ])
    report = analyze_blockers(snap)
    assert report.waits["T"].explanation is ExplanationStatus.FULLY_EXPLAINED
    assert not report.waits["T"].unresolved_gates
    assert report.fully_explained_count == 1
    assert report.partially_explained_count == 0


def test_true_or_branch_makes_unknown_alternative_irrelevant():
    snap = _snapshot({"A": JobStatus.FAILURE, "B": JobStatus.SUCCESS,
                      "U": JobStatus.UNKNOWN, "T": JobStatus.PENDING}, [
        (source, "T", "s(A) AND (s(B) OR s(U))") for source in ("A", "B", "U")
    ])
    report = analyze_blockers(snap)
    assert report.waits["T"].result == Truth.FALSE
    assert report.waits["T"].explanation is ExplanationStatus.FULLY_EXPLAINED
    assert not report.waits["T"].unresolved_gates


def test_satisfied_or_with_unknown_branch_is_unexplained_wait_not_partial():
    snap = _snapshot({"B": JobStatus.SUCCESS, "U": JobStatus.UNKNOWN,
                      "T": JobStatus.PENDING}, [
        ("B", "T", "s(B) OR s(U)"), ("U", "T", "s(B) OR s(U)"),
    ])
    report = analyze_blockers(snap)
    assert report.waits["T"].result is Truth.TRUE
    assert report.waits["T"].explanation is ExplanationStatus.UNEXPLAINED
    assert not report.waits["T"].unresolved_gates
    assert not report.roots


def test_nested_or_unknown_is_relevant_when_no_success_alternative():
    snap = _snapshot({"A": JobStatus.FAILURE, "B": JobStatus.FAILURE,
                      "U": JobStatus.UNKNOWN, "T": JobStatus.PENDING}, [
        (source, "T", "s(A) AND (s(B) OR s(U))") for source in ("A", "B", "U")
    ])
    report = analyze_blockers(snap)
    assert report.waits["T"].result == Truth.FALSE
    assert report.waits["T"].root_paths == {"A": "A"}
    assert report.waits["T"].explanation is ExplanationStatus.PARTIALLY_EXPLAINED
    assert report.waits["T"].unresolved_gates == ["U"]


def test_unknown_without_false_gate_remains_unexplained():
    snap = _snapshot({"A": JobStatus.FAILURE, "U": JobStatus.UNKNOWN,
                      "T": JobStatus.PENDING}, [
        ("A", "T", "s(A) OR s(U)"), ("U", "T", "s(A) OR s(U)"),
    ])
    report = analyze_blockers(snap)
    assert report.waits["T"].result is Truth.UNKNOWN
    assert report.waits["T"].explanation is ExplanationStatus.UNEXPLAINED
    assert report.waits["T"].unresolved_gates == ["U"]
    assert not report.roots


def test_no_edges_does_not_infer_dependencies_from_containment():
    snap = _snapshot({"BOX": JobStatus.PENDING, "BAD": JobStatus.FAILURE,
                      "DOWN": JobStatus.PENDING}, [], parents={"BAD": "BOX", "DOWN": "BOX"})
    result = analyze_blockers(snap)
    assert result.quality.level == "unavailable"
    assert not result.roots
    assert result.unexplained_count == 2


def test_unsupported_partial_graph_never_fabricates_blockers():
    snap = _snapshot({"A": JobStatus.FAILURE, "B": JobStatus.PENDING,
                      "C": JobStatus.FAILURE, "D": JobStatus.PENDING}, [
        ("A", "B", "success(A) AND external(file)"),
        ("C", "D", "s(C)"),
    ])
    result = analyze_blockers(snap)
    assert result.quality.level == "partial"
    assert not result.conditions["B"].supported
    assert result.roots[0].uid == "C"
    assert result.waits["B"].root_paths == {}


def test_missing_external_reference_not_silently_discarded():
    snap = _snapshot({"A": JobStatus.FAILURE, "T": JobStatus.PENDING}, [
        ("A", "T", "s(A) AND s(EXTERNAL_JOB)"),
    ])
    result = analyze_blockers(snap)
    assert result.quality.level == "unavailable"
    assert not result.roots
    assert "EXTERNAL_JOB" in result.conditions["T"].warning


def test_missing_predecessor_edge_invalidates_otherwise_valid_target_gate():
    snap = _snapshot({"A": JobStatus.FAILURE, "T": JobStatus.PENDING,
                      "FINAL": JobStatus.PENDING}, [
        ("A", "T", "s(A)"),
        ("MISSING", "T", "s(A)"),
        ("T", "FINAL", "s(T)"),
    ])
    result = analyze_blockers(snap, critical_names=["FINAL"])
    assert result.quality.level == "partial"
    assert result.quality.verified_targets == 1
    assert result.quality.unverified_targets == 1
    assert "1 invalid incoming dependency edge" in result.conditions["T"].warning
    assert not result.conditions["T"].supported
    assert not result.roots
    assert result.waits["T"].root_paths == {}
    assert result.waits["T"].issue == result.conditions["T"].warning
    assert result.waits["FINAL"].root_paths == {}
    assert result.path("A", "FINAL") == ()
    assert result.suspected[0].uid == "A"
    assert result.suspected[0].targets == {"T"}


def test_only_invalid_incoming_edge_is_reported_as_unverified_target():
    snap = _snapshot({"T": JobStatus.PENDING}, [("UNKNOWN", "T", "success")])
    result = analyze_blockers(snap)
    assert result.quality.level == "unavailable"
    assert result.quality.unverified_targets == 1
    assert result.quality.waiting_without_edges == 1
    assert "invalid incoming dependency" in result.conditions["T"].warning
    assert not result.roots


def test_invalid_edge_does_not_downgrade_unrelated_valid_conditions():
    snap = _snapshot({"A": JobStatus.FAILURE, "T": JobStatus.PENDING,
                      "B": JobStatus.FAILURE, "U": JobStatus.PENDING}, [
        ("A", "T", "success"),
        ("MISSING", "T", "success"),
        ("B", "U", "s(B)"),
    ])
    result = analyze_blockers(snap)
    assert result.quality.level == "partial"
    assert result.quality.verified_targets == 1
    assert result.quality.unverified_targets == 1
    assert {root.uid for root in result.roots} == {"B"}
    assert result.path("B", "U") == ("B", "U")
    assert result.waits["T"].root_paths == {}


def test_invalid_self_dependency_never_confirms_remaining_condition():
    snap = _snapshot({"A": JobStatus.FAILURE, "T": JobStatus.PENDING}, [
        ("A", "T", "s(A)"),
        ("T", "T", "s(A)"),
    ])
    result = analyze_blockers(snap)
    assert result.quality.level == "unavailable"
    assert result.quality.unverified_targets == 1
    assert not result.roots
    assert "invalid incoming dependency" in result.waits["T"].issue
    assert not any("cyclic" in warning for warning in result.quality.warnings)


def test_edge_to_nonexistent_target_only_reduces_global_readiness():
    snap = _snapshot({"A": JobStatus.FAILURE, "T": JobStatus.PENDING}, [
        ("A", "T", "s(A)"),
        ("A", "GHOST", "s(A)"),
    ])
    result = analyze_blockers(snap)
    assert result.quality.level == "partial"
    assert result.quality.verified_targets == 1
    assert result.quality.unverified_targets == 0
    assert {root.uid for root in result.roots} == {"A"}
    assert result.path("A", "T") == ("A", "T")


def test_unknown_status_cannot_be_labeled_false():
    snap = _snapshot({"A": JobStatus.UNKNOWN, "T": JobStatus.PENDING}, [
        ("A", "T", "s(A)"),
    ])
    result = analyze_blockers(snap)
    assert result.waits["T"].result == Truth.UNKNOWN
    assert not result.roots


def test_cycles_never_trigger_infinite_explanation():
    snap = _snapshot({"A": JobStatus.PENDING, "B": JobStatus.PENDING}, [
        ("A", "B", "s(A)"),
        ("B", "A", "s(B)"),
    ])
    result = analyze_blockers(snap)
    assert result.quality.level == "partial"
    assert not result.roots
    assert "cyclic" in result.waits["A"].issue.lower()


def test_legacy_explicit_conditions_form_and_not_or():
    snap = _snapshot({"A": JobStatus.FAILURE, "B": JobStatus.SUCCESS,
                      "T": JobStatus.PENDING}, [
        ("A", "T", "success"),
        ("B", "T", "success"),
    ])
    result = analyze_blockers(snap)
    assert result.roots[0].uid == "A"
    assert result.waits["T"].condition == "success(A) AND success(B)"


def test_adapter_disables_dependency_proof():
    snap = _snapshot({"A": JobStatus.FAILURE, "T": JobStatus.PENDING},
                     [("A", "T", "s(A)")], declared=False)
    result = analyze_blockers(snap)
    assert result.quality.level == "unavailable"
    assert not result.roots


def test_critical_preferences_are_local_and_do_not_mutate_snapshot(monkeypatch, tmp_path):
    from app.services import blockers_targets
    monkeypatch.setattr(blockers_targets, "_path", lambda: tmp_path / "critical.json")
    snap = _snapshot({"A": JobStatus.FAILURE, "T": JobStatus.PENDING}, [("A", "T", "s(A)")])
    original = snap.model_dump_json()
    assert not get_critical_targets(snap)
    set_critical_target(snap, "T", True)
    assert get_critical_targets(snap) == {"T"}
    set_critical_target(snap, "T", False)
    assert not get_critical_targets(snap)
    assert snap.model_dump_json() == original


def test_routes_render_root_wait_and_quality_tabs_and_critical_controls(monkeypatch, tmp_path):
    from app.services import blockers_targets
    monkeypatch.setattr(blockers_targets, "_path", lambda: tmp_path / "targets.json")
    snap = _snapshot({"A": JobStatus.FAILURE, "T": JobStatus.PENDING}, [("A", "T", "s(A)")])
    class Record:
        environment_id = "unit-test"
        snapshot_id = snap.snapshot_id
        label = "Unit test snapshot"
        source_scope = "2026-10-08"
    class Catalog:
        def list(self, *, environment_id):
            return [Record()] if environment_id == "unit-test" else []
        def load(self, snapshot_id):
            return (snap, Record()) if snapshot_id == snap.snapshot_id else None
    monkeypatch.setattr(route, "snapshot_catalog", Catalog())
    monkeypatch.setattr(route, "load_environments", lambda: [type("Env", (), {"id":"unit-test", "display_name":"Unit Test"})()])
    client = TestClient(app)
    page = client.get("/blockers")
    assert page.status_code == 200
    assert 'href="/blockers"' in page.text
    assert "Blockers analysis" in page.text
    analyze = client.post("/api/blockers/analyze", data={"snapshot_id": snap.snapshot_id, "environment_id": "unit-test"})
    assert analyze.status_code == 200, analyze.text
    assert "Potential incidents" in analyze.text
    assert "Unit test snapshot" in analyze.text
    session_id = next(reversed(route._sessions))
    root = client.get("/api/blockers/list", params={"session_id":session_id})
    assert root.status_code == 200 and "Explore" in root.text
    wait = client.get("/api/blockers/list", params={"session_id":session_id, "view":"waits"})
    assert wait.status_code == 200 and "Inspect" in wait.text
    detail = client.get("/api/blockers/explain", params={"session_id":session_id, "uid":"T", "mode":"wait"})
    assert detail.status_code == 200 and "s(A)" in detail.text and "A" in detail.text
    quality = client.get("/api/blockers/list", params={"session_id":session_id, "view":"quality"})
    assert quality.status_code == 200 and "Dependency readiness audit" in quality.text
    update = client.post("/api/blockers/critical", data={"session_id":session_id, "uid":"T", "enabled":"true"})
    assert update.status_code == 200 and "Critical targets impacted" in update.text
    assert get_critical_targets(snap) == {"T"}
    json_result = client.get("/api/blockers/report", params={"session_id":session_id}).json()
    assert json_result["totals"]["impacted_critical"] == 1
    path = client.get("/api/blockers/path", params={"session_id": session_id,
               "root_uid": "A", "target_uid": "T"})
    assert path.status_code == 200
    assert [node["uid"] for node in path.json()["nodes"]] == ["A", "T"]
    invalid_path = client.get("/api/blockers/path", params={"session_id": session_id,
               "root_uid": "T", "target_uid": "A"})
    assert invalid_path.status_code == 404
    bad = client.post("/api/blockers/analyze", data={"snapshot_id":snap.snapshot_id, "environment_id":"wrong"})
    assert bad.status_code == 400


def test_invalid_edges_are_visible_in_data_quality_and_wait_explanation(monkeypatch):
    snap = _snapshot({"A": JobStatus.FAILURE, "T": JobStatus.PENDING,
                      "B": JobStatus.FAILURE, "U": JobStatus.PENDING}, [
        ("A", "T", "s(A)"),
        ("MISSING", "T", "s(A)"),
        ("B", "U", "s(B)"),
    ])

    class Record:
        environment_id = "unit-test"
        snapshot_id = snap.snapshot_id
        label = "Damaged dependency snapshot"
        source_scope = "2026-10-08"

    class Catalog:
        def load(self, snapshot_id):
            return (snap, Record()) if snapshot_id == snap.snapshot_id else None

    monkeypatch.setattr(route, "snapshot_catalog", Catalog())
    client = TestClient(app)
    response = client.post("/api/blockers/analyze", data={
        "snapshot_id": snap.snapshot_id, "environment_id": "unit-test",
    })
    assert response.status_code == 200
    session_id = next(reversed(route._sessions))

    quality = client.get("/api/blockers/list", params={"session_id": session_id, "view": "quality"})
    assert quality.status_code == 200
    assert "Unverified conditions" in quality.text
    assert "1 invalid incoming dependency edge" in quality.text

    explain = client.get("/api/blockers/explain", params={
        "session_id": session_id, "uid": "T", "mode": "wait",
    })
    assert explain.status_code == 200
    assert "1 invalid incoming dependency edge" in explain.text
    assert "No confirmed root cause" in explain.text

    report = client.get("/api/blockers/report", params={"session_id": session_id}).json()
    assert report["quality"]["level"] == "partial"
    assert report["quality"]["verified_targets"] == 1
    assert report["quality"]["unverified_targets"] == 1
    assert [entry["uid"] for entry in report["blockers"]] == ["B"]


def test_partial_explanation_shows_in_waits_explorer_quality_and_json(monkeypatch):
    snap = _snapshot({"A": JobStatus.FAILURE, "U": JobStatus.UNKNOWN,
                      "T": JobStatus.PENDING}, [
        ("A", "T", "s(A) AND s(U)"),
        ("U", "T", "s(A) AND s(U)"),
    ])

    class Record:
        environment_id = "unit-test"
        snapshot_id = snap.snapshot_id
        label = "Partial wait snapshot"
        source_scope = "2026-10-08"

    class Catalog:
        def load(self, snapshot_id):
            return (snap, Record()) if snapshot_id == snap.snapshot_id else None

    monkeypatch.setattr(route, "snapshot_catalog", Catalog())
    client = TestClient(app)
    response = client.post("/api/blockers/analyze", data={
        "snapshot_id": snap.snapshot_id, "environment_id": "unit-test",
    })
    assert response.status_code == 200
    assert "Partially explained waits" in response.text
    assert "Incomplete wait explanations" in response.text
    session_id = next(reversed(route._sessions))

    waits = client.get("/api/blockers/list", params={"session_id": session_id, "view": "waits"})
    assert waits.status_code == 200
    assert "Partially Explained" in waits.text
    quality = client.get("/api/blockers/list", params={"session_id": session_id, "view": "quality"})
    assert quality.status_code == 200
    assert "Partially explained waits" in quality.text

    explain = client.get("/api/blockers/explain", params={
        "session_id": session_id, "uid": "T", "mode": "wait",
    })
    assert explain.status_code == 200
    assert "PARTIALLY EXPLAINED" in explain.text
    assert "Required predecessors with unknown state" in explain.text
    assert "U — unknown" in explain.text
    assert "Resolved root blockers" in explain.text

    blocker = client.get("/api/blockers/explain", params={
        "session_id": session_id, "uid": "A", "mode": "blocker",
    })
    assert blocker.status_code == 200
    assert "Partially Explained" in blocker.text

    result = client.get("/api/blockers/report", params={"session_id": session_id}).json()
    assert result["quality"]["level"] == "verified"
    assert result["totals"]["blocked_waits"] == 1
    assert result["totals"]["fully_explained_waits"] == 0
    assert result["totals"]["partially_explained_waits"] == 1
    assert result["incomplete_waits_sample"] == [{
        "uid": "T", "confirmed_contributing_roots": ["A"],
        "unknown_predecessors": ["U"], "incomplete_upstream": [],
    }]


def test_mixed_missing_and_legacy_conditions_stay_unknown():
    snap = _snapshot({"A": JobStatus.FAILURE, "B": JobStatus.FAILURE,
                      "T": JobStatus.PENDING}, [("A", "T", "success"), ("B", "T", "")])
    result = analyze_blockers(snap)
    assert result.quality.level == "unavailable"
    assert not result.roots


def test_ambiguous_job_names_do_not_resolve_to_arbitrary_uid():
    snap = _snapshot({"A1": JobStatus.FAILURE, "A2": JobStatus.FAILURE,
                      "T": JobStatus.PENDING}, [("A1", "T", "s(A)")])
    snap.flat_jobs[0].scheduler_job_name = "A"
    snap.flat_jobs[1].scheduler_job_name = "A"
    result = analyze_blockers(snap)
    assert not result.roots
    assert "ambiguous" in result.conditions["T"].warning.lower()


def test_already_running_downstream_is_not_currently_blocked():
    snap = _snapshot({"BAD": JobStatus.FAILURE, "RUN": JobStatus.RUNNING},
                     [("BAD", "RUN", "s(BAD)")])
    result = analyze_blockers(snap)
    assert not result.roots
    assert result.quality.runtime_conflicts == 1


def test_suspected_gates_remain_distinct_from_confirmed():
    snap = _snapshot({"BAD": JobStatus.FAILURE, "T": JobStatus.PENDING},
                     [("BAD", "T", "unsupported(BAD)")])
    result = analyze_blockers(snap)
    assert result.confirmed_count == 0
    assert len(result.suspected) == 1
    assert result.suspected[0].uid == "BAD"
    assert result.suspected[0].targets == {"T"}


def test_deep_chain_uses_bounded_memory_and_iterative_proof():
    count = 5000
    statuses = {f"J{i}": JobStatus.FAILURE if i == 0 else JobStatus.PENDING
                for i in range(count)}
    edges = [(f"J{i - 1}", f"J{i}", "success") for i in range(1, count)]
    result = analyze_blockers(_snapshot(statuses, edges))
    assert result.confirmed_count == 1
    assert result.roots[0].impact_count == count - 1
    assert len(result.path("J0", f"J{count - 1}")) == count
    # Only one predecessor pointer per (root, blocked target), not entire path copies.
    assert sum(len(wait.root_paths) for wait in result.waits.values()) == count - 1


def _autosys_box(snapshot: TopologySnapshot, uid: str, *, success: str | None = None,
                 failure: str | None = None) -> None:
    box = next(job for job in snapshot.flat_jobs if job.job_uid == uid)
    box.autosys.jil.job_type = "BOX"
    box.autosys.jil.box_success = success
    box.autosys.jil.box_failure = failure


def test_box_completion_proves_nested_failure_to_external_critical_target():
    snap = _snapshot({"TOP": JobStatus.RUNNING, "INNER": JobStatus.RUNNING,
                      "BROKEN": JobStatus.FAILURE, "REPORT": JobStatus.PENDING}, [
        ("TOP", "REPORT", "s(TOP)"),
    ], parents={"INNER": "TOP", "BROKEN": "INNER"})
    _autosys_box(snap, "TOP", success="s(INNER)")
    _autosys_box(snap, "INNER", success="success(BROKEN)")
    result = analyze_blockers(snap, critical_names=["REPORT"])
    assert result.confirmed_count == 1
    assert result.roots[0].uid == "BROKEN"
    assert result.roots[0].critical_targets == {"REPORT"}
    assert result.roots[0].impact_count == 1  # Boxes are transit nodes, not waiting jobs.
    assert result.path("BROKEN", "REPORT") == ("BROKEN", "INNER", "TOP", "REPORT")
    assert result.boxes["TOP"].explanation is ExplanationStatus.FULLY_EXPLAINED
    assert result.boxes["INNER"].explanation is ExplanationStatus.FULLY_EXPLAINED
    assert result.quality.boxes_resolved == 2
    assert result.evidence_for("TOP") == "box_success: s(INNER)"
    assert result.waits["REPORT"].explanation is ExplanationStatus.FULLY_EXPLAINED
    assert len(snap.edges) == 1  # No synthetic graph edges are added to the snapshot.


def test_box_failure_rule_explains_terminal_box_failure():
    snap = _snapshot({"BOX": JobStatus.FAILURE, "BAD": JobStatus.FAILURE,
                      "REPORT": JobStatus.PENDING}, [("BOX", "REPORT", "s(BOX)")],
                     parents={"BAD": "BOX"})
    _autosys_box(snap, "BOX", failure="f(BAD)")
    result = analyze_blockers(snap)
    assert [root.uid for root in result.roots] == ["BAD"]
    assert result.path("BAD", "REPORT") == ("BAD", "BOX", "REPORT")
    assert result.evidence_for("BOX") == "box_failure: f(BAD)"


def test_box_success_or_alternative_prevents_false_internal_cause():
    snap = _snapshot({"BOX": JobStatus.RUNNING, "BAD": JobStatus.FAILURE,
                      "GOOD": JobStatus.SUCCESS, "T": JobStatus.PENDING},
                     [("BOX", "T", "s(BOX)")],
                     parents={"BAD": "BOX", "GOOD": "BOX"})
    _autosys_box(snap, "BOX", success="s(BAD) OR s(GOOD)")
    report = analyze_blockers(snap)
    assert [r.uid for r in report.roots] == ["BOX"]
    assert report.waits["T"].explanation is ExplanationStatus.PARTIALLY_EXPLAINED
    assert not report.boxes["BOX"].root_paths
    assert report.boxes["BOX"].result is Truth.TRUE
    assert "conflicts" in report.boxes["BOX"].issue


def test_box_success_false_and_unknown_promotes_proven_gate_as_partial():
    snap = _snapshot({"BOX": JobStatus.RUNNING, "BAD": JobStatus.FAILURE,
                      "UNK": JobStatus.UNKNOWN, "T": JobStatus.PENDING},
                     [("BOX", "T", "s(BOX)")],
                     parents={"BAD": "BOX", "UNK": "BOX"})
    _autosys_box(snap, "BOX", success="s(BAD) AND s(UNK)")
    report = analyze_blockers(snap)
    assert {r.uid for r in report.roots} == {"BAD"}
    assert report.path("BAD", "T") == ("BAD", "BOX", "T")
    assert report.boxes["BOX"].unresolved_gates == ["UNK"]
    assert report.boxes["BOX"].explanation is ExplanationStatus.PARTIALLY_EXPLAINED
    assert report.waits["T"].explanation is ExplanationStatus.PARTIALLY_EXPLAINED
    assert report.waits["T"].unresolved_predecessors == ["BOX"]


@pytest.mark.parametrize("scenario", ["missing", "unsupported", "external", "ambiguous", "not_started"])
def test_unverified_box_completion_never_promotes_contained_failure(scenario: str):
    snap = _snapshot({"BOX": JobStatus.PENDING if scenario == "not_started" else JobStatus.RUNNING,
                      "BAD": JobStatus.FAILURE, "OUTSIDE": JobStatus.SUCCESS,
                      "T": JobStatus.PENDING}, [("BOX", "T", "s(BOX)")],
                     parents={"BAD": "BOX"})
    rule = {"missing": None, "unsupported": "e(BAD)=1", "external": "s(OUTSIDE)",
            "ambiguous": "s(BAD)", "not_started": "s(BAD)"}[scenario]
    _autosys_box(snap, "BOX", success=rule)
    if scenario == "ambiguous":
        snap.flat_jobs.append(SnapshotJob(job_uid="DUP", scheduler_job_name="BAD",
                                          status=JobStatus.SUCCESS, parent_uid="BOX"))
    report = analyze_blockers(snap)
    assert not any(root.uid == "BAD" for root in report.roots)
    if scenario == "not_started":
        assert not report.roots  # A waiting box has no proven internal or upstream root.
    else:
        assert [root.uid for root in report.roots] == ["BOX"]
        assert report.waits["T"].explanation is ExplanationStatus.PARTIALLY_EXPLAINED


def test_process_scheduler_box_attributes_are_not_autosys_proofs():
    snap = _snapshot({"BOX": JobStatus.RUNNING, "BAD": JobStatus.FAILURE,
                      "T": JobStatus.PENDING}, [("BOX", "T", "s(BOX)")],
                     parents={"BAD": "BOX"}, scheduler=SchedulerType.PROCESS_SCHEDULER)
    _autosys_box(snap, "BOX", success="s(BAD)")
    report = analyze_blockers(snap)
    assert report.boxes == {}
    assert [root.uid for root in report.roots] == ["BOX"]


def test_box_failure_condition_true_or_unknown_does_not_promote_unknown_branch():
    snap = _snapshot({"BOX": JobStatus.FAILURE, "BAD": JobStatus.FAILURE,
                      "UNKNOWN": JobStatus.UNKNOWN, "T": JobStatus.PENDING},
                     [("BOX", "T", "s(BOX)")],
                     parents={"BAD": "BOX", "UNKNOWN": "BOX"})
    _autosys_box(snap, "BOX", failure="f(BAD) OR f(UNKNOWN)")
    report = analyze_blockers(snap)
    assert [root.uid for root in report.roots] == ["BAD"]
    assert report.boxes["BOX"].explanation is ExplanationStatus.FULLY_EXPLAINED
    assert not report.boxes["BOX"].unresolved_gates


def test_box_completion_cyclic_proof_never_claims_a_root():
    snap = _snapshot({"BOX": JobStatus.RUNNING, "CHILD": JobStatus.PENDING,
                      "T": JobStatus.PENDING}, [
        ("BOX", "CHILD", "s(BOX)"), ("BOX", "T", "s(BOX)"),
    ], parents={"CHILD": "BOX"})
    _autosys_box(snap, "BOX", success="s(CHILD)")
    report = analyze_blockers(snap)
    assert not report.roots
    assert "cyclic" in " ".join(report.quality.warnings).lower()
    assert report.waits["T"].explanation is ExplanationStatus.UNEXPLAINED


def test_box_completion_ui_and_diagnostic_path(monkeypatch):
    snap = _snapshot({"BOX": JobStatus.RUNNING, "BAD": JobStatus.FAILURE,
                      "T": JobStatus.PENDING}, [("BOX", "T", "s(BOX)")],
                     parents={"BAD": "BOX"})
    _autosys_box(snap, "BOX", success="s(BAD)")

    class Record:
        environment_id = "unit-test"
        label = "Box resolution test"
        source_scope = "test"

    class Catalog:
        def load(self, snapshot_id):
            return (snap, Record()) if snapshot_id == snap.snapshot_id else None

    monkeypatch.setattr(route, "snapshot_catalog", Catalog())
    client = TestClient(app)
    response = client.post("/api/blockers/analyze", data={
        "snapshot_id": snap.snapshot_id, "environment_id": "unit-test"})
    assert response.status_code == 200
    sid = next(reversed(route._sessions))
    diag = client.get("/api/blockers/report", params={"session_id": sid}).json()
    assert diag["box_resolution"]["resolved_boxes"] == 1
    assert diag["blockers"][0]["uid"] == "BAD"
    path = client.get("/api/blockers/path", params={
        "session_id": sid, "root_uid": "BAD", "target_uid": "T"}).json()
    assert [entry["uid"] for entry in path["nodes"]] == ["BAD", "BOX", "T"]
    assert path["nodes"][1]["evidence_type"] == "box_completion_rule"
    assert path["nodes"][1]["required_condition"] == "box_success: s(BAD)"
    detail = client.get("/api/blockers/explain", params={
        "session_id": sid, "uid": "BAD", "mode": "blocker"})
    assert detail.status_code == 200 and "box_success: s(BAD)" in detail.text
    quality = client.get("/api/blockers/list", params={"session_id": sid, "view": "quality"})
    assert quality.status_code == 200
    assert "Active AutoSys box completion rules" in quality.text
    assert "Boxes with internal gates" in quality.text


def test_box_previous_run_child_status_is_not_misreported_as_proven_root():
    snap = _snapshot({"BOX": JobStatus.RUNNING, "BAD": JobStatus.FAILURE,
                      "T": JobStatus.PENDING}, [("BOX", "T", "s(BOX)")],
                     parents={"BAD": "BOX"})
    _autosys_box(snap, "BOX", success="s(BAD)")
    box = next(job for job in snap.flat_jobs if job.job_uid == "BOX")
    child = next(job for job in snap.flat_jobs if job.job_uid == "BAD")
    box.actual_start = datetime(2026, 10, 8, 10, tzinfo=timezone.utc)
    child.actual_end = datetime(2026, 10, 8, 9, tzinfo=timezone.utc)
    result = analyze_blockers(snap)
    assert [root.uid for root in result.roots] == ["BOX"]
    assert result.quality.box_rules_unverified == 1
    assert "previous-run" in result.boxes["BOX"].issue
    assert result.waits["T"].explanation is ExplanationStatus.PARTIALLY_EXPLAINED


def test_operational_categories_do_not_confuse_success_with_failure_incident():
    from app.services.blockers import OperationalKind

    snap = _snapshot({
        "OK": JobStatus.SUCCESS, "FAILED": JobStatus.FAILURE,
        "RUN": JobStatus.RUNNING, "HELD": JobStatus.DISABLED,
        "FAILURE_BRANCH": JobStatus.PENDING, "ERROR_BRANCH": JobStatus.PENDING,
        "RUN_BRANCH": JobStatus.PENDING, "HELD_BRANCH": JobStatus.PENDING,
    }, [
        ("OK", "FAILURE_BRANCH", "failure(OK)"),
        ("FAILED", "ERROR_BRANCH", "success(FAILED)"),
        ("RUN", "RUN_BRANCH", "done(RUN)"),
        ("HELD", "HELD_BRANCH", "success(HELD)"),
    ])
    report = analyze_blockers(snap, critical_names=["FAILURE_BRANCH", "ERROR_BRANCH"])
    kinds = {entry.uid: entry.operational_kind for entry in report.roots}
    assert kinds == {
        "OK": OperationalKind.CONDITION_GATE,
        "FAILED": OperationalKind.POTENTIAL_INCIDENT,
        "RUN": OperationalKind.RUNNING_GATE,
        "HELD": OperationalKind.CONDITION_GATE,
    }
    assert (report.potential_incident_count, report.running_gate_count, report.condition_gate_count) == (1, 1, 2)
    assert report.confirmed_count == 3  # Deprecated count preserves prior JSON semantics.
    assert report.active_count == 1
    assert report.path("OK", "FAILURE_BRANCH") == ("OK", "FAILURE_BRANCH")
    assert report.path("FAILED", "ERROR_BRANCH") == ("FAILED", "ERROR_BRANCH")
    assert report.impacted_critical_count == 2


def test_classification_does_not_invent_an_incident_for_satisfied_or_fallback():
    snap = _snapshot({"BAD": JobStatus.FAILURE, "GOOD": JobStatus.SUCCESS,
                      "T": JobStatus.PENDING}, [
        ("BAD", "T", "success(BAD) OR success(GOOD)"),
        ("GOOD", "T", "success(BAD) OR success(GOOD)"),
    ])
    report = analyze_blockers(snap)
    assert report.potential_incident_count == 0
    assert report.condition_gate_count == 0
    assert report.running_gate_count == 0
    assert not report.roots


def test_operational_categories_ui_filters_and_json(monkeypatch):
    snap = _snapshot({"OK": JobStatus.SUCCESS, "BROKEN": JobStatus.FAILURE,
                      "RUN": JobStatus.RUNNING, "T1": JobStatus.PENDING,
                      "T2": JobStatus.PENDING, "T3": JobStatus.PENDING}, [
        ("OK", "T1", "f(OK)"),
        ("BROKEN", "T2", "s(BROKEN)"),
        ("RUN", "T3", "s(RUN)"),
    ])

    class Record:
        environment_id = "unit-test"
        label = "Operational triage test"
        source_scope = "test"

    class Catalog:
        def load(self, snapshot_id):
            return (snap, Record()) if snapshot_id == snap.snapshot_id else None

    monkeypatch.setattr(route, "snapshot_catalog", Catalog())
    client = TestClient(app)
    response = client.post("/api/blockers/analyze", data={
        "snapshot_id": snap.snapshot_id, "environment_id": "unit-test"})
    assert response.status_code == 200
    assert "Potential incidents" in response.text
    assert "Running gates" in response.text
    assert "Condition gates" in response.text
    sid = next(reversed(route._sessions))
    diagnostic = client.get("/api/blockers/report", params={"session_id": sid}).json()
    assert diagnostic["totals"]["potential_incidents"] == 1
    assert diagnostic["totals"]["running_gates"] == 1
    assert diagnostic["totals"]["condition_gates"] == 1
    assert diagnostic["totals"]["confirmed"] == 2  # Backward compatibility.
    assert {entry["uid"]: entry["operational_kind"] for entry in diagnostic["blockers"]} == {
        "OK": "condition_gate", "BROKEN": "potential_incident", "RUN": "running_gate"}
    assert {entry["uid"]: entry["classification"] for entry in diagnostic["blockers"]} == {
        "OK": "confirmed", "BROKEN": "confirmed", "RUN": "active"}
    import re
    for category, expected in [
        ("potential_incident", {"BROKEN"}),
        ("running_gate", {"RUN"}),
        ("condition_gate", {"OK"}),
        ("confirmed", {"BROKEN", "OK"}),
    ]:
        root_list = client.get("/api/blockers/list", params={
            "session_id": sid, "view": "roots", "classification": category})
        assert root_list.status_code == 200
        assert set(re.findall(r"<td><strong>(\w+)</strong>", root_list.text)) == expected
    root_list = client.get("/api/blockers/list", params={
        "session_id": sid, "view": "roots", "classification": "condition_gate"})
    assert "not a failure incident" in root_list.text
    for category, wanted, unwanted in [
        ("potential_incident", "T2", ("T1", "T3")),
        ("running_gate", "T3", ("T1", "T2")),
        ("condition_gate", "T1", ("T2", "T3")),
    ]:
        waits = client.get("/api/blockers/list", params={
            "session_id": sid, "view": "waits", "classification": category})
        assert waits.status_code == 200
        assert wanted in waits.text
        assert all(other not in waits.text for other in unwanted)
    detail = client.get("/api/blockers/explain", params={
        "session_id": sid, "uid": "OK", "mode": "blocker"})
    assert detail.status_code == 200
    assert "Condition gate" in detail.text
    assert "not evidence of a failed job" in detail.text
    path = client.get("/api/blockers/path", params={
        "session_id": sid, "root_uid": "OK", "target_uid": "T1"})
    assert path.status_code == 200
    assert [node["uid"] for node in path.json()["nodes"]] == ["OK", "T1"]


def test_cyclic_waits_preserve_independent_gate_on_downstream_target():
    snap = _snapshot({
        "A": JobStatus.PENDING, "B": JobStatus.PENDING,
        "FAILED": JobStatus.FAILURE, "T": JobStatus.PENDING,
    }, [
        ("A", "B", "s(A)"), ("B", "A", "s(B)"),
        ("A", "T", "s(A) AND s(FAILED)"),
        ("FAILED", "T", "s(A) AND s(FAILED)"),
    ])
    report = analyze_blockers(snap, critical_names=["T"])
    assert report.quality.cyclic_jobs == 2
    assert report.quality.cycle_affected_jobs == 1
    assert {root.uid for root in report.roots} == {"FAILED"}
    assert report.path("FAILED", "T") == ("FAILED", "T")
    assert report.roots[0].critical_targets == {"T"}
    assert report.waits["T"].explanation is ExplanationStatus.PARTIALLY_EXPLAINED
    assert report.waits["T"].unresolved_predecessors == ["A"]
    assert not report.waits["A"].root_paths
    assert not report.waits["B"].root_paths


def test_external_failure_can_be_traced_out_of_cycle_without_traversing_inside_it():
    snap = _snapshot({
        "FAIL": JobStatus.FAILURE, "A": JobStatus.PENDING,
        "B": JobStatus.PENDING, "AFTER": JobStatus.PENDING,
    }, [
        ("B", "A", "s(B) AND s(FAIL)"),
        ("FAIL", "A", "s(B) AND s(FAIL)"),
        ("A", "B", "s(A)"), ("A", "AFTER", "s(A)"),
    ])
    report = analyze_blockers(snap)
    assert {root.uid for root in report.roots} == {"FAIL"}
    assert report.roots[0].targets == {"A", "AFTER"}
    assert report.path("FAIL", "AFTER") == ("FAIL", "A", "AFTER")
    assert report.path("FAIL", "B") == ()
    assert report.waits["A"].explanation is ExplanationStatus.PARTIALLY_EXPLAINED
    assert report.waits["AFTER"].explanation is ExplanationStatus.PARTIALLY_EXPLAINED
    assert report.waits["AFTER"].unresolved_predecessors == ["A"]


def test_disconnected_cycle_does_not_downgrade_verified_acyclic_waits():
    snap = _snapshot({
        "A": JobStatus.PENDING, "B": JobStatus.PENDING,
        "FAIL": JobStatus.FAILURE, "GOOD_T": JobStatus.PENDING,
    }, [("A", "B", "s(A)"), ("B", "A", "s(B)"),
        ("FAIL", "GOOD_T", "s(FAIL)")])
    report = analyze_blockers(snap)
    assert report.quality.level == "partial"
    assert report.waits["GOOD_T"].explanation is ExplanationStatus.FULLY_EXPLAINED
    assert report.path("FAIL", "GOOD_T") == ("FAIL", "GOOD_T")
    assert report.waits["A"].explanation is ExplanationStatus.UNEXPLAINED
    assert {root.uid for root in report.roots} == {"FAIL"}


def test_cyclic_source_bypassed_by_successful_or_alternative():
    snap = _snapshot({"A": JobStatus.PENDING, "B": JobStatus.PENDING,
                      "GOOD": JobStatus.SUCCESS, "T": JobStatus.PENDING}, [
        ("B", "A", "s(B)"), ("A", "B", "s(A)"),
        ("A", "T", "s(A) OR s(GOOD)"),
        ("GOOD", "T", "s(A) OR s(GOOD)"),
    ])
    report = analyze_blockers(snap)
    assert report.waits["T"].result is Truth.TRUE
    assert report.waits["T"].explanation is ExplanationStatus.UNEXPLAINED
    assert not report.roots


def test_cycle_quality_and_partial_path_visible_in_ui_and_diagnostics(monkeypatch):
    snap = _snapshot({"FAIL": JobStatus.FAILURE, "A": JobStatus.PENDING,
                      "B": JobStatus.PENDING, "T": JobStatus.PENDING}, [
        ("B", "A", "s(B) AND s(FAIL)"),
        ("FAIL", "A", "s(B) AND s(FAIL)"),
        ("A", "B", "s(A)"), ("A", "T", "s(A)"),
    ])

    class Record:
        environment_id = "unit-test"
        label = "Cycle proof test"
        source_scope = "test"

    class Catalog:
        def load(self, snapshot_id):
            return (snap, Record()) if snapshot_id == snap.snapshot_id else None

    monkeypatch.setattr(route, "snapshot_catalog", Catalog())
    client = TestClient(app)
    response = client.post("/api/blockers/analyze", data={
        "snapshot_id": snap.snapshot_id, "environment_id": "unit-test"})
    assert response.status_code == 200
    sid = next(reversed(route._sessions))
    diag = client.get("/api/blockers/report", params={"session_id": sid}).json()
    assert diag["quality"]["cyclic_jobs"] == 2
    assert diag["quality"]["cycle_affected_jobs"] == 1
    quality = client.get("/api/blockers/list", params={"session_id": sid, "view": "quality"})
    assert quality.status_code == 200
    assert "Jobs inside cycles" in quality.text
    assert "Other downstream jobs" in quality.text
    detail = client.get("/api/blockers/explain", params={
        "session_id": sid, "uid": "T", "mode": "job"})
    assert detail.status_code == 200
    assert "Incomplete upstream explanations" in detail.text
    assert "cyclic dependency" in detail.text.lower()
    path = client.get("/api/blockers/path", params={
        "session_id": sid, "root_uid": "FAIL", "target_uid": "T"}).json()
    assert [node["uid"] for node in path["nodes"]] == ["FAIL", "A", "T"]


def test_cycle_through_explicit_box_completion_keeps_independent_child_failure():
    snap = _snapshot({"BOX": JobStatus.RUNNING, "CHILD": JobStatus.PENDING,
                      "BAD": JobStatus.FAILURE, "T": JobStatus.PENDING}, [
        ("BOX", "CHILD", "s(BOX)"), ("BOX", "T", "s(BOX)"),
    ], parents={"CHILD": "BOX", "BAD": "BOX"})
    _autosys_box(snap, "BOX", success="s(CHILD) AND s(BAD)")
    report = analyze_blockers(snap)
    assert report.quality.cyclic_jobs == 2
    assert {root.uid for root in report.roots} == {"BAD"}
    assert report.path("BAD", "T") == ("BAD", "BOX", "T")
    assert report.path("BAD", "CHILD") == ()
    assert report.boxes["BOX"].explanation is ExplanationStatus.PARTIALLY_EXPLAINED
    assert report.waits["T"].explanation is ExplanationStatus.PARTIALLY_EXPLAINED


def test_large_cyclic_graph_is_iterative_and_leaves_independent_proof_intact():
    count = 3000
    statuses = {f"N{i}": JobStatus.PENDING for i in range(count)}
    statuses.update({"FAIL": JobStatus.FAILURE, "TARGET": JobStatus.PENDING})
    edges = [(f"N{i}", f"N{(i + 1) % count}", "success") for i in range(count)]
    edges.append(("FAIL", "TARGET", "s(FAIL)"))
    report = analyze_blockers(_snapshot(statuses, edges))
    assert report.quality.cyclic_jobs == count
    assert report.quality.cycle_affected_jobs == 0
    assert report.quality.level == "partial"
    assert report.roots[0].uid == "FAIL"
    assert report.path("FAIL", "TARGET") == ("FAIL", "TARGET")
    assert report.waits["TARGET"].explanation is ExplanationStatus.FULLY_EXPLAINED


def test_critical_toggle_updates_fragments_without_resetting_workspace(monkeypatch, tmp_path):
    from app.services import blockers_targets
    monkeypatch.setattr(blockers_targets, "_path", lambda: tmp_path / "targets.json")
    snapshot = _snapshot({"A": JobStatus.FAILURE, "T": JobStatus.PENDING},
                         [("A", "T", "s(A)")])

    class Record:
        environment_id = "unit-test"
        label = "Critical toggle state"
        source_scope = "test"

    class Catalog:
        def load(self, snapshot_id):
            return (snapshot, Record()) if snapshot_id == snapshot.snapshot_id else None

    monkeypatch.setattr(route, "snapshot_catalog", Catalog())
    client = TestClient(app)
    analyzed = client.post("/api/blockers/analyze", data={
        "snapshot_id": snapshot.snapshot_id, "environment_id": "unit-test"})
    assert analyzed.status_code == 200
    assert 'id="blockers-filters"' in analyzed.text
    assert 'id="blockers-offset" name="offset" value="0"' in analyzed.text
    assert 'hx-vals=\'{"offset": 0}\'' in analyzed.text
    assert 'hx-trigger="load, blockers-critical-updated from:body"' in analyzed.text
    sid = next(reversed(route._sessions))

    detail = client.get("/api/blockers/explain", params={
        "session_id": sid, "uid": "T", "mode": "wait"})
    assert detail.status_code == 200
    assert 'hx-target="#blockers-detail"' in detail.text
    assert 'name="mode" value="wait"' in detail.text

    enabled = client.post("/api/blockers/critical", data={
        "session_id": sid, "uid": "T", "mode": "wait", "enabled": "true"})
    assert enabled.status_code == 200
    assert enabled.headers["hx-trigger-after-swap"] == "blockers-critical-updated"
    assert "Why is this waiting?" in enabled.text
    assert "Remove critical target" in enabled.text
    assert 'id="blockers-metrics"' in enabled.text
    assert 'hx-swap-oob="outerHTML"' in enabled.text
    assert "Critical targets impacted</span><strong>1" in enabled.text
    assert 'id="blockers-filters"' not in enabled.text
    assert 'id="blockers-list"' not in enabled.text
    assert 'id="blockers-output"' not in enabled.text

    updated_list = client.get("/api/blockers/list", params={
        "session_id": sid, "view": "jobs", "query": "T", "critical_only": True})
    assert updated_list.status_code == 200
    assert '<span class="blockers-critical">Critical</span>' in updated_list.text
    assert 'id="blockers-offset"' in updated_list.text
    assert 'hx-swap-oob="outerHTML"' in updated_list.text

    disabled = client.post("/api/blockers/critical", data={
        "session_id": sid, "uid": "T", "mode": "wait", "enabled": "false"})
    assert disabled.status_code == 200
    assert "Mark as critical target" in disabled.text
    assert "Critical targets impacted</span><strong>0" in disabled.text
    assert get_critical_targets(snapshot) == set()

    # The same fragment protocol must preserve the root blocker explorer, too.
    root_update = client.post("/api/blockers/critical", data={
        "session_id": sid, "uid": "A", "mode": "blocker", "enabled": "true"})
    assert root_update.status_code == 200
    assert "Downstream impact" in root_update.text
    assert 'name="mode" value="blocker"' in root_update.text
    assert 'hx-target="#blockers-detail"' in root_update.text
    assert 'id="blockers-filters"' not in root_update.text


def test_critical_toggle_retains_explorer_mode_and_list_page(monkeypatch, tmp_path):
    from app.services import blockers_targets
    monkeypatch.setattr(blockers_targets, "_path", lambda: tmp_path / "targets.json")
    statuses = {f"JOB_{n:03d}": JobStatus.SUCCESS for n in range(125)}
    snapshot = _snapshot(statuses, [])

    class Record:
        environment_id = "unit-test"
        label = "Paginated snapshot"
        source_scope = "test"

    class Catalog:
        def load(self, snapshot_id):
            return (snapshot, Record()) if snapshot_id == snapshot.snapshot_id else None

    monkeypatch.setattr(route, "snapshot_catalog", Catalog())
    client = TestClient(app)
    response = client.post("/api/blockers/analyze", data={
        "snapshot_id": snapshot.snapshot_id, "environment_id": "unit-test"})
    assert response.status_code == 200
    sid = next(reversed(route._sessions))

    page_two = client.get("/api/blockers/list", params={
        "session_id": sid, "view": "jobs", "offset": 100})
    assert page_two.status_code == 200
    assert "Showing 101–125" in page_two.text
    assert 'name="offset" value="100" hx-swap-oob="outerHTML"' in page_two.text
    assert "JOB_100" in page_two.text
    assert "JOB_000" not in page_two.text

    update = client.post("/api/blockers/critical", data={
        "session_id": sid, "uid": "JOB_110", "mode": "wait", "enabled": "true"})
    assert update.status_code == 200
    assert "JOB_110" in update.text
    assert 'name="mode" value="wait"' in update.text
    assert "Remove critical target" in update.text
    assert "Downstream impact" not in update.text

    page_two_after = client.get("/api/blockers/list", params={
        "session_id": sid, "view": "jobs", "offset": 100})
    assert "Showing 101–125" in page_two_after.text
    assert 'name="offset" value="100"' in page_two_after.text
    # Critical targets are sorted first, so the selected job can move to page one;
    # pagination stays at the same offset and the explorer retains its selection.
    assert "Showing 101–125" in page_two_after.text
    page_one = client.get("/api/blockers/list", params={
        "session_id": sid, "view": "jobs", "offset": 0})
    assert "JOB_110" in page_one.text
    assert '<span class="blockers-critical">Critical</span>' in page_one.text

    # Critical-only filtering can shrink pagination; clamp stale offsets to a valid page.
    critical_only = client.get("/api/blockers/list", params={
        "session_id": sid, "view": "jobs", "critical_only": True, "offset": 100})
    assert "JOB_110" in critical_only.text
    assert 'name="offset" value="0"' in critical_only.text
    assert "No matching results" not in critical_only.text

@pytest.fixture
def isolated_blockers_cache():
    """Keep cache limit/expiry tests isolated from older API integration sessions."""
    with route._lock:
        preserved = list(route._sessions.items())
        route._sessions.clear()
    yield
    with route._lock:
        route._sessions.clear()
        route._sessions.update(preserved)


def _cache_session(*, payload_bytes: int = 0) -> route._Session:
    from types import SimpleNamespace
    snap = _snapshot({"A": JobStatus.FAILURE, "T": JobStatus.PENDING},
                     [("A", "T", "s(A)")])
    report = analyze_blockers(snap)
    return route._Session(snapshot_id=snap.snapshot_id, environment_id="unit-test",
                          report=report,
                          record=SimpleNamespace(payload=b"x" * payload_bytes))


def test_cache_inactivity_ttl_and_touch(monkeypatch, isolated_blockers_cache):
    from types import SimpleNamespace
    clock = [10.0]
    monkeypatch.setattr(route, "monotonic", lambda: clock[0])
    monkeypatch.setattr(route, "get_settings", lambda: SimpleNamespace(
        blockers_cache_ttl_sec=10, blockers_cache_max_sessions=3, blockers_cache_max_mb=4))
    sid = route._put(_cache_session())
    assert sid
    clock[0] = 19.0
    assert route._get(sid) is not None
    clock[0] = 28.9
    assert route._get(sid) is not None
    clock[0] = 39.0
    assert route._get(sid) is None
    assert not route._sessions


def test_cache_is_lru_not_fifo(monkeypatch, isolated_blockers_cache):
    from types import SimpleNamespace
    monkeypatch.setattr(route, "get_settings", lambda: SimpleNamespace(
        blockers_cache_ttl_sec=3600, blockers_cache_max_sessions=2, blockers_cache_max_mb=4))
    a = route._put(_cache_session())
    b = route._put(_cache_session())
    assert route._get(a) is not None
    c = route._put(_cache_session())
    assert set(route._sessions) == {a, c}
    assert route._get(b) is None


def test_cache_memory_budget_evicts_and_rejects_oversized(monkeypatch, isolated_blockers_cache):
    from types import SimpleNamespace
    monkeypatch.setattr(route, "get_settings", lambda: SimpleNamespace(
        blockers_cache_ttl_sec=3600, blockers_cache_max_sessions=10, blockers_cache_max_mb=1))
    one = route._put(_cache_session(payload_bytes=600_000))
    assert one
    two = route._put(_cache_session(payload_bytes=600_000))
    assert two
    assert set(route._sessions) == {two}
    assert route._get(one) is None
    assert route._put(_cache_session(payload_bytes=1_100_000)) is None
    assert set(route._sessions) == {two}  # oversize request does not evict usable cache
    assert sum(item.retained_bytes for item in route._sessions.values()) <= 1024 * 1024


def test_reanalyzed_session_reaccounted_or_evicted(monkeypatch, isolated_blockers_cache):
    from types import SimpleNamespace
    monkeypatch.setattr(route, "get_settings", lambda: SimpleNamespace(
        blockers_cache_ttl_sec=3600, blockers_cache_max_sessions=3, blockers_cache_max_mb=1))
    first = route._put(_cache_session())
    second = route._put(_cache_session(payload_bytes=600_000))
    assert first and second
    updated = analyze_blockers(_snapshot({
        f"LONG_JOB_{i:04d}_{'x'*800}": JobStatus.SUCCESS for i in range(1400)
    }, []))
    assert route._replace_report(first, updated) is False
    assert route._get(first) is None
    assert route._get(second) is not None


def test_expired_cache_html_fragments_and_json(monkeypatch, isolated_blockers_cache):
    from types import SimpleNamespace
    clock = [0.0]
    monkeypatch.setattr(route, "monotonic", lambda: clock[0])
    monkeypatch.setattr(route, "get_settings", lambda: SimpleNamespace(
        blockers_cache_ttl_sec=5, blockers_cache_max_sessions=1, blockers_cache_max_mb=1))
    sid = route._put(_cache_session())
    assert sid
    clock[0] = 6.0
    client = TestClient(app)
    htmx = client.get("/api/blockers/list", params={"session_id": sid},
                      headers={"HX-Request": "true"})
    assert htmx.status_code == 200
    assert htmx.headers["HX-Retarget"] == "#blockers-output"
    assert "Analyze snapshot" in htmx.text
    regular = client.get("/api/blockers/explain", params={
        "session_id": sid, "uid": "A"})
    assert regular.status_code == 410
    assert client.get("/api/blockers/report", params={"session_id": sid}).status_code == 404
    assert client.get("/api/blockers/path", params={
        "session_id": sid, "root_uid": "A", "target_uid": "T"}).status_code == 404
    update = client.post("/api/blockers/critical", data={
        "session_id": sid, "uid": "T", "enabled": "true"},
        headers={"HX-Request": "true"})
    assert update.status_code == 200
    assert update.headers["HX-Retarget"] == "#blockers-output"


def test_oversized_analysis_replaces_stale_htmx_results(monkeypatch, isolated_blockers_cache):
    from types import SimpleNamespace
    snap = _snapshot({f"OVER_{i}_{'x'*750}": JobStatus.SUCCESS for i in range(1500)}, [])

    class Catalog:
        def load(self, snapshot_id):
            if snapshot_id == snap.snapshot_id:
                return snap, SimpleNamespace(environment_id="unit-test", label="Large", source_scope="test")
            return None

    monkeypatch.setattr(route, "snapshot_catalog", Catalog())
    monkeypatch.setattr(route, "get_settings", lambda: SimpleNamespace(
        blockers_cache_ttl_sec=3600, blockers_cache_max_sessions=12, blockers_cache_max_mb=1))
    client = TestClient(app)
    result = client.post("/api/blockers/analyze", data={
        "snapshot_id": snap.snapshot_id, "environment_id": "unit-test"},
        headers={"HX-Request": "true"})
    assert result.status_code == 200
    assert result.headers["HX-Retarget"] == "#blockers-output"
    assert "BLOCKERS_CACHE_MAX_MB" in result.text
    assert not route._sessions
    direct = client.post("/api/blockers/analyze", data={
        "snapshot_id": snap.snapshot_id, "environment_id": "unit-test"})
    assert direct.status_code == 413
