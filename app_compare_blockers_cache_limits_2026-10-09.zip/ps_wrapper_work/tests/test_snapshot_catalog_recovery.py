"""Non-destructive recovery of immutable snapshot catalog metadata."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.main import app
from app.models import AsOf, AsOfKind, ComparisonContext, JobStatus, SchedulerType, SnapshotJob, TopologySnapshot
from app.services.snapshot_catalog import SnapshotCatalogError, snapshot_catalog

client = TestClient(app)


def sample_snapshot(label: str = "one") -> TopologySnapshot:
    return TopologySnapshot(
        context=ComparisonContext(
            environment_id="autosys-u1",
            scheduler=SchedulerType.AUTOSYS,
            as_of=AsOf(kind=AsOfKind.BUSINESS_DATE, value="2026-10-07"),
        ),
        fetched_at=datetime(2026, 10, 8, 8, 30, tzinfo=timezone.utc),
        flat_jobs=[SnapshotJob(
            job_uid=f"uid-{label}", scheduler_job_name=f"BATCH_{label}",
            status=JobStatus.SUCCESS,
        )],
    )


def corrupt_index(contents: bytes = b'{"snapshots": [broken') -> Path:
    path = snapshot_catalog.index_path
    path.write_bytes(contents)
    return path


def test_missing_index_with_no_payloads_is_a_new_healthy_catalog():
    assert snapshot_catalog.list() == []
    assert not snapshot_catalog.health().read_only
    assert snapshot_catalog.save(sample_snapshot())


def test_corrupt_index_provides_read_only_access_and_preserves_original():
    snapshot = sample_snapshot()
    record = snapshot_catalog.save(snapshot)
    original = b'{"snapshots": [broken'
    index_path = corrupt_index(original)
    before_payloads = set(snapshot_catalog.root.glob('*.snapshot.json.gz'))

    status = snapshot_catalog.health()
    assert status.read_only and status.can_restore
    assert status.recovered_count == 1 and status.invalid_count == 0
    assert snapshot_catalog.list()[0].snapshot_id == record.snapshot_id
    recovered = snapshot_catalog.load(record.snapshot_id)
    assert recovered is not None
    restored_snapshot, restored_record = recovered
    assert restored_snapshot.flat_jobs[0].job_uid == snapshot.flat_jobs[0].job_uid
    assert restored_record.sha256 == record.sha256

    with pytest.raises(SnapshotCatalogError, match="requires recovery"):
        snapshot_catalog.save(sample_snapshot("new"))
    with pytest.raises(SnapshotCatalogError, match="requires recovery"):
        snapshot_catalog.delete(record.snapshot_id)
    assert index_path.read_bytes() == original
    assert set(snapshot_catalog.root.glob('*.snapshot.json.gz')) == before_payloads

    page = client.get('/snapshots')
    assert page.status_code == 200
    assert 'Snapshot catalog needs attention' in page.text
    assert 'Restore catalog' in page.text
    assert record.snapshot_id in page.text
    for endpoint in ('/api/snapshots/start', '/api/snapshots/generate'):
        blocked = client.post(endpoint, data={'environment_id': 'autosys-u1'})
        assert blocked.status_code == 409
        assert 'requires recovery' in blocked.text
    assert index_path.read_bytes() == original


def test_explicit_restore_keeps_corrupt_backup_and_enables_writes():
    record = snapshot_catalog.save(sample_snapshot())
    original = b'not-json-at-all'
    corrupt_index(original)

    response = client.post('/api/snapshots/restore-catalog')
    assert response.status_code == 200
    assert 'Catalog restored' in response.text
    assert not snapshot_catalog.health().read_only
    assert snapshot_catalog.get_record(record.snapshot_id).sha256 == record.sha256
    backups = list(snapshot_catalog.root.glob('index.corrupt.*.json'))
    assert len(backups) == 1
    assert backups[0].read_bytes() == original
    assert snapshot_catalog.save(sample_snapshot('another'))
    assert len(snapshot_catalog.list()) == 2


def test_missing_index_with_payloads_is_recovered_without_mutating_payloads():
    record = snapshot_catalog.save(sample_snapshot())
    original_payload = (snapshot_catalog.root / record.filename).read_bytes()
    snapshot_catalog.index_path.unlink()

    assert snapshot_catalog.health().can_restore
    assert snapshot_catalog.list()[0].snapshot_id == record.snapshot_id
    assert not snapshot_catalog.index_path.exists()
    assert snapshot_catalog.restore_index() == 1
    assert snapshot_catalog.index_path.exists()
    assert not list(snapshot_catalog.root.glob('index.corrupt.*.json'))
    assert (snapshot_catalog.root / record.filename).read_bytes() == original_payload


def test_invalid_payload_blocks_restore_without_losing_healthy_snapshots():
    record = snapshot_catalog.save(sample_snapshot())
    broken = snapshot_catalog.root / 'damaged.snapshot.json.gz'
    broken.write_bytes(b'not-gzip')
    index = corrupt_index()
    initial = index.read_bytes()

    health = snapshot_catalog.health()
    assert health.status == 'recovery_blocked'
    assert health.recovered_count == 1 and health.invalid_count == 1
    assert snapshot_catalog.list()[0].snapshot_id == record.snapshot_id
    with pytest.raises(SnapshotCatalogError, match="Restoration blocked"):
        snapshot_catalog.restore_index()
    page = client.get('/snapshots')
    assert page.status_code == 200
    assert 'Invalid files: 1' in page.text
    assert '<button type="submit">Restore catalog</button>' not in page.text
    assert index.read_bytes() == initial
    assert broken.read_bytes() == b'not-gzip'
    assert not list(snapshot_catalog.root.glob('index.corrupt.*.json'))


def test_corrupt_index_without_payloads_is_not_overwritten():
    snapshot_catalog.root.mkdir(parents=True, exist_ok=True)
    index = corrupt_index()
    assert snapshot_catalog.health().status == 'recovery_blocked'
    with pytest.raises(SnapshotCatalogError):
        snapshot_catalog.save(sample_snapshot())
    with pytest.raises(SnapshotCatalogError):
        snapshot_catalog.restore_index()
    assert index.read_bytes() == b'{"snapshots": [broken'
    assert not list(snapshot_catalog.root.glob('*.snapshot.json.gz'))


def test_index_io_failure_is_not_misinterpreted_as_empty(monkeypatch):
    record = snapshot_catalog.save(sample_snapshot())
    before = snapshot_catalog.index_path.read_bytes()
    real_read = Path.read_text

    def reject_index(self: Path, *args, **kwargs):
        if self == snapshot_catalog.index_path:
            raise PermissionError('access denied')
        return real_read(self, *args, **kwargs)

    monkeypatch.setattr(Path, 'read_text', reject_index)
    assert snapshot_catalog.health().read_only
    assert snapshot_catalog.list()[0].snapshot_id == record.snapshot_id
    with pytest.raises(SnapshotCatalogError):
        snapshot_catalog.delete(record.snapshot_id)
    assert snapshot_catalog.index_path.read_bytes() == before


def test_restore_write_failure_rolls_back_original_index(monkeypatch):
    snapshot_catalog.save(sample_snapshot())
    original = b'{"snapshots": broken}'
    index = corrupt_index(original)

    def fail_write(_index):
        raise OSError("disk not writable")

    monkeypatch.setattr(snapshot_catalog, "_write_index", fail_write)
    with pytest.raises(OSError, match="disk not writable"):
        snapshot_catalog.restore_index()
    assert index.read_bytes() == original
    assert not list(snapshot_catalog.root.glob('index.corrupt.*.json'))
