@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if errorlevel 1 (
  set "EXIT_CODE=1"
  goto :finish
)

set "EXIT_CODE=0"
set "PYTHON_EXE=.venv\Scripts\python.exe"

if not exist "%PYTHON_EXE%" (
  echo ERROR: Project virtual environment is missing.
  echo Run setup-env.cmd once, then run this diagnostic again.
  set "EXIT_CODE=1"
  goto :finish
)

"%PYTHON_EXE%" -c "import yaml, pydantic" >nul 2>&1
if errorlevel 1 (
  echo ERROR: Project dependencies are incomplete in .venv.
  echo Run setup-env.cmd to install requirements.txt, then retry.
  set "EXIT_CODE=1"
  goto :finish
)

"%PYTHON_EXE%" -m scripts.diagnose_process_scheduler %*
set "EXIT_CODE=%ERRORLEVEL%"

:finish
echo.
echo [ps-tool-web] Exit code: %EXIT_CODE%
pause
endlocal & exit /b %EXIT_CODE%
