(function () {
  if (window.__psBrowseFiltersBootstrapped) {
    return;
  }
  window.__psBrowseFiltersBootstrapped = true;

  var pickerListenersBound = false;

  function inactiveStatuses() {
    var root = document.getElementById('browse-filter-status');
    if (!root) {
      return ['pending', 'not_run', 'disabled', 'killed', 'unknown'];
    }
    return (root.getAttribute('data-inactive-statuses') || '')
      .split(',')
      .map(function (s) {
        return s.trim();
      })
      .filter(Boolean);
  }

  function statusCheckboxes() {
    return Array.prototype.slice.call(document.querySelectorAll('.browse-status-checkbox'));
  }

  function getSelectedStatuses() {
    var checked = statusCheckboxes().filter(function (el) {
      return el.checked;
    });
    if (!checked.length) {
      return null;
    }
    return checked.map(function (el) {
      return el.value;
    });
  }

  function updatePickerLabel() {
    var labelEl = document.getElementById('browse-status-picker-label');
    if (!labelEl) {
      return;
    }
    var selected = getSelectedStatuses();
    if (!selected) {
      labelEl.textContent = 'All statuses';
      return;
    }
    if (selected.length === 1) {
      var text = selected[0];
      statusCheckboxes().forEach(function (box) {
        if (box.checked) {
          var row = box.closest('.browse-status-picker-row');
          var span = row ? row.querySelector('.browse-status-picker-row-label') : null;
          if (span) {
            text = span.textContent.trim();
          }
        }
      });
      labelEl.textContent = text;
      return;
    }
    labelEl.textContent = selected.length + ' selected';
  }

  function getPopover() {
    return document.getElementById('browse-status-picker-popover');
  }

  function getTrigger() {
    return document.getElementById('browse-status-picker-trigger');
  }

  function setPopoverOpen(open) {
    var trigger = getTrigger();
    var popover = getPopover();
    if (!trigger || !popover) {
      return;
    }
    if (open) {
      popover.removeAttribute('hidden');
      trigger.setAttribute('aria-expanded', 'true');
    } else {
      popover.setAttribute('hidden', '');
      trigger.setAttribute('aria-expanded', 'false');
    }
  }

  function applyStatusPreset(preset) {
    var inactive = inactiveStatuses();
    statusCheckboxes().forEach(function (box) {
      if (preset === 'all') {
        box.checked = false;
      } else if (preset === 'inactive') {
        box.checked = inactive.indexOf(box.value) !== -1;
      }
    });
    updatePickerLabel();
    applyBrowseFilters();
  }

  function bindPickerGlobalListeners() {
    if (pickerListenersBound) {
      return;
    }
    pickerListenersBound = true;


    document.addEventListener('click', function (e) {
      var picker = document.getElementById('browse-filter-status');
      if (!picker || picker.contains(e.target)) {
        return;
      }
      setPopoverOpen(false);
    });

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        setPopoverOpen(false);
      }
    });
  }

  function bindStatusPicker() {
    var picker = document.getElementById('browse-filter-status');
    if (!picker || picker.getAttribute('data-browse-status-bound') === 'true') {
      return;
    }
    picker.setAttribute('data-browse-status-bound', 'true');

    bindPickerGlobalListeners();

    var trigger = getTrigger();
    if (trigger) {
      trigger.addEventListener('click', function (e) {
        e.stopPropagation();
        var open = trigger.getAttribute('aria-expanded') === 'true';
        setPopoverOpen(!open);
      });
    }

    statusCheckboxes().forEach(function (box) {
      box.addEventListener('change', function () {
        updatePickerLabel();
        applyBrowseFilters();
      });
    });

    Array.prototype.forEach.call(picker.querySelectorAll('.browse-status-picker-action'), function (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        applyStatusPreset(btn.getAttribute('data-status-preset'));
      });
    });

    updatePickerLabel();
  }

  var activeRequest = null;
  var pendingTimer = null;
  var requestVersion = 0;
  var currentLimit = 200;

  function getPane() {
    return document.querySelector('.browse-tree-pane');
  }

  function setFeedback(pane, message) {
    var feedback = pane.querySelector('#browse-filter-feedback');
    if (!feedback) return;
    feedback.textContent = message;
    feedback.hidden = !message;
  }

  function applyBrowseFilters(nextLimit) {
    var pane = getPane();
    if (!pane) return;
    var body = pane.querySelector('.browse-tree-body');
    var session = document.getElementById('session-id');
    if (!body || !session) return;

    if (pendingTimer !== null) {
      clearTimeout(pendingTimer);
      pendingTimer = null;
    }
    if (activeRequest) {
      activeRequest.abort();
      activeRequest = null;
    }
    var version = ++requestVersion;
    var query = (document.getElementById('browse-filter-search').value || '').trim();
    var statuses = getSelectedStatuses() || [];
    currentLimit = nextLimit || 200;
    var active = Boolean(query || statuses.length);
    var params = new URLSearchParams({ session_id: session.value });
    if (active) {
      params.set('query', query);
      params.set('statuses', statuses.join(','));
      params.set('limit', String(currentLimit));
    }
    var url = (active ? '/api/browse/filter' : '/api/browse/tree') + '?' + params;
    var controller = new AbortController();
    activeRequest = controller;
    setFeedback(pane, 'Filtering jobs…');
    fetch(url, { signal: controller.signal, credentials: 'same-origin' })
      .then(function (response) {
        if (!response.ok) throw new Error('Filter request failed');
        return response.text();
      })
      .then(function (html) {
        if (version !== requestVersion || getPane() !== pane) return;
        body.innerHTML = html;
        // Rebind lazy HTMX expansions in the unfiltered tree.
        if (window.htmx && typeof window.htmx.process === 'function') {
          window.htmx.process(body);
        }
        setFeedback(pane, '');
      })
      .catch(function (error) {
        if (error.name === 'AbortError' || version !== requestVersion || getPane() !== pane) return;
        setFeedback(pane, 'Could not filter jobs. Try again.');
      })
      .finally(function () {
        if (version === requestVersion) activeRequest = null;
      });
  }

  function scheduleBrowseFilters() {
    // Do not allow an older response to overwrite the tree after new input.
    ++requestVersion;
    if (activeRequest) activeRequest.abort();
    activeRequest = null;
    if (pendingTimer !== null) clearTimeout(pendingTimer);
    pendingTimer = setTimeout(function () {
      pendingTimer = null;
      applyBrowseFilters();
    }, 250);
  }

  function bindPane(pane) {
    if (!pane || pane.getAttribute('data-browse-filters-bound') === 'true') return;
    pane.setAttribute('data-browse-filters-bound', 'true');
    setPopoverOpen(false);
    bindStatusPicker();
    var searchEl = pane.querySelector('#browse-filter-search');
    if (searchEl) searchEl.addEventListener('input', scheduleBrowseFilters);
    pane.addEventListener('click', function (event) {
      var button = event.target.closest('.browse-filter-load-more');
      if (!button) return;
      event.preventDefault();
      var limit = Number(button.getAttribute('data-next-limit'));
      if (limit > currentLimit && limit <= 10000) applyBrowseFilters(limit);
    });
  }

  function initBrowseFilters() {
    var pane = getPane();
    if (pane) bindPane(pane);
  }

  window.psBrowseFiltersInit = initBrowseFilters;
  window.psBrowseApplyFilters = applyBrowseFilters;

  document.addEventListener('htmx:afterSwap', function (event) {
    var target = event.detail && event.detail.target;
    if (!target) return;
    if (target.id === 'browse-output') {
      // A new session invalidates an in-flight search from the previous tree.
      ++requestVersion;
      if (activeRequest) activeRequest.abort();
      if (pendingTimer !== null) clearTimeout(pendingTimer);
      activeRequest = null;
      pendingTimer = null;
      initBrowseFilters();
    }
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initBrowseFilters);
  } else {
    initBrowseFilters();
  }
})();
