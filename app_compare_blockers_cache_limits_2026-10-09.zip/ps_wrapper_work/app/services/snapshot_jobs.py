"""Single-worker snapshot ingestion with progress/status outside the slow POST request."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from contextvars import ContextVar
from datetime import datetime, timezone
from threading import RLock
from time import monotonic
from typing import Callable
from uuid import uuid4

from app.services.runtime_diagnostics import log_event, log_exception

ProgressSink = Callable[[str, str, int | None, int | None], None]
_current_progress: ContextVar[ProgressSink | None] = ContextVar('snapshot_progress', default=None)


def current_progress() -> ProgressSink | None:
    return _current_progress.get()


def report_progress(stage: str, message: str, done: int | None = None, total: int | None = None) -> None:
    callback = _current_progress.get()
    if callback is not None:
        callback(stage, message, done, total)


@contextmanager
def track_progress(callback: ProgressSink):
    token = _current_progress.set(callback)
    try:
        yield
    finally:
        _current_progress.reset(token)


class SnapshotJobs:
    def __init__(self):
        self._lock = RLock()
        self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix='snapshot-ingest')
        self._jobs: dict[str, dict] = {}
        self._active: str | None = None

    def start(self, environment_id: str, topology_id: str) -> tuple[str, bool]:
        with self._lock:
            if self._active is not None:
                active = self._jobs.get(self._active)
                if active and active['state'] == 'running':
                    return self._active, False
            # Prevent unlimited memory for a long-running development server.
            for key in list(self._jobs)[:-20]:
                if self._jobs[key]['state'] != 'running':
                    del self._jobs[key]
            run_id = str(uuid4())
            timestamp = datetime.now(timezone.utc).isoformat()
            self._jobs[run_id] = {
                'run_id': run_id, 'state': 'running', 'stage': 'starting',
                'message': 'Preparing snapshot ingestion', 'done': None, 'total': None,
                'started_at': timestamp, 'updated_at': timestamp,
                'monotonic_start': monotonic(), 'snapshot_id': None,
                'error': None,
            }
            self._active = run_id
            log_event('snapshot_started', always=True, run_id=run_id, environment_id=environment_id)
            self._executor.submit(self._run, run_id, environment_id, topology_id)
            return run_id, True

    def _update(self, run_id: str, stage: str, message: str,
                done: int | None = None, total: int | None = None) -> None:
        with self._lock:
            job = self._jobs[run_id]
            if job['state'] != 'running':
                return
            changed = (job['stage'], job['done'], job['total']) != (stage, done, total)
            job.update(stage=stage, message=message, done=done, total=total,
                       updated_at=datetime.now(timezone.utc).isoformat())
            if changed:
                log_event('snapshot_progress', run_id=run_id, stage=stage, done=done, total=total,
                          elapsed_sec=int(monotonic() - job['monotonic_start']))

    def _run(self, run_id: str, environment_id: str, topology_id: str) -> None:
        from app.services.snapshot_generation import generate_snapshot
        with track_progress(lambda stage, msg, done=None, total=None:
                            self._update(run_id, stage, msg, done, total)):
            try:
                generated = generate_snapshot(environment_id, topology_id=topology_id)
                with self._lock:
                    job = self._jobs[run_id]
                    job.update(state='succeeded', stage='complete', message='Snapshot saved successfully',
                               snapshot_id=generated.record.snapshot_id,
                               updated_at=datetime.now(timezone.utc).isoformat())
                log_event('snapshot_succeeded', always=True, run_id=run_id,
                          job_count=generated.record.job_count, edge_count=generated.record.edge_count,
                          elapsed_sec=int(monotonic() - job['monotonic_start']))
            except Exception as exc:
                # Response errors originate in the existing boundary; log only type, not
                # exception messages that can contain source data/credentials.
                from app.services.snapshot_generation import SnapshotGenerationError
                display = (str(exc) if isinstance(exc, SnapshotGenerationError)
                           and exc.__cause__ is None else
                           'Snapshot generation failed. See logs/application.log and Run ID.')
                with self._lock:
                    job = self._jobs[run_id]
                    job.update(state='failed', stage='failed', message='Snapshot generation failed',
                               error=display, updated_at=datetime.now(timezone.utc).isoformat())
                log_exception('snapshot_failed', exc, operation='snapshot_generation',
                              run_id=run_id, elapsed_sec=int(monotonic() - job['monotonic_start']))
            finally:
                with self._lock:
                    if self._active == run_id:
                        self._active = None

    def current(self) -> dict | None:
        with self._lock:
            run_id = self._active
        return self.status(run_id) if run_id else None

    def status(self, run_id: str | None) -> dict | None:
        if run_id is None:
            return None
        with self._lock:
            job = self._jobs.get(run_id)
            if not job:
                return None
            return {**{k: v for k, v in job.items() if k != 'monotonic_start'},
                    'elapsed_seconds': int(monotonic() - job['monotonic_start'])}


snapshot_jobs = SnapshotJobs()
