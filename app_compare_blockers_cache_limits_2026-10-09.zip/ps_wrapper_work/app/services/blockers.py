"""Read-only, evidence-based blocker analysis for one immutable snapshot.

Containment is navigation only; only verified execution conditions propagate impact.
Unsupported conditions remain unknown rather than being treated as false.
"""
from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass, field
from enum import Enum
import re
from typing import Iterable

from app.models import DependencyEdge, DependencyKind, JobStatus, SchedulerType, SnapshotJob, TopologySnapshot


class Truth(str, Enum):
    TRUE = "true"
    FALSE = "false"
    UNKNOWN = "unknown"


class OperationalKind(str, Enum):
    """Operational triage, separate from proven dependency evidence.

    A failed/killed predecessor is a *potential* incident, not proof that its
    failure was unexpected. Other false predicates are not failure incidents.
    """

    POTENTIAL_INCIDENT = "potential_incident"
    RUNNING_GATE = "running_gate"
    CONDITION_GATE = "condition_gate"


class ExplanationStatus(str, Enum):
    FULLY_EXPLAINED = "fully_explained"
    PARTIALLY_EXPLAINED = "partially_explained"
    UNEXPLAINED = "unexplained"


@dataclass(frozen=True)
class Expr:
    op: str
    value: str = ""
    children: tuple["Expr", ...] = ()


@dataclass
class Condition:
    expression: str = ""
    ast: Expr | None = None
    references: dict[str, str] = field(default_factory=dict)  # scheduler job name -> UID
    warning: str = ""

    @property
    def supported(self) -> bool:
        return self.ast is not None


@dataclass
class WaitExplanation:
    uid: str
    condition: str = ""
    result: Truth = Truth.UNKNOWN
    direct_gates: list[str] = field(default_factory=list)
    root_paths: dict[str, str] = field(default_factory=dict)  # root UID -> preceding UID
    root_depths: dict[str, int] = field(default_factory=dict)
    explanation: ExplanationStatus = ExplanationStatus.UNEXPLAINED
    unresolved_gates: list[str] = field(default_factory=list)  # Direct UNKNOWN status UIDs
    unresolved_predecessors: list[str] = field(default_factory=list)  # Waiting ancestors without complete proof
    issue: str = ""


@dataclass
class BoxResolution:
    """Proof using an explicit native AutoSys completion rule, not containment alone."""

    uid: str
    rule: str = ""
    condition: Condition = field(default_factory=Condition)
    result: Truth = Truth.UNKNOWN
    root_paths: dict[str, str] = field(default_factory=dict)
    root_depths: dict[str, int] = field(default_factory=dict)
    unresolved_gates: list[str] = field(default_factory=list)
    unresolved_predecessors: list[str] = field(default_factory=list)
    explanation: ExplanationStatus = ExplanationStatus.UNEXPLAINED
    issue: str = ""

    @property
    def supported(self) -> bool:
        return self.condition.supported


@dataclass
class RootBlocker:
    uid: str
    classification: str  # Legacy diagnostic contract; evidence is verified for every root.
    operational_kind: OperationalKind
    targets: set[str] = field(default_factory=set)
    critical_targets: set[str] = field(default_factory=set)

    @property
    def impact_count(self) -> int:
        return len(self.targets)


@dataclass
class SuspectedGate:
    uid: str
    targets: set[str] = field(default_factory=set)
    warning: str = "Unverified edge; no proven execution condition"


@dataclass
class Readiness:
    level: str
    jobs: int
    edges: int
    verified_targets: int
    pending_targets: int
    unverified_targets: int
    waiting_without_edges: int = 0
    warnings: list[str] = field(default_factory=list)
    runtime_conflicts: int = 0
    box_rules_verified: int = 0
    box_rules_unverified: int = 0
    boxes_resolved: int = 0
    cyclic_jobs: int = 0
    cycle_affected_jobs: int = 0


@dataclass
class BlockersReport:
    snapshot: TopologySnapshot
    jobs: dict[str, SnapshotJob]
    conditions: dict[str, Condition]
    waits: dict[str, WaitExplanation]
    roots: list[RootBlocker]
    suspected: list[SuspectedGate]
    quality: Readiness
    critical_uids: frozenset[str]
    boxes: dict[str, BoxResolution] = field(default_factory=dict)

    def containment_path(self, uid: str) -> tuple[str, ...]:
        """Navigation-only hierarchy, never proof of execution dependencies."""
        if uid not in self.jobs:
            return ()
        stored = self.jobs[uid].path_labels
        if stored:
            return tuple(stored)
        current = uid
        visited: set[str] = set()
        labels: list[str] = []
        while current and current in self.jobs and current not in visited:
            visited.add(current)
            job = self.jobs[current]
            labels.append(job.scheduler_job_name)
            current = job.parent_uid
        return tuple(reversed(labels))

    def path(self, root_uid: str, target_uid: str) -> tuple[str, ...]:
        """Materialize a single evidence path on demand (bounded, cycle-safe)."""
        path = [target_uid]
        current = target_uid
        visited = {target_uid}
        while current != root_uid:
            step = self.waits.get(current) or self.boxes.get(current)
            preceding = step.root_paths.get(root_uid) if step else None
            if preceding is None or preceding in visited or len(path) > len(self.jobs):
                return ()
            path.append(preceding)
            visited.add(preceding)
            current = preceding
        path.reverse()
        return tuple(path)

    def evidence_for(self, uid: str) -> str:
        box = self.boxes.get(uid)
        if box and box.rule and box.condition.supported:
            return f"{box.rule}: {box.condition.expression}"
        wait = self.waits.get(uid)
        return wait.condition if wait else ""

    @staticmethod
    def path_preview(path: tuple[str, ...]) -> tuple[tuple[str, ...], int]:
        if len(path) <= 60:
            return path, 0
        return path[:10] + path[-30:], len(path) - 40

    @property
    def blocked_count(self) -> int:
        return sum(bool(wait.root_paths) for wait in self.waits.values())

    @property
    def unexplained_count(self) -> int:
        return sum(wait.explanation == ExplanationStatus.UNEXPLAINED for wait in self.waits.values())

    @property
    def fully_explained_count(self) -> int:
        return sum(wait.explanation == ExplanationStatus.FULLY_EXPLAINED for wait in self.waits.values())

    @property
    def partially_explained_count(self) -> int:
        return sum(wait.explanation == ExplanationStatus.PARTIALLY_EXPLAINED for wait in self.waits.values())

    @property
    def active_count(self) -> int:
        return sum(root.classification == "active" for root in self.roots)

    @property
    def confirmed_count(self) -> int:
        return sum(root.classification == "confirmed" for root in self.roots)

    @property
    def impacted_critical_count(self) -> int:
        return len({uid for root in self.roots for uid in root.critical_targets})

    @property
    def potential_incident_count(self) -> int:
        return sum(root.operational_kind == OperationalKind.POTENTIAL_INCIDENT for root in self.roots)

    @property
    def running_gate_count(self) -> int:
        return sum(root.operational_kind == OperationalKind.RUNNING_GATE for root in self.roots)

    @property
    def condition_gate_count(self) -> int:
        return sum(root.operational_kind == OperationalKind.CONDITION_GATE for root in self.roots)


# Supported grammar: AND/OR and parentheses, plus s/f/d or success/failure/done(job).
# Do not broaden without validating native scheduler semantics.
_TOKEN = re.compile(r"\s*(\(|\)|\&\&|\|\||\&|\||\bAND\b|\bOR\b|[A-Za-z0-9_.:/\-$]+)", re.I)
_PREDICATES = {"s": "success", "success": "success", "f": "failure", "failure": "failure", "d": "done", "done": "done"}
_WAITING = {JobStatus.PENDING, JobStatus.NOT_RUN}
_TERMINAL = {JobStatus.SUCCESS, JobStatus.FAILURE, JobStatus.KILLED}


class UnsupportedCondition(ValueError):
    pass


class _Parser:
    def __init__(self, expression: str):
        self.tokens: list[str] = []
        position = 0
        while position < len(expression):
            if expression[position:].isspace():
                break
            match = _TOKEN.match(expression, position)
            if not match:
                raise UnsupportedCondition("unsupported expression syntax")
            self.tokens.append(match.group(1))
            position = match.end()
        if len(self.tokens) > 256:
            raise UnsupportedCondition("condition exceeds supported complexity")
        self.pos = 0

    def _accept(self, *options: str) -> bool:
        if self.pos < len(self.tokens) and self.tokens[self.pos].upper() in options:
            self.pos += 1
            return True
        return False

    def _take(self) -> str:
        if self.pos >= len(self.tokens):
            raise UnsupportedCondition("incomplete expression")
        token = self.tokens[self.pos]
        self.pos += 1
        return token

    def parse(self) -> Expr:
        node = self._or()
        if self.pos != len(self.tokens):
            raise UnsupportedCondition("unsupported trailing condition")
        return node

    def _or(self) -> Expr:
        children = [self._and()]
        while self._accept("OR", "|", "||"):
            children.append(self._and())
        return children[0] if len(children) == 1 else Expr("or", children=tuple(children))

    def _and(self) -> Expr:
        children = [self._primary()]
        while self._accept("AND", "&", "&&"):
            children.append(self._primary())
        return children[0] if len(children) == 1 else Expr("and", children=tuple(children))

    def _primary(self) -> Expr:
        if self._accept("("):
            nested = self._or()
            if not self._accept(")"):
                raise UnsupportedCondition("unclosed condition group")
            return nested
        function = self._take().lower()
        if function not in _PREDICATES or not self._accept("("):
            raise UnsupportedCondition("unsupported predicate")
        name = self._take()
        if not re.fullmatch(r"[A-Za-z0-9_.:/\-$]+", name) or not self._accept(")"):
            raise UnsupportedCondition("unsupported predicate argument")
        return Expr(_PREDICATES[function], value=name)


def _leaves(ast: Expr) -> Iterable[Expr]:
    if not ast.children:
        yield ast
    else:
        for child in ast.children:
            yield from _leaves(child)


def _predicate(op: str, status: JobStatus) -> Truth:
    if status == JobStatus.UNKNOWN:
        return Truth.UNKNOWN
    if op == "success":
        return Truth.TRUE if status == JobStatus.SUCCESS else Truth.FALSE
    if op == "failure":
        return Truth.TRUE if status == JobStatus.FAILURE else Truth.FALSE
    if op == "done":
        return Truth.TRUE if status in _TERMINAL else Truth.FALSE
    return Truth.UNKNOWN


def _evaluate(ast: Expr, condition: Condition, jobs: dict[str, SnapshotJob]) -> Truth:
    if not ast.children:
        uid = condition.references.get(ast.value)
        return _predicate(ast.op, jobs[uid].status) if uid in jobs else Truth.UNKNOWN
    states = [_evaluate(child, condition, jobs) for child in ast.children]
    if ast.op == "and":
        if Truth.FALSE in states:
            return Truth.FALSE
        return Truth.UNKNOWN if Truth.UNKNOWN in states else Truth.TRUE
    if Truth.TRUE in states:
        return Truth.TRUE
    return Truth.UNKNOWN if Truth.UNKNOWN in states else Truth.FALSE


def _false_leaves(ast: Expr, condition: Condition, jobs: dict[str, SnapshotJob]) -> list[Expr]:
    """Returns *contributing* false predicates, not claims of sole causality."""
    if _evaluate(ast, condition, jobs) != Truth.FALSE:
        return []
    if not ast.children:
        return [ast]
    result: list[Expr] = []
    for child in ast.children:
        if _evaluate(child, condition, jobs) == Truth.FALSE:
            result.extend(_false_leaves(child, condition, jobs))
    return result


def _true_leaves(ast: Expr, condition: Condition, jobs: dict[str, SnapshotJob]) -> list[Expr]:
    """Contributing predicates for a satisfied explicit box_failure condition."""
    if _evaluate(ast, condition, jobs) != Truth.TRUE:
        return []
    if not ast.children:
        return [ast]
    result: list[Expr] = []
    for child in ast.children:
        if _evaluate(child, condition, jobs) == Truth.TRUE:
            result.extend(_true_leaves(child, condition, jobs))
    return result


def _is_descendant(uid: str, ancestor: str, jobs: dict[str, SnapshotJob]) -> bool:
    """Explicit containment validation; this alone never creates an execution edge."""
    current = jobs[uid].parent_uid
    seen: set[str] = set()
    while current and current in jobs and current not in seen:
        if current == ancestor:
            return True
        seen.add(current)
        current = jobs[current].parent_uid
    return False


def _box_condition(rule: str, box_uid: str, names: dict[str, list[str]],
                   jobs: dict[str, SnapshotJob]) -> Condition:
    condition = Condition(expression=rule.strip())
    try:
        ast = _Parser(condition.expression).parse()
    except UnsupportedCondition as exc:
        condition.warning = str(exc)
        return condition
    references: dict[str, str] = {}
    for leaf in _leaves(ast):
        candidates = names.get(leaf.value, [])
        if len(candidates) != 1:
            condition.warning = f"Missing or ambiguous box rule reference: {leaf.value}"
            return condition
        source_uid = candidates[0]
        if not _is_descendant(source_uid, box_uid, jobs):
            condition.warning = "Box rule references a job outside its containment; event timing unverified"
            return condition
        references[leaf.value] = source_uid
    condition.ast = ast
    condition.references = references
    return condition


def _box_timing_warning(box_uid: str, condition: Condition,
                        jobs: dict[str, SnapshotJob]) -> str:
    """Reject available evidence that belongs to an earlier run of the box.

    A snapshot without run identifiers cannot prove temporal coherence when
    timestamps are missing; do not invent it from containment alone.
    """
    box_start = jobs[box_uid].actual_start
    if box_start is None:
        return ""
    for source_uid in condition.references.values():
        child = jobs[source_uid]
        for event_time in (child.actual_start, child.actual_end):
            if event_time is None:
                continue
            try:
                if event_time < box_start:
                    return "Referenced child event predates this box execution; previous-run evidence"
            except TypeError:
                return "Box/child timestamps have incompatible timezone information"
    return ""


def _prepare_boxes(snapshot: TopologySnapshot, jobs: dict[str, SnapshotJob],
                   names: dict[str, list[str]]) -> dict[str, BoxResolution]:
    boxes: dict[str, BoxResolution] = {}
    if snapshot.context.scheduler != SchedulerType.AUTOSYS:
        return boxes  # Process Scheduler box state machine is not known to match AutoSys.
    for uid, job in jobs.items():
        if job.job_type not in ("box", "b") or job.status not in (JobStatus.RUNNING, JobStatus.FAILURE):
            continue
        box = BoxResolution(uid=uid)
        boxes[uid] = box
        if job.status == JobStatus.RUNNING:
            box.rule = "box_success"
            raw_rule = job.autosys.jil.box_success
        else:
            box.rule = "box_failure"
            raw_rule = job.autosys.jil.box_failure
        if not raw_rule or not str(raw_rule).strip():
            box.issue = f"No explicit {box.rule}; default box completion semantics not inferred"
            continue
        box.condition = _box_condition(str(raw_rule), uid, names, jobs)
        if not box.supported:
            box.issue = box.condition.warning
            continue
        timing_warning = _box_timing_warning(uid, box.condition, jobs)
        if timing_warning:
            box.condition.ast = None
            box.condition.warning = timing_warning
            box.issue = timing_warning
            continue
        # Never call a running box a verified success blocker if its failure
        # rule has already triggered: the capture may span inconsistent runs.
        if job.status == JobStatus.RUNNING and job.autosys.jil.box_failure:
            failure = _box_condition(str(job.autosys.jil.box_failure), uid, names, jobs)
            if not failure.supported or _evaluate(failure.ast, failure, jobs) == Truth.TRUE:
                box.condition.ast = None
                box.condition.warning = "Other box completion rule is unverified or already satisfied"
                box.issue = box.condition.warning
        if job.status == JobStatus.FAILURE and job.autosys.jil.box_success:
            success = _box_condition(str(job.autosys.jil.box_success), uid, names, jobs)
            if not success.supported or _evaluate(success.ast, success, jobs) == Truth.TRUE:
                box.condition.ast = None
                box.condition.warning = "Other box completion rule is unverified or already satisfied"
                box.issue = box.condition.warning
    return boxes


def _relevant_unknown_leaves(ast: Expr, condition: Condition, jobs: dict[str, SnapshotJob]) -> list[Expr]:
    """Find unresolved predicates without flagging unknowns bypassed by a true OR.

    A false AND is a proven gate even with an unknown sibling; the sibling
    still matters to explanation completeness. A true OR makes its other
    branches irrelevant to the currently recorded execution condition.
    """
    state = _evaluate(ast, condition, jobs)
    if ast.op == "or" and state == Truth.TRUE:
        return []
    if not ast.children:
        return [ast] if state == Truth.UNKNOWN else []
    result: list[Expr] = []
    for child in ast.children:
        result.extend(_relevant_unknown_leaves(child, condition, jobs))
    return result


def _condition_for_target(edges: list[DependencyEdge], names: dict[str, list[str]], jobs: dict[str, SnapshotJob]) -> Condition:
    if not edges:
        return Condition(warning="No incoming dependency edges")
    expressions = {edge.condition.strip() for edge in edges if edge.condition and edge.condition.strip()}
    if len(expressions) == 1 and next(iter(expressions)).lower() in _PREDICATES:
        # Legacy explicit per-edge predicate (e.g. 'success'); conjunction is explicit.
        if any(not edge.condition or edge.condition.strip().lower() != next(iter(expressions)).lower()
               for edge in edges):
            return Condition(warning="Inconsistent edge conditions")
        alias = _PREDICATES[next(iter(expressions)).lower()]
        if any(edge.kind not in (DependencyKind.FINISH_TO_START, DependencyKind.CUSTOM) for edge in edges):
            return Condition(warning="Unsupported dependency edge kind")
        if alias == "success" and any(edge.kind != DependencyKind.FINISH_TO_START for edge in edges):
            return Condition(warning="Unsupported success edge kind")
        nodes = tuple(Expr(alias, value=jobs[edge.from_uid].scheduler_job_name) for edge in edges)
        if len({node.value for node in nodes}) != len(nodes) or any(len(names.get(node.value, [])) != 1 for node in nodes):
            return Condition(warning="Duplicate or ambiguous predecessor names")
        return Condition(expression=" AND ".join(f"{alias}({node.value})" for node in nodes),
                         ast=nodes[0] if len(nodes) == 1 else Expr("and", children=nodes),
                         references={jobs[edge.from_uid].scheduler_job_name: edge.from_uid for edge in edges})
    if len(expressions) != 1 or any(not edge.condition or edge.condition.strip() not in expressions for edge in edges):
        return Condition(warning="Missing or conflicting full dependency expressions")
    expression = next(iter(expressions))
    condition = Condition(expression=expression)
    try:
        ast = _Parser(expression).parse()
    except UnsupportedCondition as exc:
        condition.warning = str(exc)
        return condition
    reference_uids: dict[str, str] = {}
    for predicate in _leaves(ast):
        candidates = names.get(predicate.value, [])
        if len(candidates) != 1:
            condition.warning = f"Missing or ambiguous predecessor: {predicate.value}"
            return condition
        reference_uids[predicate.value] = candidates[0]
    # A connector may drop external refs: an expression is valid only when its
    # entire dependency set is backed by the snapshot's explicit edges.
    incoming_uids = {edge.from_uid for edge in edges}
    if set(reference_uids.values()) != incoming_uids:
        condition.warning = "Expression references do not match snapshot edges"
        return condition
    if any(edge.kind in (DependencyKind.START_TO_START, DependencyKind.FILE_TRIGGER) for edge in edges):
        condition.warning = "Unsupported dependency edge kind"
        return condition
    condition.ast = ast
    condition.references = reference_uids
    return condition


def _dependency_components(
    jobs: dict[str, SnapshotJob], edges: list[DependencyEdge],
) -> tuple[list[list[str]], dict[str, int], set[int], int]:
    """Iterative SCC condensation, including verified box-rule proof-order links.

    A cycle is an unresolved proof boundary, not grounds to discard every node
    downstream of it. All noncyclic links between components remain ordered.
    """
    outgoing: dict[str, set[str]] = {uid: set() for uid in jobs}
    reverse: dict[str, set[str]] = {uid: set() for uid in jobs}
    for edge in edges:
        if edge.from_uid in jobs and edge.to_uid in jobs:
            outgoing[edge.from_uid].add(edge.to_uid)
            reverse[edge.to_uid].add(edge.from_uid)

    # Iterative Kosaraju: recursion on a long batch chain can overflow Python.
    seen: set[str] = set()
    finished: list[str] = []
    for start in jobs:
        if start in seen:
            continue
        seen.add(start)
        stack = [(start, iter(outgoing[start]))]
        while stack:
            uid, iterator = stack[-1]
            next_uid = next(iterator, None)
            if next_uid is None:
                finished.append(uid)
                stack.pop()
            elif next_uid not in seen:
                seen.add(next_uid)
                stack.append((next_uid, iter(outgoing[next_uid])))

    components: list[list[str]] = []
    component_of: dict[str, int] = {}
    for start in reversed(finished):
        if start in component_of:
            continue
        component_id = len(components)
        members: list[str] = []
        stack_uids = [start]
        component_of[start] = component_id
        while stack_uids:
            uid = stack_uids.pop()
            members.append(uid)
            for parent in reverse[uid]:
                if parent not in component_of:
                    component_of[parent] = component_id
                    stack_uids.append(parent)
        components.append(members)

    cyclic = {
        cid for cid, members in enumerate(components)
        if len(members) > 1 or any(uid in outgoing[uid] for uid in members)
    }
    successors: list[set[int]] = [set() for _ in components]
    indegree = [0] * len(components)
    for uid, neighbours in outgoing.items():
        source_id = component_of[uid]
        for dependent in neighbours:
            target_id = component_of[dependent]
            if source_id != target_id and target_id not in successors[source_id]:
                successors[source_id].add(target_id)
                indegree[target_id] += 1

    queue = deque(cid for cid, count in enumerate(indegree) if count == 0)
    ordered_components: list[list[str]] = []
    downstream_of_cycle: set[int] = set(cyclic)
    while queue:
        cid = queue.popleft()
        ordered_components.append(components[cid])
        for target_id in successors[cid]:
            if cid in downstream_of_cycle:
                downstream_of_cycle.add(target_id)
            indegree[target_id] -= 1
            if indegree[target_id] == 0:
                queue.append(target_id)
    affected_count = sum(len(components[cid]) for cid in downstream_of_cycle - cyclic)
    return ordered_components, component_of, cyclic, affected_count


def _root_class(status: JobStatus) -> str:
    return "active" if status == JobStatus.RUNNING else "confirmed"


def _operational_kind(status: JobStatus) -> OperationalKind:
    if status in (JobStatus.FAILURE, JobStatus.KILLED):
        return OperationalKind.POTENTIAL_INCIDENT
    if status == JobStatus.RUNNING:
        return OperationalKind.RUNNING_GATE
    return OperationalKind.CONDITION_GATE


def analyze_blockers(snapshot: TopologySnapshot, *, critical_names: Iterable[str] = ()) -> BlockersReport:
    """Analyze snapshot state only; no scheduler I/O and no time-relative claims."""
    jobs = {job.job_uid: job for job in snapshot.flat_jobs}
    duplicate_uids = len(jobs) != len(snapshot.flat_jobs)
    names: dict[str, list[str]] = defaultdict(list)
    for job in snapshot.flat_jobs:
        names[job.scheduler_job_name].append(job.job_uid)
    incoming: dict[str, list[DependencyEdge]] = defaultdict(list)
    invalid_by_target: dict[str, int] = defaultdict(int)
    valid_edges: list[DependencyEdge] = []
    invalid_edges = 0
    for edge in snapshot.edges:
        if edge.from_uid not in jobs or edge.to_uid not in jobs or edge.from_uid == edge.to_uid:
            invalid_edges += 1
            # Never silently discard an invalid predecessor for a known target:
            # the remaining valid edges might represent only part of its gate.
            if edge.to_uid in jobs:
                invalid_by_target[edge.to_uid] += 1
            continue
        incoming[edge.to_uid].append(edge)
        valid_edges.append(edge)
    conditions = {
        uid: (Condition(warning=f"{invalid_by_target[uid]} invalid incoming dependency edge(s); "
                                "execution condition cannot be verified")
              if invalid_by_target[uid] else _condition_for_target(incoming[uid], names, jobs))
        for uid in incoming.keys() | invalid_by_target.keys()
    }
    boxes = _prepare_boxes(snapshot, jobs, names)
    # These are *proof-order* links derived from verified completion rules,
    # never persisted as scheduler dependency edges or added to edge totals.
    completion_links = [
        DependencyEdge(from_uid=source, to_uid=box.uid)
        for box in boxes.values() if box.supported
        for source in set(box.condition.references.values())
    ]
    component_order, component_of, cyclic_components, cycle_downstream_count = _dependency_components(
        jobs, valid_edges + completion_links
    )
    cyclic_nodes_count = sum(
        len(component) for component in component_order
        if component_of[component[0]] in cyclic_components
    )
    waiting = {uid for uid, job in jobs.items() if job.status in _WAITING}
    warnings: list[str] = []
    if not snapshot.capabilities.dependencies:
        warnings.append("Adapter does not declare dependency support")
    if not snapshot.edges:
        warnings.append("No dependency edges in snapshot; root cause cannot be proven")
    waiting_without_edges = len(waiting - set(incoming))
    if waiting_without_edges:
        warnings.append(f"{waiting_without_edges} waiting/not-run jobs have no recorded incoming dependencies")
    if invalid_edges:
        warnings.append(f"{invalid_edges} invalid dependency edges")
    if duplicate_uids:
        warnings.append("Duplicate job UIDs in snapshot")
    if cyclic_nodes_count:
        warnings.append(
            f"{cyclic_nodes_count} nodes in {len(cyclic_components)} cyclic dependency/completion-rule "
            f"component(s); {cycle_downstream_count} additional downstream nodes. "
            "Independent gates remain analyzable; paths inside cycles are unverified"
        )
    unverified_boxes = sum(not box.supported for box in boxes.values())
    if unverified_boxes:
        warnings.append(f"{unverified_boxes} active AutoSys boxes lack a verifiable explicit completion rule")
    box_state_mismatches = sum(
        box.supported and box.rule == "box_success" and
        _evaluate(box.condition.ast, box.condition, jobs) == Truth.TRUE
        for box in boxes.values()
    )
    if box_state_mismatches:
        warnings.append(f"{box_state_mismatches} running boxes already satisfy box_success; verify status/event timing")
    unverified = sum(not item.supported for item in conditions.values())
    if unverified:
        warnings.append(f"{unverified} target conditions cannot be verified")
    verified = sum(cond.supported for cond in conditions.values())
    runtime_conflicts = sum(
        _evaluate(condition.ast, condition, jobs) == Truth.FALSE
        and jobs[uid].status in (JobStatus.RUNNING, JobStatus.SUCCESS)
        for uid, condition in conditions.items() if condition.supported and condition.ast is not None
    )
    if runtime_conflicts:
        warnings.append(f"{runtime_conflicts} active/completed jobs have unsatisfied recorded conditions; verify run timing")
    full_coverage = (verified == len(incoming) and not warnings)
    quality = Readiness(
        level=("unavailable" if not verified or duplicate_uids or not snapshot.capabilities.dependencies
               else "verified" if full_coverage else "partial"),
        jobs=len(snapshot.flat_jobs), edges=len(snapshot.edges),
        verified_targets=verified, pending_targets=len(waiting), unverified_targets=unverified,
        waiting_without_edges=waiting_without_edges,
        warnings=warnings, runtime_conflicts=runtime_conflicts,
        box_rules_verified=sum(box.supported for box in boxes.values()),
        box_rules_unverified=unverified_boxes,
        cyclic_jobs=cyclic_nodes_count,
        cycle_affected_jobs=cycle_downstream_count,
    )
    suspected_by_uid: dict[str, SuspectedGate] = {}
    for target_uid, edges in incoming.items():
        if target_uid not in waiting or conditions[target_uid].supported:
            continue
        for edge in edges:
            if jobs[edge.from_uid].status in {JobStatus.FAILURE, JobStatus.KILLED, JobStatus.RUNNING, JobStatus.DISABLED}:
                candidate = suspected_by_uid.setdefault(edge.from_uid, SuspectedGate(uid=edge.from_uid))
                candidate.targets.add(target_uid)
    suspected = sorted(suspected_by_uid.values(), key=lambda entry: (-len(entry.targets), jobs[entry.uid].scheduler_job_name.casefold()))
    critical_set = set(critical_names)
    critical_uids = frozenset(uid for uid, job in jobs.items() if job.scheduler_job_name in critical_set)
    waits = {uid: WaitExplanation(uid=uid) for uid in waiting}
    if quality.level == "unavailable":
        for wait in waits.values():
            condition = conditions.get(wait.uid)
            wait.issue = (condition.warning if snapshot.capabilities.dependencies
                          and condition is not None and not condition.supported and condition.warning
                          else "Dependency evidence unavailable")
        return BlockersReport(snapshot, jobs, conditions, waits, [], suspected, quality, critical_uids, boxes)

    def inherit(source: str, leaf_op: str, owner: WaitExplanation | BoxResolution) -> None:
        """Prefer proven internal sources over a box gate; preserve unknowns."""
        # There is no topological causality *inside* a strongly connected
        # component. Keep known independent gates, but never infer a path via
        # an intra-cycle hop (including an otherwise failed direct source).
        if (component_of[source] == component_of[owner.uid]
                and component_of[source] in cyclic_components):
            if source not in owner.unresolved_predecessors:
                owner.unresolved_predecessors.append(source)
            return
        job = jobs[source]
        wait_source = waits.get(source)
        box_source = boxes.get(source)
        if (box_source and component_of[source] in cyclic_components
                and not box_source.root_paths):
            # A box whose explicit completion proof loops cannot be treated
            # as a standalone verified root outside that cycle either.
            if source not in owner.unresolved_predecessors:
                owner.unresolved_predecessors.append(source)
            return
        can_expand_box = bool(box_source and box_source.root_paths and (
            (leaf_op == "success" and job.status in (JobStatus.RUNNING, JobStatus.FAILURE))
            or (leaf_op == "failure" and job.status == JobStatus.FAILURE)
        ))
        ancestor = wait_source if wait_source else box_source if can_expand_box else None
        if wait_source and wait_source.explanation != ExplanationStatus.FULLY_EXPLAINED:
            if source not in owner.unresolved_predecessors:
                owner.unresolved_predecessors.append(source)
        if box_source and (not can_expand_box or box_source.explanation != ExplanationStatus.FULLY_EXPLAINED):
            if source not in owner.unresolved_predecessors:
                owner.unresolved_predecessors.append(source)
        if ancestor is not None:
            for root_uid, depth in ancestor.root_depths.items():
                new_depth = depth + 1
                if root_uid not in owner.root_paths or new_depth < owner.root_depths[root_uid]:
                    owner.root_paths[root_uid] = source
                    owner.root_depths[root_uid] = new_depth
        elif not wait_source and source not in owner.root_paths:
            owner.root_paths[source] = source
            owner.root_depths[source] = 2

    for component in component_order:
        for uid in component:
            if uid in boxes:
                box = boxes[uid]
                if box.supported and box.condition.ast is not None:
                    box.result = _evaluate(box.condition.ast, box.condition, jobs)
                    box.unresolved_gates = list(dict.fromkeys(
                        box.condition.references[leaf.value]
                        for leaf in _relevant_unknown_leaves(box.condition.ast, box.condition, jobs)
                    ))
                    needed = Truth.FALSE if box.rule == "box_success" else Truth.TRUE
                    if box.result == needed:
                        leaves = (_false_leaves if box.rule == "box_success" else _true_leaves)(
                            box.condition.ast, box.condition, jobs
                        )
                        for leaf in leaves:
                            inherit(box.condition.references[leaf.value], leaf.op, box)
                        if box.root_paths:
                            box.explanation = (ExplanationStatus.PARTIALLY_EXPLAINED
                                               if box.unresolved_gates or box.unresolved_predecessors
                                               or component_of[uid] in cyclic_components
                                               else ExplanationStatus.FULLY_EXPLAINED)
                            if component_of[uid] in cyclic_components:
                                box.issue = "Independent internal gates proven; cyclic box completion proof incomplete"
                        else:
                            box.issue = ("Cyclic box completion rule; no independent internal root proven"
                                         if component_of[uid] in cyclic_components else
                                         "Box rule evaluated, but no internal root could be proven")
                    else:
                        box.issue = ("Box completion condition has unknown state" if box.result == Truth.UNKNOWN
                                     else "Box runtime state conflicts with or is not explained by its completion rule")
            if uid not in waiting:
                continue
            wait = waits[uid]
            condition = conditions.get(uid)
            if not condition or not condition.supported or not condition.ast:
                wait.issue = condition.warning if condition else "No incoming dependency edges"
                continue
            wait.condition = condition.expression
            wait.result = _evaluate(condition.ast, condition, jobs)
            wait.unresolved_gates = list(dict.fromkeys(
                condition.references[leaf.value]
                for leaf in _relevant_unknown_leaves(condition.ast, condition, jobs)
            ))
            if wait.result == Truth.TRUE:
                wait.issue = "Dependency condition satisfied; waiting has another cause"
                continue
            if wait.result == Truth.UNKNOWN:
                wait.issue = "Dependency status unresolved; inspect unknown predecessor states"
                continue
            for leaf in _false_leaves(condition.ast, condition, jobs):
                source = condition.references[leaf.value]
                if source not in wait.direct_gates:
                    wait.direct_gates.append(source)
                inherit(source, leaf.op, wait)
            if not wait.root_paths:
                wait.issue = "No provable upstream root"
            elif wait.unresolved_gates or wait.unresolved_predecessors:
                wait.explanation = ExplanationStatus.PARTIALLY_EXPLAINED
                wait.issue = "Proven blocking gates exist, but other required/upstream states remain unresolved"
            else:
                wait.explanation = ExplanationStatus.FULLY_EXPLAINED
            if component_of[uid] in cyclic_components:
                if wait.root_paths:
                    wait.explanation = ExplanationStatus.PARTIALLY_EXPLAINED
                    wait.issue = "Independent gates proven; cyclic dependency proof is incomplete"
                else:
                    wait.issue = "Cyclic dependency; no independent upstream root proven"
    by_root: dict[str, RootBlocker] = {}
    for uid, wait in waits.items():
        for root_uid in wait.root_paths:
            root = by_root.setdefault(root_uid, RootBlocker(uid=root_uid, classification=_root_class(jobs[root_uid].status),
                                                           operational_kind=_operational_kind(jobs[root_uid].status)))
            root.targets.add(uid)
            if uid in critical_uids:
                root.critical_targets.add(uid)
    priority = {OperationalKind.POTENTIAL_INCIDENT: 0, OperationalKind.RUNNING_GATE: 1,
                OperationalKind.CONDITION_GATE: 2}
    roots = sorted(by_root.values(), key=lambda root: (
        -bool(root.critical_targets), priority[root.operational_kind], -root.impact_count,
        jobs[root.uid].scheduler_job_name.casefold(),
    ))
    quality.boxes_resolved = sum(bool(box.root_paths) for box in boxes.values())
    return BlockersReport(snapshot, jobs, conditions, waits, roots, suspected, quality, critical_uids, boxes)
