"""Settings — scheduler-specific environment connection configuration."""

from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates

from app.config import (
    EnvironmentEntry,
    get_settings,
    load_scheduler_environments,
    save_scheduler_environments,
    scheduler_config_path,
)
from app.models import SchedulerType
from app.services.runtime_diagnostics import debug_enabled, set_debug_enabled, log_event

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")


def _read_config_text(path: Path) -> str:
    if not path.exists():
        return "# (file not found)\n"
    return path.read_text(encoding="utf-8")


def _scheduler_or_404(value: str) -> SchedulerType:
    try:
        scheduler = SchedulerType(value)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail="Unknown scheduler") from exc
    return scheduler


@router.get("/settings", response_class=HTMLResponse)
async def settings_page(request: Request, saved: str = ""):
    settings = get_settings()
    config_dir = settings.config_dir
    autosys = load_scheduler_environments(SchedulerType.AUTOSYS.value)
    process_scheduler = load_scheduler_environments(SchedulerType.PROCESS_SCHEDULER.value)
    autosys_path = scheduler_config_path(SchedulerType.AUTOSYS.value)
    ps_path = scheduler_config_path(SchedulerType.PROCESS_SCHEDULER.value)
    identity_path = config_dir / "identity_map.yaml"
    return templates.TemplateResponse(
        request,
        "settings.html",
        {
            "autosys_environments": autosys,
            "process_scheduler_environments": process_scheduler,
            "autosys_yaml": _read_config_text(autosys_path),
            "process_scheduler_yaml": _read_config_text(ps_path),
            "identity_yaml": _read_config_text(identity_path),
            "use_mock_adapters": settings.use_mock_adapters,
            "allow_connection_config_edit": settings.allow_connection_config_edit,
            "mock_dataset": settings.mock_dataset,
            "mock_reference_path": str(settings.mock_reference_path),
            "config_dir": str(config_dir),
            "autosys_config_path": str(autosys_path),
            "process_scheduler_config_path": str(ps_path),
            "identity_map_path": str(identity_path),
            "saved": saved,
            "debug_enabled": debug_enabled(),
            "log_dir": str(settings.log_dir),
        },
    )


@router.post("/api/settings/environments/{scheduler}", response_class=RedirectResponse)
async def save_environment_connections(request: Request, scheduler: str):
    scheduler_type = _scheduler_or_404(scheduler)
    settings = get_settings()
    if not settings.allow_connection_config_edit:
        raise HTTPException(
            status_code=403,
            detail="Connection editing is disabled by ALLOW_CONNECTION_CONFIG_EDIT",
        )

    form = await request.form()
    updated: list[EnvironmentEntry] = []
    changed = False
    for entry in load_scheduler_environments(scheduler_type.value):
        changes: dict[str, object] = {}
        for field_name, attribute in (
            ("environment", "environment"),
            ("host", "endpoint_url"),
            ("description", "description"),
        ):
            form_key = f"{field_name}_{entry.id}"
            if form_key in form:
                value = str(form[form_key]).strip()
                if value != getattr(entry, attribute):
                    changes[attribute] = value

        # An unchecked checkbox is absent from form data. The row marker
        # distinguishes an intentional "off" from a partial form submission.
        if f"present_{entry.id}" in form or f"enabled_{entry.id}" in form:
            enabled = form.get(f"enabled_{entry.id}") == "on"
            if enabled != entry.enabled:
                changes["enabled"] = enabled

        if "environment" in changes or "description" in changes:
            changes["display_name"] = ""  # Re-derived when the YAML is reloaded.
        updated.append(entry.model_copy(update=changes) if changes else entry)
        changed = changed or bool(changes)

    if changed:
        save_scheduler_environments(scheduler_type.value, updated)
    return RedirectResponse(url=f"/settings?saved={scheduler_type.value}#{scheduler_type.value}", status_code=303)


@router.post('/api/settings/debug')
async def save_debug_settings(request: Request):
    form = await request.form()
    enabled = form.get('debug') == 'on'
    set_debug_enabled(enabled)
    log_event('debug_configuration_changed', always=True)
    return RedirectResponse(url='/settings?saved=debug#advanced', status_code=303)
