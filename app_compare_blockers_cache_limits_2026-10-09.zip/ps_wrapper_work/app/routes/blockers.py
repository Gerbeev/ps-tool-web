"""Blockers: explain verified dependency gates in an existing snapshot only."""
from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass, field
from enum import Enum
from sys import getsizeof
from threading import RLock
from time import monotonic
from uuid import uuid4

from fastapi import APIRouter, Form, Query, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates

from app.config import get_settings, load_environments
from app.services.blockers import BlockersReport, analyze_blockers
from app.services.blockers_targets import get_critical_targets, set_critical_target
from app.services.snapshot_catalog import snapshot_catalog

router = APIRouter()
templates = Jinja2Templates(directory="app/templates")


@dataclass
class _Session:
    snapshot_id: str
    environment_id: str
    report: BlockersReport
    record: object
    retained_bytes: int = 0
    last_access: float = field(default_factory=monotonic)


# In-process LRU. A session references both its snapshot and computed graph;
# count the reachable objects once even when the report reuses snapshot jobs.
_sessions: OrderedDict[str, _Session] = OrderedDict()
_lock = RLock()


def _retained_size(report: BlockersReport, record: object, max_bytes: int) -> int:
    """Bounded, cycle-safe heap estimate; avoids duplicating shared references.

    It is a budget estimate, not an operating-system RSS measurement; Python
    allocator overhead and temporary in-flight analyses are not included.
    """
    total = 0
    seen: set[int] = set()
    pending: list[object] = [report, record]
    while pending:
        item = pending.pop()
        identifier = id(item)
        if identifier in seen:
            continue
        seen.add(identifier)
        total += getsizeof(item)
        if total > max_bytes:
            return total
        if isinstance(item, dict):
            for key, value in item.items():
                pending.extend((key, value))
        elif isinstance(item, (list, tuple, set, frozenset)):
            pending.extend(item)
        elif not isinstance(item, (Enum, type)) and hasattr(item, "__dict__"):
            pending.append(vars(item))
    return total


def _prune_expired(now: float, ttl_sec: int) -> None:
    # Called with _lock held. Lazy cleanup keeps this local app thread-free.
    for key, session in list(_sessions.items()):
        if now - session.last_access >= ttl_sec:
            del _sessions[key]


def _fit_cache(max_sessions: int, max_bytes: int) -> None:
    # Called with _lock held. Oldest accessed entries are evicted first.
    retained = sum(entry.retained_bytes for entry in _sessions.values())
    while _sessions and (len(_sessions) > max_sessions or retained > max_bytes):
        _, removed = _sessions.popitem(last=False)
        retained -= removed.retained_bytes


def _put(session: _Session) -> str | None:
    limits = get_settings()
    max_bytes = limits.blockers_cache_max_mb * 1024 * 1024
    retained = _retained_size(session.report, session.record, max_bytes)
    if retained > max_bytes:
        return None
    session.retained_bytes = retained
    with _lock:
        now = monotonic()
        _prune_expired(now, limits.blockers_cache_ttl_sec)
        session.last_access = now
        session_id = uuid4().hex
        _sessions[session_id] = session
        _fit_cache(limits.blockers_cache_max_sessions, max_bytes)
        return session_id


def _get(session_id: str) -> _Session | None:
    with _lock:
        now = monotonic()
        _prune_expired(now, get_settings().blockers_cache_ttl_sec)
        session = _sessions.get(session_id)
        if session is not None:
            session.last_access = now
            _sessions.move_to_end(session_id)
        return session


def _replace_report(session_id: str, report: BlockersReport) -> bool:
    """Update cached report and its budget atomically after critical-target edits."""
    limits = get_settings()
    max_bytes = limits.blockers_cache_max_mb * 1024 * 1024
    with _lock:
        now = monotonic()
        _prune_expired(now, limits.blockers_cache_ttl_sec)
        session = _sessions.get(session_id)
        if session is None:
            return False
        retained = _retained_size(report, session.record, max_bytes)
        if retained > max_bytes:
            del _sessions[session_id]
            return False
        session.report = report
        session.retained_bytes = retained
        session.last_access = now
        _sessions.move_to_end(session_id)
        _fit_cache(limits.blockers_cache_max_sessions, max_bytes)
        return session_id in _sessions


def _expired_html(request: Request) -> HTMLResponse:
    message = ("<div class='blockers-banner' role='status'><strong>Blockers analysis expired "
               "or was removed to free memory.</strong> The saved snapshot is unchanged. "
               "Select <strong>Analyze snapshot</strong> above to rebuild the analysis.</div>")
    if request.headers.get("HX-Request", "").lower() == "true":
        # HTMX does not normally swap HTTP 4xx responses. Replace stale results
        # instead of leaving non-functional controls and a misleading report.
        return HTMLResponse(message, headers={"HX-Retarget": "#blockers-output"})
    return HTMLResponse(message, status_code=410)


def _over_budget_html(request: Request) -> HTMLResponse:
    message = ("<div class='blockers-banner' role='alert'><strong>Blockers analysis exceeds "
               "the configured cache memory limit.</strong> The saved snapshot is unchanged. "
               "Increase <code>BLOCKERS_CACHE_MAX_MB</code> and analyze again.</div>")
    if request.headers.get("HX-Request", "").lower() == "true":
        return HTMLResponse(message, headers={"HX-Retarget": "#blockers-output"})
    return HTMLResponse(message, status_code=413)


def _render_results(request: Request, session_id: str, session: _Session):
    return templates.TemplateResponse(request, "partials/blockers_results.html", {
        "report": session.report,
        "record": session.record,
        "session_id": session_id,
    })


@router.get("/blockers", response_class=HTMLResponse)
def blockers_page(request: Request):
    environments = load_environments()
    default_env = environments[0].id if environments else ""
    snapshots = snapshot_catalog.list(environment_id=default_env) if default_env else []
    return templates.TemplateResponse(request, "blockers.html", {
        "environments": environments,
        "environment_id": default_env,
        "snapshots": snapshots,
        "selected_snapshot_id": snapshots[0].snapshot_id if snapshots else "",
    })


@router.get("/api/blockers/form", response_class=HTMLResponse)
def blockers_form(request: Request, environment_id: str = Query(default="", max_length=150)):
    snapshots = snapshot_catalog.list(environment_id=environment_id) if environment_id else []
    return templates.TemplateResponse(request, "partials/blockers_snapshot_select.html", {
        "snapshots": snapshots,
        "selected_snapshot_id": snapshots[0].snapshot_id if snapshots else "",
    })


@router.post("/api/blockers/analyze", response_class=HTMLResponse)
def blockers_analyze(request: Request, environment_id: str = Form(...), snapshot_id: str = Form(...)):
    if not environment_id or not snapshot_id:
        return HTMLResponse("<p>Select an environment and a saved snapshot.</p>", status_code=400)
    loaded = snapshot_catalog.load(snapshot_id)
    if loaded is None:
        return HTMLResponse("<p>Snapshot not found or corrupted.</p>", status_code=404)
    snapshot, record = loaded
    if record.environment_id != environment_id:
        return HTMLResponse("<p>Snapshot/environment mismatch.</p>", status_code=400)
    report = analyze_blockers(snapshot, critical_names=get_critical_targets(snapshot))
    session = _Session(snapshot_id=snapshot_id, environment_id=environment_id, report=report, record=record)
    session_id = _put(session)
    if session_id is None:
        return _over_budget_html(request)
    return _render_results(request, session_id, session)


def _explanation_context(session_id: str, session: _Session, uid: str, mode: str) -> dict | None:
    report = session.report
    if uid not in report.jobs:
        return None
    root = next((entry for entry in report.roots if entry.uid == uid), None)
    wait = report.waits.get(uid)
    suspected = next((entry for entry in report.suspected if entry.uid == uid), None)
    if (mode == "blocker" and root is None) or (mode == "suspected" and suspected is None):
        return None
    return {
        "session_id": session_id, "report": report, "root": root,
        "wait": wait, "box": report.boxes.get(uid), "suspected": suspected,
        "job": report.jobs[uid], "uid": uid,
        "mode": mode,
        "paths": [(target_uid, report.path(uid, target_uid)) for target_uid in
                  sorted(root.targets, key=lambda target_uid: (
                      target_uid not in report.critical_uids,
                      report.jobs[target_uid].scheduler_job_name.casefold(),
                  ))[:30]] if mode == "blocker" and root else [],
    }


@router.get("/api/blockers/explain", response_class=HTMLResponse)
def blockers_explain(request: Request, session_id: str, uid: str = Query(max_length=500), mode: str = "blocker"):
    session = _get(session_id)
    if session is None:
        return _expired_html(request)
    context = _explanation_context(session_id, session, uid, mode)
    if context is None:
        return HTMLResponse("<p>No blocker evidence for this job.</p>", status_code=404)
    return templates.TemplateResponse(request, "partials/blockers_explain.html", context)


@router.post("/api/blockers/critical", response_class=HTMLResponse)
def blockers_critical(request: Request, session_id: str = Form(...), uid: str = Form(...),
                      enabled: str = Form("false"), mode: str = Form("wait")):
    session = _get(session_id)
    if session is None:
        return _expired_html(request)
    if uid not in session.report.jobs or enabled not in ("true", "false"):
        return HTMLResponse("<p>Invalid target selection.</p>", status_code=400)
    snapshot = session.report.snapshot
    try:
        set_critical_target(snapshot, uid, enabled == "true")
    except ValueError as exc:
        # Fixed message; do not expose filesystem/internal content.
        return HTMLResponse("<p>Cannot save an ambiguous target.</p>", status_code=400)
    updated_report = analyze_blockers(snapshot, critical_names=get_critical_targets(snapshot))
    if not _replace_report(session_id, updated_report):
        return _expired_html(request)
    context = _explanation_context(session_id, session, uid, mode)
    if context is None:
        return HTMLResponse("<p>No blocker evidence for this job.</p>", status_code=404)
    response = templates.TemplateResponse(request, "partials/blockers_critical_updated.html", context)
    response.headers["HX-Trigger-After-Swap"] = "blockers-critical-updated"
    return response


@router.get("/api/blockers/report")
def blockers_report(session_id: str):
    """Compact machine-readable diagnosis for reproducibility/operator diagnostics."""
    session = _get(session_id)
    if session is None:
        return JSONResponse({"detail": "Analysis expired"}, status_code=404)
    report = session.report
    return {
        "snapshot_id": session.snapshot_id,
        "quality": report.quality.__dict__,
        "totals": {"confirmed": report.confirmed_count, "active": report.active_count,
                   "potential_incidents": report.potential_incident_count,
                   "running_gates": report.running_gate_count,
                   "condition_gates": report.condition_gate_count,
                   "blocked_waits": report.blocked_count, "unexplained_waits": report.unexplained_count,
                   "fully_explained_waits": report.fully_explained_count,
                   "partially_explained_waits": report.partially_explained_count,
                   "impacted_critical": report.impacted_critical_count,
                   "suspected_gates": len(report.suspected)},
        "incomplete_waits_sample": [
            {"uid": wait.uid,
             "confirmed_contributing_roots": sorted(wait.root_paths),
             "unknown_predecessors": wait.unresolved_gates,
             "incomplete_upstream": wait.unresolved_predecessors}
            for wait in report.waits.values() if wait.explanation.value == "partially_explained"
        ][:30],
        "box_resolution": {
            "verified_rules": report.quality.box_rules_verified,
            "unverified_rules": report.quality.box_rules_unverified,
            "resolved_boxes": report.quality.boxes_resolved,
            "sample": [
                {"uid": box.uid, "rule": box.rule,
                 "condition": box.condition.expression, "evaluation": box.result.value,
                 "explanation": box.explanation.value,
                 "roots": sorted(box.root_paths), "issue": box.issue}
                for box in report.boxes.values()
            ][:30],
        },
        "suspected": [{"uid": item.uid, "candidate_targets": len(item.targets)} for item in report.suspected],
        "blockers": [
            {"uid": root.uid, "job": report.jobs[root.uid].scheduler_job_name,
             "status": report.jobs[root.uid].status.value, "classification": root.classification,
             "operational_kind": root.operational_kind.value,
             "impacted": root.impact_count, "critical_targets": sorted(root.critical_targets)}
            for root in report.roots
        ],
    }


@router.get("/api/blockers/list", response_class=HTMLResponse)
def blockers_list(
    request: Request,
    session_id: str,
    view: str = Query("roots", pattern="^(roots|suspected|waits|jobs|quality)$"),
    query: str = Query("", max_length=200),
    classification: str = Query("all", pattern="^(all|potential_incident|running_gate|condition_gate|confirmed|active|unexplained)$"),
    critical_only: bool = False,
    scope: str = Query("", max_length=150),
    offset: int = Query(0, ge=0, le=1000000),
):
    session = _get(session_id)
    if session is None:
        return _expired_html(request)
    report = session.report
    needle = query.strip().casefold()

    def matches(uid: str) -> bool:
        job = report.jobs[uid]
        search_ok = not needle or needle in job.scheduler_job_name.casefold() or needle in uid.casefold()
        scope_ok = not scope.strip() or scope.strip().casefold() in " / ".join(report.containment_path(uid)).casefold()
        return search_ok and scope_ok

    def root_matches_class(root) -> bool:
        return classification in ("all", root.classification, root.operational_kind.value)

    matched_targets = ({uid for root in report.roots if root_matches_class(root) for uid in root.targets}
                       if classification != "all" else set())

    if view == "roots":
        entries = [root for root in report.roots if matches(root.uid)
                   and root_matches_class(root)
                   and (not critical_only or bool(root.critical_targets))]
    elif view == "suspected":
        entries = [gate for gate in report.suspected if matches(gate.uid)
                   and classification in ("all", "unexplained")
                   and (not critical_only or bool(gate.targets & report.critical_uids))]
    elif view == "waits":
        entries = [uid for uid, wait in report.waits.items() if matches(uid)
                   and (not critical_only or uid in report.critical_uids)
                   and (classification == "all"
                        or (classification == "unexplained" and not wait.root_paths)
                        or (classification != "unexplained" and uid in matched_targets))]
        entries.sort(key=lambda uid: (uid not in report.critical_uids,
                     not bool(report.waits[uid].root_paths), report.jobs[uid].scheduler_job_name.casefold()))
    elif view == "jobs":
        entries = [uid for uid, job in report.jobs.items() if matches(uid)
                   and (not critical_only or uid in report.critical_uids)
                   and (classification == "all" or
                        (classification == "unexplained" and uid in report.waits and not report.waits[uid].root_paths)
                        or (classification != "unexplained" and uid in matched_targets))]
        status_rank = {"failure": 0, "killed": 1, "running": 2, "pending": 3,
                       "disabled": 4, "not_run": 5, "unknown": 6, "success": 7}
        entries.sort(key=lambda uid: (uid not in report.critical_uids,
                     status_rank.get(report.jobs[uid].status.value, 8),
                     report.jobs[uid].scheduler_job_name.casefold()))
    else:
        entries = [(uid, condition) for uid, condition in report.conditions.items()
                   if not condition.supported and matches(uid)]
        entries.sort(key=lambda item: report.jobs[item[0]].scheduler_job_name.casefold())
    page_size = 100
    offset = min(offset, ((len(entries) - 1) // page_size) * page_size) if entries else 0
    return templates.TemplateResponse(request, "partials/blockers_list.html", {
        "session_id": session_id,
        "report": report,
        "view": view,
        "entries": entries[offset:offset + page_size],
        "total": len(entries),
        "offset": offset,
        "page_size": page_size,
    })


@router.get("/api/blockers/path")
def blockers_path(session_id: str, root_uid: str = Query(max_length=500),
                  target_uid: str = Query(max_length=500)):
    """Show an entire causal path on demand; HTML views render only a compact preview."""
    session = _get(session_id)
    if session is None:
        return JSONResponse({"detail": "Analysis expired"}, status_code=404)
    report = session.report
    if root_uid not in report.jobs or target_uid not in report.waits or root_uid not in report.waits[target_uid].root_paths:
        return JSONResponse({"detail": "No verified path for this pair"}, status_code=404)
    nodes = report.path(root_uid, target_uid)
    return {"snapshot_id": session.snapshot_id, "root_uid": root_uid, "target_uid": target_uid,
            "nodes": [{"uid": uid, "job": report.jobs[uid].scheduler_job_name,
                       "status": report.jobs[uid].status.value,
                       "required_condition": report.evidence_for(uid),
                       "evidence_type": ("box_completion_rule" if uid in report.boxes
                                         else "execution_dependency" if uid in report.waits else "root")}
                      for uid in nodes]}
