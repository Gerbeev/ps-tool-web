@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "EXIT_CODE=0"
set "PYTHON_EXE=.venv\Scripts\python.exe"

echo ================================================================
echo PS TOOL - FULL DIAGNOSTICS
echo ================================================================
echo.

if not exist "%PYTHON_EXE%" (
  echo ERROR: Project virtual environment is missing.
  echo Run setup-env.cmd once, then double-click RUN-FULL-DIAGNOSTICS.cmd again.
  set "EXIT_CODE=1"
  goto :finish
)

"%PYTHON_EXE%" -c "import yaml, pydantic" >nul 2>&1
if errorlevel 1 (
  echo ERROR: Project dependencies are incomplete in .venv.
  echo Run setup-env.cmd once, then double-click RUN-FULL-DIAGNOSTICS.cmd again.
  set "EXIT_CODE=1"
  goto :finish
)

"%PYTHON_EXE%" -m scripts.diagnose_all --scope all
set "EXIT_CODE=%ERRORLEVEL%"

:finish
echo.
echo ================================================================
echo [ps-tool-web] Full diagnostics exit code: %EXIT_CODE%
echo ================================================================
pause
endlocal & exit /b %EXIT_CODE%
