"""Shared folder is a persisted, inactive workspace setting."""

from pathlib import Path

import pytest
import yaml
from fastapi.testclient import TestClient

from app import config
from app.main import app


@pytest.fixture
def isolated_config(monkeypatch, tmp_path):
    monkeypatch.setenv("PS_TOOL_CONFIG_DIR", str(tmp_path))
    config.get_settings.cache_clear()
    config.invalidate_environment_cache()
    try:
        yield tmp_path
    finally:
        config.get_settings.cache_clear()
        config.invalidate_environment_cache()


def test_shared_folder_default_without_config_file(isolated_config):
    assert config.load_workspace_settings().shared_folder == config.DEFAULT_SHARED_FOLDER
    assert not (isolated_config / "workspace.yaml").exists()


def test_shipped_default_matches_reference_photo():
    shipped = Path(__file__).resolve().parents[1] / "config" / "workspace.yaml"
    data = yaml.safe_load(shipped.read_text(encoding="utf-8"))
    assert data["shared_folder"] == r"\\ldnroot\data\IBCT\CVA\DEV\_SWAT\gerbeev"


def test_settings_page_shows_escaped_shared_folder_value(isolated_config):
    client = TestClient(app)
    response = client.get("/settings")
    assert response.status_code == 200
    assert 'name="shared_folder"' in response.text
    assert config.DEFAULT_SHARED_FOLDER in response.text
    assert "No network connection is attempted" in response.text


def test_save_shared_folder_round_trips_without_network(isolated_config):
    target = r"\\test-server\data\mydir"
    client = TestClient(app)
    response = client.post("/api/settings/shared-folder", data={"shared_folder": target}, follow_redirects=False)
    assert response.status_code == 303
    assert response.headers["location"] == "/settings?saved=shared_folder#advanced"
    stored = yaml.safe_load((isolated_config / "workspace.yaml").read_text(encoding="utf-8"))
    assert stored["shared_folder"] == target
    assert config.load_workspace_settings().shared_folder == target
    page = client.get("/settings?saved=shared_folder")
    assert "Shared folder saved." in page.text
    assert target in page.text


def test_save_preserves_other_workspace_settings(isolated_config):
    path = isolated_config / "workspace.yaml"
    path.write_text(yaml.safe_dump({"future_setting": {"enabled": True}, "shared_folder": r"\\old\data"}), encoding="utf-8")
    config.save_shared_folder(r"\\new\share\dir")
    assert yaml.safe_load(path.read_text(encoding="utf-8")) == {
        "future_setting": {"enabled": True}, "shared_folder": r"\\new\share\dir",
    }


@pytest.mark.parametrize("value", ["", "relative/path", r"C:\temp", r"\not-unc\share", r"\\server", "\\\\server\\share\\bad\npath", "x" * 1025])
def test_rejects_invalid_path_without_overwriting(isolated_config, value):
    client = TestClient(app)
    assert client.post("/api/settings/shared-folder", data={"shared_folder": r"\\valid\share"}).status_code == 200
    config_path = isolated_config / "workspace.yaml"
    original_bytes = config_path.read_bytes()
    resp = client.post("/api/settings/shared-folder", data={"shared_folder": value})
    assert resp.status_code == 400
    assert config_path.read_bytes() == original_bytes
